
  <style>
  a:hover
  {
    color: white !important;
  }
  .imgsize
  {
   height:500px;
   width:500px;
  }
  </style>

<?php
if(isset($_REQUEST['project_type']))
{
$main_page=$_REQUEST['project_type'];
$page=$_REQUEST['page'];
//echo"$page <br> $main_page";

@include_once 'property/pss_db.php';
@$conn = new DB_con();
@$con = $conn->connection();
									 
				 ?>
     	<!-- Code -->
                    	
							
						
        <div class="wp-section estate">
            <div class="container">
                <div class="row">        
                    <div class="col-md-4">
                       <div class="row">
                            <div class="col-md-12">
                                <div class="product-gallery">
								
                                    <div class="primary-image">
									 <?php
				$res = $conn->get_website_project($con,$main_page,$page);
				$row = mysqli_fetch_array($res)
				?>
                                        <a href="<?php echo $row['image_details_path']; ?>" class="theater" rel="group" hidefocus="true">
                                            <img src="<?php echo $row['image_details_path']; ?>" class="img-responsive" alt="">
                                        </a>
										
                                    </div>
                                    <div class="thumbnail-images">
									<?php
				$res = $conn->get_website_project($con,$main_page,$page);
				while ($row = mysqli_fetch_array($res)) {
				$image_details_id=$row['image_details_id'];
				//echo"$image_details_id";
				 ?>
                <a href="<?php echo $row['image_details_path']; ?>" class="theater" rel="group" hidefocus="true" style="width:50px; height:40px;">
                                            <img src="<?php echo $row['image_details_path']; ?>" alt="" class="imgwdh">
                                        </a>
				<?php }?>
                                    </div>
                                </div>
                            </div>
                       
                        </div>

                       
                    </div>
                        <div class="col-md-5">
                                <div class="product-info">
                                   
                                    <div class="wp-block property list no-border">
                                        <div class="wp-block-content clearfix">
                <?php
				$res = $conn->get_website_project($con,$main_page,$page);
				$row = mysqli_fetch_array($res)
				?>
                                            <h4 class="content-title"><?php echo $row['image_details_title'];?></h4>
                                            <p class="description mb-15"></p>
                                            <?php echo $row['image_details_address']; ?>
                                        </div>
                                        
                                    </div>
                                </div>
                        </div>
                        </div>
                </div>
            </div>
  
 

                           
<?php
}
?>
