<?php

//include_once 'db.php';
session_start();

$page = 1;
include_once '../property/pss_db.php';
$conn = new DB_con();
$con = $conn->connection();
//include_once 'property/function_list.php';
//include_once 'property/default_values.properties';
$functions = new functions();
if(!isset($_SESSION['user']))
{
	header("Location: index.php");
}
else
{
?><?php 	  
if(isset($_REQUEST['jk'])){
	$fu="dfe_fd@><";
    $jl=base64_decode($_REQUEST['jk']);
	$jk=preg_replace(sprintf('/%s/', $fu),'',$jl);
    $get_date=mysqli_query($con,"select distributor_creation_date from distributor_detail where distributor_company_id='$jk'");
    $distributor_date= mysqli_fetch_array($get_date)  ;
	$begin1=$distributor_date['distributor_creation_date'];
$begin = new DateTime("$begin1");
$end = new DateTime();

  for($next_week1 = $begin; $begin <= $end; $next_week1->modify('+14 day'))
{
echo $begin1;
echo $next_week=$next_week1->format("Y-m-d");
}}?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Dashboard</title>
<meta name="description" content="Flatter - Flat Admin Theme">
<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/layout.css">
<link rel="stylesheet" href="css/style3.css">
<script type="text/javascript" src="js/jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.10.4.custom.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/r/bs-3.3.5/jq-2.1.4,dt-1.10.8/datatables.min.css"/>
 
		<script type="text/javascript" src="https://cdn.datatables.net/r/bs-3.3.5/jqc-1.11.3,dt-1.10.8/datatables.min.js"></script>
		  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/1.2.1/css/buttons.dataTables.min.css"/>
 
		<!--<script type="text/javascript" src="https://cdn.datatables.net/r/bs-3.3.5/jqc-1.11.3,dt-1.10.8/datatables.min.js"></script>-->
                 <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.1/js/dataTables.buttons.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.1/js/buttons.flash.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js"></script>
        <script type="text/javascript" src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/pdfmake.min.js"></script>
        <script type="text/javascript" src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/vfs_fonts.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.1/js/buttons.html5.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.1/js/buttons.print.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.1/js/buttons.colVis.min.js"></script>
        <script type="text/javascript" src="js/jquery-easing.js"></script>
		<script src="js/bootstrap-datepicker.js"></script>
        <link rel="stylesheet" href="css/datepicker.css">

		<script type="text/javascript" charset="utf-8">
			$(document).ready(function() {
				$('.example').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'pageLength',
            {
                extend: 'print',
                autoPrint: false,
                title: 'Report',
                exportOptions: {
                    columns: ':visible'
                }
            },{
                extend: 'pdf',
                title: 'Report',
                exportOptions: {
                    columns: ':visible'
                }
            },{
                extend: 'excel',
                title: 'Report',
                exportOptions: {
                    columns: ':visible'
                }
            },{
                extend: 'csv',
                title: 'Report',
                exportOptions: {
                    columns: ':visible'
                }
            },{
                extend: 'copy',
                exportOptions: {
                    columns: ':visible'
                }
            },
            'colvis'
        ]
    },
    {
        dom: 'Bfrtip',
        lengthMenu: [
            [ 10, 25, 50, -1 ],
            [ '10 rows', '25 rows', '50 rows', 'Show all' ]
        ]
      
    },
    {
        dom: 'Bfrtip',
        buttons: [
            {
                extend: 'collection',
                text: 'Table control',
                buttons: [
                    'colvis'
                ]
            }
        ]
    } 
            
                );
			} );
                        
                        
                        
                        
		</script>
                <script type="text/javascript">
	// For demo to fit into DataTables site builder...
	$('.example')
		.removeClass( 'display' )
		.addClass('table table-striped table-bordered');
</script>
</head>
<body id="body">

		<!-- Header -->
		<?php //include './header.php'; ?>

       <?php include './left-menu.php'; ?>
		<!-- Header -->

        <section id="main-wrapper">
		
   
		  
          <?php 
    if(isset($_POST['save'])){
        $payment_type=$_POST['m_payment_type'];
        $no_entries=$_POST['no_entries'];
        $amount=$_POST['amount'];
        $from=$_POST['from'];
        $to=$_POST['to'];
        $i=0;
        $commodity=$_POST['commodity'];
        foreach ($to as $val){
//            echo $val.$from[$i].$amount[$i]."<br>";
            $res=$conn->insert_admin_initial_payment_type($con,$payment_type,$commodity[$i],$amount[$i],$from[$i],$to[$i],$no_entries,$date_time);
            $i++;
        }
    }
     
    
    
                ?>
    
      
		<h3 class="subtitle">Payment Report</h3>
          <hr>
         
          <form method="post" action="#">
		  <div class="row">
                     
	    <div class="col-sm-12">
		
		</div>
		
		<div class="col-sm-4">
		<label>From</label>
		<input type="text" name="from1" id="from1" value="<?php echo $begin1; ?>" class="form-control" required> <br></div>
		<div class="col-sm-4"></div>
		<div class="col-sm-4">
		<label>To</label>
		<input type="text" name="to1" id="to1" value="<?php echo  $next_week; ?>" class="form-control" required> <br></div>
		
		<script type="text/javascript">
            // When the document is ready
            $(document).ready(function () {
                
                $('#from1').datepicker({
                    format: "yyyy-mm-dd"
                });$('#to1').datepicker({
                    format: "yyyy-mm-dd"
                });  
            
            });
        </script>
		<div class="col-sm-12">
		<label>Payment Type</label>
        <select class="form-control" id="m_payment_type" name="type" onchange="change('total');">
            <option value="">Select Payment Type</option>
            <option value="type">Reward Benefit</option>
            <!--option value="type">Coupon Benefit</option>
            <option value="type">Bonanza Benefit</option>
            <option value="type">Direct Benefit</option-->
            <option value="type">Working Group Benefit</option>
        </select><br><hr></div>
              
<script>
     function change(type){
var from1 = document.getElementById("from1").value;
var to1 = document.getElementById("to1").value;		  
		   $("#all").load("payee1.php",{"type":type,"from":from1,"to":to1})
            
        }
//        $.blockUI();
//        $(document).ready(function(){
//            $.unblockUI();
//        });

var $loading = $('.loading').hide();
$(document)
  .ajaxStart(function () {
    $loading.show();
    $("#all").css("opacity","0");
    $.blockUI({ message: '' });
  })
  .ajaxStop(function () {
    $loading.hide();
     $("#all").css("opacity","1");
     $.unblockUI();
  });

</script>   
	   <div id="all"> </div>
         
       </section>


<!--<script type="text/javascript" src="js/bootstrap.min.js"></script>-->
<script type="text/javascript" src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<div class="offline-ui offline-ui-up"><div class="offline-ui-content"></div><a href="" class="offline-ui-retry"></a>
</div>
</body>
</html>
<?php
} 
?>