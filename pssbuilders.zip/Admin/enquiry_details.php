<?php
session_start();
if(!isset($_SESSION['user']))
{
	header("Location: index.php");
}
else
{
?>
<!DOCTYPE html>
<!-- saved from url=(0038)http://flatter.cloudtub.com/index.html -->
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Dashboard</title>
<meta name="description" content="Flatter - Flat Admin Theme">
<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/layout.css">
<link rel="stylesheet" href="css/style3.css">
<script type="text/javascript" src="js/jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.10.4.custom.min.js"></script>
<style>
.imgsize
{
	height:30px; 
	width:30px;
}
</style>

</head>
<body id="body">

		<!-- Header -->
		<?php include './header.php'; ?>

       <?php include './left-menu.php'; ?>
		<!-- Header -->
		
<section id="main-wrapper">
		<h3 class="subtitle">Enquiry Details</h3>
          <hr>

		  <div class="row">
			  <div class="col-md-12">
				  	<div class="panel panel-default">
					  <div class="panel-heading">
					    <h3 class="panel-title"><strong>Enquiry Details</strong></h3> 
					  </div>

					  <div class="panel-body">
					  		<table cellpadding="0" cellspacing="0" border="0"
					  		class="table table-striped table-bordered editable-datatable">
									<thead>
									<tr>
									    <th>Name</th>
										<th>Phone</th>
										<th>Email</th>
										<th>City</th>
										<th>Max Price</th>
										<th>Min Price</th>
										<th>Action</th>
									</tr>
								</thead>
								<tbody>
								<?php
				 $res = $conn->get_admin_website_enquiry_details($con);
				 while ($row = mysqli_fetch_array($res)) {
				 $property_enquiry_id=$row['property_enquiry_id'];
				 ?>
									<tr class="1">
										
										<td><?php echo $row['property_enquiry_name']; ?></td>
										<td><?php echo $row['property_enquiry_phone']; ?></td>
										<td><?php echo $row['property_enquiry_email']; ?></td>
										<td><?php echo $row['property_enquiry_city']; ?></td>
										<td><?php echo $row['property_enquiry_max_price']; ?></td>
										<td><?php echo $row['property_enquiry_min_price']; ?></td>
	<td><a class="delete" href="delete_property_enquiry_details.php?property_enquiry_id=<?php echo"$property_enquiry_id"; ?>">Delete</a></td>
									</tr>
				<?php }?>					
								</tbody>

								</table>

					  </div>
					</div>
				</div>
				
</div>

</section>


<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<div class="offline-ui offline-ui-up"><div class="offline-ui-content"></div><a href="" class="offline-ui-retry"></a>
</div>
</body>
</html>
<?php
 } 
?>