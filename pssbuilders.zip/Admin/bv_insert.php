
<?php 
$user_id3=$_SESSION['user'];
$page = 1;
include_once '../property/pss_db.php';
$conn = new DB_con();
$con = $conn->connection();
//include_once 'property/function_list.php';
//include_once 'property/default_values.properties';
$functions = new functions();
$sql2=  mysqli_query($con, "select distributor_direct_distributor_id from distributor_detail where distributor_id='$user_id'");
 $sqll=  mysqli_fetch_assoc($sql2);		
$_REQUEST1['type']='total';
    $user_name=$conn->get_admin_login_name($con,$user_id3);
    $id=$conn->get_admin_dis_id($con,$user_name);
//    $id=1;
    
     function add_array($id,$con,$childs){
                   $count_left=array();
                   $count_right=array();
                    $i=0;
				
                    $query=mysqli_query($con,"select * from tree where parent_id='$id' order by position");
                    while( $rr=mysqli_fetch_array($query)){
                      $pp[$i]=$rr;
                      $i++;
                  }
                  if($i==2){
                      if($pp[0][1]!='blank'){
                          array_push($childs, $pp[0][0]);
                       $count_left=add_array($pp[0][0],$con,$childs);  
                      }else{
                          $count_left=['0'];
                      }
                      if($pp[1][1]!='blank'){
                          array_push($childs, $pp[1][0]);
                           $count_right=add_array($pp[1][0],$con,$childs); 
                      }else{
                          $count_right=['0'];
                      }
//                      print_r($childs);
//                      print_r($count_right);
//                      print_r($count_left);
                      $childs=  array_merge($count_right,$count_left);
//                       print_r($childs);
//                      echo "<br>";
                      return $childs;
                  }if($i==0){
                   return $childs;   
                  }
                }
                $childs=array();
    $all_childs=array();
    
     $query=mysqli_query($con,"select * from tree where parent_id='$id' order by position");
       while( $rr=  mysqli_fetch_array($query)){
          
           $idd=$rr['id'];
           $pos=$rr['position'];
            if($_REQUEST1['type']=='total'){
          array_push($all_childs,$idd);
           $all_childs=  array_merge($all_childs,add_array($idd,$con,$childs));
//           echo $idd ."<br>";
//           print_r($all_childs);
           }if($_REQUEST1['type']=='right' && $pos=='right'){
                array_push($all_childs,$idd);
           $all_childs=  array_merge($all_childs,add_array($idd,$con,$childs));
              
           }if($_REQUEST1['type']=='left' && $pos=='left'){
               array_push($all_childs,$idd);
           $all_childs=  array_merge($all_childs,add_array($idd,$con,$childs)); 
           }
           
           
       }
    
    
//    $all_childs= add_array($id,$con,$childs);
    $all_childs=  array_unique($all_childs);
//    $all_childs= array_pop();
//    print_r($all_childs);
    $all=array();
foreach($all_childs as $vv){
    if($vv!=0){
        array_push($all, $vv);
    }
}


function countt($id,$con){
                    $i=0;
                    $query=mysqli_query($con,"select * from tree where parent_id='$id' order by position");
                    while( $rr=  mysqli_fetch_array($query)){
                      
                      $pp[$i]=$rr;
                      $i++;
                  }
                  if($i==2){
                      if($pp[0][1]!='blank'){
                       $count_left=countt($pp[0][0],$con);   
                       $count_left++;
//                       echo $connt_left;
                      }else {
                          $count_left=0;                          
                      }
                      if($pp[1][1]!='blank'){
                           $count_right=countt($pp[1][0],$con); 
                           $count_right++;
                      }else{
                          $count_right=0;    
                      }
                     $counttt= $count_left+$count_right;
                     return $counttt;
                  }if($i==0){
                   return 0;   
                  }
                }
				
				function countbv($id,$con){
                    $i=0;
                    $query=mysqli_query($con,"select * from tree where parent_id='$id' order by position");
                    while( $rr=  mysqli_fetch_array($query)){
                      
                      $pp[$i]=$rr;
                      $i++;
                  }
                  if($i==2){
                      if($pp[0][1]!='blank'){
                       $count_left_bv=countbv($pp[0][0],$con); 
                       $user_left_idd=$pp[0][0];
                       $sql=  mysqli_query($con, "select distributor_bv from distributor_detail where distributor_id='$user_left_idd'");
                       $rowss=  mysqli_fetch_array($sql);
                       $count_left_bv=$count_left_bv+$rowss['distributor_bv'];
//                       echo $connt_left;
                      }else {
                          $count_left_bv=0;                          
                      }
                      if($pp[1][1]!='blank'){
                           $count_right_bv=countbv($pp[1][0],$con); 
                            $user_right_idd=$pp[1][0];
                       $sql=  mysqli_query($con, "select distributor_bv from distributor_detail where distributor_id='$user_right_idd'");
                       $rowss=  mysqli_fetch_array($sql);
                           $count_right_bv=$count_right_bv+$rowss['distributor_bv'];
                      }else{
                          $count_right_bv=0;    
                      }
                     $counttt= $count_right_bv+$count_left_bv;
                     return $counttt;
                  }if($i==0){
                   return 0;   
                  }
                }

//print_r($all);
?>


		<?php 
		
		
		
		
		
		
		?>
<?php
$ii=0;
foreach($all as $vv){
    $query=mysqli_query($con,"select * from distributor_detail where distributor_id='$vv'");
    $row=  mysqli_fetch_array($query);
    $iddd=$row['distributor_distributor_id'];
//    echo $iddd;
   $res=$conn->get_admin_distributor_detail_by_cmpny_id($con,$iddd);
//   echo $res;
   $rows=mysqli_fetch_array($res);
   $sponsor_name=$rows['distributor_name'];
   $res=$conn->get_admin_distributor_detail_by_cmpny_id($con,$row['distributor_direct_distributor_id']);
   $rows=  mysqli_fetch_array($res);
   $direct_sponsor_name=$rows['distributor_name'];
   
   
   $left=mysqli_query($con,"select * from tree where parent_id = '$row[distributor_id]' order by position");
                   
                  $pp=array();
                  $i=0;
                  $count_left=0;
                  $count_right=0;
                  while( $rr=  mysqli_fetch_array($left)){
                     
                      $pp[$i]=$rr;
                       $i++;
                  }
                  if($i==2){
                      if($pp[0][1]!='blank'){
                          $id=$pp[0][0];
                       $count_left=countt($id,$con); 
                       $count_left++;
                      }else {
                          $count_left=0;                          
                      }
                      if($pp[1][1]!='blank'){
                          $idd=$pp[1][0];
                         $count_right=countt($idd,$con); 
                         $count_right++;
                      }else {
                          $count_right=0;                          
                      }
                  }
				  $count_left_bv=0;
                  $count_right_bv=0;
                  
                  if($i==2){
                      if($pp[0][1]!='blank'){
                       $count_left_bv=countbv($pp[0][0],$con); 
                       $user_left_idd=$pp[0][0];
                       $sql=  mysqli_query($con, "select distributor_bv from distributor_detail where distributor_id='$user_left_idd'");
                       $rowss=  mysqli_fetch_array($sql);
                       $count_left_bv=$count_left_bv+$rowss['distributor_bv'];
//                       echo $connt_left;
                      }else {
                          $count_left_bv=0;                          
                      }
                      if($pp[1][1]!='blank'){
                           $count_right_bv=countbv($pp[1][0],$con); 
                            $user_right_idd=$pp[1][0];
                       $sql=  mysqli_query($con, "select distributor_bv from distributor_detail where distributor_id='$user_right_idd'");
                       $rowss=  mysqli_fetch_array($sql);
                           $count_right_bv=$count_right_bv+$rowss['distributor_bv'];
                      }else{
                          $count_right_bv=0;    
                      }
//                     $counttt= $count_right_bv+$count_left_bv;
//                     return $counttt;
                  }
				  

 
    if($row['distributor_direct_distributor_id']==$sqll['distributor_direct_distributor_id']){
$query1="insert into date_wise_user_bv(distributor_company_id,distributor_name,count_left_bv,count_right_bv) values('$row[distributor_company_id]','$row[distributor_name]','$count_left_bv','$count_right_bv')";
   $sql=  mysqli_query($con, "$query1");
   if($sql){
	   echo "<script>$(document).ready(function(){ $('#msg_su').html('<strong>Success!</strong> B.V. Added'); });</script>";
                                
   }
   }
}

?></table></div>

</div>