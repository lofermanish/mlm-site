<?php
session_start();
if(!isset($_SESSION['user']))
{
	header("Location: index.php");
}
else
{
?>
<!DOCTYPE html>
<!-- saved from url=(0038)http://flatter.cloudtub.com/index.html -->
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Dashboard</title>
<meta name="description" content="Flatter - Flat Admin Theme">
<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/layout.css">
<link rel="stylesheet" href="css/style3.css">
<script type="text/javascript" src="js/jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.10.4.custom.min.js"></script>
<style>
.imgsize
{
	height:30px; 
	width:30px;
}
</style>
</head>
<body id="body">

		<!-- Header -->
		<?php include './header.php'; ?>

       <?php include './left-menu.php'; ?>
		<!-- Header -->
                
                
                
                
                
<section id="main-wrapper">
    <?php 
                $p=0;
                $q=0;
                if(isset($_POST['cr_login'])){
                    $dis_id=$_POST['dis_id'];
                    $user_name=$_POST['user_name'];
                    $password=$_POST['user_password'];
                    $con_pass=$_POST['user_cpassword'];
                    $crr_user=$_SESSION['user'];
                    if($dis_id!=""){
                        if($user_name==$dis_id){
                            if($password==$con_pass){
                                $password=  md5($password);
                                $res=$conn->insert_admin_login($con,$user_name,$password,$crr_user,$date_time);
                                if($res){ $p++;
                                   echo "<script>$(document).ready(function(){ $('#msg_su').html('<strong>Success!</strong> Login Created Successfully'); });</script>";
                                }else{ $q++;
                                    echo "<script>$(document).ready(function(){ $('#msg').html('<strong>Error! </strong>Login already Exist.'); });</script>";
                                }
                            }else{ $q++;
                                echo "<script>$(document).ready(function(){ $('#msg').html('<strong>Error!</strong> password and confirm password does not matched'); });</script>";
                            }
                        }else{ $q++;
                            echo "<script>$(document).ready(function(){ $('#msg').html('<strong>Error!</strong> You did something fishy'); });</script>";
                        }
                    }else{ $q++;
                        echo "<script>$(document).ready(function(){ $('#msg').html('<strong>Error!</strong> Please select distributor.'); });</script>";
                    }
                }
                ?>
                <?php 
                 $u_p=0;
                $u_q=0;
                if(isset($_POST['u_cr_login'])){
                    $dis_id=$_POST['u_dis_id'];
                    $user_name=$_POST['u_user_name'];
                    $password=$_POST['u_user_password'];
                    $con_pass=$_POST['u_user_cpassword'];
                    $crr_user=$_SESSION['user'];
                    if($dis_id!=""){
                        if($user_name==$dis_id){
                            if($password==$con_pass){
                                $password=  md5($password);
                                $res=$conn->update_admin_login($con,$user_name,$password);
                                if($res){ $u_p++;
                                   echo "<script>$(document).ready(function(){ $('#u_msg_su').html('<strong>Success!</strong> Password Updated Successfully'); });</script>";
                                }else{ $u_q++;
                                    echo "<script>$(document).ready(function(){ $('#u_msg').html('<strong>Error! </strong>Login already Exist.'); });</script>";
                                }
                            }else{ $u_q++;
                                echo "<script>$(document).ready(function(){ $('#u_msg').html('<strong>Error!</strong> password and confirm password does not matched'); });</script>";
                            }
                        }else{ $u_q++;
                            echo "<script>$(document).ready(function(){ $('#u_msg').html('<strong>Error!</strong> You did something fishy'); });</script>";
                        }
                    }else{ $u_q++;
                        echo "<script>$(document).ready(function(){ $('#u_msg').html('<strong>Error!</strong> Please select distributor.'); });</script>";
                    }
                }
                ?>
    
    
    
    
    <script>
    $(document).ready(function(){
        $('#dis_id').change(function(){
           id=$('#dis_id').val();
           if(id!=""){
           var ids={id:id};
           $.ajax({
               type: "Post",
               url: "get-data.php",
               data: ids,
               success : function(dat){
                   var obj= $.parseJSON(dat);
                   $.each(obj, function(){
                       $("#user_name").val(this['comp_id']);
                   });
               }
           });
       }else{
            $("#user_name").val("");
       }
        });
    });
    
     $(document).ready(function(){
        $('#fff').submit(function(event){
            data=$("#con_pass").text();
            if(data!="OK"){
                event.preventDefault();
            }
        });
    });
    
    
    function match(){
        pass=$('#user_password').val();
        cpass=$('#user_cpassword').val();
        if(pass!=cpass){
            $('#con_pass').text("password and confirm password does not match");
            $('#con_pass').css("color","red");
        }else{
            $('#con_pass').text("OK");
             $('#con_pass').css("color","green");
        }
    }
    </script>
    
    
     <script>
    $(document).ready(function(){
        $('#u_dis_id').change(function(){
           id=$('#u_dis_id').val();
           if(id!=""){
           var ids={id:id};
           $.ajax({
               type: "Post",
               url: "get-data.php",
               data: ids,
               success : function(dat){
                   var obj= $.parseJSON(dat);
                   $.each(obj, function(){
                       $("#u_user_name").val(this['comp_id']);
                   });
               }
           });
       }else{
            $("#u_user_name").val("");
       }
        });
    });
    
     $(document).ready(function(){
        $('#ff').submit(function(event){
            data=$("#u_con_pass").text();
            if(data!="OK"){
                event.preventDefault();
            }
        });
    });
    
    
    function matchh(){
        pass=$('#u_user_password').val();
        cpass=$('#u_user_cpassword').val();
        if(pass!=cpass){
            $('#u_con_pass').text("password and confirm password does not match");
            $('#u_con_pass').css("color","red");
        }else{
            $('#u_con_pass').text("OK");
             $('#u_con_pass').css("color","green");
        }
    }
	
	
	function comp_id(data)
	{
	 document.getElementById("user_name").value = data.value ;	
	}
	
	function comp_id2(data)
	{
	 document.getElementById("u_user_name").value = data.value ;	
	}
    </script>
    
    
    
      <?php if(isset($_POST['cr_login'])){ if($q>0){ ?>
       <div class="alert alert-danger" id="msg">
  
       </div><?php } if($p>0){ ?>
            <div class="alert alert-success" id="msg_su">
  
       </div>
       <?php } } ?>
    <?php if(isset($_POST['cr_login'])){ if($u_q>0){ ?>
       <div class="alert alert-danger" id="u_msg">
  
       </div><?php } if($u_p>0){ ?>
            <div class="alert alert-success" id="u_msg_su">
  
       </div>
       <?php } } ?>
		<h3 class="subtitle">Create Login</h3>
          <hr>

		  <div class="row">
			  <div class="col-md-12">
                              <form action="#" method="post" id="fff">
                                  
                              <div class="col-md-6" style="margin-top:15px;margin-bottom:5px;"> <label>Distributor</label><select class="form-control" name="dis_id" id="dis_id" onchange="comp_id(this);">
                                      <option value="">Select Distributor</option>
                                      <?php 
                                       $res = $conn->get_admin_distributors($con);
                                       while($row=mysqli_fetch_array($res)){
                                      ?>
                                      <option value="<?php echo $row['distributor_company_id'] ?>"><?php echo $row['distributor_name']; ?></option>
                                       <?php } ?>
                                  </select>
                              </div>
                              <div class="col-md-6" style="margin-top:15px;margin-bottom:5px;"><label>User Name</label><input type="text" name="user_name" class="form-control" id="user_name" placeholder="User Name" readonly>
                              </div>
                              <div class="col-md-6" style="margin-top:15px;margin-bottom:5px;"><label>Password</label><input type="password" name="user_password" class="form-control" id="user_password" placeholder="Password" >
                              </div>
                                  <div class="col-md-6" style="margin-top:15px;margin-bottom:5px;"><label>Confirm Password </label><span id="con_pass" style="float:right;"></span><input type="password" name="user_cpassword" class="form-control" id="user_cpassword" placeholder="Confirm Password" onkeyup="match()" >
                              </div>
                                  <div class="col-md-12" style="margin-top:15px;margin-bottom:5px;">
                                      <input type="submit" name="cr_login"  value="Create" class="btn btn-success" style="float:right">
                                  </div>
                                  
                              </form>	
                          </div>
				
</div>
          
          <h3>Reset Login</h3><hr>
          
          <div class="row">
			  <div class="col-md-12">
                              <form action="#" method="post" id="ff">
                                  
                              <div class="col-md-6" style="margin-top:15px;margin-bottom:5px;"> <label>Distributor</label><select class="form-control" name="u_dis_id" id="u_dis_id" onchange="comp_id2(this);">
                                      <option value="">Select Distributor</option>
                                      <?php 
                                       $res = $conn->get_admin_distributors($con);
                                       while($row=mysqli_fetch_array($res)){
                                      ?>
                                      <option value="<?php echo $row['distributor_company_id'] ?>"><?php echo $row['distributor_name']; ?></option>
                                       <?php } ?>
                                  </select>
                              </div>
                              <div class="col-md-6" style="margin-top:15px;margin-bottom:5px;"><label>User Name</label><input type="text" name="u_user_name" class="form-control" id="u_user_name" placeholder="User Name" readonly>
                              </div>
                              <div class="col-md-6" style="margin-top:15px;margin-bottom:5px;"><label>Password</label><input type="password" name="u_user_password" class="form-control" id="u_user_password" placeholder="Password" >
                              </div>
                                  <div class="col-md-6" style="margin-top:15px;margin-bottom:5px;"><label>Confirm Password </label><span id="u_con_pass" style="float:right;"></span><input type="password" name="u_user_cpassword" class="form-control" id="u_user_cpassword" placeholder="Confirm Password" onkeyup="matchh()" >
                              </div>
                                  <div class="col-md-12" style="margin-top:15px;margin-bottom:5px;">
                                      <input type="submit" name="u_cr_login"  value="Reset" class="btn btn-success" style="float:right">
                                  </div>
                                  
                              </form>	
                          </div>
				
</div>
          
          

</section>


<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<div class="offline-ui offline-ui-up"><div class="offline-ui-content"></div><a href="" class="offline-ui-retry"></a>
</div>
</body>
</html>
<?php
 } 
?>