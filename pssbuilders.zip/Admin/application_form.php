<?php
session_start();
//include_once 'db.php';

if(!isset($_SESSION['user']))
{
	header("Location: index.php");
}
else
{
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Dashboard</title>
<meta name="description" content="Flatter - Flat Admin Theme">
<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/layout.css">
<link rel="stylesheet" href="css/style3.css">
<script type="text/javascript" src="js/jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.10.4.custom.min.js"></script>
<link rel="stylesheet" href="css/library.css">
<link rel="stylesheet" href="css/layout.css">
<link rel="stylesheet" href="css/style-wizard.css">
<script src="js/bootstrap-datepicker.js"></script>
 <link rel="stylesheet" href="css/datepicker.css">
</head>
<body id="body">

		<!-- Header -->
		<?php include './header.php'; ?>

       <?php include './left-menu.php'; ?>
		<!-- Header -->
<style type="text/css">
.stepwizard-step p {
	margin-top: 10px;
}
.stepwizard-row {
	display: table-row;
}
.stepwizard {
	display: table;
	width: 50%;
	position: relative;
}
.stepwizard-step button[disabled] {
	opacity: 1 !important;
	filter: alpha(opacity=100) !important;
}
.stepwizard-row:before {
	top: 14px;
	bottom: 0;
	position: absolute;
	content: " ";
	width: 100%;
	height: 1px;
	background-color: #ccc;
	z-order: 0;
}
.stepwizard-step {
	display: table-cell;
	text-align: center;
	position: relative;
}
.btn-circle {
	width: 30px;
	height: 30px;
	text-align: center;
	padding: 6px 0;
	font-size: 12px;
	line-height: 1.428571429;
	border-radius: 15px;
}
</style>
        <?php $res="";
        if(isset($_POST['app_submit'])){
        $app_name=$_POST['app_name'];
        $app_s_of=$_POST['app_s_of'];
        $app_dob=$_POST['app_dob'];
        $app_nationality=$_POST['app_nationality'];
        $app_address=$_POST['app_address'];
        $app_pin=$_POST['app_pin'];
        $app_tel=$_POST['app_tel'];
        $app_fax=$_POST['app_fax'];
        $app_email=$_POST['app_email'];
        
        $app_mob_no=$_POST['app_mob_no'];
        $app_qualification=$_POST['app_qualification'];
        $app_business=$_POST['app_business'];
        $app_emp_name=$_POST['app_emp_name'];
        $app_buss_no=$_POST['app_buss_no'];
        $app_annual_inc=$_POST['app_annual_inc'];
        $app_scnd_name=$_POST['app_scnd_name'];
        $app_scnd_s_of=$_POST['app_scnd_s_of'];
        $app_scnd_dob=$_POST['app_scnd_dob'];
        $app_scnd_nationality=$_POST['app_scnd_nationality'];
        $app_scnd_pin=$_POST['app_scnd_pin'];
        $app_scnd_tel=$_POST['app_scnd_tel'];
        $app_scnd_add=$_POST['app_scnd_add'];
        $app_scnd_fax=$_POST['app_scnd_fax'];
        $app_scnd_email=$_POST['app_scnd_email'];
        $app_scnd_mob_no=$_POST['app_scnd_mob_no'];
        $residedent=$_POST['residedent'];
        $payment=$_POST['payment'];
        $app_prop_type=$_POST['app_prop_type'];
        $app_sector=$_POST['app_sector'];
        $app_pocket=$_POST['app_pocket'];
        $app_unit=$_POST['app_unit'];
        $app_floor=$_POST['app_floor'];
        $app_res_area=$_POST['app_res_area'];
        $app_base_rate=$_POST['app_base_rate'];
        $app_basic_sale_price=$_POST['app_basic_sale_price'];
        if(isset($_POST['parking'])){
        $parking=$_POST['parking'];}else{$parking="";}
        if(isset($_POST['storage'])){
        $storage=$_POST['storage'];}else{$storage="";}
        if(isset($_POST['club'])){
        $club=$_POST['club'];}else{$club="";}
        $app_pan_no=$_POST['app_pan_no'];
        $app_agent_name=$_POST['app_agent_name'];
        $app_agent_ph=$_POST['app_agent_ph'];
        $login_id=$_SESSION['user'];
        $app_fund_detail=$_POST['app_fund_detail'];
		$random=rand(100001,999999);
        $applicant_detail_username="cpss".$random;
		
//        $app_photo=$_POST['app_photo'];
         move_uploaded_file($_FILES['app_photo']['tmp_name'],"../image_uploads/".$_FILES['app_photo']['name']);
	$file="../image_uploads/".$_FILES['app_photo']['name'];

if($_FILES['app_photo']!=""){
$dis_image_path=$file;
    
}else{
    $dis_image_path="";
}
        $p=0;
        
        $res=$conn->insert_admint_applicant_detail($con,$app_name,$app_s_of,$app_dob,$app_nationality,$app_address,$app_pin,$app_tel,$app_fax,$app_email,$dis_image_path,
                $app_mob_no,$app_qualification,$app_business,$app_emp_name,$app_buss_no,$app_annual_inc,$app_fund_detail,$app_scnd_name,$app_scnd_s_of,$app_scnd_dob,$app_scnd_nationality,
                $app_scnd_pin,$app_scnd_tel,$app_scnd_add,$app_scnd_fax,$app_scnd_email,$app_scnd_mob_no,$residedent,$payment,$app_prop_type,
                $app_sector,$app_pocket,$app_unit,$app_floor,$app_res_area,$app_base_rate,$app_basic_sale_price,$parking,$storage,$club,$app_pan_no,
                $app_agent_name,$app_agent_ph,$login_id,$date_time,$applicant_detail_username,$app_dob);
        if($res){
            $p++;
        }
        }
 
        ?>
        <section id="main-wrapper">
             <?php 
            if(isset($p) && $p>0){
            
                echo 'success';
            }if(isset($p) && $p<1){
                echo "fail";
            }
            echo $res;
            ?>
		<h3 class="subtitle">Dashboard</h3>
          <hr>
          <div class="row" style=" margin-left:20px; ">
		  
		<?php
			//  include './app-form.php'; ?> 
              
               <div class="stepwizard col-md-offset-3">
    <div class="stepwizard-row setup-panel">
          <div class="stepwizard-step">
        <a href="#step-1" type="button" class="btn btn-primary btn-circle">1</a>
        <p>Step 1</p>
      </div>
          <div class="stepwizard-step">
        <a href="#step-2" type="button" class="btn btn-default btn-circle" disabled="disabled">2</a>
        <p>Step 2</p>
      </div>
          <div class="stepwizard-step">
        <a href="#step-3" type="button" class="btn btn-default btn-circle" disabled="disabled">3</a>
        <p>Step 3</p>
      </div>
         <div class="stepwizard-step">
        <a href="#step-4" type="button" class="btn btn-default btn-circle" disabled="disabled">4</a>
        <p>Step 4</p>
      </div>
         <div class="stepwizard-step">
        <a href="#step-5" type="button" class="btn btn-default btn-circle" disabled="disabled">5</a>
        <p>Step 5</p>
      </div>
         
        </div>
  </div>
      <form role="form" action="#" method="post" enctype="multipart/form-data">
    <div class="row setup-content" id="step-1">
          <div class="col-xs-12">
        <div class="col-md-12">
              <h4> My/Our Particular as mentioned below may be recorded for reference and communication</h4>
              <div class="col-md-6 form-group">
            <label class="control-label">Applicant (sole/first)</label>
            <input  type="text"  class="form-control" placeholder="Applicant Name" id="app_name" name="app_name" />
          </div>
               <div class="col-md-6 form-group">
            <label class="control-label">S/WD/of</label>
            <input  type="text"  class="form-control" placeholder="S/W/D of" id="app_s_of" name="app_s_of" />
          </div>
              <div class="col-md-6 form-group">
            <label class="control-label">Date of Birth</label>
            
			<input type="text" class="form-control" placeholder="Date of Birth" name="app_dob"  id="example1" required>
          </div>
		  <script type="text/javascript">
            // When the document is ready
            $(document).ready(function () {
                
                $('#example1').datepicker({
                    format: "yyyy-mm-dd"
                });  
            });
        </script>
		 
               <div class="col-md-6 form-group">
            <label class="control-label">Nationality</label>
            <input type="text"  class="form-control" placeholder="Nationality" id="app_nationality" name="app_nationality" />
          </div>
              <div class="col-md-6 form-group">
            <label class="control-label">Address (for communication)</label>
            <input  type="text"  class="form-control" placeholder="Address" id="app_address" name="app_address" />
          </div>
               <div class="col-md-6 form-group">
            <label class="control-label">Pincode</label>
            <input  type="text"  class="form-control" placeholder="Pincode" id="app_pin" name="app_pin" />
          </div>
              <div class="col-md-6 form-group">
            <label class="control-label">Telephone No.</label>
            <input type="text"  class="form-control" placeholder="Telephone No." id="app_tel" name="app_tel" />
          </div>
               <div class="col-md-6 form-group">
            <label class="control-label">Fax No.</label>
            <input type="text"  class="form-control" placeholder="Fax No." id="app_fax" name="app_fax"/>
          </div>
              <div class="col-md-6 form-group">
            <label class="control-label">Email</label>
            <input  type="text"  class="form-control" placeholder="Email" id="app_email" name="app_email" />
          </div>
              <div class="col-md-6 form-group">
            <label class="control-label">Upload Picture</label>
            <input type="file" class="form-control" style="border: none;" id="app_photo" name="app_photo">
            <!--<input type="text"  class="form-control" placeholder="Enter Last Name" />-->
          </div>
           
             <div class="col-md-6 form-group">
            <label class="control-label">Mobile No.</label>
            <input  type="text"  class="form-control" placeholder="Mobile No." id="app_mob_no" name="app_mob_no" />
          </div>
              <div class="col-md-12 form-group">
                  <label class="control-label"><b>Personal Details</b></label><hr>
          </div>
              <div class="col-md-6 form-group">
            <label class="control-label">Qualification</label>
            <input  type="text"  class="form-control" placeholder="Qualification" id="app_qualification" name="app_qualification" />
          </div>
               <div class="col-md-6 form-group">
            <label class="control-label">Occupation/Business</label>
            <input type="text"  class="form-control" placeholder="Occupation/Business" id="app_business" name="app_business" />
          </div>
              <div class="col-md-6 form-group">
            <label class="control-label">Name of employer</label>
            <input type="text"  class="form-control" placeholder="Name of employer" id="app_emp_name" name="app_emp_name" />
          </div>              
               <div class="col-md-6 form-group">
            <label class="control-label">Business contact No. </label>
            <input type="text"  class="form-control" placeholder="Business contact No." id="app_buss_no" name="app_buss_no" />
          </div>
              <div class="col-md-6 form-group">
            <label class="control-label">Annual income</label>
            <input  type="text"  class="form-control" placeholder="Annual income" id="app_annual_inc" name="app_annual_inc" />
          </div>
             
              
              
              <div class="col-md-6 form-group" style="text-align: right"> <br>
             <button class="btn btn-primary nextBtn  pull-right" type="button" >Next</button>
          </div>
              
         
              
            
            </div>
      </div>
        </div>
    <div class="row setup-content" id="step-2">
          <div class="col-xs-12">
        <div class="col-md-12">
              <h3> Funding Details </h3>
                 <div class="col-md-12 form-group">
                     <label class="control-label" style="text-align: left;">The Purchase consideration shall be paid out of :<br> Own Source/Saving/Investments Financing from Banks/Financial Institute Quantum of loan to be raised Rs. :</label>
            <input  type="text"  class="form-control" placeholder="Rs" id="app_fund_detail" name="app_fund_detail" />
          </div>
              <div class="col-md-6 form-group">
            <label class="control-label">Second Application Name</label>
            <input type="text"  class="form-control" placeholder="Second Application Name" id="app_scnd_name" name="app_scnd_name" />
          </div>
               <div class="col-md-6 form-group">
            <label class="control-label">S/WD/of </label>
<!--            <input id="" type="file" class="form-control" style="border: none;">-->
            <input type="text"  class="form-control" placeholder="S/WD/of" id="app_scnd_s_of" name="app_scnd_s_of" />
          </div>
              <div class="col-md-6 form-group">
            <label class="control-label">Date of Birth</label>
		  <input type="text" class="form-control" placeholder="Date of Birth" name="app_scnd_dob"  id="example2" required>
          </div>
		  <script type="text/javascript">
            // When the document is ready
            $(document).ready(function () {
                
                $('#example2').datepicker({
                    format: "yyyy-mm-dd"
                });  
            });
        </script>

              <div class="col-md-6 form-group">
            <label class="control-label">Nationality</label>
            <input  type="text"  class="form-control" placeholder="Nationality" id="app_scnd_nationality" name="app_scnd_nationality" />
          </div>
               <div class="col-md-6 form-group">
            <label class="control-label">Pincode</label>
            <input  type="text"  class="form-control" placeholder="Pincode" id="app_scnd_pin" name="app_scnd_pin" />
          </div>
              <div class="col-md-6 form-group">
            <label class="control-label">Telephone No.</label>
            <input type="text"  class="form-control" placeholder="Telephone No." id="app_scnd_tel" name="app_scnd_tel"/>
          </div>
              <div class="col-md-6 form-group">
            <label class="control-label">Local Address(Any)</label>
            <input type="text"  class="form-control" placeholder="Local Address(Any)" id="app_scnd_add " name="app_scnd_add"/>
          </div>
              <div class="col-md-6 form-group">
            <label class="control-label">Fax No.</label>
            <input type="text"  class="form-control" placeholder="Fax No." id="app_scnd_fax" name="app_scnd_fax" />
          </div>
              <div class="col-md-6 form-group">
            <label class="control-label">Email</label>
            <input  type="email"  class="form-control" placeholder="Email" id="app_scnd_email" name="app_scnd_email" />
          </div>
             
              
              <div class="col-md-6 form-group">
            <label class="control-label">Mobile No.</label>
            <input  type="text"  class="form-control" placeholder="Mobile No." id="app_scnd_mob_no" name="app_scnd_mob_no" />
          </div>
              
              
              
              <div class="col-md-12 form-group" style="text-align: right"> <br>
             <button class="btn btn-primary nextBtn  pull-right" type="button" >Next</button>
          </div>
            </div>
      </div>
        </div>
          <div class="row setup-content" id="step-3">
          <div class="col-xs-12">
        <div class="col-md-12">
            <h3>Residential Status</h3><hr>
                 <div class="col-md-6 form-group">
                     <label class="control-label" style="text-align: left;">Residential Indian: 
                         <input  type="radio" name="residedent" id="app_resident" value="Residential Indian" /></label>
          </div>
              <div class="col-md-6 form-group">
            <label class="control-label">Non Residential India: 
                <input type="radio" name="residedent" id="app_resident" value="Non Residential India" /></label>
          </div>
            <h3> Payment Plan </h3><hr>
                 <div class="col-md-6 form-group">
                     <label class="control-label" style="text-align: left;">Down Payment: <input  type="radio" name="payment" value="Down Payment" /></label>
          </div>
              <div class="col-md-6 form-group">
                  <label class="control-label">Installment: <input type="radio" name="payment" id="app_installment" value="Installment" /></label>
          </div>
              
              
              <div class="col-md-12 form-group" style="text-align: right"> <br>
             <button class="btn btn-primary nextBtn  pull-right" type="button" >Next</button>
          </div>
            </div>
      </div>
        </div>
          
          <div class="row setup-content" id="step-4">
          <div class="col-xs-12">
        <div class="col-md-12">
              <h3> Detail Unit to be Purchased </h3>
                 <div class="col-md-6 form-group">
                     <label class="control-label" style="text-align: left;">Type of Property:</label>
            <input  type="text"  class="form-control" placeholder="Type of Property" id="app_prop_type" name="app_prop_type" />
          </div>
               <div class="col-md-6 form-group">
                     <label class="control-label" style="text-align: left;">Sector:</label>
            <input  type="text"  class="form-control" placeholder="Sector" id="app_sector" name="app_sector" />
          </div>
              <div class="col-md-6 form-group">
            <label class="control-label">Pocket No.</label>
            <input type="text"  class="form-control" placeholder="Pocket No." id="app_pocket" name="app_pocket" />
          </div>
              <div class="col-md-6 form-group">
            <label class="control-label">Unit No.</label>
            <input type="text"  class="form-control" placeholder="Unit No." id="app_unit" name="app_unit" />
          </div>
               <div class="col-md-6 form-group">
                     <label class="control-label" style="text-align: left;">Floor:</label>
            <input  type="text"  class="form-control" placeholder="Floor" id="app_floor" name="app_floor"  />
          </div>
              <div class="col-md-6 form-group">
                     <label class="control-label" style="text-align: left;">Requirement Area:</label>
            <input  type="text"  class="form-control" placeholder="Requirement Area"  id="app_res_area" name="app_res_area" />
          </div>
              <div class="col-md-6 form-group">
            <label class="control-label">Base Rate Per Sq.Mt./Sq. Yd.</label>
            <input type="text"  class="form-control" placeholder="Base Rate Per Sq.Mt./Sq. Yd." id="app_base_rate" name="app_base_rate" />
          </div>
              <div class="col-md-6 form-group">
            <label class="control-label">Basic Sale Price </label>
            <input type="text"  class="form-control" placeholder="Basic Sale Price" id="app_basic_sale_price" name="app_basic_sale_price"/>
          </div>
              <div class="col-md-12 form-group" style="text-align: right"> <br>
             <button class="btn btn-primary nextBtn  pull-right" type="button" >Next</button>
          </div>
            </div>
      </div>
        </div>
          
           <div class="row setup-content" id="step-5">
          <div class="col-xs-12">
        <div class="col-md-12">
              <h3> Other Details </h3>
                 <div class="col-md-12 form-group">
                     <h3>Car Parking Space:</h3><hr>
            <div class="col-md-6 form-group">
                <label class="control-label" style="text-align: left;">Open: <input  type="radio" name="parking" id="app_parking" value="open"/></label>
          </div>
              <div class="col-md-6 form-group">
                  <label class="control-label">Covered: <input type="radio" name="parking" id="app_parking"  value="covered"/></label>
          </div>
          </div>
               <div class="col-md-12 form-group">
                   <h3>Storage Space:</h3><hr>
            <div class="col-md-6 form-group">
                <label class="control-label" style="text-align: left;">Yes: <input  type="radio" name="storage" id="app_storage" value="Yes" /></label>
          </div>
              <div class="col-md-6 form-group">
                  <label class="control-label">No: <input type="radio" name="storage" id="app_storage" value="No" /></label>
          </div>
          </div>
              <div class="col-md-12 form-group">
                  <h3>Club Membership</h3><hr>
             <div class="col-md-6 form-group">
                 <label class="control-label" style="text-align: left;">Yes: <input  type="radio" name="club" id="app_club" value="Yes" /></label>
          </div>
              <div class="col-md-6 form-group">
                  <label class="control-label">No: <input type="radio" name="club" id="app_club" value="No" /></label>
          </div>
          </div>
                <div class="col-md-6 form-group">
                     <label class="control-label" style="text-align: left;">Allottee's Income Tax Permanent Account No. (PAN)</label>
            <input  type="text"  class="form-control" placeholder="Account No." id="app_pan_no" name="app_pan_no"  />
          </div>
              <div class="col-md-6 form-group">
            <label class="control-label">Particular of the Sale Executive/Agent/Dealer : ID </label>
            <input type="text"  class="form-control" placeholder="Agent Id" id="app_agent_name" name="app_agent_name" />
          </div>
              
              <div class="col-md-6 form-group" id="per_name">
            <label class="control-label">Sponsor's Name </label>
            <input type="text"  class="form-control" placeholder="Agent Name" id="app_agent_id_name" name="app_agent_id_name"  readonly/>
          </div>
              
             
              <div class="col-md-6 form-group">
                     <label class="control-label" style="text-align: left;">Address & phone Nos. </label>
            <input  type="text"  class="form-control" placeholder="Address & phone Nos." id="app_agent_ph" name="app_agent_ph" />
          </div>
              <div class="col-md-12 form-group">
                  <label class="control-label" style="text-align: left;"><h3>Declaration</h3> </label>
                  <label style="text-align: left;"> <input  type="checkbox"   required /> I/We the Undersigned (Sole/First and Application) do declare that the above mentioned/Particulars/Information's given by me/us are correct and nothing has been concealed therefore.</label>
          </div>
             
              <div class="col-md-12 form-group" style="text-align: right"> <br>
                  <button class="btn btn-success pull-right" type="submit" name="app_submit">Submit</button>
          </div>
            </div>
      </div>
        </div>
          
          
          
<!--    <div class="row setup-content" id="step-3">
          <div class="col-xs-6 col-md-offset-3">
        <div class="col-md-12">
              <h3> Step 3</h3>
              <button class="btn btn-success  pull-right" type="submit">Submit</button>
            </div>
      </div>
        </div>-->
  </form>
       
              <script>
                $(document).ready(function(){
            $("#app_agent_name").change(function(){
                cmp_id=$("#app_agent_name").val();
//                alert(cmp_id);
                $("#per_name").load("get-data.php",{"cmp_id":cmp_id});
            });
        });
                  </script>
              
         <script type="text/javascript">
  $(document).ready(function () {
  var navListItems = $('div.setup-panel div a'),
		  allWells = $('.setup-content'),
		  allNextBtn = $('.nextBtn');

  allWells.hide();

  navListItems.click(function (e) {
	  e.preventDefault();
	  var $target = $($(this).attr('href')),
			  $item = $(this);

	  if (!$item.hasClass('disabled')) {
		  navListItems.removeClass('btn-primary').addClass('btn-default');
		  $item.addClass('btn-primary');
		  allWells.hide();
		  $target.show();
		  $target.find('input:eq(0)').focus();
	  }
  });

  allNextBtn.click(function(){
	  var curStep = $(this).closest(".setup-content"),
		  curStepBtn = curStep.attr("id"),
		  nextStepWizard = $('div.setup-panel div a[href="#' + curStepBtn + '"]').parent().next().children("a"),
		  curInputs = curStep.find("input[type='text'],input[type='url'],textarea[textarea]"),
		  isValid = true;

	  $(".form-group").removeClass("has-error");
	  for(var i=0; i<curInputs.length; i++){
		  if (!curInputs[i].validity.valid){
			  isValid = false;
			  $(curInputs[i]).closest(".form-group").addClass("has-error");
		  }
	  }

	  if (isValid)
		  nextStepWizard.removeAttr('disabled').trigger('click');
  });

  $('div.setup-panel div a.btn-primary').trigger('click');
});
  </script>            
	    </div>
         
       </section>


<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<div class="offline-ui offline-ui-up"><div class="offline-ui-content"></div><a href="" class="offline-ui-retry"></a>
</div>
</body>
</html>
<?php
 } 
?>