<?php
$page = 1;
include_once '../property/pss_db.php';
$conn = new DB_con();
$con = $conn->connection();

$functions = new functions();
?>


<?php if(isset($_REQUEST['type'])){?>
            
            
            <script>
   $(document).ready(function(){
       $("#m_o_payment").change(function(){
           type=$("#m_o_payment").val();
           if(type==""){
               $("#mode_info").load("get-data-payment.php");
           }else{
               $("#mode_info").load("get-data-payment.php",{"mode_type":type});
           }
       });
   });
    </script>
	
<script>

            $(document).ready(function() {
                $("#user_id").change(function() {
                    var user = $("#user_id").val();
					//alert('123412412');
					if(user=="")
					{
						$("#get_image").load('get-data.php');
						}
						else
						{
                    $("#get_image").load('get-data.php', {"appli_id": user});
						}
                });
            });
        </script>
     <div class="col-sm-12">
                                  <?php 
                                  $res=$conn->get_admin_applicant_detail($con);
                                  ?>
                                  <label>Client Name</label>
                                  <select class="form-control" name="user_id" id="user_id">
                                      <option value="">Select Clients</option>
                                      <?php while($row=  mysqli_fetch_array($res)){ 
									  
										  ?>
                                      <option value="<?php echo $row['applicant_id']; ?>"> <?php echo $row['applicant_name']." (".$row['applicant_detail_username'].")"; ?></option>
                                      <?php } ?>
                                  </select>
                              
                              </div>
                              <div class="col-sm-12" id="get_image">

                              </div>
    	<div class="col-sm-12">
                                  <label>Payment Amount</label>
					<input type="text" name="amount" value="" class="form-control" placeholder="Please Enter Amount">
                              </div>
                              <div class="col-sm-12"><br>
                                  <label> Mode of Payment</label>
                                  <select class="form-control" id="m_o_payment" name="m_o_payment">
                                      <option value="">Select Payment Mode</option>
                                      <option value="cash">Cash</option>
                                      <option value="cheque">Cheque </option>
                                      <option value="bank transaction">Bank Transaction</option>
                                      <option value="demand draft">Demand Draft</option>
                                  </select>
                              </div>
<?php }if(isset($_REQUEST['mode_type'])){ ?>
    <br>
    <?php if($_REQUEST['mode_type']=="cash") {?>
     <div class="col-sm-6"><label>Accepted By</label>
                           <input type="text" name="field1" id="accepted_by" class="form-control" required>
                          </div>
                          <div class="col-sm-6"><label>Paid By</label>
                           <input type="text" name="field2" id="received_by" class="form-control" required>
                          </div>
                           <div class="col-sm-6"><label>Date</label>
                           <input type="date" name="received_date" id="received_date" class="form-control" required>
                          </div>
                          
    <?php } if($_REQUEST['mode_type']=="cheque") {?>    
                          <div class="col-sm-6"><label>Cheque Number</label>
                           <input type="text" name="field1" id="cheque_no" class="form-control" required>
                          </div>
                          <div class="col-sm-6"><label>Bank Name</label>
                           <input type="text" name="field2" id="bank_name" class="form-control" required>
                          </div>
                          <div class="col-sm-6"><label>Account Holder Name</label>
                           <input type="text" name="field3" id="acc_holder_name" class="form-control" required>
                          </div>
                           <div class="col-sm-6"><label>Date</label>
                           <input type="date" name="received_date" id="received_date" class="form-control" required>
                          </div>
                          
                  <?php } if($_REQUEST['mode_type']=="bank transaction") {?>            
                          <div class="col-sm-6"><label>Transaction Number</label>
                           <input type="text" name="field1" id="transaction_number" class="form-control" required>
                          </div>
                          <div class="col-sm-6"><label>Transaction Account</label>
                           <input type="text" name="field2" id="transaction_acc" class="form-control" required>
                          </div>
                           <div class="col-sm-6"><label>Date</label>
                           <input type="date" name="received_date" id="received_date" class="form-control" required>
                          </div>
                          
                     <?php } if($_REQUEST['mode_type']=="demand draft") {?>        
                          <div class="col-sm-6"><label>D.D. Number</label>
                           <input type="text" name="field1" id="cheque_no" class="form-control" required>
                          </div>
                          <div class="col-sm-6"><label>Bank Name</label>
                           <input type="text" name="field2" id="bank_name" class="form-control" required>
                          </div>
                          <div class="col-sm-6"><label>D.D Generated by</label>
                           <input type="text" name="field3" id="acc_holder_name" class="form-control" required>
                          </div>
                           <div class="col-sm-6"><label>Date</label>
                           <input type="date" name="received_date" id="received_date" class="form-control" required>
                          </div>
<?php } } ?>  
