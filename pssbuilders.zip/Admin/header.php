<?php
//echo "<script>alert('$page_name')</script>";
$page = 1;
include_once '../property/pss_db.php';
$conn = new DB_con();
$con = $conn->connection();
//include_once 'property/function_list.php';
//include_once 'property/default_values.properties';
$functions = new functions();
$page_name=basename($_SERVER['PHP_SELF']);
//$functions->get_user_rights($page_name,$con,$_SESSION["user"],$conn);
$res=$conn->check_admin_page_rights($con,$page_name,$_SESSION["user"]);
//echo $res;
    if(mysqli_num_rows($res)!=0 || $page_name=='dashboard.php'){
//    echo "<script>alert('$page_name')</script>";
}else{
    echo "<script>window.location.replace('dashboard.php')</script>";
}
?>


<header class="navbar main-header" style="background-color:#3ba0ff;">
     <script src="js/jquery.blockUI.min.js" ></script>  
     <link rel="stylesheet" href="css/spinner.css">
    <a class="navbar-brand" href="">
        <span style="font-size:17px;">Pss Builders&nbsp;</span></div>
    </a>
    <ul class="nav navbar-nav navbar-left sidebar-toggle-ul">
        <li class="navbar-main hidden-lg hidden-md">
            <a href="javascript:void(0);" id="sidebar-toggle">
                <span class="meta">
                    <span class="arrow"><i class="arrow fa fa-angle-right pull-right"></i></span>
                </span>
            </a>
        </li>

        <li class="navbar-main hidden-sm hidden-xs">
            <a href="javascript:void(0);" id="sidebar-collapse">
                <span class="meta">
                    <span class="icon"><i class="fa fa-outdent" style="color:blue;"></i></span>
                </span>
            </a>
        </li>
    </ul>
<?php
	        $id=$_SESSION['user'];
            $name=$conn->get_admin_login_name($con,$id);
            $res=$conn->get_admin_distributor_detail_by_cmpny_id($con,$name);
            $row=  mysqli_fetch_array($res);
            $dis_name=$row['distributor_name'];
            $image_path=$row['distributor_image_path'];
            if($image_path=="../image_uploads/" || $image_path==""){
                $image_path="images/avatar.png";
            }
            ?>
    <ul class="nav navbar-nav navbar-right">
        <li class="dropdown icons-dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><span style="color:blue;">Company Id : <?php echo $name ?></span></a>
<!--            <ul class="dropdown-menu list-group">
                <li class="list-group-item heading"><p>Notification</p></li>
                <a href="http://flatter.cloudtub.com/index.html#" class="list-group-item"><i class="fa fa-user"></i> <p>John sent you friend request</p></a>
                <a href="http://flatter.cloudtub.com/index.html#" class="list-group-item"><i class="fa fa-envelope-o"></i> <p>Sam sent important mail</p></a>
                <a href="http://flatter.cloudtub.com/index.html#" class="list-group-item"><i class="fa fa-calendar"></i> <p>You have pending job</p></a>
                <a href="http://flatter.cloudtub.com/index.html#" class="list-group-item"><i class="fa fa-money"></i> <p>Received $1826 from client</p></a>

            </ul>-->
        </li>
            

        <li class="dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><span  style="color:blue;"><?php echo "$dis_name" ?></span> <img class="img-circle" src="<?php echo $image_path; ?>" alt="avatar"> <b class="caret"></b></a>
            <ul class="dropdown-menu">
<!--                <li><a href="http://flatter.cloudtub.com/index.html#"><i class="fa fa-globe" ></i> Notification <span class="label label-danger"> 5</span></a></li>
                <li><a href="http://flatter.cloudtub.com/index.html#"><i class="fa fa-user"></i> Profile</a></li>
                <li><a href="http://flatter.cloudtub.com/index.html#"><i class="fa fa-gear"></i> Settings</a></li>-->
                <li><a href="logout.php?logout"><i class="fa fa-share"></i> Logout</a></li>
            </ul>
        </li>
    </ul>
</header>
