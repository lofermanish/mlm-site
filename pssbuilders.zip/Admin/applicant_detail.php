<?php
session_start();
if(!isset($_SESSION['user']))
{
	header("Location: index.php");
}
else
{
?>
<!DOCTYPE html>
<!-- saved from url=(0038)http://flatter.cloudtub.com/index.html -->
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Dashboard</title>
<meta name="description" content="Flatter - Flat Admin Theme">
<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/layout.css">
<link rel="stylesheet" href="css/style3.css">
<script type="text/javascript" src="js/jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.10.4.custom.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/r/bs-3.3.5/jq-2.1.4,dt-1.10.8/datatables.min.css"/>
 
		<script type="text/javascript" src="https://cdn.datatables.net/r/bs-3.3.5/jqc-1.11.3,dt-1.10.8/datatables.min.js"></script>
		  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/1.2.1/css/buttons.dataTables.min.css"/>
 
		<script type="text/javascript" src="https://cdn.datatables.net/r/bs-3.3.5/jqc-1.11.3,dt-1.10.8/datatables.min.js"></script>
                 <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.1/js/dataTables.buttons.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.1/js/buttons.flash.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js"></script>
        <script type="text/javascript" src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/pdfmake.min.js"></script>
        <script type="text/javascript" src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/vfs_fonts.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.1/js/buttons.html5.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.1/js/buttons.print.min.js"></script>
        <script type="text/javascript" src="js/jquery-easing.js"></script>
		<script type="text/javascript" charset="utf-8">
			$(document).ready(function() {
				$('.example').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print','pageLength'
        ]
    },
           {
        dom: 'Bfrtip',
        lengthMenu: [
            [ 10, 25, 50, -1 ],
            [ '10 rows', '25 rows', '50 rows', 'Show all' ]
        ]
    } 
                );
			} );
		</script>
                <script type="text/javascript">
	// For demo to fit into DataTables site builder...
	$('.example')
		.removeClass( 'display' )
		.addClass('table table-striped table-bordered');
</script>
<style>
.imgsize
{
	height:30px; 
	width:30px;
}
.table-container {
    border:1px solid #ccc;
    border-radius: 3px;
    width:50%;
}
.table-container table {
    width: 100%;
}
.scroll-container{
    max-height: 500px;
    overflow-y: scroll;
}
</style>

</head>
<body id="body">

		<!-- Header -->
		<?php include './header.php'; ?>

       <?php include './left-menu.php'; ?>
		<!-- Header -->
		
<section id="main-wrapper">
		<h3 class="subtitle">Client Details</h3>
          <hr>

		  <div class="row">
			  <div class="col-md-12">
				  	<div class="panel panel-default">
					  <div class="panel-heading">
					    <h3 class="panel-title"><strong>Client Details</strong></h3> 
					  </div>

					  <div class="panel-body">
					  <div class="scroll-container" style="overflow: auto; max-size:350px;">
					  		<table cellpadding="0" cellspacing="0" border="0"
					  		class="table-striped table table-bordered editable-datatable example"  id="example" >
									<thead>
									<tr>
									    <th>S.No.</th>
									    <th>Applicant Image</th>
									    <th>Applicant Name</th>
										<th>Applicant Fathers name</th>
										<th>Applicant Dob</th>
										<th>Applicant Nationality</th>
										<th>Applicant Address</th>
										<th>Applicant Pin code</th>
										<th>Applicant Telephone No</th>
										<th>Applicant Fax No</th>
										<th>Applicant Email</th>
										<th>Applicant Mobile No</th>
										<th>Applicant Qualification</th>
										<th>Applicant Bussiness</th>
										<th>Applicant Employeer Name</th>
										<th>Applicant Business_no</th>
										<th>Applicant Annual Income</th>
										<th>Applicant Fund Detail</th>
										<th>Applicant Second Name</th>
										<th>Applicant Second Father Name</th>
										<th>applicant_scnd_dob</th>
										<th>Applicant Second Nationality</th>
										<th>Applicant Second Pin Code</th>
										<th>Applicant Second Telephone No</th>
										<th>Applicant Second Address</th>
										<th>Applicant Second Fax No</th>
										<th>Applicant Second Email</th>
										<th>Applicant Second Mobile No</th>
										<th>Applicant Residential</th>
										<th>Applicant Payment Plan	</th>
										<th>Applicant Property Type</th>
										<th>Applicant Sector</th>
										<th>Applicant Pocket No</th>
										<th>Applicant Unit No</th>
										<th>Applicant Floor</th>
										<th>Applicant Requirement Area</th>
										<th>Applicant Prop Base Rate</th>
										<th>Applicant Prop Basic Sale Price</th>
										<th>Applicant Car Parking</th>
										<th>Applicant Storage Space</th>
										<th>Applicant Club</th>
										<th>Applicant A/c No</th>
										<th>Applicant Agent Name</th>
										<th>Applicant Agent Phone No</th>
										<th>Applicant Login Id</th>
										<th>Applicant Creation Date</th>
										<th>Applicant Username</th>
										<th>Applicant  Password</th>
										<th>Action</th>
									</tr>
								</thead>
								<tbody>
								<?php
				 $res = $conn->get_admin_applicant($con);
				 $count=0;
				 while ($row = mysqli_fetch_array($res)) {
				 $applicant_id=$row['applicant_id'];
				 $count=$count+1;
				 ?>
									<tr class="1">
									    <td><?php echo $count ?></td>
										<td><img src="../<?php echo $row['applicant_image_path']; ?>" class="imgsize" ></td>
										<td><?php echo $row['applicant_name']; ?></td>
										<td><?php echo $row['applicant_fa_name']; ?></td>
										<td><?php echo $row['applicant_dob']; ?></td>
										<td><?php echo $row['applicant_nationality']; ?></td>
										<td><?php echo $row['applicant_address']; ?></td>
										<td><?php echo $row['applicant_pincode']; ?></td>
										<td><?php echo $row['applicant_tel_no']; ?></td>
										<td><?php echo $row['applicant_fax_no']; ?></td>
										<td><?php echo $row['applicant_email']; ?></td>
										<td><?php echo $row['applicant_mobile_no']; ?></td>
										<td><?php echo $row['applicant_qualification']; ?></td>
										<td><?php echo $row['applicant_bussiness']; ?></td>
										<td><?php echo $row['applicant_employeer_name']; ?></td>
										<td><?php echo $row['applicant_business_no']; ?></td>
										<td><?php echo $row['applicant_annual_inc']; ?></td>
										<td><?php echo $row['applicant_fund_detail']; ?></td>
										<td><?php echo $row['applicant_scnd_fa_name']; ?></td>
										<td><?php echo $row['applicant_scnd_name']; ?></td>
										<td><?php echo $row['applicant_scnd_dob']; ?></td>
										<td><?php echo $row['applicant_scnd_pincode']; ?></td>
										<td><?php echo $row['applicant_scnd_tel_no']; ?></td>
										<td><?php echo $row['applicant_scnd_address']; ?></td>
										<td><?php echo $row['applicant_scnd_address']; ?></td>
										<td><?php echo $row['applicant_scnd_fax_no']; ?></td>
										<td><?php echo $row['applicant_scnd_email']; ?></td>
										<td><?php echo $row['applicant_scnd_mobile_no']; ?></td>
										<td><?php echo $row['applicant_residential']; ?></td>
										<td><?php echo $row['applicant_payment_plan']; ?></td>
										<td><?php echo $row['applicant_property_type']; ?></td>
										<td><?php echo $row['applicant_sector']; ?></td>
										<td><?php echo $row['applicant_pocket_no']; ?></td>
										<td><?php echo $row['applicant_unit_no']; ?></td>
										<td><?php echo $row['applicant_floor']; ?></td>
										<td><?php echo $row['applicant_requirement_area']; ?></td>
										<td><?php echo $row['applicant_prop_base_rate']; ?></td>
										<td><?php echo $row['applicant_prop_basic_sale_price']; ?></td>
										<td><?php echo $row['applicant_car_parking']; ?></td>
										<td><?php echo $row['applicant_storage_space']; ?></td>
										<td><?php echo $row['applicant_club']; ?></td>
										<td><?php echo $row['applicant_acc_no']; ?></td>
										<td><?php echo $row['applicant_agent_name']; ?></td>
										<td><?php echo $row['applicant_agent_phone_no']; ?></td>
										<td><?php echo $row['applicant_login_id']; ?></td>
										<td><?php echo $row['applicant_creation_date']; ?></td>
										<td><?php echo $row['applicant_detail_username']; ?></td>
										<td><?php echo $row['applicant_detail_password']; ?></td>
										<td><a class="delete" href="delete_applicant_details.php?applicant_id=<?php echo"$applicant_id"; ?>">Delete</a></td>
									</tr>
				<?php }?>					
								</tbody>

								</table>
</div>
					  </div>
					</div>
				</div>
				
</div>

</section>


<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<div class="offline-ui offline-ui-up"><div class="offline-ui-content"></div><a href="" class="offline-ui-retry"></a>
</div>
</body>
</html>
<?php
 } 
?>