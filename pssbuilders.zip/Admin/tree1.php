
<script>
    function user(user_id){
//        alert(user_id);
      $("#u_id").val(user_id);
      $("form").submit();
//        $.post("customer_tree.php",{"u_id":user_id});
    }
    </script>
<?php if($_SESSION['user']==1){ ?>
<!DOCTYPE HTML>
<html>
    <?php 
    $id=1;
    if(isset($_REQUEST['u_id']) &&  $_REQUEST['u_id']!=""){
//        $id=$_REQUEST['u_id'];
        $comp_id=$_REQUEST['u_id'];
        $id=$conn->get_admin_dis_id($con,$comp_id);
    }else{
        $id=1;
    }
    ?>
    
    <body>
        <form action="#" method="post">
         <div class="col-sm-12">     <table class="table table-bordered display example" id="example"><thead>  <tr>
                                                 <th>S.No.</th>
                                                  <th>Name</th>
                                                  <th>Company Id</th>
                                                  <th>Total Left B V</th>
                                                  <th>Total Right B V</th>
												 <!--th>Remaining Reward Amount</th>
												 <th>10%</th>
												 <th>5%</th>
												 <th>Payable Amount</th>                                          
   											     <th>Reward Commodity</th> 
                                                  <th>Reward Amount</th>												  
												  <th>Position</th>
												  <th>Pay</th--> 
                                      </tr></thead>
									  
             <!--<div class="col-sm-2" style="text-align: right"> <br><a href="logout.php?logout"><input type="submit" name="Logout" value="Logout" class="btn btn-danger"></a></div>-->
        <?php
//        include_once 'db.php';
//        $page=1;
//include_once '../property/dbMysql.php';
//$conn = new DB_con();
//$con=$conn->connection();
//include_once 'property/function_list.php';
//include_once 'property/default_values.properties';
$functions=new functions();

                function countt($id,$con){
                    $i=0;
                    $query=mysqli_query($con,"select * from tree where parent_id='$id' order by position");
                    while( $rr=  mysqli_fetch_array($query)){
                      
                      $pp[$i]=$rr;
                      $i++;
                  }
                  if($i==2){
                      if($pp[0][1]!='blank'){
                       $count_left=countt($pp[0][0],$con);   
                       $count_left++;
//                       echo $connt_left;
                      }else {
                          $count_left=0;                          
                      }
                      if($pp[1][1]!='blank'){
                           $count_right=countt($pp[1][0],$con); 
                           $count_right++;
                      }else{
                          $count_right=0;    
                      }
                     $counttt= $count_left+$count_right;
                     return $counttt;
                  }if($i==0){
                   return 0;   
                  }
                }
                
                
                
                 function countbv($id,$con){
                    $i=0;
                    $query=mysqli_query($con,"select * from tree where parent_id='$id' order by position");
                    while( $rr=  mysqli_fetch_array($query)){
                      
                      $pp[$i]=$rr;
                      $i++;
                  }
                  if($i==2){
                      if($pp[0][1]!='blank'){
                       $count_left_bv=countbv($pp[0][0],$con); 
                       $user_left_idd=$pp[0][0];
                       $sql=  mysqli_query($con, "select distributor_bv from distributor_detail where distributor_id='$user_left_idd'");
                       $rowss=  mysqli_fetch_array($sql);
                       $count_left_bv=$count_left_bv+$rowss['distributor_bv'];
//                       echo $connt_left;
                      }else {
                          $count_left_bv=0;                          
                      }
                      if($pp[1][1]!='blank'){
                           $count_right_bv=countbv($pp[1][0],$con); 
                            $user_right_idd=$pp[1][0];
                       $sql=  mysqli_query($con, "select distributor_bv from distributor_detail where distributor_id='$user_right_idd'");
                       $rowss=  mysqli_fetch_array($sql);
                           $count_right_bv=$count_right_bv+$rowss['distributor_bv'];
                      }else{
                          $count_right_bv=0;    
                      }
                     $counttt= $count_right_bv+$count_left_bv;
                     return $counttt;
                  }if($i==0){
                   return 0;   
                  }
                }
                
		function in_parent($in_parent, $store_all_id, $con,$p) {
                    $p++;
            if (in_array($in_parent, $store_all_id)) {
                
                $result = mysqli_query($con, "SELECT * FROM tree where parent_id = '$in_parent' order by position ");
                echo $in_parent == 0 ? "<ul class='
				'>" : "<ul>";
                while ($row = mysqli_fetch_array($result)) {
                    $res=  mysqli_query($con, "select * from distributor_detail where distributor_id='".$row['id']."'");
                    $rows=  mysqli_fetch_array($res);
                     $res_date=  mysqli_query($con, "select date(distributor_creation_date) as joining from distributor_detail where distributor_id='".$row['id']."'");
                    $rows_date=  mysqli_fetch_array($res_date);
//                    $bv=$rows['distributor_bv'];
//                    if($bv>0){
//                        
//                    }
                    $left=mysqli_query($con,"select * from tree where parent_id = '$row[id]' order by position");
                   
                  $pp=array();
                  $i=0;
                  $count_left=0;
                  $count_right=0;
                  while( $rr=  mysqli_fetch_array($left)){
                     
                      $pp[$i]=$rr;
                       $i++;
                  }
                  if($i==2){
                      if($pp[0][1]!='blank'){
                          $id=$pp[0][0];
                       $count_left=countt($id,$con); 
                       $count_left++;
                      }else {
                          $count_left=0;                          
                      }
                      if($pp[1][1]!='blank'){
                          $idd=$pp[1][0];
                         $count_right=countt($idd,$con); 
                         $count_right++;
                      }else {
                          $count_right=0;                          
                      }
                  }
                  $count_left_bv=0;
                  $count_right_bv=0;
                  
                  if($i==2){
                      if($pp[0][1]!='blank'){
                       $count_left_bv=countbv($pp[0][0],$con); 
                       $user_left_idd=$pp[0][0];
                       $sql=  mysqli_query($con, "select distributor_bv from distributor_detail where distributor_id='$user_left_idd'");
                       $rowss=  mysqli_fetch_array($sql);
                       $count_left_bv=$count_left_bv+$rowss['distributor_bv'];
//                       echo $connt_left;
                      }else {
                          $count_left_bv=0;                          
                      }
                      if($pp[1][1]!='blank'){
                           $count_right_bv=countbv($pp[1][0],$con); 
                            $user_right_idd=$pp[1][0];
                       $sql=  mysqli_query($con, "select distributor_bv from distributor_detail where distributor_id='$user_right_idd'");
                       $rowss=  mysqli_fetch_array($sql);
                           $count_right_bv=$count_right_bv+$rowss['distributor_bv'];
                      }else{
                          $count_right_bv=0;    
                      }
//                     $counttt= $count_right_bv+$count_left_bv;
//                     return $counttt;
                  }
				  
				  
//                  $qq=$pp[1][1];
//                    if ($row['hide'])
                 
			 if($p>1)
                         $p++;
//                    echo $p;

                    ?>
					<tbody>
					<tr>
					<td><?php echo 1 ; ?> </td><td><?php echo $row['first_name']; ?> </td><td><?php echo $rows['distributor_company_id']; ?> </td><td><?php echo $count_left_bv  ; ?> </td><td><?php echo   $count_right_bv ; ?> </td></tr><tbody></table>
                  <?php 
				   in_parent($row['id'], $store_all_id, $con,$p);
                   
                }
                
           
                }
        }
        $store_all_id = array();
        $id_result = mysqli_query($con, "SELECT * FROM tree");
        while ($all_id = mysqli_fetch_array($id_result)) {
            array_push($store_all_id, $all_id['parent_id']);
        }
        
//        in_parent(0, $store_all_id, $con);
         $result = mysqli_query($con, "SELECT * FROM tree where id = '$id' order by first_name");
         $row = mysqli_fetch_array($result);
         $res=  mysqli_query($con, "select * from distributor_detail where distributor_id='".$row['id']."'");
                    $rows=  mysqli_fetch_array($res);
                    
         
         
                    if ($row['hide'])
                        
                     "><div id=" . $row['id'] . "> Name: $row[first_name] <br> Company Id: $rows[distributor_company_id] ' " . $row['first_name'] ."<br>".$rows['distributor_company_id']. "<br></div>";
                    in_parent($row['id'], $store_all_id, $con,0);
                 
       
        

       
        ?>
    </body>
</html>
<?php }?>