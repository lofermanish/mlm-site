		  
		   //include"../property/pss_db.php";
		   	<?php //include './header.php'; ?>

       <?php include './left-menu.php'; 
		   $id=$_REQUEST['distributer_id'];
		   $distr_edit=$conn->get_admin_distributor_edit($con,$id);
		   $row=mysqli_fetch_assoc($distr_edit);
		   
		   ?>
<section id="main-wrapper">
		<h3 class="subtitle">Client Details</h3>
          <hr>

		  <div class="row">
		  <?php //echo"$msg"; ?>
			  <div class="col-md-12">
				  	<div class="panel panel-default">
					  <div class="panel-heading">
					    <h3 class="panel-title"><strong>Distributer Pre Details</strong></h3> 
					  </div>

					  <div class="panel-body">
					
					  		<table>

									<thead>
									<tr>
									    <th>S.No.</th>
										<th>Image</th>
									    <th>Distributor Company Id</th>
									    <th>Distributor Name</th>
										<th>Distributor Fathers name</th>
										<th>Distributor Dob</th>
										<th>Distributor Gender</th>
										<th>Distributor Marriage Status</th>
										<th>Distributor Nominee name</th>
										<th>Distributor relationship</th>
										<th>Distributor Current Address</th>
										<th>Distributor permanent address</th>
										<th>Distributor state</th>
										<th>Distributor city</th>
										<th>Distributor district</th>
										<th>Distributor pincode</th>
										<th>Distributor mobile No</th>
										<th>Distributor phone No.</th>
										<th>Distributor email</th>
										<th>Distributor pan</th>
										<th>Distributor id proof</th>
										<th>Distributor Address proof</th>
								
										<th>Distributor payment mode</th>
										<th>Distributor bank</th>
										<th>Distributor bank branch</th>
										<th>Distributor amount</th>
										<th>Distributor amount word</th>
										<th>Distributor account IFSC code</th>
										<th>Distributor account no.</th>
										<th>Distributor account name	</th>
										<th>Distributor qualification</th>
										<th>Distributor bussiness</th>
										<th>Distributor employee name</th>
										<th>Distributor business no.</th>
										<th>Distributor annual income</th>
										<th>Distributor ref1</th>
										<th>Distributor ref2</th>
										<th>Distributor ref3</th>
										<th>Distributor ref4</th>
										<th>Distributor passport no.</th>
										<th>Distributor placement</th>
										<th>Distributor placement id</th>
										<th>Distributor direct distributer id</th>
										<th>Distributor coupan</th>
										<th>Distributor coupan no.</th>
										<th>Distributor Shagun</th>
										<th>Distributor defence</th>
										<th>Distributor bv</th>
										<th>Distributor created date</th>
										<th>Distributor user unique code</th>
										<th>Action</th>
									</tr>
								</thead>
								<tbody>
								
									<tr>
									   
										<td><img src="../<?php echo $row['distributor_image_path']; ?>" class="imgsize" ></td>
										<td><input type="text" value="<?php echo $row['distributor_company_id']?>" name="distributor_company_id"></td>
										<td><input type="text" value="<?php echo $row['distributor_name']; ?>" name="distributor_name"></td>
										<td><input type="text" value="<?php echo $row['distributor_father_name']; ?>" name="distributor_father_name"></td>
										<td><input type="text" value="<?php echo $row['distributor_dob']; ?>" name="distributor_dob"></td>
										<td><input type="text" value="<?php echo $row['distributor_gender']; ?>" name="distributor_gender"></td>
										<td><input type="text" value="<?php echo $row['distributor_m_status']; ?>" name="distributor_m_status"></td>
										<td><input type="text" value="<?php echo $row['distributor_nominee_name']; ?>" name="distributor_nominee_name"></td>
										<td><input type="text" value="<?php echo $row['distributor_relationship']; ?>" name="distributor_relationship"></td>
										<td><input type="text" value="<?php echo $row['distributor_current_address']; ?>" name="distributor_current_address"></td>
										<td><input type="text" value="<?php echo $row['distributor_permanent_address']; ?>" name="distributor_permanent_address"></td>
										<td><input type="text" value="<?php echo $row['distributor_state']; ?>" name="distributor_state"></td>
										<td><input type="text" value="<?php echo $row['distributor_city']; ?>" name="distributor_city"></td>
										<td><input type="text" value="<?php echo $row['distributor_district']; ?>" name="distributor_district"></td>
										<td><input type="text" value="<?php echo $row['distributor_pincode']; ?>" name="distributor_pincode"></td>
										<td><input type="text" value="<?php echo $row['distributor_mobile']; ?>" name="distributor_mobile"></td>
										<td><input type="text" value="<?php echo $row['distributor_phone']; ?>" name="distributor_phone"></td>
										<td><input type="text" value="<?php echo $row['distributor_email']; ?>" name="distributor_email"></td>
										<td><input type="text" value="<?php echo $row['distributor_pan']; ?>" name="distributor_pan"></td>
										<td><input type="text" value="<?php echo $row['distributor_id_proof']; ?>" name="distributor_id_proof"></td>
										<td><input type="text" value="<?php echo $row['distributor_add_proof']; ?>" name="distributor_add_proof"></td>
								
										<td><input type="text" value="<?php echo $row['distributor_payment_mode']; ?>" name="distributor_payment_mode"></td>
										<td><input type="text" value="<?php echo $row['distributor_bank']; ?>" name="distributor_bank"></td>
										<td><input type="text" value="<?php echo $row['distributor_bank_branch']; ?>" name="distributor_bank_branch"></td>
										<td><input type="text" value="<?php echo $row['distributor_amount']; ?>" name="distributor_amount"></td>
										<td><input type="text" value="<?php echo $row['distributor_amoun_word']; ?>" name="distributor_amoun_word"></td>
										<td><input type="text" value="<?php echo $row['distributor_account_ifsc']; ?>" name="distributor_account_ifsc"></td>
										
										
										<td><input type="text" value="<?php echo $row['distributor_account_acc_no']; ?>" name="distributor_account_acc_no"></td>
										<td><input type="text" value="<?php echo $row['distributor_account_acc_name']; ?>" name="distributor_account_acc_name"></td>
										<td><input type="text" value="<?php echo $row['distributor_qualification']; ?>" name="distributor_qualification"></td>
										<td><input type="text" value="<?php echo $row['distributor_business']; ?>" name="distributor_business"></td>
										<td><input type="text" value="<?php echo $row['distributor_name_employer']; ?>" name="distributor_name_employer"></td>
										<td><input type="text" value="<?php echo $row['distributor_business_no']; ?>" name="distributor_business_no"></td>
										<td><input type="text" value="<?php echo $row['distributor_anual_income']; ?>" name="distributor_anual_income"></td>
										<td><input type="text" value="<?php echo $row['distributor_ref1']; ?>" name="distributor_ref1"></td>
										<td><input type="text" value="<?php echo $row['distributor_ref2']; ?>" name="distributor_ref2"></td>
										<td><input type="text" value="<?php echo $row['distributor_ref3']; ?>" name="distributor_ref3"></td>
										<td><input type="text" value="<?php echo $row['distributor_ref4']; ?>" name="distributor_ref4"></td>
										<td><input type="text" value="<?php echo $row['distributor_passport_no']; ?>" name="distributor_passport_no"></td>
										<td><input type="text" value="<?php echo $row['distributor_placement']; ?>" name="distributor_placement"></td>
										<td><input type="text" value="<?php echo $row['distributor_distributor_id']; ?>" name="distributor_distributor_id"></td>
										<td><input type="text" value="<?php echo $row['distributor_direct_distributor_id']; ?>" name="distributor_direct_distributor_id"></td>
										<td><input type="text" value="<?php echo $row['distributor_coupon']; ?>" name="distributor_coupon"></td>
										<td><input type="text" value="<?php echo $row['distributor_coupon_number']; ?>" name="distributor_coupon_number"></td>
										<td><input type="text" value="<?php echo $row['distributor_shagun']; ?>" name="distributor_shagun"></td>
										<td><input type="text" value="<?php echo $row['distributor_defense']; ?>" name="distributor_defense"></td>
										<td><input type="text" value="<?php echo $row['distributor_bv']; ?>" name="distributor_bv"></td>
										<td><input type="text" value="<?php echo $row['distributor_creation_date']; ?>" name="distributor_creation_date"></td>
										<td><input type="text" value="<?php echo $row['distributor_user_unique_code']; ?>" name="distributor_user_unique_code"></td>
								</tr>
													
									
									
									
								</tbody>

								</table>
</div>
					  </div>
					</div>
				</div>
				
</div>

</section>