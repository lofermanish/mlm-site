<?php
session_start();
include_once 'db.php';

if(isset($_SESSION['user'])!="")
{
	header("Location: dashboard.php");
}

if(isset($_POST['btn-login']))
{
	$username = $_POST['username'];
	$password = $_POST['password'];
	
	$username = trim($username);
	$password = trim($password);
	
	$res=mysqli_query($con,"SELECT login_id, username, password FROM login WHERE username='$username'");
	$row=mysqli_fetch_array($res);
	
	$count = mysqli_num_rows($res); // if uname/pass correct it returns must be 1 row
//	echo"$count";
	if($count == 1 && $row['password']==md5($password))
	{
		$_SESSION['user'] = $row['login_id'];
		header("Location: dashboard.php");
	}
	else
	{
		?>
        <script>alert('Username / Password Seems Wrong !');</script>
        <?php
	}
	
}
?>
<!DOCTYPE html>
<html >
  <head>
    <meta charset="UTF-8">
    <title>PssBuilders</title>
        <link rel="stylesheet" href="css/style.css">
  </head>
  <body>
<form method="POST" action="">
  <header>Login</header>
  <label>Username <span>*</span></label>
  <input type="Text" name="username" required="required"/>
  <label>Password <span>*</span></label>
  <input type="password" name="password" required="required"/>
  
  <button type="Submit" name="btn-login">Login</button>
  <button type="reset" style="background-color: #ff6666" >Reset</button>
</form>
  </body>
</html>
