<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: index.php");
} else {
    ?>
    <!DOCTYPE html>
    <!-- saved from url=(0038)http://flatter.cloudtub.com/index.html -->
    <html>
        <head>
            <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
            <title>Dashboard</title>
            <meta name="description" content="Flatter - Flat Admin Theme">
            <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0">
            <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
            <link rel="stylesheet" href="css/bootstrap.min.css">
            <link rel="stylesheet" href="css/layout.css">
            <link rel="stylesheet" href="css/style3.css">
            <script type="text/javascript" src="js/jquery-1.11.0.min.js"></script>
            <script type="text/javascript" src="js/jquery-ui-1.10.4.custom.min.js"></script>
            <style>
                .imgsize
                {
                    height:30px; 
                    width:30px;
                }
            </style>
        </head>
        <body id="body">

            <!-- Header -->
    <?php include './header.php'; ?>

            <?php include './left-menu.php'; ?>
            <!-- Header -->





            <section id="main-wrapper">
    <?php
    if (isset($_POST['save'])) {
        

		
        $transaction_type="money received";
        $user_id = $_POST['user_id'];
        $amount = $_POST['amount'];
        $mode_of_payment = $_POST['m_o_payment'];
        if ($user_id != "") {
           
            if ($mode_of_payment != "") 
			{
                 
                $field1=$_POST['field1'];
                $field2=$_POST['field2'];
                if(isset($_POST['field3'])){
                $field3=$_POST['field3'];
                }else{
                    $field3="";
                }
                $date=$_POST['received_date'];
                $res=$conn->insert_admin_payment_mode($con,$mode_of_payment,$field1,$field2,$field3,$date,$date_time,$_SESSION['user']);
//                 echo "<script>alert('$res');</script>";
                if($res){
                   
                    $res=$conn->get_admin_payment_mode_id($con,$mode_of_payment,$field1,$field2,$field3,$date,$date_time,$_SESSION['user']);
//                    echo "<script>alert('$res');</script>";
                    $row=  mysqli_fetch_array($res);
                    $mode_id=$row['payment_mode_id'];
					echo $payment_type=$_POST["m_o_payment"];
                    $res=$conn->insert_into_transactions($con,$transaction_type,$user_id,$amount,$mode_of_payment,$mode_id,$date_time,$_SESSION['user'],$payment_type);
                    if($res){
                        echo "<script>alert('successful')</script>";
                    }
                }
                
                
            }
        }
    }
    ?>
                <script>
                    $(document).ready(function() {
                        type = "money received";
                        if (type == "") {
                            $("#trans_info").load("get-data.php");
                            //               $("#mode_info").load("get-data.php");
                        } else {
                            $("#trans_info").load("get-data.php", {"type": type});
                            //               $("#mode_info").load("get-data.php");
                        }

                    });
                </script>
    <?php if (isset($_POST['save_bv_code'])) {
        if ($q > 0) { ?>
                        <div class="alert alert-danger" id="msg">

                        </div><?php } if ($p > 0) { ?>
                        <div class="alert alert-success" id="msg_su">

                        </div>
        <?php }
    } ?>

    <?php
//        $user_id=$_SESSION['user'];
//        $user_cmpny_id=$conn->get_admin_login_name($con,$user_id);
//        $res=$conn->get_admin_distributor_detail_by_cmpny_id($con,$user_cmpny_id);
//        $row=  mysqli_fetch_array($res);
//        $user_bv=$row['distributor_bv'];
    ?>


                <h3 class="subtitle">Add B.V. to your Account</h3>
                <hr>

                <form method="post" action="#">
                    <div class="row">

                        <div class="col-md-12" id="trans_info">


                        </div>

                        <div class="col-md-12" id="mode_info"><br>



                        </div>

                        <div class="col-md-12"><hr>
                            <input type="submit" value="save" name="save" class="btn btn-success pull-right">

                        </div>

                    </div></form>

            </section>


            <script type="text/javascript" src="js/bootstrap.min.js"></script>
            <script type="text/javascript" src="js/jquery.mCustomScrollbar.concat.min.js"></script>
            <script type="text/javascript" src="js/script.js"></script>
            <div class="offline-ui offline-ui-up"><div class="offline-ui-content"></div><a href="" class="offline-ui-retry"></a>
            </div>
        </body>
    </html>
    <?php
}
?>