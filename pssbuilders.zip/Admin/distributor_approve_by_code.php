<?php
session_start();
if(!isset($_SESSION['user']))
{
	header("Location: index.php");
}
else
{
?>
<!DOCTYPE html>
<!-- saved from url=(0038)http://flatter.cloudtub.com/index.html -->
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Dashboard</title>
<meta name="description" content="Flatter - Flat Admin Theme">
<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/layout.css">
<link rel="stylesheet" href="css/style3.css">
<script type="text/javascript" src="js/jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.10.4.custom.min.js"></script>
<style>
.imgsize
{
	height:30px; 
	width:30px;
}
</style>
</head>
<body id="body">

		<!-- Header -->
		<?php include './header.php'; ?>

       <?php include './left-menu.php'; ?>
		<!-- Header -->
                
                
 <?php
//      $count="";
//        $res="";
      $msg="";
        $dis_company_id="";
//        $id1="";
//        $id2="";
        if(isset($_POST['dis_form'])){
            $p=0;
            $code=$_POST['code'];
            $dis_name=$_POST['dis_name'];
            $dis_fa_name=$_POST['dis_fa_name'];
            $dis_dob=$_POST['dis_dob'];
//            $dis_dob=date($dis_dob,'Y');
//            echo "<script>alert($dis_dob)</script>";
            $dis_gender=$_POST['dis_gender'];
            $dis_m_status=$_POST['dis_m_status'];
            $dis_n_name=$_POST['dis_n_name'];
            $dis_n_relationship=$_POST['dis_n_relationship'];
            $dis_c_address=$_POST['dis_c_address'];
            $dis_p_address=$_POST['dis_p_address'];
            $dis_district=$_POST['dis_district'];
            $dis_state=$_POST['dis_state'];
            $dis_city=$_POST['dis_city'];
            $dis_pin=$_POST['dis_pin'];
            $dis_mobile=$_POST['dis_mobile'];
            $dis_phone=$_POST['dis_phone'];
            $dis_email=$_POST['dis_email'];
            $dis_p_a_amount=$_POST['dis_p_a_amount'];
            $dis_id_proof=$_POST['dis_id_proof'];
            $dis_add_proof=$_POST['dis_add_proof'];
            $dis_dd=$_POST['dis_dd'];
            $dis_bank=$_POST['dis_bank'];
            $dis_branch=$_POST['dis_branch'];
            $dis_amount_no=$_POST['dis_amount_no'];
            $dis_amount_wo=$_POST['dis_amount_wo'];
            $dis_acc_bank_name=$_POST['dis_acc_bank_name'];
            $dis_acc_branch=$_POST['dis_acc_branch'];
            $dis_acc_ifsc=$_POST['dis_acc_ifsc'];
            $dis_acc_no=$_POST['dis_acc_no'];
            $dis_acc_name=$_POST['dis_acc_name'];
            $dis_qualification=$_POST['dis_qualification'];
            $dis_business=$_POST['dis_business'];
            $dis_emp_name=$_POST['dis_emp_name'];
            $dis_buss_no=$_POST['dis_buss_no'];
            $dis_annual_inc=$_POST['dis_annual_inc'];
            $dis_rd_1=$_POST['dis_rd_1'];
            $dis_rd_2=$_POST['dis_rd_2'];
            $dis_rd_3=$_POST['dis_rd_3'];
            $dis_rd_4=$_POST['dis_rd_4'];
            $dis_coupon_number=$_POST['dis_coupon_number'];
            $dis_pass_no=$_POST['dis_pass_no'];
            $dis_placement_req=$_POST['dis_placement_req'];
            $dis_sponsor_id=$_POST['dis_sponsor_id'];
            if(isset($_POST['dis_coupon'])){
            $dis_coupon=$_POST['dis_coupon'];}else{$dis_coupon="";}
            if(isset($_POST['shagun'])){
            $shagun=$_POST['shagun'];}else{$shagun="";}
            if(isset($_POST['defense'])){
            $defense=$_POST['defense'];}else{$defense="";}
            $login_id=$_SESSION['user'];
            $random=rand(100001,999999);
            $dis_company_id="pss".$random;
            $direct_id=$_POST['dis_d_person_id'];
           
         if(isset($_FILES['files'])) {  
	 move_uploaded_file($_FILES['files']['tmp_name'],"../image_uploads/".$_FILES['files']['name']);
         $file="../image_uploads/".$_FILES['files']['name'];
         if($_FILES['files']!=""){
$dis_image_path=$file;
    
}else{
    $dis_image_path="";
}  
         
         
         }else{
         $file=$_POST['files']; 
         $dis_image_path=$file;
         }
             
            $id_parent=$conn->get_admin_dis_id($con,$dis_sponsor_id);
            if($id_parent!=""){
            $count=$conn->get_admin_num_dis_spon_id($con,$id_parent);
            if($dis_sponsor_id=='pss100000'){
               
                 $res = $conn->insert_admin_distributor_detail($con,$dis_company_id,$dis_name,$dis_fa_name,$dis_dob,$dis_gender,$dis_m_status,$dis_n_name,$dis_n_relationship,$dis_c_address,
                    $dis_p_address,$dis_district,$dis_state,$dis_city,$dis_pin,$dis_mobile,$dis_phone,$dis_email,$dis_p_a_amount,$dis_id_proof,
                    $dis_add_proof,$dis_dd,$dis_bank,$dis_branch,$dis_amount_no,$dis_amount_wo,$dis_acc_bank_name,$dis_acc_branch,
                    $dis_acc_ifsc,$dis_acc_no,$dis_acc_name,$dis_qualification,$dis_business,$dis_emp_name,$dis_buss_no,$dis_annual_inc,
                    $dis_rd_1,$dis_rd_2,$dis_rd_3,$dis_rd_4,$dis_pass_no,$dis_placement_req,$dis_sponsor_id,$dis_coupon,$shagun,$defense,$login_id,$date_time,$dis_image_path,$dis_coupon_number,$direct_id);
                
                 if($res){
//                echo "successful";
                $id1=$conn->get_admin_dis_id($con,$dis_company_id);
                 $id2=$conn->get_admin_dis_id($con,$dis_sponsor_id);
                 $res=$conn->insert_admin_dis_in_tree($con,$id1,$dis_name,$id2,"");
                 if($res){
                    $res=$conn->update_admin_distributor_approve($con,$code);
                }if($res)
                $p++;
                 }
                 
                 
                
            }else{
            if($count==2 || $count==0){
               $status=$conn->get_admin_position_dis_spon_id($con,$id_parent,$dis_placement_req);
               if(($count==2 && $status=='blank') || $count==0){
            $res = $conn->insert_admin_distributor_detail($con,$dis_company_id,$dis_name,$dis_fa_name,$dis_dob,$dis_gender,$dis_m_status,$dis_n_name,$dis_n_relationship,$dis_c_address,
                    $dis_p_address,$dis_district,$dis_state,$dis_city,$dis_pin,$dis_mobile,$dis_phone,$dis_email,$dis_p_a_amount,$dis_id_proof,
                    $dis_add_proof,$dis_dd,$dis_bank,$dis_branch,$dis_amount_no,$dis_amount_wo,$dis_acc_bank_name,$dis_acc_branch,
                    $dis_acc_ifsc,$dis_acc_no,$dis_acc_name,$dis_qualification,$dis_business,$dis_emp_name,$dis_buss_no,$dis_annual_inc,
                    $dis_rd_1,$dis_rd_2,$dis_rd_3,$dis_rd_4,$dis_pass_no,$dis_placement_req,$dis_sponsor_id,$dis_coupon,$shagun,$defense,$login_id,$date_time,$dis_image_path,$dis_coupon_number,$direct_id);
        
            if($res){
//                echo "successful";
                $id1=$conn->get_admin_dis_id($con,$dis_company_id);
                 $id2=$conn->get_admin_dis_id($con,$dis_sponsor_id);
                
                 if($dis_placement_req=="right" && $count==2){
                     
                  $res=$conn->update_admin_tree_by_parent($con,$id1,$id2,$dis_name);  
                }
                if($dis_placement_req=="left" && $count==2){
                  $res=$conn->update_admin_tree_by_parent($con,$id1,$id2,$dis_name);  
                }
                if($dis_placement_req=="right" && $count==0){
                    $res=$conn->insert_admin_dis_in_tree($con,$id1,$dis_name,$id2,"right");
                    $b_id=$id1.'001';
                  $res=$conn->insert_admin_dis_in_tree($con,$b_id,"blank",$id2,"left");  
                }
                if($dis_placement_req=="left" && $count==0){
                  $res=$conn->insert_admin_dis_in_tree($con,$id1,$dis_name,$id2,"left");
                    $b_id=$id1.'002';
                  $res=$conn->insert_admin_dis_in_tree($con,$b_id,"blank",$id2,"right");  
                }
                
                
                
                 
//                $res=$conn->insert_admin_dis_in_tree($con,$id1,$dis_name,$id2);
                if($res){
                    $res=$conn->update_admin_distributor_approve($con,$code);
                }if($res)
                $p++;
            }
               }else{
                   $msg="selected position is already filled";
               }
            }
        }
        
            }else{
                $msg="wrong sponsor id";
            }
        
        
        
        }
        
        
        
        ?>


        <section id="main-wrapper">
            <?php 
            if(isset($p) && $p>0){
            
                echo 'success<br>';
                echo "user id is ".$dis_company_id;
//                echo $res;
            }if(isset($p) && $p<1){
               echo "failed "." ".$msg;
//                echo $res;
            }
//            echo $res;
            ?>
    <script>
    function approve(){
        app=$("#user_app_code").val();
        if(app!=""){
//        alert(app);
    $("#appove_load").load("dis_form.php",{"code":app});
    }else{
        $("#user_app_code").css("border-color","red");
        $("#user_app_code").attr("placeholder","please fill this field first");
    }
    }
    </script>
      <?php if(isset($_POST['save_bv_code'])){ if($q>0){ ?>
       <div class="alert alert-danger" id="msg">
  
       </div><?php } if($p>0){ ?>
            <div class="alert alert-success" id="msg_su">
  
       </div>
       <?php } } ?>
    
        <?php 
        $user_id=$_SESSION['user'];
        $user_cmpny_id=$conn->get_admin_login_name($con,$user_id);
        $res=$conn->get_admin_distributor_detail_by_cmpny_id($con,$user_cmpny_id);
        $row=  mysqli_fetch_array($res);
        $user_bv=$row['distributor_bv'];
        ?>
    
    
		<h3 class="subtitle">Add B.V. to your Account</h3>
          <hr>
         
         
		  <div class="row" id="appove_load">
			  <div class="col-md-12">
                              <div class="col-md-2" style="margin-top:5px;font-size: 18px;" ><strong>Approval Code</strong></div>
                              <div class="col-md-8" ><input type="text" name="user_app_code" class="form-control" id="user_app_code" placeholder="Approval Code"></div>
                              <div class="col-md-2" ><input type="submit" name="save_app_code"  value="Check" class="btn btn-success" onclick="approve()" ></div>
                          </div>
				
                  </div>
          
</section>


<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<div class="offline-ui offline-ui-up"><div class="offline-ui-content"></div><a href="" class="offline-ui-retry"></a>
</div>
</body>
</html>
<?php
 } 
?>