<?php
session_start();
if(!isset($_SESSION['user']))
{
	header("Location: index.php");
}
else
{
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Dashboard</title>
<meta name="description" content="Flatter - Flat Admin Theme">
<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/layout.css">
<link rel="stylesheet" href="css/style3.css">
<script type="text/javascript" src="js/jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.10.4.custom.min.js"></script>
</head>
<body id="body">

		<!-- Header -->
		<?php include './header.php'; ?>

       <?php include './left-menu.php'; ?>
		<!-- Header -->
		
<section id="main-wrapper">
		<h3 class="subtitle">Add Page</h3>
          <hr>

		  <div class="row">
			  <div class="col-md-12">
				  	<div class="panel panel-default">
					  <div class="panel-heading">
					   <div align="left"> <h3 class="panel-title"><strong>Page Creation</strong></h3></div>
	<div align="right"> <button type="button" class="btn btn-success" data-toggle="modal" data-target="#myModal">Upload Website Picture</button></div>
	 
<?php
if(isset($_POST['btn_save']))
{
	
				$page_name=$_POST['page_name'];
				$page_description=$_POST['page_description'];
				$res = $conn->insert_admin_page($con,$page_name,$page_description,$date_time);
	if($res){
	?>
	<br>
			<div class='alert alert-success'><strong>Page Created successfully</strong></div>
			<?php
		}
		else
		{
	?>
      echo"<div class='alert alert-danger'><strong>Page not Created!</strong></div>"; 
	 <?php
		}

}
?>

		
					  </div>
					  <div class="panel-body">
					  <form method="POST" enctype="multipart/form-data" name="image_upload">
						<table class="table">
					        <tr>
							  <td><strong>Page Name</strong></td>
							  <td>
							 <input type="text" name="page_name" class="form-control" required="required">
							  </td>
					        </tr>
							 <tr>
							  <td><strong>Page Description</strong></td>
							  <td>
							 <textarea rows="5" name="page_description" class="form-control"></textarea>
							  </td>
					        </tr>
							
							 <tr>
							  <td></td>
							  <td>
<button type="submit" name="btn_save" class="btn btn-info" style="background-color:#3ba0ff;"><i class="fa fa-upload"></i> Add</button>
<button type="reset" name="cancel" class="btn btn-info" style="background-color:#3ba0ff;"><i class="fa fa-refresh"></i> Reset</button>
							  </td>
					        </tr>
					    </table>
						</form>
					  </div>
					</div>
				</div>
</div>

				

</section>


<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<div class="offline-ui offline-ui-up"><div class="offline-ui-content"></div><a href="" class="offline-ui-retry"></a>
</div>
</body>
</html>
<?php
 } 
?>


<div class="container">
  <!-- Trigger the modal with a button -->
  

  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Upload Picture</h4>
        </div>
        <div class="modal-body">
          <p>Some text in the modal.</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  
</div>