
          	<div class="row">
			  <div class="col-md-12">
				  	<div class="panel panel-default">
					  <div class="panel-heading">
					    <h3 class="panel-title">Simple Wizard</h3>
					    			
					  </div>
					  <div class="panel-body fuelux">
						   <div id="MyWizard" class="wizard">
								<ul class="steps">
									<li data-target="#step1" class="active"><span class="badge badge-info">1</span>Basic Info<span class="chevron"></span></li>
									<li data-target="#step2"><span class="badge">2</span>Product<span class="chevron"></span></li>
									<li data-target="#step3"><span class="badge">3</span>Payment<span class="chevron"></span></li>
								</ul>
							</div>
							<div class="step-content">

								<div class="margintop"></div>
								<!-- Form starts first-->
								<form class="form-horizontal" role="form">
								<!-- Wizard step 1 -->
								<div class="step-pane active" id="step1">
												  <div class="form-group">
												    <label for="inputEmail3" class="col-sm-2 control-label">Name</label>
												    <div class="col-sm-10">
												      <input type="text" class="form-control" id="inputEmail3" placeholder="Name">
												    </div>
												  </div>

												  <div class="form-group">
												    <label for="inputEmail3" class="col-sm-2 control-label">Email</label>
												    <div class="col-sm-10">
												      <input type="email" class="form-control" id="inputEmail3" placeholder="Email">
												    </div>
												  </div>

												  <div class="form-group">
												    <label for="inputEmail3" class="col-sm-2 control-label">Phone</label>
												    <div class="col-sm-10">
												      <input type="text" class="form-control" id="inputEmail3" placeholder="Phone Number">
												    </div>
												  </div>

												  <div class="form-group">
												    <label for="inputEmail3" class="col-sm-2 control-label">Address</label>
												    <div class="col-sm-10">
												      <textarea class="form-control" placeholder="Write Complete Address" rows="3"></textarea>
												    </div>
												  </div>
								</div>
								<!-- Wizard step 2 -->
								<div class="step-pane" id="step2">
									<!-- Wizard step 2 form -->
												  <div class="form-group">
												    <label for="inputEmail3" class="col-sm-2 control-label">Product Name</label>
												    <div class="col-sm-10">
												      <input type="text" class="form-control" id="inputEmail3" placeholder="Name">
												    </div>
												  </div>

												  <div class="form-group">
												    <label for="inputEmail3" class="col-sm-2 control-label">Product Color</label>
												    <div class="col-sm-10">
												    	<select class="form-control">
														  <option>Blue</option>
														  <option>Green</option>
														  <option>Red</option>
														  <option>Orange</option>
														  <option>White</option>
														</select>
												    </div>
												  </div>
								</div>
								<!-- Wizard step 3 -->
								<div class="step-pane" id="step3">
												  <div class="form-group">
												    <label for="inputEmail3" class="col-sm-2 control-label">Credit Card</label>
												    <div class="col-sm-10">
												      <input type="text" class="form-control" id="inputEmail3" placeholder="Credit Card Number">
												    </div>
												  </div>

												  <div class="form-group">
												    <label for="inputEmail3" class="col-sm-2 control-label">CVV</label>
												    <div class="col-xs-3">
												    	<input type="text" class="form-control" id="inputEmail3" placeholder="CVV">
												    </div>
												  </div>
											</form>
								</div>

								<div class="actions">
								<button href="#" type="button" class="btn btn-danger btn-previous">Previous</button>
								<button href="#" type="button" class="btn btn-info btn-next pull-right">Next</button>
								</div>

								</form><!-- form ends -->

							</div>
					  </div>
					</div>
				</div>
          	</div>


		  	<!-- Second row -->
		  	<div class="row">
			  <div class="col-md-12">
				  	<div class="panel panel-default">
					  <div class="panel-heading">
					    <h3 class="panel-title">Wizard with Validation</h3>
					    			
					  </div>
					  <div class="panel-body fuelux">
						   <div id="MyWizard" class="wizard">
								<ul class="steps">
									<li data-target="#step4" class="active"><span class="badge badge-info">1</span>Basic Info<span class="chevron"></span></li>
									<li data-target="#step5"><span class="badge">2</span>Product<span class="chevron"></span></li>
									<li data-target="#step6"><span class="badge">3</span>Payment<span class="chevron"></span></li>
								</ul>
							</div>
							<div class="step-content">

								<div class="margintop"></div>
								<form class="form-horizontal" role="form" id="wizardForm">
								<!-- Wizard step 1 -->
								<div class="step-pane active" id="step4">
										<!-- Wizard step 1 form -->
										  <div class="form-group">
												    <label for="inputEmail3" class="col-sm-2 control-label">Name</label>
											<div class="col-sm-10">
												<input type="text" name="name" class="form-control" minlength="3" id="name" placeholder="Name (Minimum 4 characters)" required>
										    </div>
									       </div>


								</div>
								<!-- Wizard step 2 -->
								<div class="step-pane" id="step5">
									<!-- Wizard step 2 form -->
										  <div class="form-group">
												    <label for="inputEmail3" class="col-sm-2 control-label">Email</label>
											<div class="col-sm-10">
												<input type="email" name="email" class="form-control" id="email" placeholder="Enter Valid Email" required>
										    </div>
									       </div>
								</div>
								<!-- Wizard step 3 -->
								<div class="step-pane" id="step6">
									<div class="form-group">
									 <label for="inputEmail3" class="col-sm-2 control-label">Credit Card</label>
									 <div class="col-sm-10">
									   <input type="text" class="form-control" id="inputEmail3" placeholder="Credit Card Number">
									 </div>
								   </div>

								  <div class="form-group">
									 <label for="inputEmail3" class="col-sm-2 control-label">CVV</label>
									 <div class="col-xs-3">
									 	<input type="text" class="form-control" id="inputEmail3" placeholder="CVV">
									 </div>
								  </div>
								</div>

								<div class="actions">
								<button href="#" type="button" class="btn btn-danger btn-previous">Previous</button>
								<button href="#" type="submit" class="btn btn-info btn-next-validate pull-right">Next</button>
								</div>
								</form>
							</div>
					  </div>
					</div>
				</div>
          	</div>
		
