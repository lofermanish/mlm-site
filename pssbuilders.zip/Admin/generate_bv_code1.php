<?php
session_start();
if(!isset($_SESSION['user']))
{
	header("Location: index.php");
}
else
{
?>
<!DOCTYPE html>
<!-- saved from url=(0038)http://flatter.cloudtub.com/index.html -->
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Dashboard</title>
<meta name="description" content="Flatter - Flat Admin Theme">
<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/layout.css">
<link rel="stylesheet" href="css/style3.css">
<script type="text/javascript" src="js/jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.10.4.custom.min.js"></script>
<style>
.imgsize
{
	height:30px; 
	width:30px;
}
</style>
</head>
<body id="body">

		<!-- Header -->
		<?php include './header.php'; ?>

       <?php include './left-menu.php'; ?>
		<!-- Header -->
                
                
                
                
                
<section id="main-wrapper">
    
     
       
		<h3 class="subtitle">Generate BV Code</h3>
          <hr>
          <form method="post" action="#">
		  <div class="row">
			  <div class="col-md-12">
                              
                              <div class="col-md-1" style="margin-top:5px;font-size: 18px;" ><strong>B.V.</strong></div>
                              <div class="col-md-6" ><input type="text" name="user_bv" class="form-control" id="user_bv" placeholder="B.V."   required></div>
							 
								<div class="col-md-2" ><input type="text" name="no_of_bv" class="form-control" id="no_of_bv" placeholder="No of BV"   required></div>
							
							   <div class="col-md-2" ><input type="submit" name="generate_bv" class="btn btn-danger" id="generated_bv" value="generate "  >
							  </div></div> </div> <br><br>
							 
							
							  <?php 
							  if(isset($_POST['generate_bv']))
							  {
								  $user_bv=$_POST['user_bv']; 
								  $no_of_bv=$_POST['no_of_bv'];
							  $i=1;
							 
							while($i<=$no_of_bv)
							 {
								?>
						  <script>
								 bv=$("#user_bv").val();
								 document.write(bv);
        if(bv!=""){
            var float= /^\s*(\+|-)?((\d+(\.\d+)?)|(\.\d+))\s*$/;
            if(float.test(bv)){
        <?php  $ss = substr(str_shuffle(str_repeat("0123456789abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ", 5)), 0, 16); ?>
//             
		}
		else{
			$("#user_bv").css("border-color","red");
        $("#user_bv").attr("placeholder","please fill this field first");

			
		}}
							  </script>   <table class="table">
						<tr><td>	<?php echo $i?> </td><td>Code Value<?php echo $user_bv?></td><td><input type="text" value="<?php echo $ss?>" name="bv_code" class="form-control"></td></tr><br>
							 </table> </form>
							  <?php 
							 @$bv_code=$_POST['bv_code'];
								echo $bv_code;
							//
							 $i++;
							  }?>
							<form>     <input type="submit" name="save" value="save" class="btn btn-danger"></form>
							<?php  }
								  ?>
                           
						   
                            
							 <?php if(isset($_POST['save']))
							 {
								 $i=1;
								 foreach($bv_code[arr] as $bv_code1[])
								 
								 {
									$res=$conn->insert_admin_bv_code($con,$user_bv,$bv_code1[],$date_time); 
								 }
							 }
						?>
				

</section>


<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<div class="offline-ui offline-ui-up"><div class="offline-ui-content"></div><a href="" class="offline-ui-retry"></a>
</div>
</body>
</html>
<?php }?>