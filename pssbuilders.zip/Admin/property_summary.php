<?php
	session_start();
//include_once 'db.php';

if(!isset($_SESSION['user_id']))
{
	header("Location: customer-zone.php");
}
else
{
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>PSS Builder || Home</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php include"script-css.php"; ?>
  <style>
  a:hover
  {
    color: white !important;
  }
  </style>

<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.12/css/jquery.dataTables.min.css"/>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/1.2.1/css/buttons.dataTables.min.css"/>
<script type="text/javascript" src="https://cdn.datatables.net/r/bs-3.3.5/jqc-1.11.3,dt-1.10.8/datatables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.1/js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.1/js/buttons.flash.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js"></script>
<script type="text/javascript" src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/pdfmake.min.js"></script>
<script type="text/javascript" src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/vfs_fonts.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.1/js/buttons.html5.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.1/js/buttons.print.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/plug-ins/1.10.11/api/sum().js"></script>
<script type="text/javascript" src="js/jquery-easing.js"></script>
<script type="text/javascript" charset="utf-8">
			$(document).ready(function() {
				$('.example').DataTable(               
    {
        drawCallback: function ( row, data, start, end, display ) {
//            alert("hello");
            var api = this.api(), data;
 
            // Remove the formatting to get integer data for summation
            var intVal = function ( i ) {
                return typeof i === 'string' ?
                    i.replace(/[\$,]/g, '')*1 :
                    typeof i === 'number' ?
                        i : 0;
            };
 
            // Total over all pages
            total = api
                .column( 3 )
                .data()
                .reduce( function (a, b) {
                    return intVal(a) + intVal(b);
                }, 0 );
 
            // Total over this page
            pageTotal = api
                .column( 3, { page: 'current'} )
                .data()
                .reduce( function (a, b) {
                    return intVal(a) + intVal(b);
                }, 0 );
 
            // Update footer
            $( api.column( 3 ).footer() ).html(
                'Rs:'+pageTotal +' (Rs:'+ total +' total)'
            );
        }
    }
                );
			} );
		</script>
                <script type="text/javascript">
	// For demo to fit into DataTables site builder...
	$('.example')
		.removeClass( 'display' )
		.addClass('table table-striped table-bordered');
        
        
       
       
</script>

</head>
<body id="icon_value">
	<?php include"menu.php"; ?>
	<?php
@session_start();
 include_once 'property/pss_db.php';
 $applicant_id=$_SESSION['user_id'];
                    $conn = new DB_con();
                    $con = $conn->connection();
                    $functions = new functions();
					
?>
	 <div class="pg-opt"  style="background-color:#3ba0ff;" >
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h2 style="color:white !important;">Customer Zone</h2>
                </div>
                <div class="col-md-6">
                    <ol class="breadcrumb">
                        <li><a href="index.php">Home</a></li>
                        <li style="color:white !important;" class="active">Customer Zone</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
   
	<section class="slice bg-white">
        <div class="wp-section">
            <div class="container">
                <div class="row">
				
  <div class="col-sm-12 text-right"><a href="logout.php?logout" class="btn btn-danger"><i class="fa fa-share"></i> Logout</a></div>

                    <div class="col-md-12">
                         
                            
							<?php //echo $_SESSION['user_id']; ?>
                            
							
							
							
							<section id="main-wrapper">
			
		  <div class="container">   
		  
		  
		   <section id="main-wrapper">
                <form method="post" action="#">
                    <div class="row">

                       

                        <div class="col-md-12" id="payment_detail"><br>

    <table class="table example">
	<br>
        <thead><tr>
                <th>S.No.</th>
                <th>Client Name</th>
                <th>Ploat Number</th>
                <th>Amount Paid</th>
                <th>Total Amount</th>
                <th>Date</th>
				<th>Action</th>
            </tr></thead>
        <?php 
        $client_detail=$conn->get_admin_customer_applicant_details($con,$applicant_id);
       // $client_detail_row=mysqli_fetch_array($client_detail);
       // $client_idd=$client_detail_row['applicant_id'];
       // $plot_detail_res=$conn->get_plot_detail($con,$client_idd);
      //  $plot_detail_row=  mysqli_fetch_array($plot_detail_res);
      //  $client_payment_detail=$conn->get_client_payment_detail($con,$applicant_id);
//        $client_payment_detail_res=  mysqli_fetch_array($client_payment_detail);
        $i=0;
        while($client_payment_detail_row=mysqli_fetch_array($client_detail)){
            $transaction_id=$client_payment_detail_row['transaction_id'];
            //echo"$transaction_id";
        ?>
        
        <tr>
            <td><?php echo ++$i; ?></td>
            <td><?php echo $client_payment_detail_row['applicant_name'];  ?></td>
            <td><?php echo $client_payment_detail_row['plot_price_details_plot_no']; ?></td>
            <td><?php echo $client_payment_detail_row['transaction_amount']; ?></td>
            <td><?php echo $client_payment_detail_row['applicant_fund_detail']; ?></td>
            <td><?php echo $client_payment_detail_row['transaction_date']; ?></td>
            <td><a href="#" class="btn btn-success" onclick="icon_detail('<?php echo $transaction_id; ?>')">Print Receipt</a></td>
            
        </tr>
        <?php   } ?>
           <tfoot>
        <tr>
            <th style="text-align:right" colspan="3">Total:</th>
            <th style="text-align:left" colspan="3"></th>
        </tr>
    </tfoot>
    </table>
    
	
	
	
	
 <?php   
}
 ?>	

                        </div>

                      

                    </div></form>

            </section>
		  
		 
  
</div>
          </div>
          </section>

 <div class="modal fade" id="print" role="dialog">
    <div class="modal-dialog modal-lg">
    
      <!-- Modal content-->

      
    </div>
  </div>



<script>
   function icon_detail(fa_fa_icon_id){

        $("#icon_value").load('get_data.php', {"icon_id": fa_fa_icon_id});
		//alert('welcome icon');
    }
</script>
                       
                    </div>
                </div>
            </div>
        </div>
    </section>
	
    <?php include"footer.php"; ?>

</body>
</html>
