<?php
session_start();
if(!isset($_SESSION['user']))
{
	header("Location: index.php");
}
else
{
?>
<!DOCTYPE html>
<!-- saved from url=(0038)http://flatter.cloudtub.com/index.html -->
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Dashboard</title>
<meta name="description" content="Flatter - Flat Admin Theme">
<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/layout.css">
<link rel="stylesheet" href="css/style3.css">
<script type="text/javascript" src="js/jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.10.4.custom.min.js"></script>
<style>
.imgsize
{
	height:30px; 
	width:30px;
}
</style>

</head>
<body id="body">

		<!-- Header -->
		<?php include './header.php'; ?>

       <?php include './left-menu.php'; ?>
		<!-- Header -->
		
<section id="main-wrapper">
		<h3 class="subtitle">News Details</h3>
          <hr>

		  <div class="row">
			  <div class="col-md-12">
				  	<div class="panel panel-default">
					  <div class="panel-heading">
					    <h3 class="panel-title"><strong>News Details</strong></h3> 
					  </div>

					  <div class="panel-body">
					  		<table cellpadding="0" cellspacing="0" border="0"
					  		class="table table-striped table-bordered editable-datatable">
									<thead>
									<tr>
									    <th>S.No.</th>
										<th>Plot No.</th>
										<th>Plot Name</th>
										<th>Plot Width</th>
										<th>Plot Height</th>
										<th>Plot Price</th>
										<th>Plot Availability</th>
										<th>Plot Date</th>
										<th>Delete</th>
									</tr>
								</thead>
								<tbody>
								<?php
								$count=0;
				 $res = $conn->get_admin_get_admin_plot_details($con);
				 while ($row = mysqli_fetch_array($res)) {
				 $plot_price_details_id=$row['plot_price_details_id'];
				 $count=$count+1;
				 ?>
	<tr class="1">
	<td><?php echo $count; ?></td>
	<td><?php echo $row['plot_price_details_name']; ?></td>
	<td><?php echo $row['plot_price_details_plot_no']; ?></td>
	<td><?php echo $row['plot_price_details_height']; ?></td>
	<td><?php echo $row['plot_price_details_width']; ?></td>
	<td><?php echo $row['plot_price_details_amount']; ?></td>
	<td><?php echo $row['plot_price_details_plot_availability']; ?></td>
	<td><?php echo $row['plot_price_details_date']; ?></td>
	<td><a class="delete" href="delete_price_details.php?plot_price_details_id=<?php echo"$plot_price_details_id"; ?>">Delete</a></td>
	</tr>
				<?php }?>					
								</tbody>

								</table>

					  </div>
					</div>
				</div>
				
</div>

</section>


<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<div class="offline-ui offline-ui-up"><div class="offline-ui-content"></div><a href="" class="offline-ui-retry"></a>
</div>
</body>
</html>
<?php
 } 
?>