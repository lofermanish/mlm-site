<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: index.php");
} else {
    ?>
    <!DOCTYPE html>

    <html>
        <head>
            <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
            <title>Dashboard</title>
            <meta name="description" content="Flatter - Flat Admin Theme">
            <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0">
            <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
            <link rel="stylesheet" href="css/bootstrap.min.css">
            <link rel="stylesheet" href="css/layout.css">
            <link rel="stylesheet" href="css/style3.css">
            <script type="text/javascript" src="js/jquery-1.11.0.min.js"></script>
            <script type="text/javascript" src="js/jquery-ui-1.10.4.custom.min.js"></script>
            
            
             <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/r/bs-3.3.5/jq-2.1.4,dt-1.10.8/datatables.min.css"/>
         <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.12/css/jquery.dataTables.min.css"/>
          <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/1.2.1/css/buttons.dataTables.min.css"/>
            <script type="text/javascript" src="https://cdn.datatables.net/r/bs-3.3.5/jqc-1.11.3,dt-1.10.8/datatables.min.js"></script>
                    <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.1/js/dataTables.buttons.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.1/js/buttons.flash.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js"></script>
        <script type="text/javascript" src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/pdfmake.min.js"></script>
        <script type="text/javascript" src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/vfs_fonts.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.1/js/buttons.html5.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.1/js/buttons.print.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/plug-ins/1.10.11/api/sum().js"></script>
               <script type="text/javascript" src="js/jquery-easing.js"></script>
            <style>
                .imgsize
                {
                    height:30px; 
                    width:30px;
                }
            </style>
            
            <script type="text/javascript" charset="utf-8">
			$(document).ready(function() {
				$('.example').DataTable(
//        {
//        dom: 'Bfrtip',
//        buttons: [
//            'copy', 'csv', 'excel', 'pdf', 'print','pageLength'
//        ]
//    },
//           {
//        dom: 'Bfrtip',
//        lengthMenu: [
//            [ 10, 25, 50, -1 ],
//            [ '10 rows', '25 rows', '50 rows', 'Show all' ]
//        ]
//    },                                  
    {
        drawCallback: function ( row, data, start, end, display ) {
            var api = this.api(), data;
 
            // Remove the formatting to get integer data for summation
            var intVal = function ( i ) {
                return typeof i === 'string' ?
                    i.replace(/[\$,]/g, '')*1 :
                    typeof i === 'number' ?
                        i : 0;
            };
 
            // Total over all pages
            total = api
                .column( 3 )
                .data()
                .reduce( function (a, b) {
                    return intVal(a) + intVal(b);
                }, 0 );
 
            // Total over this page
            pageTotal = api
                .column( 3, { page: 'current'} )
                .data()
                .reduce( function (a, b) {
                    return intVal(a) + intVal(b);
                }, 0 );
 
            // Update footer
            $( api.column( 3 ).footer() ).html(
                '$'+pageTotal +' ( $'+ total +' total)'
            );
//        }
    }
                );
			} );
		</script>
                <script type="text/javascript">
	// For demo to fit into DataTables site builder...
	$('.example')
		.removeClass( 'display' )
		.addClass('table table-striped table-bordered');
        
        
        
        
        
        
       
</script>
<script>
//$(document).ready(function() {
//    $('#example').DataTable( {
//        "footerCallback": function ( row, data, start, end, display ) {
//            var api = this.api(), data;
// 
//            // Remove the formatting to get integer data for summation
//            var intVal = function ( i ) {
//                return typeof i === 'string' ?
//                    i.replace(/[\$,]/g, '')*1 :
//                    typeof i === 'number' ?
//                        i : 0;
//            };
// 
//            // Total over all pages
//            total = api
//                .column( 3 )
//                .data()
//                .reduce( function (a, b) {
//                    return intVal(a) + intVal(b);
//                }, 0 );
// 
//            // Total over this page
//            pageTotal = api
//                .column( 3, { page: 'current'} )
//                .data()
//                .reduce( function (a, b) {
//                    return intVal(a) + intVal(b);
//                }, 0 );
// 
//            // Update footer
//            $( api.column( 3 ).footer() ).html(
//                '$'+pageTotal +' ( $'+ total +' total)'
//            );
//        }
//    } );
//} );
</script>
            
            
        </head>
        <body id="body">

            <!-- Header -->
    <?php include './header.php'; ?>

            <?php include './left-menu.php'; ?>
            <!-- Header -->



            <script>
            $(document).ready(function(){
               
                $("#user_id").change(function(){
                     var user_id=$("#user_id").val();
                     if(user_id!=""){
//                   alert(user_id);
                $("#payment_detail").load("get-data.php",{"client_payment_username":user_id});

               }else{
                   $("#payment_detail").load("get-data.php");
               }
                });
            });
            </script>

            <section id="main-wrapper">
    
                
   



                <h3 class="subtitle">Client Payment Detail</h3>
                <hr>

                <form method="post" action="#">
                    <div class="row">

                        <div class="col-md-12" id="trans_info">
                             <?php 
                                  $res=$conn->get_admin_applicant_detail($con);
                                  ?>
                                  <label>Client Name</label>
                                  <select class="form-control" name="user_id" id="user_id">
                                      <option value="">Select Clients</option>
                                      <?php while($row=  mysqli_fetch_array($res)){ 
									  
										  ?>
                                      <option value="<?php echo $row['applicant_detail_username']; ?>"> <?php echo $row['applicant_name']." (".$row['applicant_detail_username'].")"; ?></option>
                                      <?php } ?>
                                  </select>
                            
                        </div>

                        <div class="col-md-12" id="payment_detail"><br>



                        </div>

                      

                    </div></form>

            </section>


            <script type="text/javascript" src="js/bootstrap.min.js"></script>
            <script type="text/javascript" src="js/jquery.mCustomScrollbar.concat.min.js"></script>
            <script type="text/javascript" src="js/script.js"></script>
            <div class="offline-ui offline-ui-up"><div class="offline-ui-content"></div><a href="" class="offline-ui-retry"></a>
            </div>
        </body>
    </html>
    <?php
}
?>