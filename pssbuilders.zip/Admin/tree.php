
<script>
    function user(user_id){
//        alert(user_id);
      $("#u_id").val(user_id);
      $("form").submit();
//        $.post("customer_tree.php",{"u_id":user_id});
    }
    </script>
<?php if($_SESSION['user']==1){ ?>
<!DOCTYPE HTML>
<html>
    <?php 
    $id=1;
    if(isset($_REQUEST['u_id']) &&  $_REQUEST['u_id']!=""){
//        $id=$_REQUEST['u_id'];
        $comp_id=$_REQUEST['u_id'];
        $id=$conn->get_admin_dis_id($con,$comp_id);
    }else{
        $id=1;
    }
    ?>
    <head runat="server">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <title>jQuery Tree</title>
        <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Cabin:400,700,600"/>
        <link href="style.css" rel="stylesheet" type="text/css">
        <script src="js/jquery-1.11.1.min.js"></script>
        <script src="js/jquery-migrate-1.2.1.min.js"></script>
        <script src="js/jquery-ui.js"></script>
        <script src="js/jquery.tree.js"></script>
<!--        <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
        <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>-->
        <script>
$(document).ready(function(){
//    $('[data-toggle="tooltip"]').tooltip();   
//  $('#popoverData').popover();
  $('[data-toggle="popover"]').popover({
        container: 'body' // Popover scrolls with body
    });   
});
</script>

        <script>
            $(document).ready(function() {
                $('.tree').tree_structure({
//                    'add_option': true,
//                    'edit_option': true,
//                    'delete_option': true,
//                    'confirm_before_delete': true,
                    'animate_option': true,
                    'fullwidth_option': false,
                    'align_option': 'center',
//                    'draggable_option': true
                });
            });
          
        </script>
       
    </head>
    <body>
        <form action="#" method="post">
            <div class="col-sm-10"> Enter Id to Search:<input type="text" name="u_id" id="u_id" class="form-control"  placeholder="Enter Down Line Member PSS id"></div>
        <div class="col-sm-2"  style="text-align: right"> <br><input type="submit" name="search" class="btn btn-success" value="Search" style="text-align: center"></div></form>
        <!--<div class="col-sm-2" style="text-align: right"> <br><a href="logout.php?logout"><input type="submit" name="Logout" value="Logout" class="btn btn-danger"></a></div>-->
        <?php
//        include_once 'db.php';
//        $page=1;
//include_once '../property/dbMysql.php';
//$conn = new DB_con();
//$con=$conn->connection();
//include_once 'property/function_list.php';
//include_once 'property/default_values.properties';
$functions=new functions();
                function countt($id,$con){
                    $i=0;
                    $query=mysqli_query($con,"select * from tree where parent_id='$id' order by position");
                    while( $rr=  mysqli_fetch_array($query)){
                      
                      $pp[$i]=$rr;
                      $i++;
                  }
                  if($i==2){
                      if($pp[0][1]!='blank'){
                       $count_left=countt($pp[0][0],$con);   
                       $count_left++;
//                       echo $connt_left;
                      }else {
                          $count_left=0;                          
                      }
                      if($pp[1][1]!='blank'){
                           $count_right=countt($pp[1][0],$con); 
                           $count_right++;
                      }else{
                          $count_right=0;    
                      }
                     $counttt= $count_left+$count_right;
                     return $counttt;
                  }if($i==0){
                   return 0;   
                  }
                }
                
                
                
                 function countbv($id,$con){
                    $i=0;
                    $query=mysqli_query($con,"select * from tree where parent_id='$id' order by position");
                    while( $rr=  mysqli_fetch_array($query)){
                      
                      $pp[$i]=$rr;
                      $i++;
                  }
                  if($i==2){
                      if($pp[0][1]!='blank'){
                       $count_left_bv=countbv($pp[0][0],$con); 
                       $user_left_idd=$pp[0][0];
                       $sql=  mysqli_query($con, "select distributor_bv from distributor_detail where distributor_id='$user_left_idd'");
                       $rowss=  mysqli_fetch_array($sql);
                       $count_left_bv=$count_left_bv+$rowss['distributor_bv'];
//                       echo $connt_left;
                      }else {
                          $count_left_bv=0;                          
                      }
                      if($pp[1][1]!='blank'){
                           $count_right_bv=countbv($pp[1][0],$con); 
                            $user_right_idd=$pp[1][0];
                       $sql=  mysqli_query($con, "select distributor_bv from distributor_detail where distributor_id='$user_right_idd'");
                       $rowss=  mysqli_fetch_array($sql);
                           $count_right_bv=$count_right_bv+$rowss['distributor_bv'];
                      }else{
                          $count_right_bv=0;    
                      }
                     $counttt= $count_right_bv+$count_left_bv;
                     return $counttt;
                  }if($i==0){
                   return 0;   
                  }
                }
                
		function in_parent($in_parent, $store_all_id, $con,$p) {
                    $p++;
            if (in_array($in_parent, $store_all_id)) {
                
                $result = mysqli_query($con, "SELECT * FROM tree where parent_id = '$in_parent' order by position ");
                echo $in_parent == 0 ? "<ul class='tree'>" : "<ul>";
                while ($row = mysqli_fetch_array($result)) {
                    $res=  mysqli_query($con, "select * from distributor_detail where distributor_id='".$row['id']."'");
                    $rows=  mysqli_fetch_array($res);
                     $res_date=  mysqli_query($con, "select date(distributor_creation_date) as joining from distributor_detail where distributor_id='".$row['id']."'");
                    $rows_date=  mysqli_fetch_array($res_date);
//                    $bv=$rows['distributor_bv'];
//                    if($bv>0){
//                        
//                    }
                    $left=mysqli_query($con,"select * from tree where parent_id = '$row[id]' order by position");
                   
                  $pp=array();
                  $i=0;
                  $count_left=0;
                  $count_right=0;
                  while( $rr=  mysqli_fetch_array($left)){
                     
                      $pp[$i]=$rr;
                       $i++;
                  }
                  if($i==2){
                      if($pp[0][1]!='blank'){
                          $id=$pp[0][0];
                       $count_left=countt($id,$con); 
                       $count_left++;
                      }else {
                          $count_left=0;                          
                      }
                      if($pp[1][1]!='blank'){
                          $idd=$pp[1][0];
                         $count_right=countt($idd,$con); 
                         $count_right++;
                      }else {
                          $count_right=0;                          
                      }
                  }
                  $count_left_bv=0;
                  $count_right_bv=0;
                  
                  if($i==2){
                      if($pp[0][1]!='blank'){
                       $count_left_bv=countbv($pp[0][0],$con); 
                       $user_left_idd=$pp[0][0];
                       $sql=  mysqli_query($con, "select distributor_bv from distributor_detail where distributor_id='$user_left_idd'");
                       $rowss=  mysqli_fetch_array($sql);
                       $count_left_bv=$count_left_bv+$rowss['distributor_bv'];
//                       echo $connt_left;
                      }else {
                          $count_left_bv=0;                          
                      }
                      if($pp[1][1]!='blank'){
                           $count_right_bv=countbv($pp[1][0],$con); 
                            $user_right_idd=$pp[1][0];
                       $sql=  mysqli_query($con, "select distributor_bv from distributor_detail where distributor_id='$user_right_idd'");
                       $rowss=  mysqli_fetch_array($sql);
                           $count_right_bv=$count_right_bv+$rowss['distributor_bv'];
                      }else{
                          $count_right_bv=0;    
                      }
//                     $counttt= $count_right_bv+$count_left_bv;
//                     return $counttt;
                  }
//                  $qq=$pp[1][1];
                    echo "<li";
//                    if ($row['hide'])
                    if($p>1)
                        echo " class='thide'";
//                    $p++;
//                    echo $p;
                    echo "><div id='" . $row['id'] ."'> <a onclick=user('$rows[distributor_company_id]') data-toggle='popover' class='col-sm-12' data-html='true' href='#' data-content='<table class=table-condensed><tr><td><b>Name:</b></td><td> $row[first_name] </td></tr><tr><td><b>Total Joining</b> :</td> <td>left- $count_left right- $count_right </td></tr><tr><td> <b>Total B.V. :</b> </td><td> Left- $count_left_bv  Right- $count_right_bv </td></tr><tr><td> <b>Company Id:</b> </td><td> $rows[distributor_company_id] </td></tr><tr><td> <b>Added With:</b> </td><td> $rows[distributor_bv] B.V.</td></tr></table>' rel='popover' data-placement='top' data-original-title='Person Detail' data-trigger='hover' style='text-decoration:none; color:black' font-weight:bolder><img src='male.jpg' alt='male' ><br>" . $row['first_name'] ."<br>".$rows['distributor_company_id']. "</a><br></div>";
                    in_parent($row['id'], $store_all_id, $con,$p);
                    echo "</li>";
                }
                echo "</ul>";
           
                }
        }
        $store_all_id = array();
        $id_result = mysqli_query($con, "SELECT * FROM tree");
        while ($all_id = mysqli_fetch_array($id_result)) {
            array_push($store_all_id, $all_id['parent_id']);
        }
        echo "<div class='col-md-12'>";
//        in_parent(0, $store_all_id, $con);
         $result = mysqli_query($con, "SELECT * FROM tree where id = '$id' order by first_name");
         $row = mysqli_fetch_array($result);
         $res=  mysqli_query($con, "select * from distributor_detail where distributor_id='".$row['id']."'");
                    $rows=  mysqli_fetch_array($res);
                    
          echo "<ul class='tree'>";
          echo "<li";
                    if ($row['hide'])
                        echo " class='thide'";
                    echo "><div id=" . $row['id'] . "><a onclick=user('$rows[distributor_company_id]')  data-toggle='popover' class='col-sm-12' data-html='true' href='#' data-content='Name: $row[first_name] <br> Company Id: $rows[distributor_company_id] ' rel='popover' data-placement='top' data-original-title='Person Detail' data-trigger='hover' style='text-decoration:none; color:black' font-weight:bolder><img src='male.jpg' alt='hello' ><br>" . $row['first_name'] ."<br>".$rows['distributor_company_id']. "</a><br></div>";
                    in_parent($row['id'], $store_all_id, $con,0);
                    echo "</li>";
        echo "</div>";

        

        mysqli_close($con);
        ?>
    </body>
</html>
<?php } else{ ?>



<!DOCTYPE HTML>
<html>
    <?php 
    $user_id=$_SESSION['user'];
    $user_name=$conn->get_admin_login_name($con,$user_id);
    $id=$conn->get_admin_dis_id($con,$user_name);
//    $id=1;
    
     function add_array($id,$con,$childs){
                   $count_left=array();
                   $count_right=array();
                    $i=0;
                    $query=mysqli_query($con,"select * from tree where parent_id='$id' order by position");
                    while( $rr=  mysqli_fetch_array($query)){
                      
                      $pp[$i]=$rr;
                      $i++;
                  }
                  if($i==2){
                      if($pp[0][1]!='blank'){
                          array_push($childs, $pp[0][0]);
                       $count_left=add_array($pp[0][0],$con,$childs);  
                      }else{
                          $count_left=['0'];
                      }
                      if($pp[1][1]!='blank'){
                          array_push($childs, $pp[1][0]);
                           $count_right=add_array($pp[1][0],$con,$childs); 
                      }else{
                          $count_right=['0'];
                      }
//                      print_r($childs);
//                      print_r($count_right);
//                      print_r($count_left);
                      $childs=  array_merge($count_right,$count_left);
//                       print_r($childs);
//                      echo "<br>";
                      return $childs;
                  }if($i==0){
                   return $childs;   
                  }
                }
                $childs=array($id);
    $all_childs=array();
    $all_childs= add_array($id,$con,$childs);
    $all_childs=  array_unique($all_childs);
    
//    echo $all_childs;
//    print_r($all_childs);
    if(isset($_REQUEST['u_id']) &&  $_REQUEST['u_id']!=""){
//        $id=$_REQUEST['u_id'];
        $comp_id=$_REQUEST['u_id'];
        $id_req=$conn->get_admin_dis_id($con,$comp_id);
        if(in_array($id_req, $all_childs)){
            $id=$id_req;
        }
    }else{
        $id=$id;
    }
    ?>
    <head runat="server">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <title>jQuery Tree</title>
        <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Cabin:400,700,600"/>
        <link href="style.css" rel="stylesheet" type="text/css">
        <script src="js/jquery-1.11.1.min.js"></script>
        <script src="js/jquery-migrate-1.2.1.min.js"></script>
        <script src="js/jquery-ui.js"></script>
        <script src="js/jquery.tree.js"></script>
<!--        <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
        <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>-->
        <script>
$(document).ready(function(){
//    $('[data-toggle="tooltip"]').tooltip();   
//  $('#popoverData').popover();
  $('[data-toggle="popover"]').popover({
        container: 'body' // Popover scrolls with body
    });   
});
</script>

        <script>
            $(document).ready(function() {
                $('.tree').tree_structure({
//                    'add_option': true,
//                    'edit_option': true,
//                    'delete_option': true,
//                    'confirm_before_delete': true,
                    'animate_option': true,
                    'fullwidth_option': false,
                    'align_option': 'center',
//                    'draggable_option': true
                });
            });
          
        </script>
       
    </head>
    <body>
        <form action="#" method="post">
            <div class="col-sm-10"> Enter Id to Search:<input type="text" name="u_id" id="u_id" class="form-control"  placeholder="Enter Down Line Member PSS id"></div>
        <div class="col-sm-2"  style="text-align: right"> <br><input type="submit" name="search" class="btn btn-success" value="Search" style="text-align: center"></div></form>
        <!--<div class="col-sm-2" style="text-align: right"> <br><a href="logout.php?logout"><input type="submit" name="Logout" value="Logout" class="btn btn-danger"></a></div>-->
        <?php
//        include_once 'db.php';
//        $page=1;
//include_once '../property/dbMysql.php';
//$conn = new DB_con();
//$con=$conn->connection();
//include_once 'property/function_list.php';
//include_once 'property/default_values.properties';
$functions=new functions();
                function countt($id,$con){
                    $i=0;
                    $query=mysqli_query($con,"select * from tree where parent_id='$id' order by position");
                    while( $rr=  mysqli_fetch_array($query)){
                      
                      $pp[$i]=$rr;
                      $i++;
                  }
                  if($i==2){
                      if($pp[0][1]!='blank'){
                       $count_left=countt($pp[0][0],$con);   
                       $count_left++;
//                       echo $connt_left;
                      }else {
                          $count_left=0;                          
                      }
                      if($pp[1][1]!='blank'){
                           $count_right=countt($pp[1][0],$con); 
                           $count_right++;
                      }else{
                          $count_right=0;    
                      }
                     $counttt= $count_left+$count_right;
                     return $counttt;
                  }if($i==0){
                   return 0;   
                  }
                }
                
                
                
                 function countbv($id,$con){
                    $i=0;
                    $query=mysqli_query($con,"select * from tree where parent_id='$id' order by position");
                    while( $rr=  mysqli_fetch_array($query)){
                      
                      $pp[$i]=$rr;
                      $i++;
                  }
                  if($i==2){
                      if($pp[0][1]!='blank'){
                       $count_left_bv=countbv($pp[0][0],$con); 
                       $user_left_idd=$pp[0][0];
                       $sql=  mysqli_query($con, "select distributor_bv from distributor_detail where distributor_id='$user_left_idd'");
                       $rowss=  mysqli_fetch_array($sql);
                       $count_left_bv=$count_left_bv+$rowss['distributor_bv'];
//                       echo $connt_left;
                      }else {
                          $count_left_bv=0;                          
                      }
                      if($pp[1][1]!='blank'){
                           $count_right_bv=countbv($pp[1][0],$con); 
                            $user_right_idd=$pp[1][0];
                       $sql=  mysqli_query($con, "select distributor_bv from distributor_detail where distributor_id='$user_right_idd'");
                       $rowss=  mysqli_fetch_array($sql);
                           $count_right_bv=$count_right_bv+$rowss['distributor_bv'];
                      }else{
                          $count_right_bv=0;    
                      }
                     $counttt= $count_right_bv+$count_left_bv;
                     return $counttt;
                  }if($i==0){
                   return 0;   
                  }
                }
                
		function in_parent($in_parent, $store_all_id, $con,$p) {
                    $p++;
            if (in_array($in_parent, $store_all_id)) {
                
                $result = mysqli_query($con, "SELECT * FROM tree where parent_id = '$in_parent' order by position ");
                echo $in_parent == 0 ? "<ul class='tree'>" : "<ul>";
                while ($row = mysqli_fetch_array($result)) {
                    $res=  mysqli_query($con, "select * from distributor_detail where distributor_id='".$row['id']."'");
                    $rows=  mysqli_fetch_array($res);
                    $left=mysqli_query($con,"select * from tree where parent_id = '$row[id]' order by position");
                   
                  $pp=array();
                  $i=0;
                  $count_left=0;
                  $count_right=0;
                  while( $rr=  mysqli_fetch_array($left)){
                     
                      $pp[$i]=$rr;
                       $i++;
                  }
                  if($i==2){
                      if($pp[0][1]!='blank'){
                          $id=$pp[0][0];
                       $count_left=countt($id,$con); 
                       $count_left++;
                      }else {
                          $count_left=0;                          
                      }
                      if($pp[1][1]!='blank'){
                          $idd=$pp[1][0];
                         $count_right=countt($idd,$con); 
                         $count_right++;
                      }else {
                          $count_right=0;                          
                      }
                  }
                  $count_left_bv=0;
                  $count_right_bv=0;
                  
                  if($i==2){
                      if($pp[0][1]!='blank'){
                       $count_left_bv=countbv($pp[0][0],$con); 
                       $user_left_idd=$pp[0][0];
                       $sql=  mysqli_query($con, "select distributor_bv from distributor_detail where distributor_id='$user_left_idd'");
                       $rowss=  mysqli_fetch_array($sql);
                       $count_left_bv=$count_left_bv+$rowss['distributor_bv'];
//                       echo $connt_left;
                      }else {
                          $count_left_bv=0;                          
                      }
                      if($pp[1][1]!='blank'){
                           $count_right_bv=countbv($pp[1][0],$con); 
                            $user_right_idd=$pp[1][0];
                       $sql=  mysqli_query($con, "select distributor_bv from distributor_detail where distributor_id='$user_right_idd'");
                       $rowss=  mysqli_fetch_array($sql);
                           $count_right_bv=$count_right_bv+$rowss['distributor_bv'];
                      }else{
                          $count_right_bv=0;    
                      }
//                     $counttt= $count_right_bv+$count_left_bv;
//                     return $counttt;
                  }
                  
                  
                  
//                  $qq=$pp[1][1];
                    echo "<li";
//                    if ($row['hide'])
                    if($p>1)
                        echo " class='thide'";
//                    $p++;
//                    echo $p;
                    echo "><div id='" . $row['id'] ."'> <a onclick=user('$rows[distributor_company_id]')  
					data-toggle='popover' class='col-sm-12' data-html='true' href='#' data-content=
					'<table class=table-condensed><tr><td><b>Name:</b></td><td> 
					$row[first_name] </td></tr><tr><td><b>Total Joining</b> :</td> 
					<td>left- $count_left right- $count_right </td></tr><tr><td> 
					<b>Total B.V. :</b> </td><td> Left- $count_left_bv  Right- $count_right_bv 
					</td></tr><tr><td> <b>Company Id:</b> </td><td> $rows[distributor_company_id] 
					</td></tr><tr><td> <b>Added With:</b> </td><td> $rows[distributor_bv] B.V. </td>
					</tr></table>' rel='popover' data-placement='top' data-original-title='Person Detail' 
					data-trigger='hover' style='text-decoration:none; color:black' font-weight:bolder><img 
					src='male.jpg' alt='male' ><br>" . $row['first_name'] ."<br>".$rows['distributor_company_id']. "</a><br></div>";
                    in_parent($row['id'], $store_all_id, $con,$p);
                    echo "</li>";
                }
                echo "</ul>";
           
                }
        }
        $store_all_id = array();
        $id_result = mysqli_query($con, "SELECT * FROM tree");
        while ($all_id = mysqli_fetch_array($id_result)) {
            array_push($store_all_id, $all_id['parent_id']);
        }
        echo "<div class='col-md-12'>";
//        in_parent(0, $store_all_id, $con);
         $result = mysqli_query($con, "SELECT * FROM tree where id = '$id' order by first_name");
         $row = mysqli_fetch_array($result);
         $res=  mysqli_query($con, "select * from distributor_detail where distributor_id='".$row['id']."'");
                    $rows=  mysqli_fetch_array($res);
                     $left=mysqli_query($con,"select * from tree where parent_id = '$row[id]' order by position");
                   
                  $pp=array();
                  $i=0;
                  $count_left=0;
                  $count_right=0;
                  while( $rr=  mysqli_fetch_array($left)){
                     
                      $pp[$i]=$rr;
                       $i++;
                  }
                  if($i==2){
                      if($pp[0][1]!='blank'){
                          $id=$pp[0][0];
                       $count_left=countt($id,$con); 
                       $count_left++;
                      }else {
                          $count_left=0;                          
                      }
                      if($pp[1][1]!='blank'){
                          $idd=$pp[1][0];
                         $count_right=countt($idd,$con); 
                         $count_right++;
                      }else {
                          $count_right=0;                          
                      }
                  }
                  
                   $count_left_bv=0;
                  $count_right_bv=0;
                  
                  if($i==2){
                      if($pp[0][1]!='blank'){
                       $count_left_bv=countbv($pp[0][0],$con); 
                       $user_left_idd=$pp[0][0];
                       $sql=  mysqli_query($con, "select distributor_bv from distributor_detail where distributor_id='$user_left_idd'");
                       $rowss=  mysqli_fetch_array($sql);
                       $count_left_bv=$count_left_bv+$rowss['distributor_bv'];
//                       echo $connt_left;
                      }else {
                          $count_left_bv=0;                          
                      }
                      if($pp[1][1]!='blank'){
                           $count_right_bv=countbv($pp[1][0],$con); 
                            $user_right_idd=$pp[1][0];
                       $sql=  mysqli_query($con, "select distributor_bv from distributor_detail where distributor_id='$user_right_idd'");
                       $rowss=  mysqli_fetch_array($sql);
                           $count_right_bv=$count_right_bv+$rowss['distributor_bv'];
                      }else{
                          $count_right_bv=0;    
                      }
                    
                  }
                  
                  
                    
          echo "<ul class='tree'>";
          echo "<li";
                    if ($row['hide'])
                        echo " class='thide'";
                    echo "><div id=" . $row['id'] . "><a onclick=user('$rows[distributor_company_id]')  data-toggle='popover' class='col-sm-12' data-html='true' href='#' data-content='<table class=table-condensed><tr><td><b>Name:</b></td><td> $row[first_name] </td></tr><tr><td><b>Total Joining</b> :</td> <td>left- $count_left right- $count_right </td></tr><tr><td> <b>Total B.V. :</b> </td><td> Left- $count_left_bv  Right- $count_right_bv </td></tr><tr><td> <b>Company Id:</b> </td><td> $rows[distributor_company_id] </td></tr><tr><td> <b>Added With:</b> </td><td> $rows[distributor_bv] B.V. </td></tr></table>' rel='popover' data-placement='top' data-original-title='Person Detail' data-trigger='hover' style='text-decoration:none; color:black' font-weight:bolder><img src='male.jpg' alt='hello' ><br>" . $row['first_name'] ."<br>".$rows['distributor_company_id']. "</a><br></div>";
                    in_parent($row['id'], $store_all_id, $con,0);
                    echo "</li>";
        echo "</div>";

        

        mysqli_close($con);
        ?>
    </body>
</html>




<?php } ?>