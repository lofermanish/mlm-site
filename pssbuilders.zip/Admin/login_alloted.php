<?php
//echo "<script>alert('$page_name')</script>";
$page = 1;
include_once '../property/pss_db.php';
$conn = new DB_con();
$con = $conn->connection();

?>
<!DOCTYPE html>
<!-- saved from url=(0038)http://flatter.cloudtub.com/index.html -->
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Dashboard</title>
<meta name="description" content="Flatter - Flat Admin Theme">
<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/layout.css">
<link rel="stylesheet" href="css/style3.css">
<script type="text/javascript" src="js/jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.10.4.custom.min.js"></script>
<style>
.imgsize
{
	height:30px; 
	width:30px;
}
</style>
</head>
<body id="body">

		<!-- Header -->
		<?php //include './header.php'; ?>

<?php 
							 
                        
                         
                        if(isset($_POST['submit'])){
                            if(isset($_POST['users']) && $_POST['users']!=""){
                               
                            if(isset($_POST['right_select']) && $_POST['right_select']!=""){
                                
                            $xx=$_POST['right_select'];
                            $login_id=$_POST['users'];                           
                             
                            foreach($xx as $value){
                               
                                $result=$conn->insert_login_rights($con,$login_id,$value,$date_time);
                                
                            }
                            
                            
                            }else{
                                $login_id=$_POST['users'];
                                $result=$conn->insert_login_rights($con,$login_id,"",$date_time);
                            }
                            }else{
                               echo "<span style='color:red;'>please select username</span>"; 
                            }
//                            $res=$con->insert_int
//                            echo $_POST['sport'];
//                            echo $_POST['status'];
//                            if($result){
//                                
//                            }
                            if($result){
                                 echo "<script>alert('successful'); </script>";
                            }
                        }
                        ?>	
                
                
       <?php //include './left-menu.php'; ?>
		<!-- Header -->
                
                
                
                
                
<section id="main-wrapper">
    
    
    
    <script type="text/javascript">
function moveSelectedItems(source, destination){
  var selected = $(source+' option:selected').remove();
  var sorted = $.makeArray($(destination+' option').add(selected)).sort(function(a,b){
    return $(a).text() > $(b).text() ? 1:-1;
  });
  $(destination).empty().append(sorted);
}
</script>

<script type="text/javascript">
$(document).ready(function(){
  $('#t1add').click(function(){
    moveSelectedItems('#t1available', '#t1published');
  });
//  $('#t1addAll').click(function(){
//    $('#t1available option').attr('selected', 'true');
//    moveSelectedItems('#t1available', '#t1published');
//  });
  $('#t1remove').click(function(){
    moveSelectedItems('#t1published', '#t1available');
  });
//  $('#t1removeAll').click(function(){
//    $('#t1published option').attr('selected', 'true');
//    moveSelectedItems('#t1published', '#t1available');
//  });
});
$(document).ready(function(){
  $('#ss').click(function(){
     $('#t1published option').prop('selected',true); 
  });
  });
 $(document).ready(function(){
        $("#sport").change(function(){
            var user=$("#sport").val();
            if(user==""){
               
                $("#t1available").load('get-data.php');
            }else{
             
            $("#t1available").load('get-data.php',{"user_id":user});}
        });
    });
    $(document).ready(function(){
        $("#sport").change(function(){
            var user=$("#sport").val();
            if(user==""){
                $("#t1published").load('get-data.php');
            }else{
            $("#t1published").load('get-data.php',{"user_idd":user});}
        });
    });
 
</script>
      
        <?php 
       $res=$conn->get_admin_logins($con);
       
        ?>
    
    
		<h3 class="subtitle">Add B.V. to your Account</h3>
          <hr>
         
          <form method="post" action="#">
		  <div class="row">
			  <div class="col-md-12">
                              <div class="col-md-1" style="margin-top:5px;font-size: 18px;" ><strong>Users</strong></div>
                              <div class="col-md-11" >
<!--                                  <input type="text" name="user_bv_code" class="form-control" id="user_bv_code" placeholder="B.V. Code">-->
                                  <select class="form-control" name="users" id="sport">
                                      <option value="">Select User</option>
                                      <?php while($row =  mysqli_fetch_array($res)){  
                                          $ress=$conn->get_admin_distributor_detail_by_cmpny_id($con,$row['username']);
                                          $roww=  mysqli_fetch_array($ress);
                                          
                                          ?>
                                      <option value="<?php echo $row['login_id'] ?>"><?php echo "$roww[distributor_name] ($row[username])"; ?></option>
                                      <?php } ?>
                                  </select>
                              </div>
                          </div>
                      
                      
                      
                      <div style="margin-top: 100px; margin-left: 30px; margin-right: 30px;">
    <div class="col-md-4">
      <div class="box">
        <div class="box-header with-border">
            <select  id="t1available" size="10" multiple="multiple" class="box" name="left_select[]" style="overflow: auto">
              
			</select>
            <span id="hell"></span>
        </div><!-- /.box-header -->
        
 
 <br>
      </div><!-- /.box -->
    </div>
    <div class="col-md-4">
      <div class="box box-red">
        <div class="box-header with-border">
		<br><br><br>
                <input type="button" class="btn btn-block btn-danger btn-lg" value="--&gt;" id="t1add" style="background-color: #3ba0ff;"/>
			 <!--onclick="moveOptions(this.form.sel1, this.form.sel2);" /><br/><br/>-->
                         <input type="button" class="btn btn-block btn-danger btn-lg" value="&lt;--" id="t1remove" style="background-color: #3ba0ff;"/>
			 <!--onclick="moveOptions(this.form.sel2, this.form.sel1);" />-->
			 <br><br><br>
        </div><!-- /.box-header -->
       
      </div><!-- /.box -->
    </div>
    <div class="col-md-4">
      <div class="box">
        <div class="box-header with-border">
            <select  id="t1published" size="10" multiple="multiple" class="box" name="right_select[]" style="overflow: auto;  ">
              
			</select>
        </div><!-- /.box-header -->
        
        <button type="submit" name="submit" id="ss" class="btn btn-danger" style="float: right; margin-right: 10px; background-color: #3ba0ff;">Save</button>
<br>
      </div><!-- /.box -->
    </div>
  </div><!-- /.row -->
                      
				
                  </div>
          
          
          </form>
          
</section>


<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<div class="offline-ui offline-ui-up"><div class="offline-ui-content"></div><a href="" class="offline-ui-retry"></a>
</div>
</body>
</html>
<?php
 //} 
?>