<?php
session_start();
if(!isset($_SESSION['user']))
{
	header("Location: index.php");
}
else
{
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Dashboard</title>
<meta name="description" content="Flatter - Flat Admin Theme">
<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/layout.css">
<link rel="stylesheet" href="css/style3.css">
<script type="text/javascript" src="js/jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.10.4.custom.min.js"></script>

 <script>

            $(document).ready(function() {
                $("#plot_name").change(function() {
                    var user = $("#plot_name").val();
					if(user=="")
					{
						$("#get_image").load('get-data.php');
						}
						else
						{
                    $("#get_image").load('get-data.php', {"id": user});
						}
                });
            });
        </script>
</head>
<body id="body">

		<!-- Header -->
		<?php include './header.php'; ?>

       <?php include './left-menu.php'; ?>
		<!-- Header -->
		
<section id="main-wrapper">
		<h3 class="subtitle">Update Property Details</h3>
          <hr>

		  <div class="row">
			  <div class="col-md-12">
				  	<div class="panel panel-default">
					  <div class="panel-heading">
					    <h3 class="panel-title"><strong>Property Details</strong></h3>
						<br>
					    			
<?php
		if(isset($_POST['btn_upload']))
    {

				$applicant_name=$_POST['applicant_name'];
				$plot_no=$_POST['plot_no'];
				//$plot_name=$_POST['plot_name'];
				

				$res = $conn->update_admin_plot_price_details($con,$applicant_name,$plot_no);
	           
	if($res)
		{
			?>
			<div class="alert alert-success">
  <strong>Plot alloted Updated successfully</strong>
</div>
			<?php
		}
		else
		{
			?>
			<div class="alert alert-danger">
  <strong>Plot alloted Not Updated</strong>
          </div>
			<?php
		}	
    }
?>
		<p align="center"></p>	
					  </div>
					  <div class="panel-body">
					  <form method="POST" enctype="multipart/form-data" name="image_upload">
				
						<table class="table">
					        <tr>
							  <td><strong>Applicant Name</strong></td>
							  <td>
							<select name="applicant_name" class="form-control" required="required" id="upload_type">
							  <option value="">Select Applicant Name</option>
							  				<?php
				 $res = $conn->get_admin_applicant($con);
				 while ($row = mysqli_fetch_array($res)) {
				 $applicant_id=$row['applicant_id'];
				 ?>
				 <option value="<?php echo $row['applicant_id']; ?>"><?php echo $row['applicant_name']; ?> <?php echo $row['applicant_detail_username']; ?></option>
				 <?php }?>
							  </select>
							  </td>
					        </tr>
							<tr>
							  <td><strong>Plot Name</strong></td>
							  <td>
							 <select name="plot_name" class="form-control" required="required" id="plot_name">
							  <option value="">Select Plot Name</option>
							  				<?php
				 $res = $conn->get_admin_plot_price_details($con);
				 while ($row = mysqli_fetch_array($res)) {
				 $plot_price_details_name=$row['plot_price_details_name'];
				 ?>
				 <option value="<?php echo $row['plot_price_details_name']; ?>">  <?php echo $row['plot_price_details_name']; ?>  </option>
				 <?php }?>
							  </select>
							  </td>
					        
							 </tr>
								<tr>
							  <td><strong>Plot No</strong></td>
							 <td>
							
							 <div  id='get_image'></div> 
					        
							 </td>
					        
							 </tr>
							 
							 
							 
							 
							 
							  <td></td>
							  <td>
<button type="submit" name="btn_upload" class="btn btn-info" style="background-color:#3ba0ff;"><i class="fa fa-upload"></i> Allot</button>
<button type="reset" name="cancel" class="btn btn-info" style="background-color:#3ba0ff;"><i class="fa fa-refresh"></i> Reset</button>
							  </td>
					        </tr>
					    </table>
						</form>
					  </div>
					</div>
				</div>
</div>
</section>


<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<div class="offline-ui offline-ui-up"><div class="offline-ui-content"></div><a href="" class="offline-ui-retry"></a>
</div>
</body>
</html>
<?php
 } 
?>