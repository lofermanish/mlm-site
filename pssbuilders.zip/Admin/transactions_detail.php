<?php
session_start();
//include_once 'db.php';

if(!isset($_SESSION['user']))
{
	header("Location: index.php");
}
else
{
?>
<!DOCTYPE html>
<!-- saved from url=(0038)http://flatter.cloudtub.com/index.html -->
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Dashboard</title>
<meta name="description" content="Flatter - Flat Admin Theme">
<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/layout.css">
<link rel="stylesheet" href="css/style3.css">
<script type="text/javascript" src="js/jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.10.4.custom.min.js"></script>
</head>
<body id="body">

		<!-- Header -->
		<?php include './header.php'; ?>

       <?php include './left-menu.php'; ?>
		<!-- Header -->
                
                
                <?php $past_month=date('Y-m-d', strtotime(date('Y-m-d') .'-1 month')); 
        $present_month=date('Y-m-d')
        ?>

        <section id="main-wrapper">
		<h3 class="subtitle">Dashboard</h3>
          <hr>
		  <div class="row">
                      <div class="col-sm-12"><center><h3 style="margin-top: 0px; margin-bottom: 20px; "><span id="show_id"></span><span id="show_user"></span><span id="show_this"> Report</span> Date from <span id="show_from"> <?php echo $past_month ?></span> to <span id="show_to"><?php echo $present_month ?></span> </h3></center>
                          

                      </div>
	 <div class="col-md-12">
                              <div class="col-md-2" style="margin-top:5px;font-size: 18px;" ><strong>Transaction</strong></div>
                              <div class="col-md-8" >
                                
                                  <!--<input type="text" name="user_bv_code" class="form-control" id="user_bv_code" placeholder="B.V. Code">-->
                                  <select class="form-control" name="transaction_type" id="transaction_type" onchange="show_detail()">
                                      <option value="">Select Transaction Detail</option>
                                      <option value="money received">Money Received Detail</option>
                                      <option value="money dispatched">Money Dispatched Detail</option>
                                      <option value="all">All Detail</option>
                                  </select>
                              
                              </div>
                              <div class="pull-right">                 
  <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Filter
  <span class="caret"></span></button>
  <ul class="dropdown-menu">
     <li><a href="#" data-toggle="modal" data-target="#byDate">By Date</a></li>
    <li><a href="#"  data-toggle="modal" data-target="#byUser">By User</a></li>
  </ul></div> 
                       </div> 
                      <div id="transaction_detail" class="col-sm-12">
                          <hr>
                      </div>
                      
                
	    </div>
         
       </section>


<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>

<script>
//$(document).ready(function(){
//    $("#transaction_type").change(function(){
//        type=$("#transaction_type").val();
//        $("#transaction_detail").load("get-data.php",{"transaction_detail_type":type});
//    });
//});

function show_detail(){
      
    from=$("#show_from").text();
    to=$("#show_to").text();
        type=$("#transaction_type").val();
         user_id=$("#show_id").text();
          if(user_id==""){
        if(type!=""){
        $("#transaction_detail").load("get-data.php",{"transaction_detail_type":type,"transaction_detail_past_month":from,"transaction_detail_present_month":to});
    }else{
        $("#transaction_detail").load("get-data.php");
    }
    }else{
        if(type!=""){
          $("#transaction_detail").load("get-data.php",{"transaction_detail_type":type,"transaction_detail_past_month":from,"transaction_detail_present_month":to,"transaction_detail_user_id":user_id});
    }else{
        $("#transaction_detail").load("get-data.php");  
        } 
    }
}

</script>
</body>
</html>
<?php
 } 
?>
   
              <div id="byDate" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Choose Date</h4>
      </div>
      <div class="modal-body">
          <div class="row"> <div class="col-sm-6"><label>From</label><input type="date" name='from' class="form-control" id="from"></div>
          <div class="col-sm-6"><label>To</label><input type="date" name='to' id="to" class="form-control"></div>
          <div class="col-sm-12 "><br><input type="submit" value='Check' class="btn btn-danger pull-right" onclick='transaction_by_date()'></div>
          </div>
      </div>
     
    </div>

  </div>
</div>
              
              
              
               <div id="byUser" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Choose User</h4>
      </div>
      <div class="modal-body">
          <div class="row"> <div class="col-sm-12"><label>Select User</label>
                  <?php  $res=$conn->get_admin_distributors($con); ?>
                   <select class="form-control" name="user_id" id="user_id">
                                      <option value="">Select User</option>
                                      <?php while($row=  mysqli_fetch_array($res)){ ?>
                                      <option value="<?php echo $row['distributor_company_id'] ?>"> <?php echo $row['distributor_name']." (".$row['distributor_company_id'].")"; ?></option>
                                      <?php } ?>
                                  </select>
              
              </div>
          <div class="col-sm-12 "><br><input type="submit" value='Check' class="btn btn-danger pull-right" onclick='transaction_by_user()'></div>
          </div>
      </div>
     
    </div>

  </div>
</div>
<script>
    function transaction_by_date(){
        from=$("#from").val();
        to=$("#to").val();
        if(from!="" && to!=""){
        $("#show_from").text(from);
        $("#show_to").text(to);
        user_id=$("#show_id").text();
        type=$("#transaction_type").val();
        if(user_id==""){
        if(type!=""){
        $("#transaction_detail").load("get-data.php",{"transaction_detail_type":type,"transaction_detail_past_month":from,"transaction_detail_present_month":to});
    }else{
        $("#transaction_detail").load("get-data.php");
    }
    }else{
        if(type!=""){
          $("#transaction_detail").load("get-data.php",{"transaction_detail_type":type,"transaction_detail_past_month":from,"transaction_detail_present_month":to,"transaction_detail_user_id":user_id});
    }else{
        $("#transaction_detail").load("get-data.php");  
        }
    }
    $("#byDate").modal("hide");
    }
        }
        
        function transaction_by_user(){
            from=$("#show_from").text();
    to=$("#show_to").text();
        type=$("#transaction_type").val();
        user_id=$("#user_id").val();
        user_name=$("#user_id option:selected").text();
        if(user_id!=""){
            $("#show_user").text(user_name);
            $("#show_id").text(user_id);
            $("#show_this").show();
        if(type!=""){
          $("#transaction_detail").load("get-data.php",{"transaction_detail_type":type,"transaction_detail_past_month":from,"transaction_detail_present_month":to,"transaction_detail_user_id":user_id});
    }else{
        $("#transaction_detail").load("get-data.php");  
        }
         $("#byUser").modal("hide");
        }
    }
    $(document).ready(function (){
         $("#show_this").hide();
         $("show_id").hide();
    });
</script>