<?php

if (isset($page) && $page == 1) {
    $add = '../';
} else {
    $add = "";
}
//$db=$add.'property/db.php';
$function_list = $add . 'property/function_list.php';
$default_values = $add . 'property/default_values.properties';
include_once $function_list;
include_once $default_values;
//define('DB_SERVER', 'localhost');
//define('DB_USER', 'root');
//define('DB_PASS', '');
//define('DB_NAME', 'pss_builder');

class DB_con {


    public function connection() {

        $con = mysqli_connect("localhost", "root", "", "pss_builder") or die("Could not connect");
        return $con;
    }

    public function insert_website_career($con, $jobs_postion, $Qualification, $resume, $email, $phone, $Address, $date_time) {
//                echo "hello";
        $sql = "INSERT into career_details(career_details_position,career_details_qualification,career_details_resume,career_details_email,career_details_phone,career_details_address,career_details_date) VALUES('$jobs_postion','$Qualification','$resume','$email','$phone','$Address','$date_time')";
        $res = mysqli_query($con, "$sql");
        return $res;
    }

    public function insert_admin_image($con, $image_details_title,$image_details_address, $image_details_path, $image_details_type,$upload_type) {
       echo $sql = "INSERT into image_details(image_details_title,image_details_address,image_details_path,image_details_type,image_details_hide_show,image_details_menu_type) VALUES('$image_details_title','$image_details_address','$image_details_path','$image_details_type',0,'$upload_type')";
        $res = mysqli_query($con, "$sql");
        return $res;
    }
	public function verify_bv($con,$code)
{
  $sql="select * from bv_code where bv_code_number='$code'";
$res=mysqli_query($con,$sql);
//                echo $sql;
 return $res;
            }
			
	public function insert_website_loading_page_enquiry($con, $property_enquiry_name, $property_enquiry_phone, $property_enquiry_email, $property_enquiry_city, $property_enquiry_min_price, $property_enquiry_max_price, $property_enquiry_date_time)
	{
	$property="INSERT into property_enquiry(property_enquiry_name,property_enquiry_phone,property_enquiry_email,property_enquiry_city,property_enquiry_min_price,property_enquiry_max_price,property_enquiry_date_time)VALUES('$property_enquiry_name','$property_enquiry_phone','$property_enquiry_email','$property_enquiry_city','$property_enquiry_min_price','$property_enquiry_max_price','$property_enquiry_date_time')";
	//echo"$property";
	$res = mysqli_query($con, "$property");
        return $res;
	}
	
	public function insert_admin_news($con,$news_title,$news_image,$news_description,$news_link,$date_time) {
        $sql = "INSERT into news(news_title,news_image,news_description,news_link,news_date) VALUES('$news_title','$news_image','$news_description','$news_link','$date_time')";
		//echo"$sql";
        $res = mysqli_query($con, "$sql");
        return $res;
    }	
		public function insert_plot_price_details($con,$plot_no,$plot_name,$plot_width,$plot_height,$plot_price,$plot_Availability,$date_time) {
        $sql = "INSERT into plot_price_details(plot_price_details_plot_no,plot_price_details_name,plot_price_details_height,plot_price_details_width,plot_price_details_amount,	plot_price_details_plot_availability,plot_price_details_date) VALUES('$plot_no','$plot_name','$plot_width','$plot_height','$plot_price','$plot_Availability','$date_time')";
		//echo"$sql";
        $res = mysqli_query($con, "$sql");
        return $res;
    }
	
	public function insert_admin_achiever_product($con,$achiever_product,$type_achiever_product,$date_time) {
        $sql = "INSERT into achiever_project(achiever_product_name,type,achiver_product_date) VALUES('$achiever_product','$type_achiever_product','$date_time')";
		//echo"$sql";
        $res = mysqli_query($con, "$sql");
        return $res;
    }
	
	
	public function insert_admin_plot_price_details($con,$site_name,$plot_no,$plot_name,$plot_height,$plot_width,$plot_amount,$date_time,$available) {
       $sql = "INSERT into plot_price_details(plot_price_details_site_name,plot_price_details_plot_no,plot_price_details_name,plot_price_details_height,plot_price_details_width,plot_price_details_amount,plot_price_details_date,plot_price_details_plot_availability) VALUES('$site_name','$plot_no','$plot_name','$plot_height','$plot_width','$plot_amount','$date_time','$available')";
		echo"$sql";
        $res = mysqli_query($con, "$sql");
        return $res;
     }
	
	
	public function insert_admin_page($con,$page_name,$page_description,$date_time) {
        $sql = "INSERT into page(page_name,page_data,page_created_date) VALUES('$page_name','$page_description','$date_time')";
		//echo"$sql";
        $res = mysqli_query($con, "$sql");
        return $res;
    }
	
	public function insert_admin_website_manu($con,$menu_page,$myfile,$menu_id) {
        $sql = "INSERT into website_menu(website_menu_name,website_menu_link,website_parent_menu_id,type) VALUES('$menu_page','$myfile','$menu_id','$menu_page')";
		//echo"$sql";
        $res = mysqli_query($con, "$sql");
        return $res;
    }
	
	public function get_admin_menu_project($con) {
        $achiever_product = "SELECT * FROM website_menu where type!=''";
		//echo"$achiever_product";
        $res = mysqli_query($con, "$achiever_product");
        return $res;
    }
	
	public function insert_admin_achiever_team($con,$achiever_team_name,$achiever_team_description,$achiever_team_type,$achiever_team_image,$date_time) {
        $sql = "INSERT into achiever_poject_details(achiever_team_name,achiever_team_description,achiever_team_type,achiever_team_image,achiever_team_date) VALUES('$achiever_team_name','$achiever_team_description','$achiever_team_type','$achiever_team_image','$date_time')";
		//echo"$sql";
        $res = mysqli_query($con, "$sql");
        return $res;
    }
    
    public function insert_login_rights($con,$login_id,$value,$date_time){
        $sql="insert into login_rights(login_rights_login_id,login_rights_menu_id,login_rights_creation_date) values('$login_id','$value','$date_time')";
        // echo $sql;
		$res=  mysqli_query($con, $sql);
        return $res;
    }
     public function fetch_distributor_id($con,$dis_company_id,$dis_name,
		$dis_fa_name,
		$dis_dob,$dis_gender,$dis_m_status,
					$dis_n_name,$dis_n_relationship,$dis_c_address,
                    $dis_p_address,$dis_district,$dis_state,
					$dis_city,$dis_pin,$dis_mobile,$dis_phone,$dis_email,$dis_p_a_amount,$dis_id_proof
					,$dis_add_proof,$dis_placement_req,$dis_sponsor_id,$bv_code1,$direct_id)
		 {
  $query="select distributor_id from distributor_detail where distributor_creation_date =select max(distributor_creation_date) from distributor_detail where distributor_company_id='$dis_company_id'
 and distributor_name='$dis_name' and distributor_father_name='$dis_fa_name' and distributor_dob
 ='$dis_dob' and distributor_gender='$dis_gender' and distributor_m_status='$dis_m_status'
 and distributor_nominee_name='$dis_n_name' and distributor_relationship='$dis_n_relationship'
 and distributor_current_address='$dis_c_address' and distributor_permanent_address='$dis_p_address' and distributor_placement='$dis_placement_req' and distributor_distributor_id='$dis_sponsor_id'
 and distributor_bv='$bv_code1' and distributor_direct_distributor_id='$direct_id'";
$res= mysqli_query($con,"$query");
        return $res;			 
			 
			  
			     
		 }
		 
		 
		 public function update_bv($con,$bv_code,$bv_code_used_by)
		 {
		 $query="update bv_code set bv_code_used_by='$bv_code_used_by' , bv_code_used_date=NOW(), bv_code_use='1' where bv_code_number='$bv_code'";
$res= mysqli_query($con,"$query");
        return $res;	 
			 
			 
		 }
		  public function insert_login($con,$dis_company_id,$password,$date_time,$crr_user)
		 {
$sql="insert into login(username,password,login_creation_date,login_login_id) values('$dis_company_id','$password','$date_time','$crr_user')";
			  //echo"$sql";
$res= mysqli_query($con,"$sql");
        return $res;	 
			 
			 
		 }
    public function insert_admin_initial_payment_type($con,$payment_type,$commodity,$amount,$from,$to,$no_entries,$date_time){
        $sql="insert into payment_type(payment_type_type,payment_type_commodity,payment_type_price,payment_type_from,payment_type_to,payment_type_no_of_entries,payment_type_date) values('$payment_type','$commodity','$amount','$from','$to','$no_entries','$date_time')";
        $res = mysqli_query($con, "$sql");
        return $res;
        
    }


    public function get_admin_achiever_product($con) {
        $achiever_product = "SELECT * FROM achiever_project where type='achiever_product' ";
        $res = mysqli_query($con, "$achiever_product");
        return $res;
    }
	
	 public function get_admin_plot_price_details($con) {
        $plot_price_details = "SELECT * FROM plot_price_details where plot_price_details_plot_availability='Available'";
        $res = mysqli_query($con, "$plot_price_details");
        return $res;
    }
	public function get_admin_plot_price_details_plot_no($con,$plot_name)
	{
		
 $plot_price_details1 = "SELECT plot_price_details_plot_no FROM plot_price_details where plot_price_details_plot_availability='Available'and plot_price_details_name='$plot_name'";
        $res1 = mysqli_query($con, "$plot_price_details1");
        return $res1;
		
	}
    public function get_client_payment_detail($con,$client_id){
        $sql="select * from transaction where transaction_distributor_id='$client_id'";
        $res=  mysqli_query($con, $sql);
        return $res;
    }
	
	
	public function update_admin_plot_price_details($con,$applicant_id,$plot_detail_id) {
        $plot_price_details = "UPDATE plot_price_details SET plot_price_details_plot_availability = 'Booked', plot_price_details_plot_book_applicant_id='$applicant_id' WHERE plot_price_details_id = $plot_detail_id";
        $res = mysqli_query($con, "$plot_price_details");
        return $res;
    }
	

	
	public function get_admin_plot_price_project($con) {
        $plot_price_project = "SELECT DISTINCT plot_price_details_name from plot_price_details";
        $res = mysqli_query($con, "$plot_price_project");
        return $res;
    }
	
	public function get_admin_product($con,$main_page) {
        $achiever_product = "SELECT * FROM achiever_project where type='$main_page' ";
		//echo"$achiever_product";
        $res = mysqli_query($con, "$achiever_product");
        return $res;
    }
	
	public function get_website_achiever_team_details($con,$achiever_type) {
        $achiever_type = "SELECT * FROM achiever_poject_details where achiever_team_type='$achiever_type' ORDER BY achiever_team_date DESC";
        $res = mysqli_query($con, "$achiever_type");
        return $res;
    }
	
	public function get_website_achiever_team($con) {
        $achiever_team = "SELECT * FROM achiever_poject_details group BY achiever_team_date DESC";
        $res = mysqli_query($con, "$achiever_team");
        return $res;
    }
	
	public function get_website_project($con,$page_name,$page) {
       $achiever_team = "SELECT * FROM image_details where image_details_type='$page_name'and image_details_menu_type='$page'";
		//$achiever_team = "SELECT * FROM image_details where image_details_type='hello'&image_details_menu_type='ranjeet'";
		//echo"$achiever_team";
        $res = mysqli_query($con, "$achiever_team");
        return $res;
    }
	
	public function get_website_bankers($con) {
        $bankers = "SELECT * FROM image_details where image_details_type='Bankers'";
        $res = mysqli_query($con, "$bankers");
        return $res;
    }
	
	public function get_website_events($con,$picture_date) {
        $event = "SELECT * FROM image_details where image_details_date='$picture_date'";
        $res = mysqli_query($con, "$event");
        return $res;
    }
	
	public function get_website_legals($con) {
        $legals = "SELECT * FROM image_details where image_details_type='Legals'";
        $res = mysqli_query($con, "$legals");
        return $res;
    }
	
	public function get_website_Branch($con) {
        $Branch = "SELECT * from image_details where image_details_type='Branch' GROUP by image_details_title";
        $res = mysqli_query($con, "$Branch");
        return $res;
    }
	
	public function get_website_gallery($con) {
        $gallery = "SELECT * from image_details where image_details_type='picture_gallery' GROUP by image_details_date";
		//echo"$gallery";
        $res = mysqli_query($con, "$gallery");
        return $res;
    }
	
	public function get_website_event_image($con) {
        $gallery = "SELECT * from image_details where image_details_type='Event' GROUP by image_details_date";
		//echo"$gallery";
        $res = mysqli_query($con, "$gallery");
        return $res;
    }
	
	
	public function get_website_gallery_image($con,$image_date) {
        $gallery = "select * from image_details where image_details_date='$image_date'";
		//echo"$gallery";
        $res = mysqli_query($con, "$gallery");
        return $res;
    }
	
	
	public function get_website_page_image($con,$image_type) {
        $website_page = "select * from image_details where image_details_type='$image_type'";
		//echo"$website_page";
        $res = mysqli_query($con, "$website_page");
        return $res;
    }
	
	public function get_website_gallery_branch_image($con,$image_date) {
        $gallery = "select * from image_details where image_details_date='$image_date'";
		//echo"$gallery";
        $res = mysqli_query($con, "$gallery");
        return $res;
    }
	
	public function get_website_image_gallery($con,$id) {
        $gallery = "SELECT * FROM image_details where image_details_type='$id' and image_details_hide_show='0'";
        $res = mysqli_query($con, "$gallery");
        return $res;
    }
	
	public function get_website_gallery_slider_image($con) {
        $gallery = "SELECT * FROM image_details where image_details_type='picture_gallery'";
        $res = mysqli_query($con, "$gallery");
        return $res;
    }
	public function get_admin_website_menu($con) {
        $website_menu = "SELECT * FROM website_menu";
        $res = mysqli_query($con, "$website_menu");
        return $res;
    }
	
	public function get_admin_image_delete($con,$image_id) {
       //$delete_image_details = "DELETE FROM image_details WHERE image_details_id ='$image_id'";
		$delete_image_details = "UPDATE image_details SET image_details_hide_show= '1' WHERE image_details_id ='$image_id'";
		//echo"$delete_image_details";
        $res = mysqli_query($con, "$delete_image_details");
        return $res;
    }
	
	public function get_admin_news($con) {
        $news = "SELECT * FROM news where news_hide_show='0'";
        $res = mysqli_query($con, "$news");
        return $res;
    }
	
	public function get_admin_get_admin_plot_details($con) {
        $plot = "SELECT * FROM plot_price_details where plot_price_details_hide_show ='0' && plot_price_details_site_name='Defence Enclave'";
		//echo"$plot";
        $res = mysqli_query($con, "$plot");
        return $res;
    }
	public function get_admin_property_enquiry($con) {
        $plot = "SELECT * FROM property_enquiry where property_enquiry_hide_show ='0'";
		//echo"$plot";
        $res = mysqli_query($con, "$plot");
        return $res;
    }
	public function get_admin_get_admin_plot_details1($con) {
        $plot = "SELECT * FROM plot_price_details where plot_price_details_hide_show ='0' && plot_price_details_site_name='Shagun City'";
		//echo"$plot";
        $res = mysqli_query($con, "$plot");
        return $res;
    }
	public function get_admin_news_delete($con,$news_id) {
	    $delete_news_details = "UPDATE news SET news_hide_show= '1' WHERE news_id ='$news_id'";
		//echo"$delete_news_details";
        $res = mysqli_query($con, "$delete_news_details");
        return $res;
    }
	
	 public function get_admin_applicant_delete($con,$applicant_id) {
	    $delete_applicant_details = "UPDATE applicant_detail SET applicant_detail_hide_show= '1' WHERE applicant_id ='$applicant_id'";
		//echo"$delete_applicant_details";
        $res = mysqli_query($con, "$delete_applicant_details");
        return $res;
    }
	
	
	
	public function get_admin_plot_delete($con,$plot_price_details_id) {
	    $delete_news_details = "UPDATE plot_price_details SET plot_price_details_hide_show= '1' WHERE plot_price_details_id ='$plot_price_details_id'";
			//echo"$delete_news_details";
        $res = mysqli_query($con, "$delete_news_details");
        return $res;
    }
	
	
	
	
	public function get_admin_property_enquiry_details_delete($con,$property_enquiry_id) {
	    $delete_property_enquiry_details = "UPDATE property_enquiry SET property_enquiry_hide_show= '1' WHERE property_enquiry_id ='$property_enquiry_id'";
		//echo"$delete_property_enquiry_details";
        $res = mysqli_query($con, "$delete_property_enquiry_details");
        return $res;
    }
	
	
	public function get_admin_website_news($con) {
        $news = "SELECT * FROM news where news_hide_show= '0'";
        $res = mysqli_query($con, "$news");
        return $res;
    }
	
	public function get_admin_applicant($con) {
        $applicant_detail = "SELECT * FROM applicant_detail where applicant_detail_hide_show='0'";
        $res = mysqli_query($con, "$applicant_detail");
        return $res;
    }
	
	
	
	public function get_admin_website_enquiry_details($con) {
        $enquiry_details = "SELECT * FROM property_enquiry where property_enquiry_hide_show= '0'";
		//echo"$enquiry_details";
        $res = mysqli_query($con, "$enquiry_details");
        return $res;
    }
	
	
	public function get_admin_image_details($con) {
        $image_details = "SELECT DISTINCT image_details_type from image_details";
        $res = mysqli_query($con, "$image_details");
        return $res;
    }
    public function get_admin_distributors($con){
        $sql="select distributor_id,distributor_company_id,distributor_name,distributor_bv from distributor_detail where status=1 order by distributor_id desc";
		//echo"$sql";
        $res=  mysqli_query($con, $sql);
        return $res;
    }
	
	public function get_admin_applicant_detail($con){
        $sql="select applicant_detail_username,applicant_name,applicant_id from applicant_detail order by applicant_id desc";
		//echo"$sql";
        $res=  mysqli_query($con, $sql);
        return $res;
    }
    public function get_admin_applicant_details($con,$client_id){
        $sql="select * from applicant_detail where applicant_detail_username='$client_id'";
		//echo"$sql";
        $res=  mysqli_query($con, $sql);
        return $res;
    }
	public function get_admin_customer_applicant_details($con,$client_id){
        $sql="select applicant_detail.applicant_name,applicant_detail.applicant_fund_detail,plot_price_details.plot_price_details_plot_no,plot_price_details.plot_price_details_name,plot_price_details.plot_price_details_plot_availability,transaction.transaction_id,transaction.payment_type,transaction.transaction_type,transaction.transaction_distributor_id,transaction.transaction_payment_mode,transaction.transaction_date,transaction.transaction_amount from applicant_detail,plot_price_details,transaction where applicant_detail.applicant_id='$client_id' and applicant_detail.applicant_id=plot_price_details.plot_price_details_plot_book_applicant_id and applicant_detail.applicant_detail_username=transaction.transaction_distributor_id";
		//echo"$sql";
        $res=  mysqli_query($con, $sql);
        return $res;
    }
	
	
	
	public function get_admin_payment_details($con,$applicant_id,$transation_id)
	{
        $sql="select applicant_detail.applicant_name,applicant_detail.applicant_fund_detail,plot_price_details.plot_price_details_plot_no,plot_price_details.plot_price_details_name,plot_price_details.plot_price_details_plot_availability,transaction.transaction_id,transaction.payment_type,transaction.transaction_type,transaction.transaction_distributor_id,transaction.transaction_payment_mode,transaction.transaction_date,transaction.transaction_amount from applicant_detail,plot_price_details,transaction where applicant_detail.applicant_id='$applicant_id' and transaction.transaction_id='$transation_id' and applicant_detail.applicant_id=plot_price_details.plot_price_details_plot_book_applicant_id and applicant_detail.applicant_detail_username=transaction.transaction_distributor_id";
		//echo"$sql";
        $res=  mysqli_query($con, $sql);
        return $res;
    }
	
	
    public function get_plot_detail($con,$client_idd){
        $sql="select * from plot_price_details where plot_price_details_plot_book_applicant_id='$client_idd'";
        $res=  mysqli_query($con, $sql);
        return $res;
    }
	
	
	public function get_admin_fund_detail($con,$applicant_id){
        $sql="SELECT applicant_fund_detail,applicant_detail_username FROM applicant_detail WHERE applicant_id=$applicant_id";
		//echo"$sql";
        $res=  mysqli_query($con, $sql);
        return $res;
    }

	
    public function get_website_parent_menu($con) {
        $website_menu = "SELECT * FROM website_menu where website_parent_menu_id='0'";
        $res = mysqli_query($con, "$website_menu");
        return $res;
    }

    public function get_website_sub_menu($con, $menu_id) {
        $website_sub_menu = "SELECT * FROM website_menu WHERE website_parent_menu_id=" . $menu_id;
        $res_pro = mysqli_query($con, "$website_sub_menu");
        return $res_pro;
    }

    public function get_admin_parent_menu($con,$user_id) {
        $res = mysqli_query($con, "select * from main_menu where m_menu_id in(select distinct parent_menu_id from main_menu where parent_menu_id not in(0) and m_menu_id in(select m_menu_id from main_menu,login_rights where (m_menu_id = login_rights_menu_id ) and login_rights_login_id=$user_id and login_rights_creation_date=(select max(login_rights_creation_date) from login_rights where login_rights_login_id=$user_id) group by m_menu_id) order by m_menu_name) order by m_menu_name");
        return $res;
    }

    public function get_admin_sub_menu($con, $menu_id,$user_id) {
        $query3 = mysqli_query($con, "select * from main_menu where parent_menu_id=$menu_id and m_menu_id in(select m_menu_id from main_menu where parent_menu_id not in(0) and m_menu_id in(select m_menu_id from main_menu,login_rights where (m_menu_id = login_rights_menu_id ) and login_rights_login_id=$user_id and login_rights_creation_date=(select max(login_rights_creation_date) from login_rights where login_rights_login_id=$user_id) group by m_menu_id) order by m_menu_name) order by m_menu_name");
        return $query3;
    }
      public function get_admin_dis_id($con,$comp_id){
          $sql="select distributor_id from distributor_detail where distributor_company_id='$comp_id'";
          $res=  mysqli_query($con,"$sql");
          $row=  mysqli_fetch_array($res);
          $id=$row['distributor_id'];
          return $id;
      }
      public function get_admin_num_dis_spon_id($con,$id_parent){
          $sql="select * from tree where parent_id='$id_parent'";
		 // echo"$sql";
          $res=  mysqli_query($con, $sql);
          $count=  mysqli_num_rows($res);
          return $count;
      }
      public function get_admin_position_dis_spon_id($con,$id_parent,$dis_placement_req){
          $sql="select first_name from tree where parent_id='$id_parent' and position='$dis_placement_req'";
          $res=  mysqli_query($con, "$sql");
          $row=  mysqli_fetch_array($res);
          $name=$row['first_name'];
          return $name;
      }
      public function get_admin_login_name($con,$user_id){
          $sql="select username from login where login_id='$user_id'";
          $res=  mysqli_query($con, $sql);
          $row=  mysqli_fetch_array($res);
          $name=$row['username'];
          return $name;
      }
      public function get_admin_logins($con){
          $sql="select * from login";
           $res=  mysqli_query($con, $sql);
           return $res;
      }
      public function get_admin_menus($con,$user_id){
          $sql="select m_menu_id,m_menu_name from main_menu where parent_menu_id not in(0) and m_menu_id not in(select m_menu_id from main_menu,login_rights where (m_menu_id = login_rights_menu_id ) and login_rights_login_id='$user_id' and login_rights_creation_date=(select max(login_rights_creation_date) from login_rights where login_rights_login_id='$user_id') group by m_menu_id) order by m_menu_name";
          $res=  mysqli_query($con, $sql);
          return $res;
      }
      public function get_login_rights($con,$user_id){
          $sql="select m_menu_id,m_menu_name from main_menu,login_rights where (m_menu_id = login_rights_menu_id ) and login_rights_login_id=$user_id and login_rights_creation_date=(select max(login_rights_creation_date) from login_rights where login_rights_login_id=$user_id) group by m_menu_id";
          $res=  mysqli_query($con, $sql);
          return $res;
      }

      public function get_admin_distributor_detail_by_cmpny_id($con,$cmpny_id){
          $sql="select * from distributor_detail where distributor_company_id='$cmpny_id'";
          $res=mysqli_query($con,$sql);
          return $res;   
      }
      public function get_admin_distributor_detail_by_id($con,$id){
          $sql="select * from distributor_detail where distributor_id='$id'";
          $res=mysqli_query($con,$sql);
          return $res;
      }

      public function get_admin_bv_code($con,$bv_code){
          $sql="select bv_code_value,bv_code_use,bv_code_number,bv_code_id from bv_code where bv_code_number='$bv_code'";
           $res=mysqli_query($con,$sql);
          return $res; 
      }
        public function get_admin_password($con,$crr_user){
          $sql="select password from login where login_id='$crr_user'";
          $res=  mysqli_query($con, $sql);
          $row=  mysqli_fetch_array($res);
          $pass=$row['password'];
          return $pass;
      }
        public function get_admin_bv_all_code($con){
            $sql="select * from bv_code where bv_code_use='0'";
            $res=mysqli_query($con,$sql);
            return $res;
        }
        public function get_admin_bv_all_used_code($con){
             $sql="select * from bv_code where bv_code_use!='0' order by bv_code_used_date desc";
            $res=mysqli_query($con,$sql);
            return $res;
        }
        
        public function get_admin_distributor_pre_detail_by_app_code($con,$app_code){
            $sql="select * from distributor_pre_detail where distributor_user_unique_code='$app_code' and distributor_aprove_code_use='0'";
            $res=  mysqli_query($con, $sql);
            return $res;
        }
        public function get_admin_payment_mode_id($con,$mode_of_payment,$field1,$field2,$field3,$date,$date_time,$user_id){
            $sql="select payment_mode_id from payment_mode where payment_mode_mode='$mode_of_payment' and payment_mode_field1='$field1' and "
                    . "payment_mode_field2='$field2' and payment_mode_field3='$field3' and payment_mode_date='$date' and "
                    . "payment_mode_date_time='$date_time' and payment_mode_login_id='$user_id'";
            $res=  mysqli_query($con, $sql);
            return $res;
        }
        
        public function get_admin_transaction_detail($con,$type,$past_month,$present_month){
            if($type!="all"){
            $sql="SELECT sum(transaction_amount) as transaction_amount,date(transaction_date) as date FROM `transaction`,distributor_detail WHERE distributor_company_id=transaction_distributor_id and transaction_type='$type' and date(transaction_date) between '$past_month' and '$present_month' group by date(transaction_date)";
            }else{
              $sql="select date, transaction_distributor_id,sum(ifnull(credit,0)) as credit,sum(ifnull(debit,0)) as debit from(select date(transaction_date) as date, transaction_distributor_id, (case when transaction_type='money received' then transaction_amount end) as credit, (case when transaction_type='money dispatched' then transaction_amount end) as debit from transaction)as tt where date  between '$past_month' and '$present_month' group by date";  
            }
            $res=mysqli_query($con, $sql);
            return $res;
        }
        public function get_admin_total_transaction_detail($con,$type,$past_month,$present_month){
             if($type!="all"){
            $sql="SELECT sum(transaction_amount) as transaction_amount FROM `transaction`,distributor_detail WHERE distributor_company_id=transaction_distributor_id and transaction_type='$type' and date(transaction_date) between '$past_month' and '$present_month'";
            }else{
              $sql="select date, transaction_distributor_id,sum(ifnull(credit,0)) as credit,sum(ifnull(debit,0)) as debit from(select date(transaction_date) as date, transaction_distributor_id, (case when transaction_type='money received' then transaction_amount end) as credit, (case when transaction_type='money dispatched' then transaction_amount end) as debit from transaction)as tt where date between '$past_month' and '$present_month'";  
            }
            $res=mysqli_query($con, $sql);
            return $res;
        }


        public function get_admin_transaction_detail_by_date($con,$type,$date){
            if($type!="all"){
            $sql="select * from transaction where transaction_type='$type' and date(transaction_date)='$date'";
            }else{
                $sql="select date, transaction_distributor_id,ifnull(credit,0) as credit,ifnull(debit,0) as debit from(select date(transaction_date) as date, transaction_distributor_id, (case when transaction_type='money received' then transaction_amount end) as credit, (case when transaction_type='money dispatched' then transaction_amount end) as debit from transaction)as tt where date='$date' ORDER by date,transaction_distributor_id";
            }
            $res=mysqli_query($con, $sql);
            return $res;
        }
        
        public function get_admin_total_transaction_detail_by_user($con,$type,$past_month,$present_month,$user_id){
            if($type=="money dispatched"){
                $sql=" select date, transaction_distributor_id,sum(ifnull(credit,0)) as credit,sum(ifnull(debit,0)) as transaction_amount from(select date(transaction_date) as date, transaction_distributor_id, (case when transaction_type='money received' then transaction_amount end) as credit, (case when transaction_type='money dispatched' then transaction_amount end) as debit from transaction)as tt where transaction_distributor_id='$user_id' and date BETWEEN '$past_month' and '$present_month'";
            }if($type=="money received"){
                 $sql=" select date, transaction_distributor_id,sum(ifnull(credit,0)) as transaction_amount,sum(ifnull(debit,0)) as debit from(select date(transaction_date) as date, transaction_distributor_id, (case when transaction_type='money received' then transaction_amount end) as credit, (case when transaction_type='money dispatched' then transaction_amount end) as debit from transaction)as tt where transaction_distributor_id='$user_id' and date BETWEEN '$past_month' and '$present_month'";
            }if($type=="all"){
                $sql=" select date, transaction_distributor_id,sum(ifnull(credit,0)) as credit,sum(ifnull(debit,0)) as debit from(select date(transaction_date) as date, transaction_distributor_id, (case when transaction_type='money received' then transaction_amount end) as credit, (case when transaction_type='money dispatched' then transaction_amount end) as debit from transaction)as tt where transaction_distributor_id='$user_id' and date BETWEEN '$past_month' and '$present_month'";
            }
            $res=mysqli_query($con, $sql);
            return $res;
        }
        public function get_admin_transaction_detail_by_user($con,$type,$past_month,$present_month,$user_id){
            if($type=="money dispatched"){
                $sql=" select date, transaction_distributor_id,ifnull(credit,0) as credit,ifnull(debit,0) as transaction_amount from(select date(transaction_date) as date, transaction_distributor_id, (case when transaction_type='money received' then transaction_amount end) as credit, (case when transaction_type='money dispatched' then transaction_amount end) as debit from transaction)as tt where transaction_distributor_id='$user_id' and date BETWEEN '$past_month' and '$present_month'";
            }if($type=="money received"){
                $sql=" select date, transaction_distributor_id,ifnull(credit,0) as transaction_amount,ifnull(debit,0) as debit from(select date(transaction_date) as date, transaction_distributor_id, (case when transaction_type='money received' then transaction_amount end) as credit, (case when transaction_type='money dispatched' then transaction_amount end) as debit from transaction)as tt where transaction_distributor_id='$user_id' and date BETWEEN '$past_month' and '$present_month'";
            }if($type=="all"){
                $sql=" select date, transaction_distributor_id,ifnull(credit,0) as credit,ifnull(debit,0) as debit from(select date(transaction_date) as date, transaction_distributor_id, (case when transaction_type='money received' then transaction_amount end) as credit, (case when transaction_type='money dispatched' then transaction_amount end) as debit from transaction)as tt where transaction_distributor_id='$user_id' and date BETWEEN '$past_month' and '$present_month'";
            }
            $res=mysqli_query($con, $sql);
            return $res;
        }
        public function get_admin_no_of_entries($con,$payment_type){
            $sql="select payment_type_no_of_entries from payment_type where payment_type_type='$payment_type' ORDER by payment_type_id desc limit 1";
             $res=mysqli_query($con, $sql);
             $row=  mysqli_fetch_array($res);
             $entries=$row['payment_type_no_of_entries'];
            return $entries;
        }
        public function get_admin_no_of_entry($con,$reward_type,$date){
           $sql="select payment_type_no_of_entries from payment_type where payment_type_type='coupon' and date(payment_type_date) <= '$date' ORDER by payment_type_id desc limit 1"; 
       $res=mysqli_query($con, $sql);
             $row=  mysqli_fetch_array($res);
             $entries=$row['payment_type_no_of_entries'];
            return $entries;
           }
        public function get_admin_payment_type($con,$payment_type,$entries){
            $sql="select * from payment_type where payment_type_type='$payment_type'  order by payment_type_id desc limit $entries";
             $res=mysqli_query($con, $sql);
            return $res;
        }
        public function get_admin_commodity_amount($con,$payment_type,$entries,$commodity){
            $sql="select * from(select * from payment_type where payment_type_type='$payment_type' order by payment_type_id desc limit $entries) as tt where payment_type_commodity='$commodity'";
             $res=mysqli_query($con, $sql);
            return $res;
        }
        public function get_admin_rewards($con,$payment_type,$entries,$smallest){
            if($payment_type!="coupon"){
                
            $sql="select * from(select * from payment_type where payment_type_type='$payment_type' order by payment_type_id desc limit $entries) as tt where payment_type_from <= $smallest";
               
            }else{
                if($smallest!="default"){
                $sql="select * from(select * from payment_type where payment_type_type='$payment_type' order by payment_type_id desc limit $entries) as tt where payment_type_from <= $smallest order by payment_type_id desc limit 1";
                 }else{
               $sql="select * from(select * from payment_type where payment_type_type='$payment_type' order by payment_type_id desc limit $entries) as tt where payment_type_from ='$smallest' order by payment_type_id desc limit 1";
                }
                }
//            echo $sql;
            $res=mysqli_query($con, $sql);
            return $res;
            }
            public function get_admin_reward_coupon($con,$reward_type,$entries,$perecent,$date){
                if($perecent!="default"){
                $sql="select * from(select * from payment_type where payment_type_type='$reward_type' and date(payment_type_date) <= '$date' order by payment_type_id desc limit $entries) as tt where payment_type_from <= $perecent order by payment_type_id desc limit 1";
                }else{
                    $sql="select * from(select * from payment_type where payment_type_type='$reward_type' and date(payment_type_date) <= '$date' order by payment_type_id desc limit $entries) as tt where payment_type_from = '$perecent' order by payment_type_id desc limit 1";
                }
               //echo $sql."<br>";
                $res=mysqli_query($con, $sql);
            return $res;
            }

            public function get_admin_reward($payment_type,$greatest,$no_entry,$key){
                if($payment_type=="pair income" && $key==""){
                    $sql="select * from(select * from payment_type where payment_type_type='$payment_type' and payment_type_date<='$greatest' order by payment_type_id desc limit $no_entry) as tt order by payment_type_id limit 1";
                }else{
                $sql="select * from(select * from payment_type where payment_type_type='$payment_type' and payment_type_date<='$greatest' order by payment_type_id desc limit $no_entry) as tt order by payment_type_id limit $key,1";
                } return $sql;
            }
            public function get_admin_reward_entry($payment_type,$greatest){
                $sql="select payment_type_no_of_entries from payment_type where payment_type_type='$payment_type' and payment_type_date <= '$greatest'ORDER by payment_type_id desc limit 1";
                return $sql;
            }
            public function get_admin_reward_from($payment_type,$greatest,$no_entry){
                $sql="select * from(select payment_type_from from payment_type where payment_type_type='$payment_type' and payment_type_date<='$greatest' order by payment_type_id desc limit $no_entry)as tt order by payment_type_from";
            return $sql;
                }
            
            
            public function get_admin_direct_distributors($con){
                $sql="select count(distributor_id) as total,distributor_direct_distributor_id from distributor_detail GROUP by distributor_direct_distributor_id";
                $res=  mysqli_query($con, $sql);
                return $res;
            }
            public function get_admin_client_transaction($con){
                $sql="SELECT applicant_detail.applicant_detail_username,applicant_name,applicant_fund_detail,sum(transaction_amount) as paid,(applicant_fund_detail-sum(transaction_amount)) as remaining,date(applicant_creation_date)as date , adddate(date(applicant_creation_date), interval 45 day) as 'date_after_45_days',applicant_agent_name,'on date' as 'payment' FROM `applicant_detail`, transaction where applicant_detail_username=transaction_distributor_id and date(applicant_creation_date)=date(transaction_date) GROUP by applicant_name UNION SELECT applicant_detail.applicant_detail_username, applicant_name,applicant_fund_detail,sum(transaction_amount) as paid,(applicant_fund_detail-sum(transaction_amount)) as remaining,date(applicant_creation_date)as date , adddate(date(applicant_creation_date), interval 45 day) as 'date_after_45_days',applicant_agent_name,'after date' FROM `applicant_detail`, transaction where applicant_detail_username=transaction_distributor_id and date(applicant_creation_date)!=date(transaction_date) and applicant_detail.applicant_detail_username not in (SELECT applicant_detail.applicant_detail_username FROM `applicant_detail`, transaction where applicant_detail_username=transaction_distributor_id and date(applicant_creation_date)=date(transaction_date) GROUP by applicant_name) GROUP by applicant_name";
                 $res=  mysqli_query($con, $sql);
                return $res;
            }
            
            public function get_admin_complete_client_transaction($con,$date_after_45,$start_date){
                $sql="SELECT applicant_name,applicant_fund_detail,sum(transaction_amount) as paid,(applicant_fund_detail-sum(transaction_amount)) as remaining,date(applicant_creation_date)as date , adddate(date(applicant_creation_date), interval 45 day) as 'date_after_45_days',applicant_agent_name FROM `applicant_detail`, transaction where applicant_detail_username=transaction_distributor_id and date(applicant_creation_date) BETWEEN '$start_date' and '$date_after_45' group by applicant_detail.applicant_detail_username";
//                echo $sql."<br>";
                $res=  mysqli_query($con, $sql);
                return $res;
            }
        
            public function get_admin_paid_reward($con,$transaction_type,$reward_type,$from,$to){
                $sql="select * from transaction where transaction_type='$transaction_type' and payment_type='$reward_type' and (transaction_date between '$from' and '$to')";
                $res=  mysqli_query($con,$sql);
//                echo $sql;
                return $res;
            }
            public function get_admin_paid_reward11($con,$transaction_type,$reward_type,$id){
                $sql="select sum(transaction_amount),service_tax from transaction where transaction_type='$transaction_type' and payment_type='$reward_type' and 	transaction_distributor_id='$id'";
                $res=  mysqli_query($con,$sql);
//                echo $sql;
                return $res;
            }


          public function insert_admin_distributor_detail($con,$dis_company_id,$dis_name,
		$dis_fa_name,
		$dis_dob,$dis_gender,$dis_m_status,
					$dis_n_name,$dis_n_relationship,$dis_c_address,
                    $dis_p_address,$dis_district,$dis_state,
					$dis_city,$dis_pin,$dis_mobile,$dis_phone,
					$dis_email,$dis_p_a_amount,$dis_id_proof,
                    $dis_add_proof,$dis_acc_bank_name,$dis_acc_branch,
                    $dis_acc_ifsc,$dis_acc_no,$dis_acc_name,
					$dis_qualification,$dis_business,$dis_emp_name,$dis_buss_no,$dis_annual_inc,
                    $dis_rd_1,$dis_rd_2,$dis_rd_3,$dis_rd_4,$dis_pass_no,
					$dis_placement_req,$dis_sponsor_id,$date_time,$dis_image_path,$direct_id,$bv_code1){
         $sql="insert into distributor_detail(distributor_company_id,distributor_name,
		distributor_father_name,distributor_dob,distributor_gender,distributor_m_status,
                    distributor_nominee_name,distributor_relationship,
					distributor_current_address,
					distributor_permanent_address,distributor_district,distributor_state,
                    distributor_city,distributor_pincode,distributor_mobile,
					distributor_phone,
					distributor_email,distributor_pan,distributor_id_proof,
					distributor_add_proof,
                 distributor_account_bank,distributor_account_branch,
                 distributor_account_ifsc,distributor_account_acc_no,
				 distributor_account_acc_name,
				 distributor_qualification,distributor_business,
				 distributor_name_employer,
                 distributor_business_no,distributor_anual_income,distributor_ref1,
				 distributor_ref2,
				 distributor_ref3,distributor_ref4,distributor_passport_no,
				 distributor_placement,
                 distributor_distributor_id,distributor_creation_date,
				 distributor_image_path,distributor_direct_distributor_id,distributor_bv,status)"
                 . " values('$dis_company_id','$dis_name','$dis_fa_name','$dis_dob',
				 '$dis_gender',
				 '$dis_m_status','$dis_n_name','$dis_n_relationship','$dis_c_address',
                    '$dis_p_address','$dis_district','$dis_state','$dis_city','$dis_pin',
					'$dis_mobile','$dis_phone','$dis_email','$dis_p_a_amount','$dis_id_proof',
                    '$dis_add_proof','$dis_acc_bank_name','$dis_acc_branch',
                    '$dis_acc_ifsc','$dis_acc_no','$dis_acc_name','$dis_qualification',
					'$dis_business','$dis_emp_name','$dis_buss_no','$dis_annual_inc',
                    '$dis_rd_1','$dis_rd_2','$dis_rd_3','$dis_rd_4','$dis_pass_no',
					'$dis_placement_req','$dis_sponsor_id',
					'$date_time','$dis_image_path','$direct_id','$bv_code1','1')";
        $res= mysqli_query($con,"$sql");
        return $res;
         }
		 
		 public function get_admin_distributors1($con){
        $sql="select distributor_id,distributor_company_id,distributor_name,distributor_bv from distributor_detail where status=0 order by distributor_id desc";
		echo"$sql";
        $res=  mysqli_query($con, $sql);
        return $res;
    }
	public function update_pre_distributor($con,$dis_company_id)
		{
			  $sql="update distributor_detail set status = '1' where distributor_company_id='$dis_company_id'";
            $res=  mysqli_query($con, $sql);
            return $res;
		}
				 
		 
		 
		 
		 
		 
		 
		         public function insert_admin_distributor_detail1($con,$dis_company_id,$dis_name,$dis_fa_name,$dis_dob,$dis_gender,$dis_m_status,$dis_n_name,$dis_n_relationship,$dis_c_address,
                    $dis_p_address,$dis_district,$dis_state,$dis_city,$dis_pin,$dis_mobile,$dis_phone,$dis_email,$dis_p_a_amount,$dis_id_proof,
                    $dis_add_proof,$dis_acc_bank_name,$dis_acc_branch,
                    $dis_acc_ifsc,$dis_acc_no,$dis_acc_name,$dis_qualification,$dis_business,$dis_emp_name,$dis_buss_no,$dis_annual_inc,
                    $dis_rd_1,$dis_rd_2,$dis_rd_3,$dis_rd_4,$dis_pass_no,$dis_placement_req,$dis_sponsor_id,$dis_coupon,$shagun,$defense,$login_id,$date_time,$dis_image_path,$distributor_bv,$direct_id){
         $sql="insert into distributor_detail(distributor_company_id,distributor_name,distributor_father_name,distributor_dob,distributor_gender,distributor_m_status,"
                    . "distributor_nominee_name,distributor_relationship,distributor_current_address,distributor_permanent_address,distributor_district,distributor_state,"
                    . "distributor_city,distributor_pincode,distributor_mobile,distributor_phone,distributor_email,distributor_pan,distributor_id_proof,distributor_add_proof,"
                 . "distributor_account_bank,distributor_account_branch,"
                 . "distributor_account_ifsc,distributor_account_acc_no,distributor_account_acc_name,distributor_qualification,distributor_business,distributor_name_employer,"
                 . "distributor_business_no,distributor_anual_income,distributor_ref1,distributor_ref2,distributor_ref3,distributor_ref4,distributor_passport_no,distributor_placement,"
                 . "distributor_distributor_id,distributor_coupon,distributor_shagun,distributor_defense,distributor_login_id,distributor_creation_date,distributor_image_path,distributor_direct_distributor_id,distributor_bv)"
                 . " values('$dis_company_id','$dis_name','$dis_fa_name','$dis_dob','$dis_gender','$dis_m_status','$dis_n_name','$dis_n_relationship','$dis_c_address',
                    '$dis_p_address','$dis_district','$dis_state','$dis_city','$dis_pin','$dis_mobile','$dis_phone','$dis_email','$dis_p_a_amount','$dis_id_proof',
                    '$dis_add_proof','$dis_acc_bank_name','$dis_acc_branch',
                    '$dis_acc_ifsc','$dis_acc_no','$dis_acc_name','$dis_qualification','$dis_business','$dis_emp_name','$dis_buss_no','$dis_annual_inc',
                    '$dis_rd_1','$dis_rd_2','$dis_rd_3','$dis_rd_4','$dis_pass_no','$dis_placement_req','$dis_sponsor_id','$dis_coupon','$shagun','$defense','$login_id','$date_time','$dis_image_path','$direct_id','$distributor_bv')";
					//echo"$sql";
        $res= mysqli_query($con,"$sql");
        return $res;
         }
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
	 public function insert_admin_pre_distributor_detail1($con,$dis_company_id,$dis_name,$dis_fa_name,$dis_dob,$dis_gender,$dis_m_status,$dis_n_name,$dis_n_relationship,$dis_c_address,
                    $dis_p_address,$dis_district,$dis_state,$dis_city,$dis_pin,$dis_mobile,$dis_phone,$dis_email,$dis_p_a_amount,$dis_id_proof,
                    $dis_add_proof,$dis_acc_bank_name,$dis_acc_branch,
                    $dis_acc_ifsc,$dis_acc_no,$dis_acc_name,$dis_qualification,$dis_business,$dis_emp_name,$dis_buss_no,$dis_annual_inc,
                    $dis_rd_1,$dis_rd_2,$dis_rd_3,$dis_rd_4,$dis_pass_no,$dis_placement_req,$dis_sponsor_id,$login_id,$date_time,$dis_image_path,$ss,$direct_id){
        $sql="insert into distributor_detail(distributor_company_id,distributor_name,distributor_father_name,distributor_dob,distributor_gender,distributor_m_status,"
                    . "distributor_nominee_name,distributor_relationship,distributor_current_address,distributor_permanent_address,distributor_district,distributor_state,"
                    . "distributor_city,distributor_pincode,distributor_mobile,distributor_phone,distributor_email,distributor_pan,distributor_id_proof,distributor_add_proof,"
                 . "distributor_account_bank,distributor_account_branch,"
                 . "distributor_account_ifsc,distributor_account_acc_no,distributor_account_acc_name,distributor_qualification,distributor_business,distributor_name_employer,"
                 . "distributor_business_no,distributor_anual_income,distributor_ref1,distributor_ref2,distributor_ref3,distributor_ref4,distributor_passport_no,distributor_placement,"
                 . "distributor_distributor_id,distributor_login_id,distributor_creation_date,distributor_image_path,distributor_direct_distributor_id)"
                 . " values('$dis_company_id','$dis_name','$dis_fa_name','$dis_dob','$dis_gender','$dis_m_status','$dis_n_name','$dis_n_relationship','$dis_c_address',
                    '$dis_p_address','$dis_district','$dis_state','$dis_city','$dis_pin','$dis_mobile','$dis_phone','$dis_email','$dis_p_a_amount','$dis_id_proof',
                    '$dis_add_proof','$dis_acc_bank_name','$dis_acc_branch',
                    '$dis_acc_ifsc','$dis_acc_no','$dis_acc_name','$dis_qualification','$dis_business','$dis_emp_name','$dis_buss_no','$dis_annual_inc',
                    '$dis_rd_1','$dis_rd_2','$dis_rd_3','$dis_rd_4','$dis_pass_no','$dis_placement_req','$dis_sponsor_id','$login_id','$date_time','$dis_image_path','$direct_id')";
        $res= mysqli_query($con,"$sql");
        return $res;
         }	 
		 
         
          public function insert_admin_pre_distributor_detail($con,$dis_company_id,$dis_name,$dis_fa_name,$dis_dob,$dis_gender,$dis_m_status,$dis_n_name,$dis_n_relationship,$dis_c_address,
                    $dis_p_address,$dis_district,$dis_state,$dis_city,$dis_pin,$dis_mobile,$dis_phone,$dis_email,$dis_p_a_amount,$dis_id_proof,
                    $dis_add_proof,$dis_acc_bank_name,$dis_acc_branch,
                    $dis_acc_ifsc,$dis_acc_no,$dis_acc_name,$dis_qualification,$dis_business,$dis_emp_name,$dis_buss_no,$dis_annual_inc,
                    $dis_rd_1,$dis_rd_2,$dis_rd_3,$dis_rd_4,$dis_pass_no,$dis_placement_req,$dis_sponsor_id,$login_id,$date_time,$dis_image_path,$ss,$direct_id){
        echo $sql="insert into distributor_pre_detail(distributor_company_id,distributor_name,distributor_father_name,distributor_dob,distributor_gender,distributor_m_status,"
                    . "distributor_nominee_name,distributor_relationship,distributor_current_address,distributor_permanent_address,distributor_district,distributor_state,"
                    . "distributor_city,distributor_pincode,distributor_mobile,distributor_phone,distributor_email,distributor_pan,distributor_id_proof,distributor_add_proof,"
                 . "distributor_account_bank,distributor_account_branch,"
                 . "distributor_account_ifsc,distributor_account_acc_no,distributor_account_acc_name,distributor_qualification,distributor_business,distributor_name_employer,"
                 . "distributor_business_no,distributor_anual_income,distributor_ref1,distributor_ref2,distributor_ref3,distributor_ref4,distributor_passport_no,distributor_placement,"
                 . "distributor_distributor_id,distributor_login_id,distributor_creation_date,distributor_image_path,distributor_user_unique_code,distributor_direct_distributor_id)"
                 . " values('$dis_company_id','$dis_name','$dis_fa_name','$dis_dob','$dis_gender','$dis_m_status','$dis_n_name','$dis_n_relationship','$dis_c_address',
                    '$dis_p_address','$dis_district','$dis_state','$dis_city','$dis_pin','$dis_mobile','$dis_phone','$dis_email','$dis_p_a_amount','$dis_id_proof',
                    '$dis_add_proof','$dis_acc_bank_name','$dis_acc_branch',
                    '$dis_acc_ifsc','$dis_acc_no','$dis_acc_name','$dis_qualification','$dis_business','$dis_emp_name','$dis_buss_no','$dis_annual_inc',
                    '$dis_rd_1','$dis_rd_2','$dis_rd_3','$dis_rd_4','$dis_pass_no','$dis_placement_req','$dis_sponsor_id','$login_id','$date_time','$dis_image_path','$ss','$direct_id')";
        $res= mysqli_query($con,"$sql");
        return $res;
         }
         
         
         
      public function insert_admint_applicant_detail($con,$app_name,$app_s_of,$app_dob,$app_nationality,$app_address,$app_pin,$app_tel,$app_fax,$app_email,$dis_image_path,
                $app_mob_no,$app_qualification,$app_business,$app_emp_name,$app_buss_no,$app_annual_inc,$app_fund_detail,$app_scnd_name,$app_scnd_s_of,$app_scnd_dob,$app_scnd_nationality,
                $app_scnd_pin,$app_scnd_tel,$app_scnd_add,$app_scnd_fax,$app_scnd_email,$app_scnd_mob_no,$residedent,$payment,$app_prop_type,
                $app_sector,$app_pocket,$app_unit,$app_floor,$app_res_area,$app_base_rate,$app_basic_sale_price,$parking,$storage,$club,$app_pan_no,
                $app_agent_name,$app_agent_ph,$login_id,$date_time,$applicant_detail_username,$applicant_detail_password){
          $sql="insert into applicant_detail(applicant_name,applicant_fa_name,applicant_dob,applicant_nationality,applicant_address,applicant_pincode,applicant_tel_no,"
                  . "applicant_fax_no,applicant_email,applicant_image_path,applicant_mobile_no,applicant_qualification,applicant_bussiness,applicant_employeer_name,"
                  . "applicant_business_no,applicant_annual_inc,applicant_fund_detail,applicant_scnd_name,applicant_scnd_fa_name,applicant_scnd_dob,applicant_scnd_nationality,"
                  . "applicant_scnd_pincode,applicant_scnd_tel_no,applicant_scnd_address,applicant_scnd_fax_no,applicant_scnd_email,applicant_scnd_mobile_no,applicant_residential,"
                  . "applicant_payment_plan,applicant_property_type,applicant_sector,applicant_pocket_no,applicant_unit_no,applicant_floor,applicant_requirement_area,"
                  . "applicant_prop_base_rate,applicant_prop_basic_sale_price,applicant_car_parking,applicant_storage_space,applicant_club,applicant_acc_no,"
                  . "applicant_agent_name,applicant_agent_phone_no,applicant_login_id,applicant_creation_date,applicant_detail_username,applicant_detail_password) "
                  . "values('$app_name','$app_s_of','$app_dob','$app_nationality','$app_address','$app_pin','$app_tel','$app_fax','$app_email','$dis_image_path',
                '$app_mob_no','$app_qualification','$app_business','$app_emp_name','$app_buss_no','$app_annual_inc','$app_fund_detail','$app_scnd_name','$app_scnd_s_of','$app_scnd_dob','$app_scnd_nationality',
                '$app_scnd_pin','$app_scnd_tel','$app_scnd_add','$app_scnd_fax','$app_scnd_email','$app_scnd_mob_no','$residedent','$payment','$app_prop_type',
                '$app_sector','$app_pocket','$app_unit','$app_floor','$app_res_area','$app_base_rate','$app_basic_sale_price','$parking','$storage','$club','$app_pan_no',
                '$app_agent_name','$app_agent_ph','$login_id','$date_time','$applicant_detail_username','$applicant_detail_password')";
          $res= mysqli_query($con,"$sql");
        return $res;
          }
          
          public function insert_admin_dis_in_tree($con,$dis_company_id,$dis_name,$dis_sponsor_id,$position){
              $sql="insert into tree(id,first_name,parent_id,hide,position) values('$dis_company_id','$dis_name','$dis_sponsor_id','0','$position')";
              $res=  mysqli_query($con,"$sql");
              return $res;
          }
          
            public function insert_admin_bv_code($con,$user_bv,$code,$date_time){
             $sql="insert into bv_code(bv_code_number,bv_code_value,bv_code_creation_date) values('$code','$user_bv','$date_time')";
		
               $res= mysqli_query($con,"$sql");
              return $res;
          }
          
          public function update_admin_tree_by_parent($con,$dis_company_id,$dis_sponsor_id,$dis_name){
              $sql="update tree set id='$dis_company_id' , first_name='$dis_name' where parent_id='$dis_sponsor_id' and first_name='blank' ";
              $res=  mysqli_query($con, $sql);
              return $sql;
          }
          public function insert_admin_login($con,$user_name,$password,$crr_user,$date_time){
              $sql="insert into login(username,password,login_creation_date,login_login_id) values('$user_name','$password','$date_time','$crr_user')";
			 // echo"$sql";
              $res= mysqli_query($con, $sql);
              return $res;
          }
          
          public function insert_admin_payment_mode($con,$mode_of_payment,$field1,$field2,$field3,$date,$date_time,$login_id){
           $sql="insert into payment_mode(payment_mode_mode,payment_mode_field1,payment_mode_field2,payment_mode_field3,payment_mode_date,payment_mode_date_time,"
                      . "payment_mode_login_id) values('$mode_of_payment','$field1','$field2','$field3','$date','$date_time','$login_id')";
              $res= mysqli_query($con,$sql);
              return $sql;
          }
		  
		  public function insert_admin_client_payment_mode($con,$mode_of_payment,$field1,$field2,$field3,$date,$date_time,$login_id,$amount,$applicant_id){
              $sql="insert into client_payment_mode(client_payment_mode_mode,client_payment_mode_field1,client_payment_mode_field2,client_payment_mode_field3,client_payment_mode_date,client_payment_mode_date_time,client_payment_mode_login_id,client_payment_mode_amount,client_payment_mode_applicant_id) values('$mode_of_payment','$field1','$field2','$field3','$date','$date_time','$login_id','$amount','$applicant_id')";
			 // echo"$sql";
              $res= mysqli_query($con,$sql);
              return $sql;
          }
		  
          public function insert_into_transactions($con,$transaction_type,$user_id,$amount,$mode_of_payment,$mode_id,$date_time,$login_id,$payment_type){
			  $x=($amount*100)/85;
			  $y=$x*15/100;
       $sql="insert into transaction(transaction_type,transaction_distributor_id,transaction_amount,transaction_payment_mode,transaction_payment_mode_id
        ,payment_type,transaction_date,transaction_login_id,service_tax) values('$transaction_type','$user_id','$amount','$mode_of_payment','$mode_id','$payment_type','$date_time','$login_id','$y')";
//					  echo"$sql";
              $res= mysqli_query($con,$sql);
              return $res;
          }
          
          
           public function update_admin_login_password($con,$crr_user,$password){
              $sql="update login set password = '$password' where login_id='$crr_user'";
              $res=  mysqli_query($con, $sql);
              return $res;
          }
          public function update_admin_login($con,$user_name,$password){
               $sql="update login set password = '$password' where username='$user_name'";
              $res=  mysqli_query($con, $sql);
              return $res;
          }
        public function update_admin_distributor_bv($con,$dis_id,$user_bv){
            $sql="update distributor_detail set distributor_bv = '$user_bv' where distributor_company_id='$dis_id'";
            $res=  mysqli_query($con, $sql);
            return $res;
        }
        public function update_admin_bv_code($con,$bv_code_use,$user_id,$date_time,$bv_code){
            $sql="update bv_code set bv_code_use='$bv_code_use', bv_code_used_by='$user_id', bv_code_used_date='$date_time' where bv_code_number='$bv_code'";
             $res=  mysqli_query($con, $sql);
            return $res;
        }
				
      public function update_admin_dist_bv_code($con,$user_id,$vb_code_use,$bv_code_id,$distributor_bv){
$sql="UPDATE bv_code SET bv_code_used_by ='$user_id',bv_code_use='$vb_code_use' WHERE bv_code_id ='$bv_code_id' and bv_code_number='$distributor_bv'";
	// echo"$sql";
        $res=  mysqli_query($con, $sql);
            return $res;
		 	}
		
        public function update_admin_distributor_approve($con,$code){
            $sql="update distributor_pre_detail set distributor_aprove_code_use='1' where distributor_user_unique_code='$code'";
            $res=  mysqli_query($con, $sql);
            return $res;
        }

        public function check_admin_page_rights($con,$page_name,$user_id){
            $sql="select m_menu_id FROM main_menu where m_menu_link='$page_name' and m_menu_id in(select m_menu_id from main_menu,login_rights where (m_menu_id = login_rights_menu_id ) and login_rights_login_id=$user_id and login_rights_creation_date=(select max(login_rights_creation_date) from login_rights where login_rights_login_id=$user_id) group by m_menu_id)";
            $res=  mysqli_query($con, $sql);
            return $res;
        }
			
			public function get_admin_distributor_pre_form_details($con) 
			{
        $distributor_pre_detail = "SELECT * FROM  distributor_detail";
        $res1 = mysqli_query($con, "$distributor_pre_detail");
        return $res1;
            }
			
			public function get_admin_distributor_pre_form_details123($con,$id) 
			{
        $distributor_pre_detail = "SELECT * FROM  distributor_detail where distributor_id='$id'";
        $res1 = mysqli_query($con, "$distributor_pre_detail");
        return $res1;
            }
			
			
			public function get_admin_UPDATE_distributer_payment_details($con,$distributor_company_id,$distributor_name,$distributor_father_name,$distributor_dob,$distributor_gender,$distributor_m_status,$distributor_nominee_name,$distributor_relationship
										,$distributor_current_address
										,$distributor_permanent_address
										,$distributor_state
										,$distributor_city
										,$distributor_district
										,$distributor_pincode
										,$distributor_mobile
										,$distributor_phone
										,$distributor_email
										,$distributor_pan
										,$distributor_id_proof
										,$distributor_add_proof
								
										,$distributor_payment_mode
										,$distributor_bank
										,$distributor_bank_branch
										,$distributor_amount
										,$distributor_amoun_word
										,$distributor_account_ifsc
										
										
										,$distributor_account_acc_no
										,$distributor_account_acc_name
										,$distributor_qualification
										,$distributor_business
										,$distributor_name_employer
										,$distributor_business_no
										,$distributor_anual_income
										,$distributor_ref1
										,$distributor_ref2
										,$distributor_ref3
										,$distributor_ref4
										,$distributor_passport_no
										,$distributor_placement
										,$distributor_distributor_id
										,$distributor_direct_distributor_id
										,$distributor_coupon
										,$distributor_coupon_number
										,$distributor_shagun
										,$distributor_defense
										,$distributor_bv
										,$distributor_creation_date
									){
									 $distributor_pre_detail =	"update  distributor_detail  set distributor_name='$distributor_name',
										distributor_father_name='$distributor_father_name',
										distributor_dob='$distributor_dob'
										,distributor_gender='$distributor_gender'
										,distributor_m_status='$distributor_m_status'
										,distributor_nominee_name='$distributor_nominee_name'
										,distributor_relationship='$distributor_relationship'
										,distributor_current_address='$distributor_current_address'
										,distributor_permanent_address='$distributor_permanent_address'
										,distributor_state='$distributor_state'
										,distributor_city='$distributor_city'
										,distributor_district='$distributor_district'
										,distributor_pincode='$distributor_pincode'
										,distributor_mobile='$distributor_mobile'
										,distributor_phone='$distributor_phone'
										,distributor_email='$distributor_email'
										,distributor_pan='$distributor_pan'
										,distributor_id_proof='$distributor_id_proof'
										,distributor_add_proof='$distributor_add_proof'
								
										,distributor_payment_mode='$distributor_payment_mode'
										,distributor_bank='$distributor_bank'
										,distributor_bank_branch='$distributor_bank_branch'
										,distributor_amount='$distributor_amount'
										,distributor_amoun_word='$distributor_amoun_word'
										,distributor_account_ifsc='$distributor_account_ifsc'
										
										
										,distributor_account_acc_no='$distributor_account_acc_no'
										,distributor_account_acc_name='$distributor_account_acc_name'
										,distributor_qualification='$distributor_qualification'
										,distributor_business='$distributor_business'
										,distributor_name_employer='$distributor_name_employer'
										,distributor_business_no='$distributor_business_no'
										,distributor_anual_income='$distributor_anual_income'
										,distributor_ref1='$distributor_ref1'
										,distributor_ref2='$distributor_ref2'
										,distributor_ref3='$distributor_ref3'
										,distributor_ref4='$distributor_ref4'
										,distributor_passport_no='$distributor_passport_no'
										,distributor_placement='$distributor_placement'
										,distributor_distributor_id='$distributor_distributor_id'
										,distributor_direct_distributor_id='$distributor_direct_distributor_id'
										,distributor_coupon='$distributor_coupon'
										,distributor_coupon_number='$distributor_coupon_number'
										,distributor_shagun='$distributor_shagun'
										,distributor_defense='$distributor_defense'
										,distributor_bv='$distributor_bv'
										,distributor_creation_date='$distributor_creation_date' where distributor_company_id='$distributor_company_id'";
									
									$res1 = mysqli_query($con, "$distributor_pre_detail");
                                   return $res1;
									}
			
			
			
			
			
			
      
public function get_admin_insert_distributer_payment_details($con,$payment_mode,$distributor_bank,$distributor_bank_branch,$amount,$amount_in_words,$coupon_no,$product_details,$project_shagun_city,$project_defense_enclave,$distributor_id,$amount_paid)
{
	$distributor_payment_insert="update distributor_detail set distributor_payment_mode='$payment_mode',distributor_bank='$distributor_bank',distributor_bank_branch='$distributor_bank_branch',distributor_amount='$amount',distributor_amoun_word='$amount_in_words',distributor_shagun='$project_shagun_city',distributor_defense='$project_defense_enclave',distributor_coupon='$product_details',distributor_coupon_number='$coupon_no',distributor_pre_detail_paid_unpaid='$amount_paid' where distributor_id='$distributor_id'";
	//echo 



"$distributor_payment_insert";
 $distributor_payment_insert_execute=mysqli_query($con,$distributor_payment_insert);
 return $distributor_payment_insert_execute;
}


public function get_admin_distributor_edit($con,$id)
{
$get_admin_distributor_edit="select * from distributor_detail where distributor_id='$id'";	
$get_admin_distributor_edit_exe=mysqli_query($get_admin_distributor_edit);
return $get_admin_distributor_edit_exe;	
}

									   
									  
public function get_admin_paid_reward12($con,$reward_type,$bv)
{
 $sql="select payment_type_commodity,payment_type_price,payment_type_position FROM `payment_type` where payment_type_to=(SELECT max(payment_type_to) FROM `payment_type` WHERE  payment_type_to<=$bv AND payment_type_type='$reward_type')";
$res=  mysqli_query($con,$sql);
//                echo $sql;
 return $res;
            }
			
public function date_wise_payment($con,$from,$to)
{
 $sql="select * FROM `date_wise_user_bv` where date_time between '$from' and '$to'";
$res=  mysqli_query($con,$sql);
//                echo $sql;
 return $res;
            }

public function fetch_amount_tax12($con,$row_id)
{
 echo $sql="SELECT * FROM transaction  where transaction_type='money dispatched' and transaction_distributor_id='$row_id' having  max('transaction_date')";
$res=  mysqli_query($con,$sql);
 return $res;
            }


}
        
?>





