
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>jQuery Twbs Pagination Plugin Demo</title>
<link href="http://www.jqueryscript.net/css/jquerysctipttop.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="http://netdna.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css">
</head>
<body>
<div id="jquery-script-menu">
<div class="jquery-script-center">
<div class="container" style="margin-top:150px;">
<div id="page-content" class="well text-center">Page 1</div>
            <div class="text-center">
                <ul id="pagination-demo" class="pagination-lg"></ul>
            </div>
            </div>
<script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
<script src="https://github.com/esimakin/twbs-pagination/blob/develop/jquery.twbsPagination.js"></script>
            <script>
 $('#pagination-demo').twbsPagination({
        totalPages: 35,
        visiblePages: 7,
        onPageClick: function (event, page) {
            $('#page-content').text('Page ' + page);
        }
    });
</script>

</body>
</html>
