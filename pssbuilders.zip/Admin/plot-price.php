<?php
session_start();
if(!isset($_SESSION['user']))
{
	header("Location: index.php");
}
else
{
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Dashboard</title>
<meta name="description" content="Flatter - Flat Admin Theme">
<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/layout.css">
<link rel="stylesheet" href="css/style3.css">
<script type="text/javascript" src="js/jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.10.4.custom.min.js"></script>
</head>
<body id="body">

		<!-- Header -->
		<?php include './header.php'; ?>

       <?php include './left-menu.php'; ?>
		<!-- Header -->
		
<section id="main-wrapper">
		<h3 class="subtitle">Upload Plot Price</h3>
          <hr>

		  <div class="row">
			  <div class="col-md-12">
				  	<div class="panel panel-default">
					  <div class="panel-heading">
					    <h3 class="panel-title"><strong>Plot Price Upload</strong></h3>
						<br>
					    			
<?php
		if(isset($_POST['btn_upload']))
    {
				$plot_no=$_POST['plot_no'];
				$plot_name=$_POST['plot_name'];
				$plot_width=$_POST['plot_width'];
				$plot_height=$_POST['plot_height'];
				$plot_price=$_POST['plot_price'];
				$plot_Availability=$_POST['plot_Availability'];
$res = $conn->insert_plot_price_details($con,$plot_no,$plot_name,$plot_width,$plot_height,$plot_price,$plot_Availability,$date_time);
	           
	if($res)
		{
			?>
			<div class="alert alert-success">
  <strong>Plot details Updated successfully</strong>
</div>
			<?php
		}
		else
		{
			?>
			<div class="alert alert-danger">
  <strong>Plot details Not Updated</strong>
          </div>
			<?php
		}	
    }
?>

			
					  </div>
					  <div class="panel-body">
					  <form method="POST" enctype="multipart/form-data" name="image_upload">
						<table class="table">
					        <tr>
							  <td><strong>Plot No.</strong></td>
							  <td>
							 <input type="text" name="plot_no" class="form-control" required="required">
							  </td>
					        </tr>
							 <tr>
							  <td><strong>Plot Name</strong></td>
							  <td>
							 <input type="text" name="plot_name" class="form-control" required="required">
							  </td>
					        </tr>
							 <tr>
							  <td><strong>Plot Width</strong></td>
							  <td>
							 <input type="text" name="plot_width" class="form-control" required="required">
							  </td>
					        </tr>
							 <tr>
							  <td><strong>Plot Height</strong></td>
							  <td>
							 <input type="text" name="plot_height" class="form-control" required="required">
							  </td>
					        </tr>
							<tr>
							  <td><strong>Plot Price</strong></td>
							  <td>
							 <input type="text" name="plot_price" class="form-control" required="required">
							  </td>
					        </tr>
							<tr>
							  <td><strong>Plot Availability</strong></td>
							  <td>
							 <input type="text" name="plot_Availability" class="form-control" required="required">
							  </td>
					        </tr>
							 <tr>
							  <td></td>
							  <td>
<button type="submit" name="btn_upload" class="btn btn-info" style="background-color:#3ba0ff;"><i class="fa fa-upload"></i> update</button>
<button type="reset" name="cancel" class="btn btn-info" style="background-color:#3ba0ff;"><i class="fa fa-refresh"></i> Reset</button>
							  </td>
					        </tr>
					    </table>
						</form>
					  </div>
					</div>
				</div>
</div>

				

</section>


<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<div class="offline-ui offline-ui-up"><div class="offline-ui-content"></div><a href="" class="offline-ui-retry"></a>
</div>
</body>
</html>
<?php
 } 
?>