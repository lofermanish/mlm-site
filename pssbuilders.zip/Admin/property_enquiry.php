<?php
$page = 1;
include_once '../property/pss_db.php';
$conn = new DB_con();
$con = $conn->connection();
//include_once 'property/function_list.php';
//include_once 'property/default_values.properties';
$functions = new functions();session_start();
if(!isset($_SESSION['user']))
{
	header("Location: index.php");
}
else
{
	
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Dashboard</title>
<meta name="description" content="Flatter - Flat Admin Theme">
<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/layout.css">
<link rel="stylesheet" href="css/style3.css">
<script type="text/javascript" src="js/jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.10.4.custom.min.js"></script>
</head>
<body id="body">

		<!-- Header -->
		<header class="navbar main-header" style="background-color:#3ba0ff;">
     <script src="js/jquery.blockUI.min.js" ></script>  
     <link rel="stylesheet" href="css/spinner.css">
    <a class="navbar-brand" href="">
        <span style="font-size:17px;">Pss Builders&nbsp;</span></div>
    </a>
    <ul class="nav navbar-nav navbar-left sidebar-toggle-ul">
        <li class="navbar-main hidden-lg hidden-md">
            <a href="javascript:void(0);" id="sidebar-toggle">
                <span class="meta">
                    <span class="arrow"><i class="arrow fa fa-angle-right pull-right"></i></span>
                </span>
            </a>
        </li>

        <li class="navbar-main hidden-sm hidden-xs">
            <a href="javascript:void(0);" id="sidebar-collapse">
                <span class="meta">
                    <span class="icon"><i class="fa fa-outdent" style="color:blue;"></i></span>
                </span>
            </a>
        </li>
    </ul>
<?php
	        $id=$_SESSION['user'];
            $name=$conn->get_admin_login_name($con,$id);
            $res=$conn->get_admin_distributor_detail_by_cmpny_id($con,$name);
            $row=  mysqli_fetch_array($res);
            $dis_name=$row['distributor_name'];
            $image_path=$row['distributor_image_path'];
            if($image_path=="../image_uploads/" || $image_path==""){
                $image_path="images/avatar.png";
            }
            ?>
    <ul class="nav navbar-nav navbar-right">
        <li class="dropdown icons-dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><span style="color:blue;">Company Id : <?php echo $name ?></span></a>
<!--            <ul class="dropdown-menu list-group">
                <li class="list-group-item heading"><p>Notification</p></li>
                <a href="http://flatter.cloudtub.com/index.html#" class="list-group-item"><i class="fa fa-user"></i> <p>John sent you friend request</p></a>
                <a href="http://flatter.cloudtub.com/index.html#" class="list-group-item"><i class="fa fa-envelope-o"></i> <p>Sam sent important mail</p></a>
                <a href="http://flatter.cloudtub.com/index.html#" class="list-group-item"><i class="fa fa-calendar"></i> <p>You have pending job</p></a>
                <a href="http://flatter.cloudtub.com/index.html#" class="list-group-item"><i class="fa fa-money"></i> <p>Received $1826 from client</p></a>

            </ul>-->
        </li>
            

        <li class="dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><span  style="color:blue;"><?php echo "$dis_name" ?></span> <img class="img-circle" src="<?php echo $image_path; ?>" alt="avatar"> <b class="caret"></b></a>
            <ul class="dropdown-menu">
<!--                <li><a href="http://flatter.cloudtub.com/index.html#"><i class="fa fa-globe" ></i> Notification <span class="label label-danger"> 5</span></a></li>
                <li><a href="http://flatter.cloudtub.com/index.html#"><i class="fa fa-user"></i> Profile</a></li>
                <li><a href="http://flatter.cloudtub.com/index.html#"><i class="fa fa-gear"></i> Settings</a></li>-->
                <li><a href="logout.php?logout"><i class="fa fa-share"></i> Logout</a></li>
            </ul>
        </li>
    </ul>
</header>

       <?php include './left-menu.php'; ?>
		<!-- Header -->
		
<section id="main-wrapper">
		<h3 class="subtitle">Propery Enquiry Details</h3>
          <hr>

		  <div class="row">
			  <div class="col-md-12">
				  	<div class="panel panel-default">
					  <div class="panel-heading">
					    <h3 class="panel-title"><strong>Propery Enquiry Details</strong></h3>
						<br>
						</div>
						
                            <table class="table table-bordered">
    <thead>
      <tr>                              <th>S.No.</th>
                                        <th>Name</th>
										<th>Phone</th>
										<th>Email</th>
										<th>City</th>
										<th>Minimum Range</th>
										<th>Maximum Range</th>
					
										<th>Date Of Enquiry</th>
		</tr>
		
    </thead>
    <tbody>
      				<?php
				 
                   
                    
				 $count=0;
				 $res = $conn->get_admin_property_enquiry($con);
				 while ($row = mysqli_fetch_array($res)) {
				 //$plot_price_details_id=$row['plot_price_details_id'];
				 $count=$count+1;
				 ?>
	<tr class="1">
	<td><?php echo $count; ?></td>
	<td><?php echo $row['property_enquiry_name']; ?></td>
	<td><?php echo $row['property_enquiry_phone']; ?></td>
	<td><?php echo $row['property_enquiry_email']; ?></td>
	<td><?php echo $row['property_enquiry_city']; ?></td>
	<td><?php echo $row['property_enquiry_min_price']; ?></td>
	<td><?php echo $row['property_enquiry_max_price']; ?></td>
	
	<td><?php echo $row['property_enquiry_date_time']; ?></td>
	
	</tr>
				<?php }?>
    </tbody>
  </table>
						</div>
						</div>
						</div>
						  </section>
	
   

</body>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>
</html>
<?php
 } 
?>