<?php

//include_once 'db.php';
session_start();

$page = 1;
include_once '../property/pss_db.php';
$conn = new DB_con();
$con = $conn->connection();
//include_once 'property/function_list.php';
//include_once 'property/default_values.properties';
$functions = new functions();
if(!isset($_SESSION['user']))
{
	header("Location: index.php");
}
else
{
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Dashboard</title>
<meta name="description" content="Flatter - Flat Admin Theme">
<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/layout.css">
<link rel="stylesheet" href="css/style3.css">
<script type="text/javascript" src="js/jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.10.4.custom.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/r/bs-3.3.5/jq-2.1.4,dt-1.10.8/datatables.min.css"/>
 
		<script type="text/javascript" src="https://cdn.datatables.net/r/bs-3.3.5/jqc-1.11.3,dt-1.10.8/datatables.min.js"></script>
		  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/1.2.1/css/buttons.dataTables.min.css"/>
 
		<!--<script type="text/javascript" src="https://cdn.datatables.net/r/bs-3.3.5/jqc-1.11.3,dt-1.10.8/datatables.min.js"></script>-->
                 <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.1/js/dataTables.buttons.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.1/js/buttons.flash.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js"></script>
        <script type="text/javascript" src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/pdfmake.min.js"></script>
        <script type="text/javascript" src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/vfs_fonts.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.1/js/buttons.html5.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.1/js/buttons.print.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.1/js/buttons.colVis.min.js"></script>
        <script type="text/javascript" src="js/jquery-easing.js"></script>
		<script src="js/bootstrap-datepicker.js"></script>
        <link rel="stylesheet" href="css/datepicker.css">

		<script type="text/javascript" charset="utf-8">
			$(document).ready(function() {
				$('.example').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'pageLength',
            {
                extend: 'print',
                autoPrint: false,
                title: 'Report',
                exportOptions: {
                    columns: ':visible'
                }
            },{
                extend: 'pdf',
                title: 'Report',
                exportOptions: {
                    columns: ':visible'
                }
            },{
                extend: 'excel',
                title: 'Report',
                exportOptions: {
                    columns: ':visible'
                }
            },{
                extend: 'csv',
                title: 'Report',
                exportOptions: {
                    columns: ':visible'
                }
            },{
                extend: 'copy',
                exportOptions: {
                    columns: ':visible'
                }
            },
            'colvis'
        ]
    },
    {
        dom: 'Bfrtip',
        lengthMenu: [
            [ 10, 25, 50, -1 ],
            [ '10 rows', '25 rows', '50 rows', 'Show all' ]
        ]
      
    },
    {
        dom: 'Bfrtip',
        buttons: [
            {
                extend: 'collection',
                text: 'Table control',
                buttons: [
                    'colvis'
                ]
            }
        ]
    } 
            
                );
			} );
                        
                        
                        
                        
		</script>
                <script type="text/javascript">
	// For demo to fit into DataTables site builder...
	$('.example')
		.removeClass( 'display' )
		.addClass('table table-striped table-bordered');
</script>
</head>
<body id="body">

		<!-- Header -->
		<?php// include './header.php'; ?>

       <?php include './left-menu.php'; ?>
		<!-- Header -->

        <section id="main-wrapper">
		
  <?php 	  
if(isset($_REQUEST['jk'])){
	$fu="dfe_fd@><";
    $jl=base64_decode($_REQUEST['jk']);
	$jk=preg_replace(sprintf('/%s/', $fu),'',$jl);
    $get_date=mysqli_query($con,"select distributor_creation_date from distributor_detail where distributor_company_id='$jk'");
    $distributor_date= mysqli_fetch_array($get_date)  ;
	$begin1=$distributor_date['distributor_creation_date'];
$begin = new DateTime("$begin1");
$end = new DateTime();

  for($next_week1 = $begin; $begin <= $end; $next_week1->modify('+14 day'))
{

echo $next_week=$next_week1->format("Y-m-d");

$from=$begin;
$to=$next_week;



include "weekly.php";





 }?>
<!--<script type="text/javascript" src="js/bootstrap.min.js"></script>-->
<script type="text/javascript" src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<div class="offline-ui offline-ui-up"><div class="offline-ui-content"></div><a href="" class="offline-ui-retry"></a>
</div>
</body>
</html>
<?php
}} 
?>