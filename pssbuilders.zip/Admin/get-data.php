<?php
$page = 1;
include_once '../property/pss_db.php';
$conn = new DB_con();
$con = $conn->connection();
//include_once 'property/function_list.php';
//include_once 'property/default_values.properties';
$functions = new functions();
?>
<?php
if(isset($_REQUEST['id']))
{

	$id=$_REQUEST['id'];
	//echo"$id";
	?>

							 <select name="plot_no" class="form-control" required="required">
							  <option value="">Select Plot No</option>
							  				<?php
				
				 $res = $conn->get_admin_plot_price_details_plot_no($con,$id);
				 while ($row = mysqli_fetch_array($res)) {
				// $plot_price_details_id=$row['plot_price_details_id'];
				 ?>
				 <option value="<?php echo $row['plot_price_details_plot_no']; ?>">  <?php echo $row['plot_price_details_plot_no']; ?>    <?php //echo $row['plot_price_details_name']; ?></option>
				 <?php }?>
							  </select>
							 
							 <?PHP
}
?>
<?php
if(isset($_REQUEST['distributor_id']))
{
$distributor_id1=$_REQUEST['distributor_id'];
//echo"$distributor_id1";
 ?>

       <form method="POST"> 
		<div class="row">
			<div class="col-md-6">
		<input type='text' name='payment_mode' class="form-control" placeholder="DD/cheque/Cash">
	<input type='hidden' name='distri_id' class="form-control" placeholder="bank" value="<?php echo"$distributor_id1"; ?>">	
		</div>
	<div class="col-md-6">
 <input type='text' name='distributor_bank' class="form-control" placeholder="bank"> <br></div></div>
   <div class="row">
   <div class="col-md-6">
  <input type='text' name='distributor_bank_branch' class="form-control" placeholder="Branch"></div>
   <div class="col-md-6">    <input type='text' name='amount' class="form-control" placeholder="Amount"><br></div></div>
   <div class="row">
   
  <div class="col-md-6">  <input type='text' name='amount_in_words' class="form-control" placeholder="Amount in Words"> </div>
 <div class="col-md-6"><input type='text' name='coupon_no' placeholder="Coupon_No" class="form-control"></div></div>
 
 <div class="row">
 
			
			<h2>Product Details</h2>
			<hr>
			<div class="col-md-6"><input type='radio' name='product_details' value="Rs 2000 Coupon "> Rs 2000 Coupon
		</div>
	<div class="col-md-6"></div></div>
	 <div class="row">
<h2> Project Shagun City</h2>
<hr>
  <div class="col-md-6"><input type='radio' name='project_shagun_city' value="30% Booking"> 30%Booking</div>
  
   <div class="col-md-6">
  <input type='radio' name='project_shagun_city'  value="full payment">Full payment</div>
   </div>
  
  <div class="row">
  <h2> Project Defense Enclave</h2>
  <div class="col-md-6">  <input type='radio' name='project_defense_enclave' value="30% Booking" >30% Booking </div>
 <div class="col-md-6"> <input type='radio' name='project_defense_enclave' value="full payment" >full payment</div></div>
 <hr>
         <div class="row">
		 <div class="col-md-12">
	   <input type='submit' name='paid' value='Paid' class="btn btn-success">  <input type='reset' name='reset' value='Reset' class="btn btn-danger"></div></div>
 

    </form>
<?php
	}
?>


<?php


if(isset($_REQUEST['distributor_id2']))
{
$distributor_id1=$_REQUEST['distributor_id2'];
//echo"$distributor_id1";

	?>			
				<div>
 <table align="center">

									
									<tr>
									
								
								
								<?php




				
				
				 $res = $conn->get_admin_distributor_pre_form_details123($con,$distributor_id1);
				 $count=0;
				 $row1 = mysqli_fetch_array($res);
				 
				
				 ?>
								
								     <tr><th>Distributor Company Id</th><td><input type ="text" name="distributor_company_id" value="<?php echo $row1['distributor_company_id']?>"></td></tr>
										<tr><th>Distributor Name</th><td><input type ="text" name="distributor_name" value="<?php echo $row1['distributor_name']; ?>"></td></tr>
										<tr><th>Distributor Fathers name</th><td><input type ="text" name="distributor_father_name" value="<?php echo $row1['distributor_father_name']; ?>"></td></tr>
										<tr><th>Distributor Dob</th><td><input type ="text" name="distributor_dob" value="<?php echo $row1['distributor_dob']; ?>"></td></tr>
										<tr><th>Distributor Gender</th><td><input type ="text" name="distributor_gender" value="<?php echo $row1['distributor_gender']; ?>"></td></tr>
										<tr><th>Distributor Marriage Status</th><td><input type ="text" name="distributor_m_status" value="<?php echo $row1['distributor_m_status']; ?>"></td></tr>
										<tr><th>Distributor Nominee name</th><td><input type ="text" name="distributor_nominee_name" value="<?php echo $row1['distributor_nominee_name']; ?>"></td></tr>
										<tr><th>Distributor relationship</th><td><input type ="text" name="distributor_relationship" value="<?php echo $row1['distributor_relationship']; ?>"></td></tr>
										<tr><th>Distributor Current Address</th><td><input type ="text" name="distributor_current_address" value="<?php echo $row1['distributor_current_address']; ?>"></td></tr>
										<tr><th>Distributor permanent address</th><td><input type ="text" name="distributor_permanent_address" value="<?php echo $row1['distributor_permanent_address']; ?>"></td></tr>
										<tr><th>Distributor state</th><td><input type ="text" name="distributor_state" value="<?php echo $row1['distributor_state']; ?>"></td></tr>
										<tr><th>Distributor city</th><td><input type ="text" name="distributor_city" value="<?php echo $row1['distributor_city']; ?>"></td></tr>
										<tr><th>Distributor district</th><td><input type ="text" name="distributor_district" value="<?php echo $row1['distributor_district']; ?>"></td></tr>
										<tr><th>Distributor pincode</th><td><input type ="text" name="distributor_pincode" value="<?php echo $row1['distributor_pincode']; ?>"></td></tr>
										<tr><th>Distributor mobile No</th><td><input type ="text" name="distributor_mobile" value="<?php echo $row1['distributor_mobile']; ?>"></td></tr>
										<tr><th>Distributor phone No</th><td><input type ="text" name="distributor_phone" value="<?php echo $row1['distributor_phone']; ?>"></td></tr>
										<tr><th>Distributor email</th><td><input type ="text" name="distributor_email" value="<?php echo $row1['distributor_email']; ?>"></td></tr>
										<tr><th>Distributor pan</th><td><input type ="text" name="distributor_pan" value="<?php echo $row1['distributor_pan']; ?>"></td></tr>
										
										<tr><th>Distributor id proof</th><td><input type ="text" name="distributor_id_proof" value="<?php echo $row1['distributor_id_proof']; ?>"></td></tr>
										<tr><th>Distributor Address proof</th><td><input type ="text" name="distributor_add_proof" value="<?php echo $row1['distributor_add_proof']; ?>"></td></tr>
								
										<tr><th>Distributor payment mode</th><td><input type ="text" name="distributor_payment_mode" value="<?php echo $row1['distributor_payment_mode']; ?>"></td></tr>
										<tr><th>Distributor bank</th><td><input type ="text" name="distributor_bank" value="<?php echo $row1['distributor_bank']; ?>"></td></tr>
										<tr><th>Distributor bank branch</th><td><input type ="text" name="distributor_bank_branch" value="<?php echo $row1['distributor_bank_branch']; ?>"></td></tr>
										<tr><th>Distributor amount</th><td><input type ="text" name="distributor_amount" value="<?php echo $row1['distributor_amount']; ?>"></td></tr>
										<tr><th>Distributor amount word</th><td><input type ="text" name="distributor_amoun_word" value="<?php echo $row1['distributor_amoun_word']; ?>"></td></tr>
										<tr><th>Distributor account IFSC code</th><td><input type ="text" name="distributor_account_ifsc" value="<?php echo $row1['distributor_account_ifsc']; ?>"></td></tr>
										
										
										<tr><th>Distributor account no</th><td><input type ="text" name="distributor_account_acc_no" value="<?php echo $row1['distributor_account_acc_no']; ?>"></td></tr>
										<tr><th>Distributor account name</th><td><input type ="text" name="distributor_account_acc_name" value="<?php echo $row1['distributor_account_acc_name']; ?>"></td></tr>
										<tr><th>Distributor qualification</th><td><input type ="text" name="distributor_qualification" value="<?php echo $row1['distributor_qualification']; ?>"></td></tr>
										<tr><th>Distributor bussiness</th><td><input type ="text" name="distributor_business" value="<?php echo $row1['distributor_business']; ?>"></td></tr>
										<tr><th>Distributor employee name</th><td><input type ="text" name="distributor_name_employer" value="<?php echo $row1['distributor_name_employer']; ?>"></td></tr>
										<tr><th>Distributor business no</th><td><input type ="text" name="distributor_business_no" value="<?php echo $row1['distributor_business_no']; ?>"></td></tr>
										<tr><th>Distributor annual income</th><td><input type ="text" name="distributor_anual_income" value="<?php echo $row1['distributor_anual_income']; ?>"></td></tr>
										<tr><th>Distributor ref1</th><td><input type ="text" name="distributor_ref1" value="<?php echo $row1['distributor_ref1']; ?>"></td></tr>
										<tr><th>Distributor ref2</th><td><input type ="text" name="distributor_ref2" value="<?php echo $row1['distributor_ref2']; ?>"></td></tr>
										<tr><th>Distributor ref3</th><td><input type ="text" name="distributor_ref3" value="<?php echo $row1['distributor_ref3']; ?>"></td></tr>
										<tr><th>Distributor ref4</th><td><input type ="text" name="distributor_ref4" value="<?php echo $row1['distributor_ref4']; ?>"></td></tr>
										<tr><th>Distributor passport no</th><td><input type ="text" name="distributor_passport_no" value="<?php echo $row1['distributor_passport_no']; ?>"></td></tr>
										<tr><th>Distributor placement</th><td><input type ="text" name="distributor_placement" value="<?php echo $row1['distributor_placement']; ?>"></td></tr>
										<tr><th>Distributor placement id</th><td><input type ="text" name="distributor_distributor_id" value="<?php echo $row1['distributor_distributor_id']; ?>"></td></tr>
										<tr><th>Distributor direct distributer id</th><td><input type ="text" name="distributor_direct_distributor_id" value="<?php echo $row1['distributor_direct_distributor_id']; ?>"></td></tr>
										<tr><th>Distributor coupan</th><td><input type ="text" name="distributor_coupon" value="<?php echo $row1['distributor_coupon']; ?>"></td></tr>
										<tr><th>Distributor coupan no</th><td><input type ="text" name="distributor_coupon_number" value="<?php echo $row1['distributor_coupon_number']; ?>"></td></tr>
										<tr><th>Distributor Shagun</th><td><input type ="text" name="distributor_shagun" value="<?php echo $row1['distributor_shagun']; ?>"></td></tr>
										<tr><th>Distributor defence</th><td><input type ="text" name="distributor_defense" value="<?php echo $row1['distributor_defense']; ?>"></td></tr>
										<tr><th>Distributor bv</th><td><input type ="text" name="distributor_bv" value="<?php echo $row1['distributor_bv']; ?>"></td></tr>
                                        <tr><th>Distributor created date</th><td><input type ="text" name="distributor_creation_date" value="<?php echo $row1['distributor_creation_date']; ?>"></td>
																		

								</tr>
													
									
									
									<input type ="hidden" name="distributor_id" value="<?php echo $row1['distributor_id']?>">
								

								</table>
								<br><br><center> <input type='submit' name='update1' value='Update' class="btn btn-success"> 
</center>

	</div>				
									
								
<?php
} ?>












<?php
if(isset($_REQUEST['id'])){
    $comp_id=$_REQUEST['id'];
    echo '[{"comp_id":"'.$comp_id.'"}]';
}
if(isset($_REQUEST['cmp_id'])){
    $comp_id=$_REQUEST['cmp_id'];
   
}if(isset($_REQUEST['user_id'])){
    

    $user_id=$_REQUEST['user_id'];
        $res=$conn->get_admin_menus($con,$user_id);
        if(mysqli_num_rows($res)!=0){ ?>
             <select  id="t1available" size="10" multiple="multiple" class="box" name="left_select[]">
              <?php while($row=mysqli_fetch_array($res))
			  {
			echo "<option value=";
			if ($row['m_menu_id']==0) 
			{echo $row['m_menu_id'].">"."&nbsp;&nbsp;".$row['m_menu_name'] ;}
		else
			{ echo $row['m_menu_id'].">"."<strong>".$row['m_menu_name']."</strong>";}
			echo "</option> ";
              }?>
			</select>
      <?php  }
    
    
}if(isset($_REQUEST['user_idd'])){
    

    $user_id=$_REQUEST['user_idd'];
        $res=$conn->get_login_rights($con,$user_id);
        if(mysqli_num_rows($res)!=0){ ?>
             <select  id="t1published" size="10" multiple="multiple" class="box" name="right_select[]">
              <?php while($row=mysqli_fetch_array($res)){?>
			<option value="<?php echo $row['m_menu_id'] ; ?>"><?php echo $row['m_menu_name'] ; ?></option>
              <?php }?>
			</select>
      <?php  }
    
    
}if(isset($_REQUEST['cmp_id'])){
    $comp_id=$_REQUEST['cmp_id'];
    $res=$conn->get_admin_distributor_detail_by_cmpny_id($con,$comp_id);
    $row=mysqli_fetch_array($res);
    ?>
 <label class="control-label" style="text-align: left;">Sponsor's Name</label>
 <input  type="text"  class="form-control" placeholder="Sponsor's Name" id="dis_sponsor_name" name="dis_sponsor_name" value="<?php echo $row['distributor_name'];?>"/>

<?php
}if(isset($_REQUEST['d_cmp_id'])){
    $comp_id=$_REQUEST['d_cmp_id'];
    $res=$conn->get_admin_distributor_detail_by_cmpny_id($con,$comp_id);
    $row=mysqli_fetch_array($res);
    ?>
 <label class="control-label" style="text-align: left;">Direct Person's Name</label>
            <input  type="text"  class="form-control" placeholder="Direct Person's Name" id="dis_d_person_name" name="dis_d_person_name"  value="<?php echo $row['distributor_name'];?>"  />
<?php
}if(isset($_REQUEST['imgchange'])){?>
 <!--<script>alert('hello');</script>-->
     <label class="control-label">Upload Picture</label>
            <input id="" type="file" class="form-control" name="files" style="border: none;" accept="image/*">
<?php }if(isset($_REQUEST['type'])){?>
            
            
            <script>
   $(document).ready(function(){
       $("#m_o_payment").change(function(){
           type=$("#m_o_payment").val();
           if(type=="" && type!="commodity"){
               $("#mode_info").load("get-data.php");
           }else{
               $("#mode_info").load("get-data.php",{"mode_type":type});
           }
       });
   });
    </script>
     <div class="col-sm-6"><br>
                                  <?php 
                                  $res=$conn->get_admin_distributors($con);
                                  ?>
                                  <!--<input type="text" name="user_bv_code" class="form-control" id="user_bv_code" placeholder="B.V. Code">-->
                                  <label> User</label>
                                  <select class="form-control" name="user_id" id="user_id">
                                      <option value="">Select User</option>
                                      <?php while($row=  mysqli_fetch_array($res)){ ?>
                                      <option value="<?php echo $row['distributor_company_id'] ?>"> <?php echo $row['distributor_name']." (".$row['distributor_company_id'].")"; ?></option>
                                      <?php } ?>
                                  </select>
                              
                              </div>
                              <div class="col-sm-6" id="amnt"><br>
                                  <label> Amount</label>
                                  <input type="text" name="amount" id="amount" class="form-control" required>
                              </div>
    
                              <div class="col-sm-12"><br>
                                  <label> Mode of Payment</label>
                                  <select class="form-control" id="m_o_payment" name="m_o_payment">
                                      <option value="">Select Payment Mode</option>
                                      <option value="cash">Cash</option>
                                      <option value="cheque">Cheque </option>
                                      <option value="bank transaction">Bank Transaction</option>
                                      <option value="demand draft">Demand Draft</option>
                                      <option value="commodity">Commodity</option>
                                  </select>
                              </div>
<?php }if(isset($_REQUEST['mode_type'])){ ?>
    <br>
    <?php if($_REQUEST['mode_type']=="cash") {?>
     <div class="col-sm-6"><label>Accepted By</label>
                           <input type="text" name="field1" id="accepted_by" class="form-control" required>
                          </div>
                          <div class="col-sm-6"><label>Paid By</label>
                           <input type="text" name="field2" id="received_by" class="form-control" required>
                          </div>
                           <div class="col-sm-6"><label>Date</label>
                           <input type="date" name="received_date" id="received_date" class="form-control" required>
                          </div>
                          
    <?php } if($_REQUEST['mode_type']=="cheque") {?>    
                          <div class="col-sm-6"><label>Cheque Number</label>
                           <input type="text" name="field1" id="cheque_no" class="form-control" required>
                          </div>
                          <div class="col-sm-6"><label>Bank Name</label>
                           <input type="text" name="field2" id="bank_name" class="form-control" required>
                          </div>
                          <div class="col-sm-6"><label>Account Holder Name</label>
                           <input type="text" name="field3" id="acc_holder_name" class="form-control" required>
                          </div>
                           <div class="col-sm-6"><label>Date</label>
                           <input type="date" name="received_date" id="received_date" class="form-control" required>
                          </div>
                          
                  <?php } if($_REQUEST['mode_type']=="bank transaction") {?>            
                          <div class="col-sm-6"><label>Transaction Number</label>
                           <input type="text" name="field1" id="transaction_number" class="form-control" required>
                          </div>
                          <div class="col-sm-6"><label>Transaction Account</label>
                           <input type="text" name="field2" id="transaction_acc" class="form-control" required>
                          </div>
                           <div class="col-sm-6"><label>Date</label>
                           <input type="date" name="received_date" id="received_date" class="form-control" required>
                          </div>
                          
                     <?php } if($_REQUEST['mode_type']=="demand draft") {?>        
                          <div class="col-sm-6"><label>D.D. Number</label>
                           <input type="text" name="field1" id="cheque_no" class="form-control" required>
                          </div>
                          <div class="col-sm-6"><label>Bank Name</label>
                           <input type="text" name="field2" id="bank_name" class="form-control" required>
                          </div>
                          <div class="col-sm-6"><label>D.D Generated by</label>
                           <input type="text" name="field3" id="acc_holder_name" class="form-control" required>
                          </div>
                           <div class="col-sm-6"><label>Date</label>
                           <input type="date" name="received_date" id="received_date" class="form-control" required>
                          </div>
     <?php } ?>  
  <?php  
    }if(isset($_REQUEST['transaction_detail_type'])){
        $type=$_REQUEST['transaction_detail_type'];
        $past_month=$_REQUEST['transaction_detail_past_month'];
        $present_month=$_REQUEST['transaction_detail_present_month'];
        if(!isset($_REQUEST['transaction_detail_user_id'])){
         $res=$conn->get_admin_transaction_detail($con,$type,$past_month,$present_month);
         $res_total=$conn->get_admin_total_transaction_detail($con,$type,$past_month,$present_month);
//         echo $past_month.$present_month;
//         echo $res;
         $row_total=mysqli_fetch_array($res_total);
         ?>
    <script>
    $(document).ready(function(){
        $(".hide1").hide();
    });
    function show(id){
        $(".hide1").hide();
        $("."+id).show();
    }
    </script> <hr>
    <div class="col-sm-12"><span class="pull-right" style="font-weight: bolder;"><?php if($type!="all"){ ?>Total <?php echo $type." : ".$row_total['transaction_amount']; }else{ ?>Total Credit <?php echo " : ".$row_total['credit']; ?> and Total Debit<?php echo " : ".$row_total['debit'];  } ?></span></div>
    <table class="table table-bordered">
        <thead>
        <tr>
            <th>S.no.</th>
            <th>Date</th>
         <?php if($type!="all"){?>   <th   colspan="2" >Amount</th>
             <?php if($type=="all"){ ?><th><?php echo "Transaction Type" ?></th> <?php } ?><?php }else{ ?>
             <th>Credit Amount</th>
             <th>Debit Amount</th> <?php } ?>
        </tr></thead>
        <?php $i=0; while($row=mysqli_fetch_array($res)){ 
            
            if($type=="all"){
            $typee="all";
        }else{
            $typee=$type;
        }
//        $tip=  explode(" ", $typee);
        
            ?>
        <tr  onclick="show('<?php echo $row['date']; ?>')" >
            <td><?php echo ++$i; ?></td>
            <td><?php echo $row['date']; ?></td>
          <?php if($type!="all"){?>  <td  colspan="2" ><?php echo $row['transaction_amount']; ?></td><?php } ?>
            <?php if($type=="all"){ ?><td><?php echo $row['credit']; ?></td><td><?php echo $row['debit']; ?></td> <?php } ?>
        </tr>
        <tr style="color:red" class="hide1 <?php echo $row['date']; ?>">
            <th>S.No.</th>
            <th>Name</th>
           <?php if($type!="all"){ ?> <th>Amount</th>
            <th>Payment mode</th><?php }else{ ?>
            <th>Credit</th>
            <th>Debit</th> <?php } ?>
        </tr>
        <?php 
        
        $ress=$conn->get_admin_transaction_detail_by_date($con,$typee,$row['date']); 
       $j=0; while($roww=  mysqli_fetch_array($ress)){
           $rr=$conn->get_admin_distributor_detail_by_cmpny_id($con,$roww['transaction_distributor_id']);
           $roro=  mysqli_fetch_array($rr);
           $name=$roro['distributor_name'];
           
        ?>
        <tr style="color:red" class=" hide1 <?php echo $row["date"]; ?>">
            <td><?php echo $i.".".++$j; ?></td>
            <td><?php echo $name; ?></td>
            <?php if($type!="all"){ ?>  
			<td><?php echo $roww['transaction_amount']; ?></td>
            <td><?php echo $roww['transaction_payment_mode']; ?></td><?php }else{ ?>
            <td><?php echo $roww['credit']; ?></td>
            <td><?php echo $roww['debit']; ?></td>
            <?php } ?>
        </tr>
        
       <?php } } ?>
    </table>
         
  <?php      
        }else{
            $user_id=$_REQUEST['transaction_detail_user_id'];
            $res=$conn->get_admin_transaction_detail_by_user($con,$type,$past_month,$present_month,$user_id);
         $res_total=$conn->get_admin_total_transaction_detail_by_user($con,$type,$past_month,$present_month,$user_id);
         $row_total=mysqli_fetch_array($res_total);
            ?>
    
    
     <div class="col-sm-12"><span class="pull-right" style="font-weight: bolder;"><?php if($type!="all"){ ?>Total <?php echo $type." : ".$row_total['transaction_amount']; }else{ ?>Total Credit <?php echo " : ".$row_total['credit']; ?> and Total Debit<?php echo " : ".$row_total['debit'];  } ?></span></div>
    <table class="table table-bordered">
        <thead>
        <tr>
            <th>S.no.</th>
            <th>Date</th>
            <th>Distributor</th>
         <?php if($type!="all"){?>   <th   colspan="2" >Amount</th>
            <?php }else{ ?>
             <th>Credit Amount</th>
             <th>Debit Amount</th> <?php } ?>
        </tr></thead>
        <?php $i=0; while($row=mysqli_fetch_array($res)){ 
            $rr=$conn->get_admin_distributor_detail_by_cmpny_id($con,$row['transaction_distributor_id']);
           $roro=  mysqli_fetch_array($rr);
           $name=$roro['distributor_name'];
            
            if($type=="all"){
            $typee="all";
        }else{
            $typee=$type;
        }
//        $tip=  explode(" ", $typee);
        
            ?>
        <tr >
            <td><?php echo ++$i; ?></td>
            <td><?php echo $row['date']; ?></td>
            <td><?php echo $name; ?></td>
          <?php if($type!="all"){?>  <td  colspan="2" ><?php echo $row['transaction_amount']; ?></td><?php } ?>
            <?php if($type=="all"){ ?><td><?php echo $row['credit']; ?></td><td><?php echo $row['debit']; ?></td> <?php } ?>
        </tr>
       
       <?php  } ?>
    </table>
    
    
    
    
    
            
    <?php    }
    }if(isset($_REQUEST['m_payment_type'])){
        $type=$_REQUEST['m_payment_type'];
        $entries=$_REQUEST['no_entries'];
//        echo $entries;
        if($type!=""&& $entries!=""){
        if($type!=""){ 
            for($i=0;$i<$entries;$i++){
            ?>
      <div class="col-sm-6"><hr><label>Commodity</label><input type="text" name="commodity[]" class="form-control" placeholder="Commodity"></div>
      <div class="col-sm-6" ><hr><label>Amount</label><input type="text" name="amount[]" class="form-control" placeholder="Amount"></div>
    
     <div class="col-sm-6"><br><label>From </label> <input type="text" name="from[]" class="form-control" placeholder="From"></div>
     <div class="col-sm-6"><br> <label>To</label><input type="text" name="to[]" class="form-control" placeholder="To"> </div>
     <hr>
            <?php } } ?>
     <div class="col-sm-12"><br><input type="submit" name="save" value="Save" class="btn btn-info pull-right"></div>
     <?php
    }
    }if(isset($_REQUEST['payment_type'])){
        $payment_type=$_REQUEST['payment_type'];
        $entries=$conn->get_admin_no_of_entries($con,$payment_type);
        $res=$conn->get_admin_payment_type($con,$payment_type,$entries);
         if($payment_type=="reward" || $payment_type=="bonanza"){ 
             ?>
     <div class="col-sm-12"><br><label>Commodity</label><select class="form-control" id="commodity_type" name="commodity_type" onchange="commodity_amount()">
         <option value="">Choose Commodity</option>
     
     <?php
        while($row=  mysqli_fetch_array($res)){ ?>
         <option value="<?php echo $row['payment_type_commodity'] ?>"><?php echo $row['payment_type_commodity'] ?></option>
    
         <?php   } ?>
         </select>
     </div><?php
         
        }
    }if(isset($_REQUEST['commodity'])){
        $commodity=$_REQUEST['commodity'];
        if($commodity!=""){
        $payment_type=$_REQUEST['commodity_payment_type'];
        $entries=$conn->get_admin_no_of_entries($con,$payment_type);
        $res=$conn->get_admin_commodity_amount($con,$payment_type,$entries,$commodity);
        $row=  mysqli_fetch_array($res);
        ?>
     <br>
                                  <label> Amount</label>
                                  <input type="text" name="amount" id="amount" class="form-control" value="<?php echo $row['payment_type_price']; ?>" required>
    <?php }else{ ?>
        <br>
                                  <label> Amount</label>
                                  <input type="text" name="amount" id="amount" class="form-control" required>
   <?php }
    
    }if(isset($_REQUEST['reward_type'])){
        
        ?>
        <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/r/bs-3.3.5/jq-2.1.4,dt-1.10.8/datatables.min.css"/>
 
		<!--<script type="text/javascript" src="https://cdn.datatables.net/r/bs-3.3.5/jqc-1.11.3,dt-1.10.8/datatables.min.js"></script>-->
		<script type="text/javascript" charset="utf-8">
			$(document).ready(function() {
				$('.example').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print','pageLength'
        ]
    },
           {
        dom: 'Bfrtip',
        lengthMenu: [
            [ 10, 25, 50, -1 ],
            [ '10 rows', '25 rows', '50 rows', 'Show all' ]
        ]
    } 
                );
			} );
		</script>
                <script type="text/javascript">
	// For demo to fit into DataTables site builder...
	$('.example')
		.removeClass( 'display' )
		.addClass('table table-striped table-bordered');
</script>

<br><br><br><br>
        <?php
        $reward_type=$_REQUEST['reward_type'];
        
         function countt($id,$con){
                    $i=0;
                    $ss="select tree.id,tree.first_name,tree.position,distributor_detail.distributor_creation_date,tree.parent_id from tree left join distributor_detail on tree.id=distributor_detail.distributor_id where parent_id='$id' order by distributor_detail.distributor_creation_date desc";
                    $query=mysqli_query($con,$ss);
                    while( $rr=  mysqli_fetch_array($query)){
                      
                      $pp[$i]=$rr;
                      $i++;
                  }
//                  echo $ss."<br>";
                  if($i==2){
//                      echo $ss."<br>";
                      if($pp[0][1]!='blank'){
                          if($pp[0][1]!='blank' && $pp[1][1]!='blank'){
//                              $num++;
//                              echo $num;
                          }
                       $count_left=countt($pp[0][0],$con);   
                       $count_left++;
//                       echo $connt_left;
                      }else {
                          $count_left=0;                          
                      }
                      if($pp[1][1]!='blank'){
                           $count_right=countt($pp[1][0],$con); 
                           $count_right++;
                      }else{
                          $count_right=0;    
                      }
                     $counttt= $count_left+$count_right;
                     return $counttt;
                     
                  }if($i==0){
                   return 0;   
                  }
                }
                function countbv($id,$con){
                    $i=0;
                    $query=mysqli_query($con,"select * from tree where parent_id='$id' order by position");
                    while( $rr=  mysqli_fetch_array($query)){
                      
                      $pp[$i]=$rr;
                      $i++;
                  }
                  if($i==2){
                      if($pp[0][1]!='blank'){
                       $count_left_bv=countbv($pp[0][0],$con); 
                       $user_left_idd=$pp[0][0];
                       $sql=  mysqli_query($con, "select distributor_bv from distributor_detail where distributor_id='$user_left_idd'");
                       $rowss=  mysqli_fetch_array($sql);
                       $count_left_bv=$count_left_bv+$rowss['distributor_bv'];
//                       echo $connt_left;
                      }else {
                          $count_left_bv=0;                          
                      }
                      if($pp[1][1]!='blank'){
                           $count_right_bv=countbv($pp[1][0],$con); 
                            $user_right_idd=$pp[1][0];
                       $sql=  mysqli_query($con, "select distributor_bv from distributor_detail where distributor_id='$user_right_idd'");
                       $rowss=  mysqli_fetch_array($sql);
                           $count_right_bv=$count_right_bv+$rowss['distributor_bv'];
                      }else{
                          $count_right_bv=0;    
                      }
                     $counttt= $count_right_bv+$count_left_bv;
                     return $counttt;
                  }if($i==0){
                   return 0;   
                  }
                }
                 function countt_num($id,$con,$member_time){
                    $i=0;
                    $ss="select tree.id,tree.first_name,tree.position,distributor_detail.distributor_creation_date,tree.parent_id from tree left join distributor_detail on tree.id=distributor_detail.distributor_id where parent_id='$id' order by distributor_detail.distributor_creation_date desc";
                    $query=mysqli_query($con,$ss);
                    while( $rr=  mysqli_fetch_array($query)){
                      
                      $pp[$i]=$rr;
                      $i++;
                  }
//                  echo $ss."<br>";
                  if($i==2){
                      if($pp[0][1]!='blank'){
                          array_push($member_time, $pp[0][3]);
                       $count_left=countt_num($pp[0][0],$con,$member_time);  
                      }else{
                          $count_left=['0'];
                      }
                      if($pp[1][1]!='blank'){
                          array_push($member_time, $pp[1][3]);
                           $count_right=countt_num($pp[1][0],$con,$member_time); 
                      }else{
                          $count_right=['0'];
                      }
//                      print_r($childs);
//                      print_r($count_right);
//                      print_r($count_left);
                      $member_time=  array_merge($count_right,$count_left);
//                       print_r($childs);
//                      echo "<br>";
                      return $member_time;
                  }if($i==0){
                   return $member_time;   
                  }
                }
                
                
                
                
                function smallest($num1,$num2){
                    if($num1>$num2){
                        return $num2;
                    }
                    if($num2>$num1){
                        return $num1;
                    }
                    if($num1==$num2){
                        return $num1;
                    }
                    
                }
                
                function greatest($num1,$num2){
                    if($num1>$num2){
                        return $num1;
                    }
                    if($num2>$num1){
                        return $num2;
                    }
                    if($num1==$num2){
                        return $num1;
                    }
                    
                }
        
        
        if($reward_type=="reward" || $reward_type=="pair income" || $reward_type=="bonanza"){
            $payment_type=$reward_type;
            
            ?>
                
<div class="col-sm-12">     <table class="table table-bordered display example" id="example"><thead>  <tr>
                                       <th>S.No.</th>
                                                  <th>Name</th>
                                                  <th>Company Id</th>
                                                  <th>Total Left B V</th>
                                                  <th>Total Right B V</th>
												<?php if($payment_type=="pair income" ){ ?> <th>Remaining Reward Amount</th><th>10%</th><th>5%</th><th>Payable Amount</th> <?php } ?>
                                              <?php if($payment_type=="reward" || $payment_type=="bonanza" ){ ?>    
   											     <th>Reward Commodity</th> 
                                                  <th>Reward Amount</th> <?php } ?>
												  <th>Position</th>
												  <th>Pay</th> 
                                      </tr></thead>
       <?php     $res=$conn->get_admin_distributors($con);
       $k=0;
       $jj=0;
        $ttotal=0;
            while($row=  mysqli_fetch_array($res)){
               
                if($row['distributor_id']!=1){
                    $ss="select tree.id,tree.first_name,tree.position,distributor_detail.distributor_creation_date,tree.parent_id from tree left join distributor_detail on tree.id=distributor_detail.distributor_id where parent_id='$row[distributor_id]' order by position";
                    $left=mysqli_query($con,$ss);
                  $pp=array();
                  $i=0;
                  $count_left=0;
                  $count_right=0;
                  
                  while( $rr=  mysqli_fetch_array($left)){
                     
                      $pp[$i]=$rr;
                       $i++;
                  }
//                  echo "<br><br>";
                   
                  if($i==2){
                      
                      if($pp[0][1]!='blank'){
                          $id=$pp[0][0];
                          
                       $count_left=countt($id,$con); 
                       $count_left++;
                      }else {
                          $count_left=0;                          
                      }
                      if($pp[1][1]!='blank'){
                          $idd=$pp[1][0];
                         $count_right=countt($idd,$con); 
                         $count_right++;
                      }else {
                          $count_right=0;                          
                      }
                  } $count_left_bv=0;
                  $count_right_bv=0;
                  
                  if($i==2){
                      if($pp[0][1]!='blank'){
                       $count_left_bv=countbv($pp[0][0],$con); 
                       $user_left_idd=$pp[0][0];
                       $sql=  mysqli_query($con, "select distributor_bv from distributor_detail where distributor_id='$user_left_idd'");
                       $rowss=  mysqli_fetch_array($sql);
                       $count_left_bv=$count_left_bv+$rowss['distributor_bv'];
//                       echo $connt_left;
                      }else {
                          $count_left_bv=0;                          
                      }
                      if($pp[1][1]!='blank'){
                           $count_right_bv=countbv($pp[1][0],$con); 
                            $user_right_idd=$pp[1][0];
                       $sql=  mysqli_query($con, "select distributor_bv from distributor_detail where distributor_id='$user_right_idd'");
                       $rowss=  mysqli_fetch_array($sql);
                           $count_right_bv=$count_right_bv+$rowss['distributor_bv'];
                      }else{
                          $count_right_bv=0;    
                      }
//                     $counttt= $count_right_bv+$count_left_bv;
//                     return $counttt;
                  }

                  
                  $count_left_time=array();
                  $count_right_time=array();
//                  echo "<br>";
//                  $jj=0;
                  $kk=0;
                  if($i==2){
                      
                      if($pp[0][1]!='blank' && $pp[1][1]!='blank'){
                      $member_time=array();
                      $member_time_right=array();
                  
                      if($pp[0][1]!='blank'){
                          $id=$pp[0][0];
                          array_push($member_time, $pp[0][3]);
                       $count_left_time=countt_num($id,$con,$member_time); 
//                       $count_left++;
                      }else {
                          $count_left_time=[0];                          
                      }
                      if($pp[1][1]!='blank'){
                          $idd=$pp[1][0];
                          array_push($member_time_right, $pp[1][3]);
                         $count_right_time=countt_num($idd,$con,$member_time_right); 
//                         $count_right++;
                      }else {
                          $count_right_time=[0];                          
                      }
//                      echo $ss."<br>";
//                      print_r($row['distributor_id']);echo "<br>";
                      $left_time=array();
                      $right_time=array();
                        $count_left_time=array_unique($count_left_time);
                        $count_right_time=  array_unique($count_right_time);
                        foreach ($count_left_time as $value) {
                           if($value!=0){
                               array_push($left_time,$value);
                           }
                        }
                        foreach ($count_right_time as $value) {
                           if($value!=0){
                               array_push($right_time,$value);
                           }
                        }
                       asort($left_time);
                        sort($right_time);
                        $left_count=count($left_time);
                        $right_count=count($right_time);
//                        print_r($left_time);echo "<br>";
//                        print_r($right_time);echo "<br>";echo "<br>";
                        $smallest=smallest($left_count,$right_count);
//                        echo $smallest."<br>";
                     if($payment_type=="pair income"){  $ttl=0;}
                        for($k=0;$k<$smallest;$k++){
                             $from_array=array();
                           $left_times=$left_time[$k];
                           $right_times=$right_time[$k];
                           $greatest=greatest($left_times,$right_times);
                           ++$kk;
//                            echo $greatest."<br>".$kk."<br>";
                           $sql_entry=$conn->get_admin_reward_entry($payment_type,$greatest);
                           $res_entry=  mysqli_query($con, $sql_entry);
                           $row_entry=  mysqli_fetch_array($res_entry);
//                           echo $sql_entry."<br>".$greatest."<br>".$row_entry['payment_type_no_of_entries']."<br><br>";
                           if($row_entry['payment_type_no_of_entries']==""){
                               $no_entry=0;
                           }else{
                               $no_entry=$row_entry['payment_type_no_of_entries'];
                           }
                           $sql_from=$conn->get_admin_reward_from($payment_type,$greatest,$no_entry);
//                         echo $sql_from;
                           $res_from=  mysqli_query($con, $sql_from);
                           while($row_from=mysqli_fetch_array($res_from)){
                               array_push($from_array, $row_from['payment_type_from']);
                           } 
//                           print_r($from_array);
//                         if($payment_type!="pair income"){
                           if(in_array($kk, $from_array)){
//                               echo $kk."<br>";
                              $key= array_search($kk, $from_array);
//                             echo $key;
                             if($key===""){
                                 $key=-1;
                             }
                              $paid=array();
                             $sql_paid_reward="SELECT * FROM `transaction` where transaction_distributor_id='$row[distributor_company_id]' and payment_type='$payment_type' and transaction_type='money dispatched'";
                             $res_paid_reward=mysqli_query($con,$sql_paid_reward);
                             while($row_paid_reward=mysqli_fetch_array($res_paid_reward)){
                                 array_push($paid, $row_paid_reward['transaction_payment_mode']);
                             }
//                             print_r($paid);echo "<br><br>";
                              if($key>=0){
                             $sql_reward=$conn->get_admin_reward($payment_type,$greatest,$no_entry,$key);
//                             echo $sql_reward."<br>";
                              $res_reward=  mysqli_query($con, $sql_reward);
                              $row_reward=  mysqli_fetch_array($res_reward);
//                              $ttotal=$ttotal+$row_reward['payment_type_price'];
                              $small=smallest($count_left,$count_right);
                              if(($payment_type=="reward" || $payment_type=="bonanza") && !preg_grep("/$row_reward[payment_type_commodity]/i", $paid)){
                              
	
							  
							  ?>
                               <tr>
                                          <td>
                                              <?php echo ++$jj; ?>
                                          </td>
                                          <td>
                                              <?php echo $row['distributor_name']; ?>
                                          </td>
                                          <td>
                                              <?php echo $row['distributor_company_id']; ?>
                                          </td>
                                          <td>
                                              <?php echo $count_left_bv; ?>
                                          </td>
                                          <td>
                                              <?php echo $count_right_bv; ?>
                                          </td>
										 <?php if($count_left_bv<$count_right_bv){
											  
											  ?>
                                              <?php  $bv=$count_left_bv; ?>
                                          <?php
										  }
										  else{
											   ?>
                                              <?php $bv=$count_right_bv; ?>
                                          <?php
		}
										  ?>
                                       										  <?php 
										  
									$paid_res=$conn->get_admin_paid_reward12($con,$payment_type,$bv);
        
									$paid_row=mysqli_fetch_array($paid_res);
		?>
		
	 
										  
                                         
										  
                                       <?php if($payment_type=="reward" || $payment_type=="bonanza"){ ?>   <td>
                                              <?php echo $commodity=$paid_row['payment_type_commodity']; ?>
                                       <?php }?></td> 
                                          <td>
                                              <?php if($payment_type=="reward" || $payment_type=="bonanza"){echo $paid_row['payment_type_price'];} else { echo $small*$row_reward['payment_type_price']; } ?>
                                          </td>
										  
										 <td>
										 <?php echo $paid_row['payment_type_position']; ?>
										 
										 </td>
										  <td>
										   <?php if($commodity==""){
											   echo "";
										   }else{?>
										  <a href="money_dispatched.php" class="btn btn-success">Pay</a><?php } ?>
										  </td>
                                      </tr>
                     
                              
                              
                           <?php   
                              }else if($payment_type=="pair income"){
                                 $sql_paid_reward="SELECT sum(transaction_amount) as sum FROM `transaction` where transaction_distributor_id='$row[distributor_company_id]' and payment_type='$payment_type' and transaction_type='money dispatched'";
                             $res_paid_reward=mysqli_query($con,$sql_paid_reward); 
                                  $row_paid_reward=mysqli_fetch_array($res_paid_reward);
                                       $sum=$row_paid_reward['sum'];
                                 if(($small*$row_reward['payment_type_price']-$sum)!=0){ 
                                    ?>
                               <tr>
                                          <td>
                                              <?php echo ++$jj; ?>
                                          </td>
                                          <td>
                                              <?php echo $row['distributor_name']; ?>
                                          </td>
                                          <td>
                                              <?php echo $row['distributor_company_id']; ?>
                                          </td>
                                          <td>
                                              <?php echo $count_left_bv; ?>
                                          </td>
                                          <td>
                                              <?php echo $count_right_bv; ?>
                                          </td>
										 
                                       <?php if($payment_type=="reward" || $payment_type=="bonanza"){ ?>   <td>
                                              <?php echo $row_reward['payment_type_commodity']; ?>
                                       </td> <?php } ?>
                                          <td>
                                               <?php 
										  
$paid_res=$conn->get_admin_paid_reward11($con,"money dispatched","$payment_type",$row['distributor_company_id']);
        
        while($paid_row=mysqli_fetch_array($paid_res))
		{   
	
		$paid_row1=$paid_row['sum(transaction_amount)'];
        $paid_row2=$paid_row['service_tax'];		
										  if($count_left_bv<$count_right_bv){
											  
											  ?>
                                              <?php echo $a=($count_left_bv*$bv_in_amount)-($paid_row1+$paid_row2); ?>
                                          <?php
										  }
										  else{
											   ?>
                                              <?php echo $a=($count_right_bv*$bv_in_amount)-($paid_row1+$paid_row2); ?>
                                          <?php
		}}
										  ?>   
                                          </td>
										   <td><?php echo $b=$a*0.1; ?></td> 
										   <td><?php echo $c=$a*0.05; ?></td>
										  <td><?php echo $a-($b+$c); ?></td>
										  
										  
										 <?php if($count_left_bv<$count_right_bv){
											  
											  ?>
                                              <?php  $bv=$count_left_bv; ?>
                                          <?php
										  }
										  else{
											   ?>
                                              <?php $bv=$count_right_bv; ?>
                                          <?php
		}
										  ?>
                                         <?php 
										  
									$paid_res=$conn->get_admin_paid_reward12($con,'reward',$bv);
        
									$paid_row=mysqli_fetch_array($paid_res);
		?>
										  
										  										 <td>
										 <?php echo $paid_row['payment_type_position']; ?>
										 
										 </td>
										  
										  <td><?php if($a==""){
											   echo "";
										   }else{?>
										  <a href="money_dispatched.php" class="btn btn-success">Pay</a><?php } ?>
										  </td>
                                      </tr>
                     
                              
                              
                           <?php  
                                 }
                              }
                              }
                           }
                           
                         
                           
                           
                           
                           
                        } 
                       
                        
                      
                      }  
                  }
                
                 
                  
                  
                  
                  
//                 if($reward_type!="bonanza"){$smallest=smallest($count_left,$count_right);}else{$smallest=$row['distributor_bv'];}
//                 if($smallest>0) {
//                     $entries=$conn->get_admin_no_of_entries($con,$payment_type);
//        $ress=$conn->get_admin_rewards($con,$payment_type,$entries,$smallest);
//        while($rows=  mysqli_fetch_array($ress)){
//                     ?>
                                     
                  
           <?php      
//        }   }   
         
       
        } 
         }     ?>
                                      
                                      </table></div>
                                      
                                      <?php
        }if($reward_type=="direct income"){ ?>
              <div class="col-sm-12">     <table class="table table-bordered display  example" id="example">
                                      <thead>  <tr> <th>S.No.</th>
                                                  <th>Name</th>
                                                  <th>Company Id</th>
                                                  <th>Total Left BV</th>
                                                  <th>Total Right BV</th>
                                                  <th>Total Direct Member</th>
												  
                                                 <th>Reward Amount</th>
												 <th>10%</th><th>5%</th><th>Payable Amount</th>
												  <th>Position</th>
												  <th>Pay</th> 
												 </tr> </thead>
                                      
                                      <?php  $res=$conn->get_admin_direct_distributors($con);
                                        $k=0;
                                            while($row=  mysqli_fetch_array($res)){
                                                if($row['distributor_direct_distributor_id']!=1 && $row['distributor_direct_distributor_id']!='pss100000'){
                                                    $dis_res=$conn->get_admin_distributor_detail_by_cmpny_id($con,$row['distributor_direct_distributor_id']);
                                                    $dis_row=  mysqli_fetch_array($dis_res);
                                                     $left=mysqli_query($con,"select * from tree where parent_id = '$dis_row[distributor_id]' order by position");
                   
                  $pp=array();
                  $i=0;
                  $count_left=0;
                  $count_right=0;
                  while( $rr=  mysqli_fetch_array($left)){
                     
                      $pp[$i]=$rr;
                       $i++;
                  } 
                  if($i==2){
                      if($pp[0][1]!='blank'){
                          $id=$pp[0][0];
                       $count_left=countt($id,$con); 
                       $count_left++;
                      }else {
                          $count_left=0;                          
                      }
                      if($pp[1][1]!='blank'){
                          $idd=$pp[1][0];
                         $count_right=countt($idd,$con); 
                         $count_right++;
                      }else {
                          $count_right=0;                          
                      }
                  }
				  $count_left_bv=0;
                  $count_right_bv=0;
                  
                  if($i==2){
                      if($pp[0][1]!='blank'){
                       $count_left_bv=countbv($pp[0][0],$con); 
                       $user_left_idd=$pp[0][0];
                       $sql=  mysqli_query($con, "select distributor_bv from distributor_detail where distributor_id='$user_left_idd'");
                       $rowss=  mysqli_fetch_array($sql);
                       $count_left_bv=$count_left_bv+$rowss['distributor_bv'];
//                       echo $connt_left;
                      }else {
                          $count_left_bv=0;                          
                      }
                      if($pp[1][1]!='blank'){
                           $count_right_bv=countbv($pp[1][0],$con); 
                            $user_right_idd=$pp[1][0];
                       $sql=  mysqli_query($con, "select distributor_bv from distributor_detail where distributor_id='$user_right_idd'");
                       $rowss=  mysqli_fetch_array($sql);
                           $count_right_bv=$count_right_bv+$rowss['distributor_bv'];
                      }else{
                          $count_right_bv=0;    
                      }
//                     $counttt= $count_right_bv+$count_left_bv;
//                     return $counttt;
                  }
				  
                  $smallest=1;
                   $entries=$conn->get_admin_no_of_entries($con,$reward_type);
				  
				   if($entries=="")
				   {
					$entries=0;   
					   }
        $ress=$conn->get_admin_rewards($con,$reward_type,$entries,$smallest);
        while($rows=  mysqli_fetch_array($ress)){
            
             $sql_paid_reward="SELECT sum(transaction_amount) as sum FROM `transaction` where transaction_distributor_id='$dis_row[distributor_company_id]' and payment_type='$reward_type' and transaction_type='money dispatched'";
//               echo $sql_paid_reward."<br>";            
             $res_paid_reward=mysqli_query($con,$sql_paid_reward); 
                                  $row_paid_reward=mysqli_fetch_array($res_paid_reward);
                                       $sum=$row_paid_reward['sum'];
            if(($row['total']*$rows['payment_type_price']-$sum)!=0){
?>
                   <tr>
                                          <td>
                                              <?php echo ++$k; ?>
                                          </td>
                                          <td>
                                              <?php echo $dis_row['distributor_name']; ?>
                                          </td>
                                          <td>
                                              <?php echo $dis_row['distributor_company_id']; ?>
                                          </td>
                                          <td>
                                              <?php echo $count_left_bv; ?>
                                          </td>
                                          <td>
                                              <?php echo $count_right_bv; ?>
                                          </td>

                                          <td>
                                              <?php echo $row['total']; ?>
                                          </td>
                                          
										 
										  <td><?php 
			$paid_res=$conn->get_admin_paid_reward11($con,"money dispatched","$reward_type",$dis_row['distributor_company_id']);
        
        
        while($paid_row=mysqli_fetch_array($paid_res))
		{   
	
		$paid_row1=$paid_row['sum(transaction_amount)']; 
		$paid_row2=$paid_row['service_tax'];
										  if($count_left_bv<$count_right_bv){
											  
											  ?>
                                              <?php echo $a = ($count_left_bv*$bv_in_amount-($paid_row1+$paid_row2)); ?>
                                          <?php
										  }
										  else{
											   ?>
                                              <?php echo $a = ($count_right_bv*$bv_in_amount-($paid_row1+$paid_row2)); ?>
                                          <?php
		}}
										  ?>
										  </td> <td><?php echo $b=$a*0.1; ?></td> 
										   <td><?php echo $c=$a*0.05; ?></td>
										  <td><?php echo $a-($b+$c); ?></td>
											 <?php if($count_left_bv<$count_right_bv){
											  
											  ?>
                                              <?php  $bv=$count_left_bv; ?>
                                          <?php
										  }
										  else{
											   ?>
                                              <?php $bv=$count_right_bv; ?>
                                          <?php
		}
										  ?>
                                         <?php 
										  
									$paid_res=$conn->get_admin_paid_reward12($con,'reward',$bv);
        
									$paid_row=mysqli_fetch_array($paid_res);
		?>
										  
										  										 <td>
										 <?php echo $paid_row['payment_type_position']; ?>
										 
										 </td>
										  
										  <td><?php if($a=="0"){
											   echo "";
										   }else{?>
										  <a href="money_dispatched.php" class="btn btn-success">Pay</a><?php } ?>
										  </td>
                                          
                   </tr>
                                          <?php     
            }
        }
        
        
        }
                                                }
                                                  
                                      
                                      
                                            ?></table></div>
                                     
   <?php    }if($reward_type=="coupon"){
       ?>
       <div class="col-sm-12">     <table class="table table-bordered display  example" id="example"> <thead><tr>
                                        <th>S.No.</th>
                                                  <th>Name</th>
                                                  <th>Company Id</th>
                                                  <th>Total Left B V</th>
                                                  <th>Total Right B V</th>
                                                
                                                  <th>Coupon Benefit Amount</th> 
												   <th>Position</th>
												   <th>Pay</th> 
                                      </tr></thead>
       
     <?php  
     $res=$conn->get_admin_client_transaction($con); $k=0;
     $remaining=array();
     $count=array();
     while($row=mysqli_fetch_array($res)){ 
         $comp_id=$row['applicant_agent_name'];
         
         if($row['applicant_agent_name']!=1 && $row['applicant_agent_name']!='pss100000'){
                                                    $dis_res=$conn->get_admin_distributor_detail_by_cmpny_id($con,$row['applicant_agent_name']);
                                                    $dis_row=  mysqli_fetch_array($dis_res);
                                                     $left=mysqli_query($con,"select * from tree where parent_id = '$dis_row[distributor_id]' order by position");
                   
                  $pp=array();
                  $i=0;
                  $count_left=0;
                  $count_right=0;
                  while( $rr=  mysqli_fetch_array($left)){
                     
                      $pp[$i]=$rr;
                       $i++;
                  }
                  if($i==2){
                      if($pp[0][1]!='blank'){
                          $id=$pp[0][0];
                       $count_left=countt($id,$con); 
                       $count_left++;
                      }else {
                          $count_left=0;                          
                      }
                      if($pp[1][1]!='blank'){
                          $idd=$pp[1][0];
                         $count_right=countt($idd,$con); 
                         $count_right++;
                      }else {
                          $count_right=0;                          
                      }
                  }
                  
				  $count_left_bv=0;
                  $count_right_bv=0;
                  
                  if($i==2){
                      if($pp[0][1]!='blank'){
                       $count_left_bv=countbv($pp[0][0],$con); 
                       $user_left_idd=$pp[0][0];
                       $sql=  mysqli_query($con, "select distributor_bv from distributor_detail where distributor_id='$user_left_idd'");
                       $rowss=  mysqli_fetch_array($sql);
                       $count_left_bv=$count_left_bv+$rowss['distributor_bv'];
//                       echo $connt_left;
                      }else {
                          $count_left_bv=0;                          
                      }
                      if($pp[1][1]!='blank'){
                           $count_right_bv=countbv($pp[1][0],$con); 
                            $user_right_idd=$pp[1][0];
                       $sql=  mysqli_query($con, "select distributor_bv from distributor_detail where distributor_id='$user_right_idd'");
                       $rowss=  mysqli_fetch_array($sql);
                           $count_right_bv=$count_right_bv+$rowss['distributor_bv'];
                      }else{
                          $count_right_bv=0;    
                      }
//                     $counttt= $count_right_bv+$count_left_bv;
//                     return $counttt;
                  }
				  
                  $total=$row['applicant_fund_detail'];
              if($row['payment']=="on date"){
                  $paid=$row['paid'];
                  $perecent=$paid*100/$total;
              }else{
                  $perecent="default";
              }  
                    $entries=$conn->get_admin_no_of_entry($con,$reward_type,$row['date']);
					 
				   if($entries=="")
				   {
					$entries=0;   
					   }
        $ress=$conn->get_admin_reward_coupon($con,$reward_type,$entries,$perecent,$row['date']);
        $rowss=  mysqli_fetch_array($ress);
        $date_after_45=$row['date_after_45_days'];
        $start_date=$row['date'];
        $check_res=$conn->get_admin_complete_client_transaction($con,$date_after_45,$start_date);
        $check_row=mysqli_fetch_array($check_res);
        $total_paid=$check_row['paid'];
//        echo $total_paid."--".$total."<br>";
        if($total_paid==$total){
//                  echo "hellos <br>";
                  if(!isset($count[$dis_row['distributor_company_id']])){
                      $count[$dis_row['distributor_company_id']]=0;
                  }
            
              $sql_paid_reward="SELECT sum(transaction_amount) as sum FROM `transaction` where transaction_distributor_id='$dis_row[distributor_company_id]' and payment_type='$reward_type' and transaction_type='money dispatched'";
//               echo $sql_paid_reward."<br>";            
             $res_paid_reward=mysqli_query($con,$sql_paid_reward); 
                                  $row_paid_reward=mysqli_fetch_array($res_paid_reward);
                                       $sum=$row_paid_reward['sum'];
//                                       echo $sum."<br><br>";
                                       $values=0;
                                       if(($sum>$rowss['payment_type_price']) && !isset($remaining[$dis_row['distributor_company_id']])){
                                           $remaining[$dis_row['distributor_company_id']]=$sum-$rowss['payment_type_price'];
//                                           echo"1";
                                       }else if(isset($remaining[$dis_row['distributor_company_id']]) && (($remaining[$dis_row['distributor_company_id']])>$rowss['payment_type_price'])){
                                            $remaining[$dis_row['distributor_company_id']]=$remaining[$dis_row['distributor_company_id']]-$rowss['payment_type_price'];
//                                      echo"2";
                                            }else if(($sum<$rowss['payment_type_price']) && !isset($remaining[$dis_row['distributor_company_id']])){
                                           $remaining[$dis_row['distributor_company_id']]=0;
                                           $values=$rowss['payment_type_price']-$sum;
//                                           echo"3";
                                       }else if(isset($remaining[$dis_row['distributor_company_id']]) && (($remaining[$dis_row['distributor_company_id']])<$rowss['payment_type_price'])){
                                           
                                           $values=$rowss['payment_type_price']-$remaining[$dis_row['distributor_company_id']];
                                            $remaining[$dis_row['distributor_company_id']]=0;
//                                           echo"4";
                                       }
//                                       echo $values."--";
                                   if($values!=0){    
         
         ?>
                                      
                        <tr>
                                          <td>
                                              <?php echo ++$k; ?>
                                          </td>
                                          <td>
                                              <?php echo $dis_row['distributor_name']; ?>
                                          </td>
                                          <td>
                                              <?php echo $dis_row['distributor_company_id']; ?>
                                          </td>
                                          <td>
                                              <?php echo $count_left_bv; ?>
                                          </td>
                                          <td>
                                              <?php echo $count_right_bv; ?>
                                          </td>
                                          <td>
										  
										  <?php 
			$paid_res=$conn->get_admin_paid_reward11($con,"money dispatched","$reward_type",$dis_row['distributor_company_id']);
        
        
        while($paid_row=mysqli_fetch_array($paid_res))
		{   
	
		$paid_row=$paid_row['sum(transaction_amount)']; 
										  if($count_left_bv<$count_right_bv){
											  
											  ?>
                                              <?php echo $a = ($count_left_bv*$bv_in_amount-$paid_row); ?>
                                          <?php
										  }
										  else{
											   ?>
                                              <?php echo $a = ($count_right_bv*$bv_in_amount-$paid_row); ?>
                                          <?php
		}}
										  ?>
										  </td>
											 <?php if($count_left_bv<$count_right_bv){
											  
											  ?>
                                              <?php  $bv=$count_left_bv; ?>
                                          <?php
										  }
										  else{
											   ?>
                                              <?php $bv=$count_right_bv; ?>
                                          <?php
		}
										  ?>
                                         <?php 
										  
									$paid_res=$conn->get_admin_paid_reward12($con,'reward',$bv);

        
									$paid_row=mysqli_fetch_array($paid_res);
		?>
										  
										  										 <td>
										 <?php echo $paid_row['payment_type_position']; ?>
										 
										 </td>

										 <td><?php if($a==""){
											   echo "";
										   }else{?>
										  <a href="money_dispatched.php" class="btn btn-success">Pay</a><?php } ?>
										  </td>
                                          
                   </tr>               
                                      
         
        <?php 
                                   }
                                   } 
        }
     
   } ?>
  
   <?php
    }  ?></table>
    
    <?php
        }
?>

<?php
if(isset($_REQUEST['distributor_idd']))
{
	$distributor_edit_id=$_REQUEST['distributor_idd'];
	echo"$distributor_edit_id";
	$distr_edit=$conn->get_admin_distributor_edit($con,$distributor_edit_id);
		   $row=mysqli_fetch_assoc($distr_edit);
		   $distributor_name=$row['distributor_name'];
		   echo"$distributor_name";
	?>
	
	
	
	<?php
	
}
?>







<?php
if(isset($_REQUEST['appli_id']))
{

$applicant_id=$_REQUEST['appli_id'];
//echo"$applicant_id";

$res=$conn->get_admin_fund_detail($con,$applicant_id);
    $row=mysqli_fetch_array($res);
	$fund=$row['applicant_fund_detail'];
	$applicant_username=$row['applicant_detail_username'];
	//Echo"$applicant_username";
	?>

	<div class="col-sm-12">
                                  <label> Amount</label>
					<input type="text" name="funt_amount" value="<?php echo"$fund"; ?>" class="form-control" id="get_image" readonly>
					<input type="hidden" name="applicant_username" value="<?php echo"$applicant_username"; ?>" class="form-control" id="get_image" readonly>
                              </div>
	<?php
}
if(isset($_REQUEST['paid_reward_type'])){
    if($_REQUEST['paid_reward_type']!=""){
        
        ?>
        <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/r/bs-3.3.5/jq-2.1.4,dt-1.10.8/datatables.min.css"/>
         <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.12/css/jquery.dataTables.min.css"/>
          <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/1.2.1/css/buttons.dataTables.min.css"/>
 
		<!--<script type="text/javascript" src="https://cdn.datatables.net/r/bs-3.3.5/jqc-1.11.3,dt-1.10.8/datatables.min.js"></script>-->
        
<!--        <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.1/js/dataTables.buttons.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.1/js/buttons.flash.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js"></script>
        <script type="text/javascript" src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/pdfmake.min.js"></script>
        <script type="text/javascript" src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/vfs_fonts.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.1/js/buttons.html5.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.1/js/buttons.print.min.js"></script>
        -->
        
        
		<script type="text/javascript" charset="utf-8">
			$(document).ready(function() {
				$('.example').DataTable();
			} );
		</script>
                <script type="text/javascript">
	// For demo to fit into DataTables site builder...
	$('.example')
		.removeClass( 'display' )
		.addClass('table table-striped table-bordered');
        
        
       
</script>


<br><br><br><br>
        <?php
        $reward_type=$_REQUEST['paid_reward_type'];
         $from=$_REQUEST['from'];
        $to=$_REQUEST['to'];
        
         function countt($id,$con){
                    $i=0;
                    $ss="select tree.id,tree.first_name,tree.position,distributor_detail.distributor_creation_date,tree.parent_id from tree left join distributor_detail on tree.id=distributor_detail.distributor_id where parent_id='$id' order by distributor_detail.distributor_creation_date desc";
                    $query=mysqli_query($con,$ss);
                    while( $rr=  mysqli_fetch_array($query)){
                      
                      $pp[$i]=$rr;
                      $i++;
                  }
//                  echo $ss."<br>";
                  if($i==2){
//                      echo $ss."<br>";
                      if($pp[0][1]!='blank'){
                          if($pp[0][1]!='blank' && $pp[1][1]!='blank'){
//                              $num++;
//                              echo $num;
                          }
                       $count_left=countt($pp[0][0],$con);   
                       $count_left++;
//                       echo $connt_left;
                      }else {
                          $count_left=0;                          
                      }
                      if($pp[1][1]!='blank'){
                           $count_right=countt($pp[1][0],$con); 
                           $count_right++;
                      }else{
                          $count_right=0;    
                      }
                     $counttt= $count_left+$count_right;
                     return $counttt;
                     
                  }if($i==0){
                   return 0;   
                  }
                }
				function countbv($id,$con){
                    $i=0;
                    $query=mysqli_query($con,"select * from tree where parent_id='$id' order by position");
                    while( $rr=  mysqli_fetch_array($query)){
                      
                      $pp[$i]=$rr;
                      $i++;
                  }
                  if($i==2){
                      if($pp[0][1]!='blank'){
                       $count_left_bv=countbv($pp[0][0],$con); 
                       $user_left_idd=$pp[0][0];
                       $sql=  mysqli_query($con, "select distributor_bv from distributor_detail where distributor_id='$user_left_idd'");
                       $rowss=  mysqli_fetch_array($sql);
                       $count_left_bv=$count_left_bv+$rowss['distributor_bv'];
//                       echo $connt_left;
                      }else {
                          $count_left_bv=0;                          
                      }
                      if($pp[1][1]!='blank'){
                           $count_right_bv=countbv($pp[1][0],$con); 
                            $user_right_idd=$pp[1][0];
                       $sql=  mysqli_query($con, "select distributor_bv from distributor_detail where distributor_id='$user_right_idd'");
                       $rowss=  mysqli_fetch_array($sql);
                           $count_right_bv=$count_right_bv+$rowss['distributor_bv'];
                      }else{
                          $count_right_bv=0;    
                      }
                     $counttt= $count_right_bv+$count_left_bv;
                     return $counttt;
                  }if($i==0){
                   return 0;   
                  }
                }
                
                 function countt_num($id,$con,$member_time){
                    $i=0;
                    $ss="select tree.id,tree.first_name,tree.position,distributor_detail.distributor_creation_date,tree.parent_id from tree left join distributor_detail on tree.id=distributor_detail.distributor_id where parent_id='$id' order by distributor_detail.distributor_creation_date desc";
                    $query=mysqli_query($con,$ss);
                    while( $rr=  mysqli_fetch_array($query)){
                      
                      $pp[$i]=$rr;
                      $i++;
                  }
//                  echo $ss."<br>";
                  if($i==2){
                      if($pp[0][1]!='blank'){
                          array_push($member_time, $pp[0][3]);
                       $count_left=countt_num($pp[0][0],$con,$member_time);  
                      }else{
                          $count_left=['0'];
                      }
                      if($pp[1][1]!='blank'){
                          array_push($member_time, $pp[1][3]);
                           $count_right=countt_num($pp[1][0],$con,$member_time); 
                      }else{
                          $count_right=['0'];
                      }
//                      print_r($childs);
//                      print_r($count_right);
//                      print_r($count_left);
                      $member_time=  array_merge($count_right,$count_left);
//                       print_r($childs);
//                      echo "<br>";
                      return $member_time;
                  }if($i==0){
                   return $member_time;   
                  }
                }
                
                
                
                
                function smallest($num1,$num2){
                    if($num1>$num2){
                        return $num2;
                    }
                    if($num2>$num1){
                        return $num1;
                    }
                    if($num1==$num2){
                        return $num1;
                    }
                    
                }
                
                function greatest($num1,$num2){
                    if($num1>$num2){
                        return $num1;
                    }
                    if($num2>$num1){
                        return $num2;
                    }
                    if($num1==$num2){
                        return $num1;
                    }
                    
                }
        
        
      {
            $payment_type=$reward_type;
            
            ?>
                
<div class="col-sm-12">     <table class="table table-bordered display example" id="example"><thead>  <tr>
                                       <th>S.No.</th>
                                                  <th>Name</th>
                                                  <th>Company Id</th>
                                                  <th>Total Left B V</th>
                                                  <th>Total Right B V</th>
                                              <?php if($payment_type=="reward" || $payment_type=="bonanza" ){ ?>    
  											      <th>Reward Commodity</th> <?php } ?>
                                                  <th>Reward Amount</th> 
                                      </tr></thead>
        
        
        <?php
        $paid_res=$conn->get_admin_paid_reward($con,"money dispatched",$reward_type,$from,$to);
        $j=0;
        while($paid_row=mysqli_fetch_array($paid_res)){
//            echo $paid_row['transaction_distributor_id'];
            $res_id=$conn->get_admin_distributor_detail_by_cmpny_id($con,$paid_row['transaction_distributor_id']);
            $row_id=  mysqli_fetch_array($res_id);
            $id=$row_id['distributor_id'];
//            echo "<br>".$id;
              $ss="select tree.id,tree.first_name,tree.position,distributor_detail.distributor_creation_date,tree.parent_id from tree left join distributor_detail on tree.id=distributor_detail.distributor_id where parent_id='$id' order by position";
                    $left=mysqli_query($con,$ss);
                  $pp=array();
                  $i=0;
                  $count_left=0;
                  $count_right=0;
                  
                  while( $rr=  mysqli_fetch_array($left)){
                     
                      $pp[$i]=$rr;
                       $i++;
                  }
//                  echo "<br><br>";
                   
                  if($i==2){
                      
                      if($pp[0][1]!='blank'){
                          $id=$pp[0][0];
                          
                       $count_left=countt($id,$con); 
                       $count_left++;
                      }else {
                          $count_left=0;                          
                      }
                      if($pp[1][1]!='blank'){
                          $idd=$pp[1][0];
                         $count_right=countt($idd,$con); 
                         $count_right++;
                      }else {
                          $count_right=0;                          
                      }
                  }
                  
				  $count_left_bv=0;
                  $count_right_bv=0;
                  
                  if($i==2){
                      if($pp[0][1]!='blank'){
                       $count_left_bv=countbv($pp[0][0],$con); 
                       $user_left_idd=$pp[0][0];
                       $sql=  mysqli_query($con, "select distributor_bv from distributor_detail where distributor_id='$user_left_idd'");
                       $rowss=  mysqli_fetch_array($sql);
                       $count_left_bv=$count_left_bv+$rowss['distributor_bv'];
//                       echo $connt_left;
                      }else {
                          $count_left_bv=0;                          
                      }
                      if($pp[1][1]!='blank'){
                           $count_right_bv=countbv($pp[1][0],$con); 
                            $user_right_idd=$pp[1][0];
                       $sql=  mysqli_query($con, "select distributor_bv from distributor_detail where distributor_id='$user_right_idd'");
                       $rowss=  mysqli_fetch_array($sql);
                           $count_right_bv=$count_right_bv+$rowss['distributor_bv'];
                      }else{
                          $count_right_bv=0;    
                      }
//                     $counttt= $count_right_bv+$count_left_bv;
//                     return $counttt;
                  }
				  
//                 echo "<br>".$count_left."---".$count_right.$row_id['distributor_name']; ?>
        
        <tr>
            <td><?php echo ++$j; ?></td>
            <td><?php echo $row_id['distributor_name']; ?></td>
            <td><?php echo $paid_row['transaction_distributor_id']; ?></td>
             <td><?php echo $count_left_bv; ?></td>
              <td><?php echo $count_right_bv; ?></td>
           <?php if($payment_type=="reward" || $payment_type=="bonanza" ){ ?>     
		   <td><?php echo $paid_row['transaction_payment_mode']; ?></td> <?php } ?>
               <td><?php echo $paid_row['transaction_amount']; ?></td>
        </tr>
        
        <?php
            
        }
        ?>
    </table>
        <?php
        
        }
    }
}if(isset($_REQUEST["client_payment_username"])){
    $client_id=$_REQUEST["client_payment_username"];
    ?>
     <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/r/bs-3.3.5/jq-2.1.4,dt-1.10.8/datatables.min.css"/>
         <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.12/css/jquery.dataTables.min.css"/>
          <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/1.2.1/css/buttons.dataTables.min.css"/>
          
          <script type="text/javascript" charset="utf-8">
			$(document).ready(function() {
				$('.example').DataTable(
//                 {
//        dom: 'Bfrtip',
//        buttons: [
//            'copy', 'csv', 'excel', 'pdf', 'print','pageLength'
//        ]
//    },             
//           {
//        dom: 'Bfrtip',
//        lengthMenu: [
//            [ 10, 25, 50, -1 ],
//            [ '10 rows', '25 rows', '50 rows', 'Show all' ]
//        ]
//    },
    {
        drawCallback: function ( row, data, start, end, display ) {
//            alert("hello");
            var api = this.api(), data;
 
            // Remove the formatting to get integer data for summation
            var intVal = function ( i ) {
                return typeof i === 'string' ?
                    i.replace(/[\$,]/g, '')*1 :
                    typeof i === 'number' ?
                        i : 0;
            };
 
            // Total over all pages
            total = api
                .column( 3 )
                .data()
                .reduce( function (a, b) {
                    return intVal(a) + intVal(b);
                }, 0 );
 
            // Total over this page
            pageTotal = api
                .column( 3, { page: 'current'} )
                .data()
                .reduce( function (a, b) {
                    return intVal(a) + intVal(b);
                }, 0 );
 
            // Update footer
            $( api.column( 3 ).footer() ).html(
                'Rs:'+pageTotal +' (Rs:'+ total +' total)'
            );
        }
    }
                );
			} );
		</script>
                <script type="text/javascript">
	// For demo to fit into DataTables site builder...
	$('.example')
		.removeClass( 'display' )
		.addClass('table table-striped table-bordered');
        
        
       
       
</script>
<script>

// $(document).ready(function() {
//    $('#example').DataTable(  );
//} );
</script>

<br><br>
          
    <table class="table example">
        <thead><tr>
                <th>S.No.</th>
                <th>Client Name</th>
                <th>Ploat Number</th>
                <th>Amount Paid</th>
                <th>Total Amount</th>
                <th>Date</th>
            </tr></thead>
        <?php 
        $client_detail=$conn->get_admin_applicant_details($con,$client_id);
        $client_detail_row=mysqli_fetch_array($client_detail);
        $client_idd=$client_detail_row['applicant_id'];
        $plot_detail_res=$conn->get_plot_detail($con,$client_idd);
        $plot_detail_row=  mysqli_fetch_array($plot_detail_res);
        $client_payment_detail=$conn->get_client_payment_detail($con,$client_id);
//        $client_payment_detail_res=  mysqli_fetch_array($client_payment_detail);
        $i=0;
        while($client_payment_detail_row=mysqli_fetch_array($client_payment_detail)){
            
      
        ?>
        
        <tr>
            <td><?php echo ++$i; ?></td>
            <td><?php echo $client_detail_row['applicant_name'];  ?></td>
            <td><?php echo $plot_detail_row['plot_price_details_plot_no']; ?></td>
            <td><?php echo $client_payment_detail_row['transaction_amount']; ?></td>
            <td><?php echo $client_detail_row['applicant_fund_detail']; ?></td>
            <td><?php echo $client_payment_detail_row['transaction_date']; ?></td>
            
            
        </tr>
        <?php   } ?>
           <tfoot>
        <tr>
            <th style="text-align:right" colspan="3">Total:</th>
            <th style="text-align:left" colspan="3"></th>
        </tr>
    </tfoot>
    </table>
    
 <?php   
}
 ?>	