<?php
session_start();
$user_id=$_SESSION['user'];
$page = 1;
include_once '../property/pss_db.php';
$conn = new DB_con();
$con = $conn->connection();
$functions = new functions();
if(isset($_REQUEST['jk']))

{
       
       
       $get_date=mysqli_query($con,"select distributor_creation_date from distributor_detail where distributor_company_id='$_REQUEST[jk]'");
    $distributor_date= mysqli_fetch_array($get_date);
    $begin1=$distributor_date['distributor_creation_date'];
$begin = new DateTime("$begin1");
$end = new DateTime();
                        
  for($next_week1 = $begin; $begin <= $end; $next_week1->modify('+14 day'))
{
  $next_week=$next_week1->format("Y-m-d");   
}  ?> <center><input type="text"  id="jk">
<input type="text" value="<?php echo $begin1; ?>" id="begin1">
    
 <input type="text" value="<?php echo $next_week; ?>" id="next_week">
<input type="text" value="total" id="type">
<a onclick="change1()" class="btn btn-success" ">pay</a></center>
<?php} ?>