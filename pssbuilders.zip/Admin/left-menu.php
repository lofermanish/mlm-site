 <div class="sidebar sidebar-left mCustomScrollbar _mCS_1 bg-in">
            <div class="mCustomScrollBox mCS-light-thin" id="mCSB_1" style="position:relative; height:100%; overflow:hidden; max-width:100%;">
                
                
                <div class="mCSB_container mCS_no_scrollbar" style="position: relative; top: 0px;">
        	<div class="content">
	             <ul class="nav nav-tabs nav-justified sidetabs">
				  <li class="active"><a href="http://flatter.cloudtub.com/index.html#home" data-toggle="tab"><i class="fa fa-compass"></i> </a></li>
				  <li class=""><a href="http://flatter.cloudtub.com/index.html#users" data-toggle="tab"><i class="fa fa-user"></i> </a></li>
				  <li class=""><a href="http://flatter.cloudtub.com/index.html#email" data-toggle="tab"><i class="fa fa-envelope-o"></i></a></li>
				</ul>

				<div class="tab-content sidetabs">
				  <div class="tab-pane active" id="home">
					  	 <ul class="sidemenu">
						    <li class="sidebar-header">Home</li>
						    <li class="active">
                                                        <a href="dashboard.php">
						            <span class="icon"><i class="fa fa-dashboard"></i></span>
						            <span class="name">Dashboard</span>
						           
						        </a>
						    </li>
							
<!--//							include_once 'db.php';-->
                                                        <?php
                                                        $user_id=$_SESSION['user'];
                                                        $res=$conn->get_admin_parent_menu($con,$user_id);


while ($row=mysqli_fetch_array($res))
{
	?>
						    <li>
							
                <i class=""></i> <span></span> <i class="fa fa-angle-left pull-right"></i>
              </a>
              
						        <a href="javascript:void(0);">
						            <span class="icon"><i class="fa fa-chain"></i></span>
						            <span class="name"><?php echo $row['m_menu_name']; ?></span>
						            <i class=""></i> <span></span> <i class="fa fa-angle-left pull-right"></i>
									<?php
                                                                       $menu_id= $row['m_menu_id'];
				$query3=$conn->get_admin_sub_menu($con,$menu_id,$user_id);
	?>
						        </a>
						        <ul class="sidebar-dropdown" style="">
								<?php  
			  
		while($pro_row=mysqli_fetch_array($query3))
		{
			?>
						        		<li class="sidebar-dropdown-title"><p>Elements</p></li>
						        		 <li><a href="<?php echo $pro_row['m_menu_link']; ?>"><i class="<?php echo $pro_row['icon']; ?>"></i><?php echo $pro_row['m_menu_name']; ?></a></li>
			                            
			                         <?php
		}


		?>  
			                    </ul>
						    </li>
							 <?php
		}


		?>
					</ul>
				  </div>

				  <div class="tab-pane" id="users">
					  <ul class="sidemenu">
						    <li class="sidebar-header">Users</li>
						    <li class="active">
						        <a href="http://flatter.cloudtub.com/index.html">
						            <span class="icon"><i class="fa fa-home"></i></span>
						            <span class="name">Users</span>
						            <span class="number pull-right"><span class="label label-danger">5</span></span>
						        </a>
								</li>
					  </ul>
				  </div>

				  <div class="tab-pane" id="email">
				  		<ul class="sidemenu">
						    <li class="sidebar-header">Email</li>
						    <li>
						        <a href="http://flatter.cloudtub.com/mail-inbox.html">
						            <span class="icon"><i class="fa fa-inbox"></i></span>
						            <span class="name">Inbox</span>
						            <span class="number pull-right"><span class="label label-success">10</span></span>
						        </a>
						    </li>
						    <li>
						        <a href="http://flatter.cloudtub.com/mail-compose.html">
						            <span class="icon"><i class="fa fa-edit"></i></span>
						            <span class="name">Compose</span>
						        </a>
						    </li>
						    <li>
						        <a href="http://flatter.cloudtub.com/mail-view.html">
						            <span class="icon"><i class="fa fa-file-o"></i></span>
						            <span class="name">View</span>
						        </a>
						    </li>
				  		</ul>
				  </div>
				</div>
        	</div>
        </div>
                <div class="mCSB_scrollTools" style="position: absolute; display: none;">
                    <div class="mCSB_draggerContainer"><div class="mCSB_dragger" style="position: absolute; top: 0px;" oncontextmenu="return false;">
                    <div class="mCSB_dragger_bar" style="position:relative;">
                        
                    </div>
                        
                    
                </div>
                <div class="mCSB_draggerRail">
                    
                </div>
                    
            </div>
                    
        </div>
            
            </div>
                
        </div>