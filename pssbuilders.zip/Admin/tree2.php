
<!DOCTYPE HTML>
<html>
    <?php 
    $id=1;
    if(isset($_POST['search']) &&  $_POST['u_id']!=""){
        $id=$_POST['u_id'];
    }else{
        $id=1;
    }
    ?>
    <head runat="server">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <title>jQuery Tree</title>
        <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Cabin:400,700,600"/>
        <link href="style.css" rel="stylesheet" type="text/css">
        <script src="js/jquery-1.11.1.min.js"></script>
        <script src="js/jquery-migrate-1.2.1.min.js"></script>
        <script src="js/jquery-ui.js"></script>
        <script src="js/jquery.tree.js"></script>
<!--        <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
        <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>-->
        <script>
$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();   
});
</script>

        <script>
            $(document).ready(function() {
                $('.tree').tree_structure({
                    'add_option': true,
                    'edit_option': true,
                    'delete_option': true,
                    'confirm_before_delete': true,
                    'animate_option': false,
                    'fullwidth_option': false,
                    'align_option': 'center',
                    'draggable_option': true
                });
            });
        </script>
    </head>
    <body>
        <form action="#" method="post">
        <div class="col-sm-10"> Enter Id to Search:<input type="text" name="u_id" class="form-control"></div>
        <div class="col-sm-2"  style="text-align: right"> <br><input type="submit" name="search" class="btn btn-success" value="Search" style="text-align: center"></div></form>
        <!--<div class="col-sm-2" style="text-align: right"> <br><a href="logout.php?logout"><input type="submit" name="Logout" value="Logout" class="btn btn-danger"></a></div>-->
        <?php
//        include_once 'db.php';
//        $page=1;
//include_once '../property/dbMysql.php';
//$conn = new DB_con();
//$con=$conn->connection();
//include_once 'property/function_list.php';
//include_once 'property/default_values.properties';
$functions=new functions();
		function in_parent($in_parent, $store_all_id, $con,$p) {
                    $p++;
            if (in_array($in_parent, $store_all_id)) {
                
                $result = mysqli_query($con, "SELECT * FROM tree where parent_id = $in_parent");
                echo $in_parent == 0 ? "<ul class='tree'>" : "<ul>";
                while ($row = mysqli_fetch_array($result)) {
                    echo "<li";
//                    if ($row['hide'])
                    if($p>1)
                        echo " class='thide'";
//                    $p++;
//                    echo $p;
                    echo "><div id=" . $row['id'] ."><span class='first_name' data-toggle='tooltip' data-placement='top'  title=".$row['first_name'] ."><img src='male.jpg' alt='hello' ><br>" . $row['first_name'] . "</span></div>";
                    in_parent($row['id'], $store_all_id, $con,$p);
                    echo "</li>";
                }
                echo "</ul>";
           
                }
        }
        $store_all_id = array();
        $id_result = mysqli_query($con, "SELECT * FROM tree");
        while ($all_id = mysqli_fetch_array($id_result)) {
            array_push($store_all_id, $all_id['parent_id']);
        }
        echo "<div class='overflow col-sm-12'><div>";
//        in_parent(0, $store_all_id, $con);
         $result = mysqli_query($con, "SELECT * FROM tree where id = $id");
         $row = mysqli_fetch_array($result);
          echo "<ul class='tree'>";
          echo "<li";
                    if ($row['hide'])
                        echo " class='thide'";
                    echo "><div id=" . $row['id'] . "><span class='first_name' data-toggle='tooltip' data-placement='top' title=".$row['first_name'] ."><img src='male.jpg' alt='hello' ><br>" . $row['first_name'] . "</span></div>";
                    in_parent($row['id'], $store_all_id, $con,0);
                    echo "</li>";
        echo "</div></div>";

        

        mysqli_close($con);
        ?>
    </body>
</html>
