
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head><title>
	Welcome to pssbuilders.com.
</title><link href="Css/StyleBinary.css" rel="stylesheet" /></head>
<body>
    <form name="form1" method="post" action="binaryincomeRpt.aspx?PayoutNo=39" id="form1">
<div>
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="" />
</div>
<script>
	function print1() {
		window.print();
    window.location.href="welcome.php";
}
$(document).keyup(function(e){
  if(e.keyCode == 44) return false;
});
</script>
            	<link rel="stylesheet" type="text/css" href="/css/print.css" media="print" />
		<style type="text/css" media="print">
@page {
    size: auto;   /* auto is the initial value */
    margin: 0;  /* this affects the margin in the printer settings */
}
</style>

<div>

	
</div>
    <div id="DivPayoutReport" align="center">
				<table style="BORDER-BOTTOM: #000000 1px solid; BORDER-LEFT: #000000 1px solid; BORDER-TOP: #000000 1px solid; BORDER-RIGHT: #000000 1px solid"
					border="0" cellspacing="0" cellpadding="0" width="640">
					<tr>
						<td colspan="2" style="BORDER-BOTTOM: #000000 1px solid" >
							<table border="0" cellspacing="0" cellpadding="2" width="100%">
								<tr>
								    <td id="CompName" class="receipthead" align="left" style="height:80px;" >
								        <img alt="" src="../images/boomerang-logo-black.png" width="250" height="100px" /></td>
<td id="CompName" class="receipthead" align="right" style="height:80px;" >
								        <img alt="" src="../images/Untitled.png" width="250" height="100px" />
			
									</td>

								</tr>
								<tr>
									<td style="WIDTH: 2px" width="2" align="left">
									
									</td>
									<td valign="middle" align="center" style="width: 551px">
									</td>
								</tr>
							</table>


							<?php if(isset($_REQUEST['i']))
                               {
            $res=$conn->get_admin_distributor_detail_by_cmpny_id($con,$_REQUEST['i']);
            $row=  mysqli_fetch_array($res);
                               }
                        
							?>

						</td>
					</tr>
					<tr>
						<td class="tdHeading" colspan="2" style="BORDER-BOTTOM: #000000 1px solid" >
							<div align="center">Personal Details
							</div>
						</td>
					</tr>
					<tr>
						<td style="BORDER-BOTTOM: #000000 1px solid; BORDER-RIGHT: #000000 1px solid; width: 50%;">
							<table border="0" cellspacing="0" cellpadding="0" width="100%">
								<tr>
									<td class="labelBin" colspan="6">To</td>
								</tr>
								<tr>
									<td class="labelto" colspan="6">
										<div id="Name"><?php echo $row['distributor_name'];?></div>
									</td>
								</tr>
								<tr>
									<td colspan="6">
										<div id="Add1" class="labelto"><?php echo $row['distributor_current_address'];?> </div>
									</td>
								</tr>
								<tr>
									<td colspan="6">
										<div id="Add2" class="labelto"></div>
									</td>
								</tr>
								<tr>
									<td class="labelper">City
									</td>
									<td>
										<div align="center">:</div>
									</td>
									<td>
										<div id="Tehsil" class="textto"><?php echo $row['distributor_city'];?></div>
									</td>
									<td class="labelper">
									</td>
									<td>
										<div align="center"></div>
									</td>
									<td>
										<div id="Mobile" class="textto"></div>
									</td>
								</tr>
								<tr>
									<td class="labelper">District</td>
									<td>
										<div align="center">:</div>
									</td>
									<td colspan="4">
										<div id="District" class="textto"><?php echo $row['distributor_district'];?></div>
									</td>
								</tr>
								<tr>
									<td class="labelper">State</td>
									<td>
										<div align="center">:</div>
									</td>
									<td>
										<div id="State" class="textto"><?php echo $row['distributor_state'];?></div>
									</td>
									<td class="labelper">PinNo.
									</td>
									<td>
										<div align="center">:</div>
									</td>
									<td>
										<div id="PinNo" class="textto"><?php echo $row['distributor_pincode'];?></div>
									</td>
								</tr>
							</table>
						</td>
						<td width="50%" style="BORDER-BOTTOM: #000000 1px solid" >
							<table border="0" cellspacing="0" bordercolordark="#000000" cellpadding="3" width="100%">
								<tr>
									<td class="labelBin" style="height: 37px">PanNo
									</td>
									<td class="Colonbin" style="height: 37px">
										<div align="center">:</div>
									</td>
									<td style="height: 37px">
										<div id="PanNo" class="textbin"><?php echo $row['distributor_pan'];?></div>
									</td>
								</tr>
								<tr>
									<td class="labelBin">Distributor ID
									</td>
									<td class="Colonbin">
										<div align="center">:</div>
									</td>
									<td>
										<div id="DistributorID" class="textbin"><?php echo $row['distributor_company_id'];?></div>
									</td>
								</tr>
								<tr>
									<td class="labelBin"></td>
									<td class="Colonbin">
										<div align="center"></div>
									</td>
									<td>
										<div id="PayoutNo" class="textbin"></div>
									</td>
								</tr>
								<tr>
									<td style="Z-INDEX: 0" class="labelBin">From Date
									</td>
									<td class="Colonbin">
										<div align="center">:</div>
									</td>
									<td>
										<div id="FromDate" class="textbin"><?php echo $from=date('Y-m-d', strtotime($_REQUEST['t'].'-1 month'));?>
  </div>
									</td>
								</tr>
								<tr>
									<td class="labelBin">To Date
									</td>
									<td class="Colonbin">
										<div align="center">:</div>
									</td>
									<td>
										<div id="ToDate" class="textbin" DESIGNTIMEDRAGDROP="107"><?php echo $_REQUEST['t'];?></div>
									</td>
								</tr>
								<tr>
									<td class="labelBin">Mobile No
									</td>
									<td class="Colonbin">
										<div align="center">:</div>
									</td>
									<td>
										<div id="MobileNo" class="textbin"><?php echo $row['distributor_mobile'];?></div>
									</td>
								</tr>
							</table>
						</td>
					</tr>
					<tr>
						<td class="tdHeading" colspan="2" style="BORDER-BOTTOM: #000000 1px solid" >
							<div align="center">Incentive Report
							</div>
						</td>
					</tr>
					<tr>
						<td style="BORDER-BOTTOM: #000000 1px solid; BORDER-RIGHT: #000000 1px solid; width: 50%;">
							<table border="0" cellspacing="0" cellpadding="3" width="100%">
								<tr>
									
								</tr>
                                <tr>
                                    
                                </tr>
								<tr>
								<td class="labelBin">Net Income
									</td>
									<td class="Colonbin">
										<div align="center">:</div>
									</td>
									<td>
										<div id="NetIncome" class="textbin"><?php echo $_REQUEST['a'];?></div>
									</td>
									
								</tr>
							</table>
						</td>
						<td style="BORDER-BOTTOM: #000000 1px solid" width="50%" valign="top">
							<table border="0" cellspacing="0" cellpadding="3" width="100%">
								<tr>
									<td class="labelBin">TDS Amount
									</td>
									<td>
										<div class="Colonbin" align="center">:</div>
									</td>
									<td>
										<div id="TDSAmount" class="textbin"><?php echo $_REQUEST['a']*.1;?></div>
									</td>
								</tr>
								<tr>
									<td class="labelBin">Admin Charge&nbsp;</td>
									<td>
										<div class="Colonbin" align="center">:</div>
									</td>
									<td>
										<div id="AdminCharge" class="textbin"><?php echo $_REQUEST['a']*.05;?></div>
									</td>
								</tr>
								
                                <tr>
                                    <td class="labelBin">
                                        </td>
                                    <td>
                                        <div class="Colonbin" align="center"></div></td>
                                    <td>
                                        <div id="Prevbal" class="textbin"></div>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="labelBin"></td>
                                    <td>
                                        <div class="Colonbin" align="center"></div></td>
                                    <td>
                                        <div id="clsbal" class="textbin"></div>
                                    </td>
                                </tr>
							</table>
						</td>
					</tr>
					<tr>
						<td colspan="2" style="BORDER-BOTTOM: #000000 1px solid" >
							<table border="0" cellspacing="0" cellpadding="3" width="100%">
								<tr>
									<td class="labelAmt">Cheque Amount
									</td>
									<td>
										<div class="Colonbin" align="center">:</div>
									</td>
									<td>
										<div id="Amountword" class="textAmt"><?php echo $_REQUEST['a']-$_REQUEST['a']*.15;?></div>
									</td>
								</tr>
							</table>
						</td>
					</tr>
					<tr>
						<td class="tdHeading" colspan="2" style="BORDER-BOTTOM: #000000 1px solid" >
							<div align="center">Leg Details
							</div>
						</td>
					</tr>
					<tr>
						<td colspan="2">
							<table cellspacing="0" cellpadding="3" width="100%" border="0" style="BORDER-BOTTOM: #000000 1px solid">
								<tr>
									<td colspan="4" style="BORDER-RIGHT: #000000 1px solid">
										<div class="labelmid"><center>Current Month Leg</center>
										</div>
									</td>
									<!--td colspan="2" style="BORDER-RIGHT: #000000 1px solid">
										<div class="labelmid">Up to Date Leg
										</div>
									</td-->
									<td colspan="4" style="BORDER-RIGHT: #000000 1px solid">
										<div class="labelmid"><center>
											Current Month&nbsp;Income</center>
										</div>
									</td>
									<!--td colspan="2" style="BORDER-RIGHT: #000000 1px solid">
										<div class="labelmid">Up To Date Unit
										</div>
									</td-->
								</tr>
								<tr>
									<td colspan="2" style="BORDER-RIGHT: #000000 1px solid; BORDER-TOP: #000000 1px solid">
										<div class="labelmid">
											Leg&nbsp;Left
										</div>
									</td>
									<td colspan="2" style="BORDER-RIGHT: #000000 1px solid; BORDER-TOP: #000000 1px solid">
										<div class="labelmid">
											Leg&nbsp;Right
										</div>
									</td>
									<!--td style="BORDER-RIGHT: #000000 1px solid; BORDER-TOP: #000000 1px solid">
										<div class="labelmid">
											Leg&nbsp;Left
										</div>
									</td>
									<td style="BORDER-RIGHT: #000000 1px solid; BORDER-TOP: #000000 1px solid">
										<div class="labelmid">
											Leg&nbsp;Right
										</div>
									</td-->
									<td colspan="2"style="BORDER-RIGHT: #000000 1px solid; BORDER-TOP: #000000 1px solid">
										<div class="labelmid">Leg&nbsp;Left&nbsp;Income
										</div>
									</td>
									<td colspan="2" style="BORDER-RIGHT: #000000 1px solid; BORDER-TOP: #000000 1px solid">
										<div class="labelmid">Leg&nbsp;Right&nbsp;Income
										</div>
									</td>
									<!--td style="BORDER-RIGHT: #000000 1px solid; BORDER-TOP: #000000 1px solid">
										<div class="labelmid">
											Leg&nbsp;Left Unit
										</div>
									</td>
									<td style="BORDER-RIGHT: #000000 1px solid; BORDER-TOP: #000000 1px solid">
										<div class="labelmid">Leg&nbsp;Right&nbsp;Unit
										</div>
									</td-->
								</tr>
								<tr>
									<td colspan="2" style="BORDER-RIGHT: #000000 1px solid; BORDER-TOP: #000000 1px solid">
										<div id="CurLgX" class="textleg"><?php echo $_REQUEST['lb'];?></div>
									</td>
									<td colspan="2" style="BORDER-RIGHT: #000000 1px solid; BORDER-TOP: #000000 1px solid">
										<div id="CurLgY" class="textleg"><?php echo $_REQUEST['rb'];?></div>
									</td>
									<!--td style="BORDER-RIGHT: #000000 1px solid; BORDER-TOP: #000000 1px solid">
										<div id="UpLgX" class="textleg">382</div>
									</td>
									<td style="BORDER-RIGHT: #000000 1px solid; BORDER-TOP: #000000 1px solid">
										<div id="UpLgY" class="textleg">194</div>
									</td-->
									<td colspan="2" style="BORDER-RIGHT: #000000 1px solid; BORDER-TOP: #000000 1px solid">
										<div id="CurBvX" class="textleg"><?php echo $_REQUEST['lb']*20000;?></div>
									</td>
									<td colspan="2" style="BORDER-RIGHT: #000000 1px solid; BORDER-TOP: #000000 1px solid">
										<div id="CurBvY" class="textleg"><?php echo $_REQUEST['rb']*20000;?></div>
									</td>
									<!--td style="BORDER-RIGHT: #000000 1px solid; BORDER-TOP: #000000 1px solid">
										<div id="UpBvX" class="textleg">15420.00</div>
									</td>
									<td style="BORDER-RIGHT: #000000 1px solid; BORDER-TOP: #000000 1px solid">
										<div id="UpBvY" class="textleg">5625.00</div>
									</td-->
								</tr>
							</table>
						</td>
					</tr>
					<tr>
						<td colspan="2">
							<table border="0" cellspacing="0" cellpadding="3" width="635">
								<tr>
									<td class="labelBin">Notes : -
									</td>
								</tr>
								<tr>
									<td class="labelnote">* TDS as per rates applicable under section 194H of Income 
										tax Act. This section has been inserted&nbsp;from 1st Jan 2001</td>
								</tr>
								<tr>
									<td class="labelnote">* This is a Computer Generated Statement and does not need 
										any signature</td>
								</tr>
								<tr>
									<td class="labelnote">* If there is any Change in Address please inform us with 
										Address Proof to serve you better</td>
								</tr>
							</table>
						</td>
					</tr>
					<tr>
						<td colspan="2">
							<table border="0" cellspacing="0" cellpadding="3" width="635">
								<tr>
									<td class="labelAmt">** &nbsp; Abbreviations &nbsp; **
									</td>
								</tr>
								<tr>
									<td>&nbsp;</td>
								</tr>
								<tr>
									<td class="labelnote">* T.D.S. - Tax Deduction Source
									</td>
								</tr>
							</table>
						</td>
					</tr>
					<tr>
						<td colspan="2">&nbsp;</td>
					</tr>
					<tr>
						<td colspan="2">
							<table border="0" cellspacing="0" cellpadding="3" width="635">
								<tr>
									<td class="subfooter" align="left"></td>
								</tr>
								<tr>
									<td class="subfooter" align="left"></td>
								</tr>
								<tr>
									<td class="subfooter" align="right">Commission Received &amp; Confirm
									</td>
								</tr>
							</table>
						</td>
					</tr>
					<tr>
						<td colspan="2">&nbsp;</td>
					</tr>
					<tr>
						<td colspan="2">
							<table border="0" cellspacing="0" cellpadding="0" width="635">
								<tr>
									<td>
										<div align="center">
											<div id="CmpName" class="cmpname"></div>
										</div>
									</td>
								</tr>
								<tr>
									<td>
										<div align="center">
											<div id="CmpAdd1"></div>
										</div>
									</td>
								</tr>
								<tr>
									<td>
										<div align="center">
											<div id="CmpAdd2"></div>
										</div>
									</td>
								</tr>
								<tr>
									<td>
										<div align="center">
											<div id="CmpPhoneNo"></div>
										</div>
									</td>
								</tr>
								<tr>
									<td>
										<div align="center">
											<div id="CmpEmail"></div>
										</div>
									</td>
								</tr>
								<tr>
									<td align="center">&nbsp;
									</td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
				<center><a href="" onclick="print1()"></a> </center>
				</div>
    </form>
</body>
</html>