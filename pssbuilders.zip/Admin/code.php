<?php

	$i=1;
while($i<100)
{ 
  $ss1 = substr(str_shuffle(str_repeat("0123456789abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ", 5)), 0, 16);
echo    $ss1;
$i++;
?><br><?php
  }


?>