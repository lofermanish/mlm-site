<?php
if(isset($_REQUEST['plot_price_details_id']))
{
@include_once '../property/pss_db.php';
@$conn = new DB_con();
@$con = $conn->connection();
$plot_price_details_id=$_REQUEST['plot_price_details_id'];

//echo"$news_id";
		?>						
								<?php
				$res = $conn->get_admin_plot_delete($con,$plot_price_details_id);
				if($res)
				{
		   // header("location:news-details.php");
				echo"<script>alert('Plot Details deleted Successfully');
                         window.location.href='plot_details.php';
                        </script>";
				}
				else
				{
				echo"<script>alert('Record not deleted');<script>";
				}
				 ?>
			
								
<?php
}
?>