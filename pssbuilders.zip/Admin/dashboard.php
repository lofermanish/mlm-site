<?php
	session_start();
//include_once 'db.php';

if(!isset($_SESSION['user']))
{
	header("Location: index.php");
}
else
{
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Dashboard</title>
<meta name="description" content="Flatter - Flat Admin Theme">
<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/layout.css">
<link rel="stylesheet" href="css/style3.css">
<script type="text/javascript" src="js/jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.10.4.custom.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/r/bs-3.3.5/jq-2.1.4,dt-1.10.8/datatables.min.css"/>
 
		<script type="text/javascript" src="https://cdn.datatables.net/r/bs-3.3.5/jqc-1.11.3,dt-1.10.8/datatables.min.js"></script>
		  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/1.2.1/css/buttons.dataTables.min.css"/>
 
		<!--<script type="text/javascript" src="https://cdn.datatables.net/r/bs-3.3.5/jqc-1.11.3,dt-1.10.8/datatables.min.js"></script>-->
                 <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.1/js/dataTables.buttons.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.1/js/buttons.flash.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js"></script>
        <script type="text/javascript" src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/pdfmake.min.js"></script>
        <script type="text/javascript" src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/vfs_fonts.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.1/js/buttons.html5.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.1/js/buttons.print.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.1/js/buttons.colVis.min.js"></script>
        <script type="text/javascript" src="js/jquery-easing.js"></script>
		<script type="text/javascript" charset="utf-8">
			$(document).ready(function() {
				$('.example').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'pageLength',
            {
                extend: 'print',
                autoPrint: false,
                title: 'Report',
                exportOptions: {
                    columns: ':visible'
                }
            },{
                extend: 'pdf',
                title: 'Report',
                exportOptions: {
                    columns: ':visible'
                }
            },{
                extend: 'excel',
                title: 'Report',
                exportOptions: {
                    columns: ':visible'
                }
            },{
                extend: 'csv',
                title: 'Report',
                exportOptions: {
                    columns: ':visible'
                }
            },{
                extend: 'copy',
                exportOptions: {
                    columns: ':visible'
                }
            },
            'colvis'
        ]
    },
    {
        dom: 'Bfrtip',
        lengthMenu: [
            [ 10, 25, 50, -1 ],
            [ '10 rows', '25 rows', '50 rows', 'Show all' ]
        ]
      
    },
    {
        dom: 'Bfrtip',
        buttons: [
            {
                extend: 'collection',
                text: 'Table control',
                buttons: [
                    'colvis'
                ]
            }
        ]
    } 
            
                );
			} );
                        
                        
                        
                        
		</script>
                <script type="text/javascript">
	// For demo to fit into DataTables site builder...
	$('.example')
		.removeClass( 'display' )
		.addClass('table table-striped table-bordered');
</script>
</head>
<body id="body">

		<!-- Header -->
		<?php include './header.php'; ?>

       <?php include './left-menu.php'; ?>
		<!-- Header -->

        <section id="main-wrapper">
		<h3 class="subtitle">Dashboard</h3>
          <hr>
		  <div class="row">
		  
	
                <?php 
                
                function countt($id,$con){
                    $i=0;
                    $query=mysqli_query($con,"select * from tree where parent_id='$id' order by position");
                    while( $rr=  mysqli_fetch_array($query)){
                      
                      $pp[$i]=$rr;
                      $i++;
                  }
                  if($i==2){
                      if($pp[0][1]!='blank'){
                       $count_left=countt($pp[0][0],$con);   
                       $count_left++;
//                       echo $connt_left;
                      }else {
                          $count_left=0;                          
                      }
                      if($pp[1][1]!='blank'){
                           $count_right=countt($pp[1][0],$con); 
                           $count_right++;
                      }else{
                          $count_right=0;    
                      }
                     $counttt= $count_left+$count_right;
                     return $counttt;
                  }if($i==0){
                   return 0;   
                  }
                }
                
                
                
                function countbv($id,$con){
                    $i=0;
                    $query=mysqli_query($con,"select * from tree where parent_id='$id' order by position");
                    while( $rr=  mysqli_fetch_array($query)){
                      
                      $pp[$i]=$rr;
                      $i++;
                  }
                  if($i==2){
                      if($pp[0][1]!='blank'){
                       $count_left_bv=countbv($pp[0][0],$con); 
                       $user_left_idd=$pp[0][0];
                       $sql=  mysqli_query($con, "select distributor_bv from distributor_detail where distributor_id='$user_left_idd'");
                       $rowss=  mysqli_fetch_array($sql);
                       $count_left_bv=$count_left_bv+$rowss['distributor_bv'];
//                       echo $connt_left;
                      }else {
                          $count_left_bv=0;                          
                      }
                      if($pp[1][1]!='blank'){
                           $count_right_bv=countbv($pp[1][0],$con); 
                            $user_right_idd=$pp[1][0];
                       $sql=  mysqli_query($con, "select distributor_bv from distributor_detail where distributor_id='$user_right_idd'");
                       $rowss=  mysqli_fetch_array($sql);
                           $count_right_bv=$count_right_bv+$rowss['distributor_bv'];
//                          echo "<script>alert($rowss[distributor_bv])</script>";
                      }else{
                          $count_right_bv=0;    
                      }
                     $counttt= $count_right_bv+$count_left_bv;
                     return $counttt;
                  }if($i==0){
                   return 0;   
                  }
                }
                $user_id=$_SESSION['user'];
                $user_cmpny_id=$conn->get_admin_login_name($con,$user_id);
                $id=$conn->get_admin_dis_id($con,$user_cmpny_id);
                if($id!=1){
                $t_member=countt($id,$con);
                $t_bv=countbv($id,$con); ?>
                
<!--//                echo "total members = $t_member <br><br> total bv = $t_bv";-->
     <div id="all">
<div class="col-sm-3" onclick="change('total')">
    <div class="jumbotron btn-success" style="background-color: yellowgreen;">
    <h3 style="text-align: center;  color: yellow">Total Members</h3>      
    <p style="text-align: center;"><b><?php echo $t_member; ?></b></p>
  </div>
</div>

<div class="col-sm-1">
    
</div>
<div class="col-sm-3" onclick="change('total')">
    <div class="jumbotron btn-success" style="background-color: yellowgreen">
    <h3 style="text-align: center;  color: yellow">Total B. V.</h3>      
    <p style="text-align: center;"><b><?php echo $t_bv; ?></b></p>
  </div>
</div>
 <div class="col-sm-1">
    
</div>  
<?php 
$ress=  mysqli_query($con, "select distributor_bv from distributor_detail where distributor_id='$id'");
                        $rows=  mysqli_fetch_array($ress);
                        $dis_bv=$rows['distributor_bv'];

?>
<div class="col-sm-3">
    <div class="jumbotron btn-success" style="background-color: yellowgreen">
    <h3 style="text-align: center;  color: yellow">Self B. V.</h3>      
    <p style="text-align: center;"><b><?php echo $dis_bv; ?></b></p>
  </div>
</div>
 <div class="col-sm-1">
    
</div>  
<?php 

$left=mysqli_query($con,"select * from tree where parent_id = '$id' order by position");
                   
                  $pp=array();
                  $i=0;
                  $count_left=0;
                  $count_right=0;
                  while( $rr=  mysqli_fetch_array($left)){
                     
                      $pp[$i]=$rr;
                       $i++;
                  }
                  if($i==2){
                      if($pp[0][1]!='blank'){
                          $id=$pp[0][0];
                       $count_left=countt($id,$con); 
                       $count_left++;
                      }else {
                          $count_left=0;                          
                      }
                      if($pp[1][1]!='blank'){
                          $idd=$pp[1][0];
                         $count_right=countt($idd,$con); 
                         $count_right++;
                      }else {
                          $count_right=0;                          
                      }
                  }

?>
<div class="col-sm-5">
    <div class="panel panel-success" style="background-color: yellowgreen">
        <div class="panel-body" style="text-align: center;" ><h4 style="color: yellow;">Total Members</h4></div>
         <table class="table table-bordered" style="margin-top: 0px;">
        <thead>
            <tr>
                <th style="text-align: center;">Left</th>
                <th style="text-align: center;">Right</th>
            </tr>
        </thead>
        <tr style="background-color: whitesmoke;">
                <th style="text-align: center;" onclick="change('left')"><?php echo $count_left; ?></th>
                <th style="text-align: center;" onclick="change('right')"><?php echo $count_right; ?></th>
            </tr>
    </table>
</div>
   
</div>
<div class="col-sm-1"></div>
<?php 
$count_left_bv=0;
                  $count_right_bv=0;
                  
                  if($i==2){
                      if($pp[0][1]!='blank'){
                       $count_left_bv=countbv($pp[0][0],$con); 
                       $user_left_idd=$pp[0][0];
                       $sql=  mysqli_query($con, "select distributor_bv from distributor_detail where distributor_id='$user_left_idd'");
                       $rowss=  mysqli_fetch_array($sql);
                       $count_left_bv=$count_left_bv+$rowss['distributor_bv'];
//                       echo $connt_left;
                      }else {
                          $count_left_bv=0;                          
                      }
                      if($pp[1][1]!='blank'){
                           $count_right_bv=countbv($pp[1][0],$con); 
                            $user_right_idd=$pp[1][0];
                       $sql=  mysqli_query($con, "select distributor_bv from distributor_detail where distributor_id='$user_right_idd'");
                       $rowss=  mysqli_fetch_array($sql);
                           $count_right_bv=$count_right_bv+$rowss['distributor_bv'];
                      }else{
                          $count_right_bv=0;    
                      }
//                     $counttt= $count_right_bv+$count_left_bv;
//                     return $counttt;
                  }?> 
<div class="col-sm-5">
     <div class="panel panel-success" style="background-color: yellowgreen">
        <div class="panel-body" style="text-align: center;" ><h4 style="color: yellow;">Total B.V.</h4></div>
         <table class="table table-bordered" style="margin-top: 0px;">
        <thead>
            <tr>
                <th style="text-align: center;">Left</th>
                <th style="text-align: center;">Right</th>
            </tr>
        </thead>
        <tr style="background-color: whitesmoke;">
                <th style="text-align: center;" onclick="change('left')"><?php echo $count_left_bv; ?></th>
                <th style="text-align: center;" onclick="change('right')"><?php echo $count_right_bv; ?></th>
            </tr>
    </table>
</div>
</div></div>



                
            <?php     }else{
                    $res=  mysqli_query($con, "select * from tree where parent_id= $id");
                    $t_member=0;
                    $t_bv=0;
                    while($row=mysqli_fetch_array($res)){
                        $t_member=$t_member+countt($row['id'],$con);
                        $t_member++;
                        $t_bv=$t_bv+countbv($row['id'],$con);
                        $ress=mysqli_query($con, "select * from distributor_detail where distributor_id='$row[id]'");
                        $rows=  mysqli_fetch_array($ress);
                        $dis_bv=$rows['distributor_bv'];
                        $t_bv=$t_bv+$dis_bv;
                    }
                 ?>
                
<!--//                echo "total members = $t_member <br><br> total bv = $t_bv";-->
<div id="all" >
<div class="col-sm-3" onclick="change('total')">
    <div class="jumbotron btn-success" style="background-color: yellowgreen;">
    <h3 style="text-align: center;  color: yellow">Total Members</h3>      
    <p style="text-align: center;"><b><?php echo $t_member; ?></b></p>
  </div>
</div>

<div class="col-sm-1">
    
</div>
<div class="col-sm-3" onclick="change('total')">
    <div class="jumbotron btn-success" style="background-color: yellowgreen">
    <h3 style="text-align: center;  color: yellow">Total B. V.</h3>      
    <p style="text-align: center;"><b><?php echo $t_bv; ?></b></p>
  </div>
</div>
 <div class="col-sm-1">
    
</div>  
<?php 
$ress=  mysqli_query($con, "select distributor_bv from distributor_detail where distributor_id='$id'");
                        $rows=  mysqli_fetch_array($ress);
                        $dis_bv=$rows['distributor_bv'];

?>
<div class="col-sm-3">
    <div class="jumbotron btn-success" style="background-color: yellowgreen">
    <h3 style="text-align: center;  color: yellow">Self B. V.</h3>      
    <p style="text-align: center;"><b><?php echo $dis_bv; ?></b></p>
  </div>
</div>
 <div class="col-sm-1">
    
</div>  
</div>        
            <?php  
                }
                
                ?>


<style>


</style>
                

<div class="loading">
    <div class="sk-fading-circle">
  <div class="sk-circle1 sk-circle"></div>
  <div class="sk-circle2 sk-circle"></div>
  <div class="sk-circle3 sk-circle"></div>
  <div class="sk-circle4 sk-circle"></div>
  <div class="sk-circle5 sk-circle"></div>
  <div class="sk-circle6 sk-circle"></div>
  <div class="sk-circle7 sk-circle"></div>
  <div class="sk-circle8 sk-circle"></div>
  <div class="sk-circle9 sk-circle"></div>
  <div class="sk-circle10 sk-circle"></div>
  <div class="sk-circle11 sk-circle"></div>
  <div class="sk-circle12 sk-circle"></div>
</div>
</div>


              
<script>
     function change(type){
         $("#all").load("dashboard_detail.php",{"type":type})
            
        }
//        $.blockUI();
//        $(document).ready(function(){
//            $.unblockUI();
//        });

var $loading = $('.loading').hide();
$(document)
  .ajaxStart(function () {
    $loading.show();
    $("#all").css("opacity","0");
    $.blockUI({ message: '' });
  })
  .ajaxStop(function () {
    $loading.hide();
     $("#all").css("opacity","1");
     $.unblockUI();
  });

</script>     
	    </div>
         
       </section>


<!--<script type="text/javascript" src="js/bootstrap.min.js"></script>-->
<script type="text/javascript" src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<div class="offline-ui offline-ui-up"><div class="offline-ui-content"></div><a href="" class="offline-ui-retry"></a>
</div>
</body>
</html>
<?php
 } 
?>