<?php
if(isset($_REQUEST['id']))
{
@include_once '../property/pss_db.php';
@$conn = new DB_con();
@$con = $conn->connection();
	$id=$_REQUEST['id'];
	echo"$id";
	?>
	<div class="well" style="text-align:center;font-size:18px;"><strong><?php echo"$id"; ?></strong></div>
<table cellpadding="0" cellspacing="0" border="0"
					  		class="table table-striped table-bordered editable-datatable">
									<thead>
									<tr>
									    <th>Image</th>
										<th>Image Title</th>
										<th>Image Address</th>
										<th>image Uploade date</th>
										<th>Delete</th>
									</tr>
								</thead>
								<tbody>
								
								<?php
				 $res = $conn->get_website_image_gallery($con,$id);
				 while ($row = mysqli_fetch_array($res)) {
				 $image_id=$row['image_details_id'];
				 ?>
									<tr class="1">
										<td><img src="../<?php echo $row['image_details_path']; ?>" class="imgsize" ></td>
										<td><?php echo $row['image_details_title']; ?></td>
										<td><?php echo $row['image_details_address']; ?></td>
										<td><?php echo $row['image_details_date']; ?></td>
										<td><a class="delete" href="delete_image_details.php?image_id=<?php echo"$image_id"; ?>">Delete</a></td>
									</tr>
				<?php }?>					
								</tbody>

								</table>
<?php
}
?>
			
