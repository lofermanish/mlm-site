<?php
session_start();
if(!isset($_SESSION['user']))
{
	header("Location: index.php");
}
else
{
	
?>
<!DOCTYPE html>
<!-- saved from url=(0038)http://flatter.cloudtub.com/index.html -->
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Dashboard</title>
<meta name="description" content="Flatter - Flat Admin Theme">
<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/layout.css">
<link rel="stylesheet" href="css/style3.css">
<script type="text/javascript" src="js/jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.10.4.custom.min.js"></script>
<style>
.imgsize
{
	height:30px; 
	width:30px;
}
.table-container {
    border:1px solid #ccc;
    border-radius: 3px;
    width:50%;
}
.table-container table {
    width: 100%;
}
.scroll-container{
    max-height: 500px;
   
}
body {
  font-family: Arial, sans-serif;
  background: url(4.jpg);
  background-size: cover;
}

h1 {
  text-align: center;
  font-family: Tahoma, Arial, sans-serif;
  color: orange;
  margin: 100px 0;
}

.box {
  width: 20%;
  margin: 0 auto;
  background: rgba(255,255,255,0.2);
  padding: 35px;
  border: 2px solid #fff;
  border-radius: 20px/50px;
  background-clip: padding-box;
  text-align: center;
}

.button {
  font-size: 1em;
  padding: 10px;
  color: #fff;
  border: 2px solid orange;
  border-radius: 20px/50px;
  text-decoration: none;
  cursor: pointer;
  transition: all 0.3s ease-out;
}
.button:hover {
  background: orange;
}

.overlay {
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  background: rgba(0, 0, 0, 0.7);
  transition: opacity 500ms;
  visibility: hidden;
  opacity: 0;
}
.overlay:target {
  visibility: visible;
  opacity: 1;
}

.popup {
  margin: 70px auto;
  padding: 20px;
  background: #fff;
  border-radius: 5px;
  width: 30%;
  position: relative;
  transition: all 5s ease-in-out;
}

.popup h2 {
  margin-top: 0;
  color: #333;
  font-family: Tahoma, Arial, sans-serif;
}
.popup .close {
  position: absolute;
  top: 20px;
  right: 30px;
  transition: all 200ms;
  font-size: 30px;
  font-weight: bold;
  text-decoration: none;
  color: #333;
}
.popup .close:hover {
  color: orange;
}
.popup .content {
  max-height: 30%;
  
}



</style>

</head>
<body id="body">

		<!-- Header -->
		<?php include './header.php'; ?>

       <?php include './left-menu.php'; 
		   $msg="";
		   ?>
		<!-- Header -->
		
<section id="main-wrapper">
		<h3 class="subtitle">Client Details</h3>
          <hr>

		  <div class="row">
		  <?php echo"$msg"; ?>
			  <div class="col-md-12">
				  	<div class="panel panel-default">
					  <div class="panel-heading">
					    <h3 class="panel-title"><strong>Distributer Pre Details</strong></h3> 
					  </div>

					  <div class="panel-body">
					  <div class="scroll-container" style="overflow: auto; max-size:350px;">
					  		<table cellpadding="0" cellspacing="0" border="0"
					  		class="table-striped table table-bordered editable-datatable">
									<thead>
									<tr>
									    <th>S.No.</th>
										<th>Image</th>
									    <th>Distributor Company Id</th>
									    <th>Distributor Name</th>
										<th>Distributor Fathers name</th>
										<th>Distributor Dob</th>
										<th>Distributor Gender</th>
										<th>Distributor Marriage Status</th>
										<th>Distributor Nominee name</th>
										<th>Distributor relationship</th>
										<th>Distributor Current Address</th>
										<th>Distributor permanent address</th>
										<th>Distributor state</th>
										<th>Distributor city</th>
										<th>Distributor district</th>
										<th>Distributor pincode</th>
										<th>Distributor mobile No</th>
										<th>Distributor phone No.</th>
										<th>Distributor email</th>
										<th>Distributor pan</th>
										<th>Distributor id proof</th>
										<th>Distributor Address proof</th>
								
										<th>Distributor payment mode</th>
										<th>Distributor bank</th>
										<th>Distributor bank branch</th>
										<th>Distributor amount</th>
										<th>Distributor amount word</th>
										<th>Distributor account IFSC code</th>
										<th>Distributor account no.</th>
										<th>Distributor account name	</th>
										<th>Distributor qualification</th>
										<th>Distributor bussiness</th>
										<th>Distributor employee name</th>
										<th>Distributor business no.</th>
										<th>Distributor annual income</th>
										<th>Distributor ref1</th>
										<th>Distributor ref2</th>
										<th>Distributor ref3</th>
										<th>Distributor ref4</th>
										<th>Distributor passport no.</th>
										<th>Distributor placement</th>
										<th>Distributor placement id</th>
										<th>Distributor direct distributer id</th>
										<th>Distributor coupan</th>
										<th>Distributor coupan no.</th>
										<th>Distributor Shagun</th>
										<th>Distributor defence</th>
										<th>Distributor bv</th>
										<th>Distributor created date</th>
										<th>Distributor user unique code</th>
										<th>Action</th>
									</tr>
								</thead>
								<tbody>
								<?php
				 $res = $conn->get_admin_distributor_pre_form_details($con);
				 $count=0;
				 while ($row = mysqli_fetch_array($res)) {
				 $distributor_id=$row['distributor_id'];
				// echo"$distributor_id";
				 $count=$count+1;
				 ?>
									<tr class="1">
									    <td><?php echo $count ?></td>
										<td><img src="../<?php echo $row['distributor_image_path']; ?>" class="imgsize" ></td>
										<td><?php echo $row['distributor_company_id']?></td>
										<td><?php echo $row['distributor_name']; ?></td>
										<td><?php echo $row['distributor_father_name']; ?></td>
										<td><?php echo $row['distributor_dob']; ?></td>
										<td><?php echo $row['distributor_gender']; ?></td>
										<td><?php echo $row['distributor_m_status']; ?></td>
										<td><?php echo $row['distributor_nominee_name']; ?></td>
										<td><?php echo $row['distributor_relationship']; ?></td>
										<td><?php echo $row['distributor_current_address']; ?></td>
										<td><?php echo $row['distributor_permanent_address']; ?></td>
										<td><?php echo $row['distributor_state']; ?></td>
										<td><?php echo $row['distributor_city']; ?></td>
										<td><?php echo $row['distributor_district']; ?></td>
										<td><?php echo $row['distributor_pincode']; ?></td>
										<td><?php echo $row['distributor_mobile']; ?></td>
										<td><?php echo $row['distributor_phone']; ?></td>
										<td><?php echo $row['distributor_email']; ?></td>
										<td><?php echo $row['distributor_pan']; ?></td>
										<td><?php echo $row['distributor_id_proof']; ?></td>
										<td><?php echo $row['distributor_add_proof']; ?></td>
								
										<td><?php echo $row['distributor_payment_mode']; ?></td>
										<td><?php echo $row['distributor_bank']; ?></td>
										<td><?php echo $row['distributor_bank_branch']; ?></td>
										<td><?php echo $row['distributor_amount']; ?></td>
										<td><?php echo $row['distributor_amoun_word']; ?></td>
										<td><?php echo $row['distributor_account_ifsc']; ?></td>
										
										
										<td><?php echo $row['distributor_account_acc_no']; ?></td>
										<td><?php echo $row['distributor_account_acc_name']; ?></td>
										<td><?php echo $row['distributor_qualification']; ?></td>
										<td><?php echo $row['distributor_business']; ?></td>
										<td><?php echo $row['distributor_name_employer']; ?></td>
										<td><?php echo $row['distributor_business_no']; ?></td>
										<td><?php echo $row['distributor_anual_income']; ?></td>
										<td><?php echo $row['distributor_ref1']; ?></td>
										<td><?php echo $row['distributor_ref2']; ?></td>
										<td><?php echo $row['distributor_ref3']; ?></td>
										<td><?php echo $row['distributor_ref4']; ?></td>
										<td><?php echo $row['distributor_passport_no']; ?></td>
										<td><?php echo $row['distributor_placement']; ?></td>
										<td><?php echo $row['distributor_distributor_id']; ?></td>
										<td><?php echo $row['distributor_direct_distributor_id']; ?></td>
										<td><?php echo $row['distributor_coupon']; ?></td>
										<td><?php echo $row['distributor_coupon_number']; ?></td>
										<td><?php echo $row['distributor_shagun']; ?></td>
										<td><?php echo $row['distributor_defense']; ?></td>
										<td><?php echo $row['distributor_bv']; ?></td>
										<td><?php echo $row['distributor_creation_date']; ?></td>
										<td><?php echo $row['distributor_user_unique_code']; ?></td>
<td><a href="#" class="btn btn-danger" data-toggle="modal" data-target="#myModal" onclick="distributor_detail('<?php echo $distributor_id; ?>')">Unpaid</button></td>
									</tr>
				<?php }?>					
								</tbody>

								</table>
</div>
					  </div>
					</div>
				</div>
				
</div>

</section>

<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        
        <h2 class="modal-title">Payment Details</h2>
      </div>
      <div class="modal-body" id="distributor_value">
 

	</div>

</div>

      </div>
      
    </div>

<<<<<<< .mine
 
||||||| .r62
 <?php
if (isset($_POST['paid']))
{
	$payment_mode=$_POST['payment_mode'];
	$distributor_bank=$_POST['distributor_bank'];
	$distributor_bank_branch=$_POST['distributor_bank_branch'];
	$amount=$_POST['amount'];
	$amount_in_words=$_POST['amount_in_words'];
	$coupon_no=$_POST['coupon_no'];
	$product_details=$_POST['product_details'];
$project_shagun_city=$_POST['project_shagun_city'];	
$project_defense_enclave=$_POST['project_defense_enclave'];

 $res_payment = $conn->get_admin_insert_distributer_payment_details($con,$payment_mode,$distributor_bank,$distributor_bank_branch,$amount,$amount_in_words,$coupon_no,$product_details,$project_shagun_city,$project_defense_enclave,$distributor_id);
if($res_payment)
{
	echo "success";
}
else
	echo "error";
 }
	
 
 
 ?>

=======
 <?php
if (isset($_POST['paid']))
{
	$distributor_id1=$_POST['distri_id'];
	$payment_mode=$_POST['payment_mode'];
	$distributor_bank=$_POST['distributor_bank'];
	$distributor_bank_branch=$_POST['distributor_bank_branch'];
	$amount=$_POST['amount'];
	$amount_in_words=$_POST['amount_in_words'];
	$coupon_no=$_POST['coupon_no'];
	$product_details=$_POST['product_details'];
$project_shagun_city=$_POST['project_shagun_city'];	
$project_defense_enclave=$_POST['project_defense_enclave'];

 $res_payment = $conn->get_admin_insert_distributer_payment_details($con,$payment_mode,$distributor_bank,$distributor_bank_branch,$amount,$amount_in_words,$coupon_no,$product_details,$project_shagun_city,$project_defense_enclave,$distributor_id1);
if($res_payment)
{
	
	//$msg= "<div class='alert alert-success'><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a><strong>Success!</strong>Payment successful.</div>"; 
	?>
	<script>alert("Payment successful");</script>
	<?php
}
else
{
	//$msg= "<div class='alert alert-danger'><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a><strong>Success!</strong>Payment successful.</div>";
	?>
	<script>alert("Payment Not successful");</script>
	<?php
 }
}
 ?>

>>>>>>> .r64
<script>
   function distributor_detail(dist_id){

        $("#distributor_value").load('get-data.php', {"distributor_id": dist_id});
		//alert('welcome icon');
    }
</script>
		

<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<div class="offline-ui offline-ui-up"><div class="offline-ui-content"></div><a href="" class="offline-ui-retry"></a>
</div>
</body>
</html>
<?php
 } 
?>