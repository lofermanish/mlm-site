<?php
session_start();
if(!isset($_SESSION['user']))
{
	header("Location: index.php");
}
else
{
?>
<!DOCTYPE html>
<!-- saved from url=(0038)http://flatter.cloudtub.com/index.html -->
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Dashboard</title>
<meta name="description" content="Flatter - Flat Admin Theme">
<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/layout.css">
<link rel="stylesheet" href="css/style3.css">
<script type="text/javascript" src="js/jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.10.4.custom.min.js"></script>
<style>
.imgsize
{
	height:30px; 
	width:30px;
}
</style>
</head>
<body id="body">

		<!-- Header -->
		<?php include './header.php'; ?>

       <?php include './left-menu.php'; ?>
		<!-- Header -->
                
                
                
                
                
<section id="main-wrapper">
    <?php 
                $p=0;
                $q=0;
                if(isset($_POST['cr_login'])){
                    
                    $old_pass=$_POST['old_password'];
                    $password=$_POST['user_password'];
                    $con_pass=$_POST['user_cpassword'];
                    $crr_user=$_SESSION['user'];
                    $old_pass_db=$conn->get_admin_password($con,$crr_user);
                    $old_pass=md5($old_pass);
                    if($old_pass==$old_pass_db){
                    
                            if($password==$con_pass){
                                $password=  md5($password);
                                $res=$conn->update_admin_login_password($con,$crr_user,$password);
                                if($res){
                                    $p++;
                                   echo "<script>$(document).ready(function(){ $('#msg_su').html('<strong>Success!</strong> Password Updated Successfully'); });</script>";
                                }else{
                                    echo "Failed";
                                    $q++;
                                }
                            }else{
                                echo "<script>$(document).ready(function(){ $('#msg').html('<strong>Error!</strong> password and confirm password does not matched'); });</script>";
                            $q++;
                                
                            }
                        
                    }else{
                        echo "<script>$(document).ready(function(){ $('#msg').html('<strong>Error!</strong> Old Password is incorrect.'); });</script>";
                    $q++;
                        
                    }
                }
                ?>
    <script>
   
    
    function match(){
        pass=$('#user_password').val();
        cpass=$('#user_cpassword').val();
        if(pass!=cpass){
            $('#con_pass').text("password and confirm password does not match");
            $('#con_pass').css("color","red");
        }else{
            $('#con_pass').text("OK");
             $('#con_pass').css("color","green");
        }
    }
    $(document).ready(function(){
        $('form').submit(function(event){
            data=$("#con_pass").text();
            if(data!="OK"){
                event.preventDefault();
            }
        });
    });
    </script>
       <?php if(isset($_POST['cr_login'])){ if($q>0){ ?>
       <div class="alert alert-danger" id="msg">
  
       </div><?php } if($p>0){ ?>
            <div class="alert alert-success" id="msg_su">
  
       </div>
       <?php } } ?>
		<h3 class="subtitle">Change Password</h3>
          <hr>

		  <div class="row">
			  <div class="col-md-12">
                              <form action="#" method="post">
                                  
<!--                             <div class="col-md-6" style="margin-top:15px;margin-bottom:5px;"><label>User Name(Company Id)</label><input type="text" name="user_name" class="form-control" id="user_name" placeholder="User Name">
                              </div>-->
                              <div class="col-md-6" style="margin-top:15px;margin-bottom:5px;"><label>Old Password</label><input type="password" name="old_password" class="form-control" id="old_password" placeholder="Password" >
                              </div>
                              <div class="col-md-6" style="margin-top:15px;margin-bottom:5px;"><label>New Password</label><input type="password" name="user_password" class="form-control" id="user_password" placeholder="Password" >
                              </div>
                                  <div class="col-md-6" style="margin-top:15px;margin-bottom:5px;"><label>Confirm Password </label><span id="con_pass" style="float:right;"></span><input type="password" name="user_cpassword" class="form-control" id="user_cpassword" placeholder="Confirm Password" onkeyup="match()" >
                              </div>
                                  <div class="col-md-6" style="margin-top:15px;margin-bottom:5px;"><br>
                                      <input type="submit" name="cr_login"  value="Update" class="btn btn-success" style="float:right">
                                  </div>
                                  
                              </form>	
                          </div>
				
</div>

</section>


<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<div class="offline-ui offline-ui-up"><div class="offline-ui-content"></div><a href="" class="offline-ui-retry"></a>
</div>
</body>
</html>
<?php
 } 
?>