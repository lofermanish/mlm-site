
<?php 
	
		if(isset($_POST['btn-press']))
           {
	   @include_once '../property/pss_db.php';
@$conn = new DB_con();
@$con = $conn->connection();
	   $project_menu=$_REQUEST['menu_name'];
	   $pmenu_id=$_REQUEST['pmenu_id'];
	  copy("../page.php","../$project_menu.php");
	  // echo"123    $achiever_product";
	  // $res = $conn->insert_admin_achiever_product($con,$achiever_product,$type_achiever_product,$date_time);
	   $res = $conn->insert_admin_website_manu($con,$project_menu,"$project_menu.php",$pmenu_id,$project_menu);	
	   if($res)
	       {
	  echo "<script>
       alert('menu created successfully');
       window.location.href='add-menu.php';
      </script>";
		   }
           }
	?>