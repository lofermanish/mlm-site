<?php
$page = 1;
include_once '../property/pss_db.php';
$conn = new DB_con();
$con = $conn->connection();
//include_once 'property/function_list.php';
//include_once 'property/default_values.properties';
$functions = new functions();
?>

<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/r/bs-3.3.5/jq-2.1.4,dt-1.10.8/datatables.min.css"/>
 
		<!--<script type="text/javascript" src="https://cdn.datatables.net/r/bs-3.3.5/jqc-1.11.3,dt-1.10.8/datatables.min.js"></script>-->
		  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/1.2.1/css/buttons.dataTables.min.css"/>
 
<!--		<script type="text/javascript" src="https://cdn.datatables.net/r/bs-3.3.5/jqc-1.11.3,dt-1.10.8/datatables.min.js"></script>
                 <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.1/js/dataTables.buttons.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.1/js/buttons.flash.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js"></script>
        <script type="text/javascript" src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/pdfmake.min.js"></script>
        <script type="text/javascript" src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/vfs_fonts.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.1/js/buttons.html5.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.1/js/buttons.print.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.1/js/buttons.colVis.min.js"></script>
         <script type="text/javascript" src="js/jquery-easing.js"></script>-->
		<script type="text/javascript" charset="utf-8">
			$(document).ready(function() {
				$('.example').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'pageLength',
            {
                extend: 'print',
                autoPrint: false,
                title: 'Report',
                exportOptions: {
                    columns: ':visible'
                }
            },{
                extend: 'pdf',
                title: 'Report',
                exportOptions: {
                    columns: ':visible'
                }
            },{
                extend: 'excel',
                title: 'Report',
                exportOptions: {
                    columns: ':visible'
                }
            },{
                extend: 'csv',
                title: 'Report',
                exportOptions: {
                    columns: ':visible'
                }
            },{
                extend: 'copy',
                exportOptions: {
                    columns: ':visible'
                }
            },
            'colvis'
        ]
    },
           {
        dom: 'Bfrtip',
        lengthMenu: [
            [ 10, 25, 50, -1 ],
            [ '10 rows', '25 rows', '50 rows', 'Show all' ]
        ]
    } ,
    {
        dom: 'Bfrtip',
        buttons: [
            {
                extend: 'collection',
                text: 'Table control',
                buttons: [
                    'colvis'
                ]
            }
        ]
    },{
        dom: 'Bfrtip',
        buttons: [
            {
                extend: 'print',
                exportOptions: {
                    columns: ':visible'
                }
            },
            'colvis'
        ]} 
                );
			} );
                        
                        
                       
		</script>
                <script type="text/javascript">
	// For demo to fit into DataTables site builder...
	$('.example')
		.removeClass( 'display' )
		.addClass('table table-striped table-bordered');
</script>

<div class="row" style="padding-right: 30px;padding-left: 30px;">
<div class="col-sm-12">     <table text-align="center" class="table table-bordered display example" id="example">
		                                   <thead> 
										      <tr>
                                                  <th rowspan="2" ><center>S.No.</center></th>
                                                  <th rowspan="2"><center>Name</center></th>
                                                  <th rowspan="2"><center>Company Id</center></th>
                                                  <th rowspan="2">Total Left B V</th>
                                                  <th rowspan="2">Total Right B V</th>
												  <th colspan="4"><center> Working Group</center></th>
												  <th colspan="2"><center> Reward</center></th>												  
												  <th rowspan="2"><center>Position</center></th>
												  <th rowspan="2"><center>Pay</center></th> 
												  </tr>
												 <tr>
												 
												 <th>Remaining Reward Amount</th>
												 <th>10%</th>
												 <th>5%</th>
												 <th>Payable Amount</th>                                          
   											     <th>Reward Commodity</th> 
                                                 <th>Reward Amount</th>
										     </tr>
									  </thead> 
									  
<?php

if(isset($_REQUEST['paid_reward_type']))
{
	
      $from=$_REQUEST['from'];
        $to=$_REQUEST['to'];
}
$ii=1;
 $res111 = $conn->date_wise_payment($con,$from,$to);
 while ($row = mysqli_fetch_assoc($res111)) {
					 ?>

<tr>
        <td><?php echo $ii++; ?></td>
		 <td><?php echo $row['distributor_name']; ?></td>
        <td><?php echo $row['distributor_company_id']; ?></td>
         <td><?php echo $count_left_bv=$row['count_left_bv']; ?></td>
       <td><?php echo $count_right_bv=$row['count_right_bv']; ?></td>      
<td>
                                               <?php 
										  
$paid_res=mysqli_query($con,"select sum(transaction_amount),service_tax from transaction where transaction_type='money dispatched' and transaction_distributor_id='$row[distributor_company_id]'");
        
        while($paid_row=mysqli_fetch_array($paid_res))
		{   
	
		$paid_row1=$paid_row['sum(transaction_amount)'];
$paid_row2=$paid_row['service_tax'];		
										  if($count_left_bv<$count_right_bv){
											  
											  ?>
                                              <?php echo $a=($count_left_bv*20000)-($paid_row1+$paid_row2); ?>
                                          <?php
										  }
										  else{
											   ?>
                                              <?php echo $a=($count_right_bv*20000)-($paid_row1+$paid_row2); ?>
                                          <?php
		}}
										  ?>   
                                          </td>
										   <td><?php echo $b=$a*0.1; ?></td> 
										   <td><?php echo $c=$a*0.05; ?></td>
										  <td><?php echo $a-($b+$c); ?></td>
										  <?php if($count_left_bv<$count_right_bv){
											  
											  ?>
                                              <?php  $bv=$count_left_bv; ?>
                                          <?php
										  }
										  else{
											   ?>
                                              <?php $bv=$count_right_bv; ?>
                                          <?php
		}
										  ?>
                                       										  <?php 
										  
									$paid_res=mysqli_query($con,"select payment_type_commodity,payment_type_price,payment_type_position FROM `payment_type` where payment_type_to=(SELECT max(payment_type_to) FROM `payment_type` WHERE payment_type_type='reward' and  payment_type_to<=$bv)");
        
									$paid_row=mysqli_fetch_assoc($paid_res);
		?>
		
	 
										  
                                         
										  
                                          <td>
                                              <?php echo $commodity=$paid_row['payment_type_commodity']; ?>
                                       </td> 
                                          <td>
                                            <?php  echo $paid_row['payment_type_price']; ?>
                                          </td>
										  
										 <td>
										 <?php echo $paid_row['payment_type_position']; ?>
										 
										 </td>
										  <td>
										  
										   <?php if($a==""){
											   echo "";
										   }else{
											   $fu="dfe_fd@><";
                                              											   
											   ?>
										  <a href="money_dispatched2.php?jk=<?php echo base64_encode($row['distributor_company_id'].$fu); ?>" class="btn btn-success">Pay</a><?php } ?>
										  </td>
                                      </tr>
	
	
   <?php 
   }

?>
</table>				 