<?php	
session_start();
if(!isset($_SESSION['user_id']))
{
	header("Location: customer-zone.php");
}
else
{
include_once 'property/pss_db.php';
                    $conn = new DB_con();
                    $con = $conn->connection();
                    $functions = new functions();
 $applicant_id=$_SESSION['user_id'];
if(isset($_REQUEST['icon_id']))
{
$transation_id=$_REQUEST['icon_id'];
//echo"$transation_id <br> $applicant_id";
?>
<div class="container">
<div class="col-sm-12 text-right">
	<br>
<a href="logout.php?logout" class="btn btn-danger"><i class="fa fa-share"></i> Logout</a>
<a href="property_summary.php" class="btn btn-success"> Back</a>	
	</div>

  <div class="panel-group">
    <div class="panel panel-danger" style="margin-top:100px;">
      <div class="panel-heading"><h2><strong>Property Payment Details</strong></h2></div>
      <div class="panel-body">
		<div class="row table-row">
							<table class="table table-striped">
						      <thead>
						        <tr>
						          <th>S.No.</th>
						          <th>Client Name</th>
								  <th>Payment Date</th>
						          <th>Ploat Number</th>
						          <th>Amount Paid</th>
						          <th class="text-right">Total Amount</th>
						        </tr>
						      </thead>
						      <tbody>
							  <?php
							   $client_payment=$conn->get_admin_payment_details($con,$applicant_id,$transation_id);

        $i=0;
       $payment_detail_row=mysqli_fetch_array($client_payment) 
	      ?>
			
						        <tr>
						          <td><?php echo ++$i; ?></td>
						          <td><?php echo $payment_detail_row['applicant_name'];  ?></td>
								  <td><?php echo $payment_detail_row['transaction_date'];  ?></td>
						          <td><?php echo $payment_detail_row['plot_price_details_plot_no']; ?></td>
						          <td><?php echo $payment_detail_row['transaction_amount']; ?></td>
						          <td class="text-right"><?php echo $payment_detail_row['applicant_fund_detail']; ?></td>
						        </tr>
						       </tbody>
						    </table>
							<?php
$pay_amt=$payment_detail_row['transaction_amount'];
           $total_amt=$payment_detail_row['applicant_fund_detail'];
		   $net_balance=$total_amt-$pay_amt;
		  // echo"$net_balance";
			?>
		</div>
        <div class="row">
						
						<div class="col-xs-6 text-right pull-right invoice-total">					          
						          <h5>Total : <span class="text-success"><?php echo $net_balance ?> </span></p>
						</div>
						</div>
		  
	 </div>
	 
    </div>
	<br>
	      <div class="col-xs-6 margintop pull-right invoice-total">
							<button class="btn btn-success"  onclick="myFunction()"><i class="fa fa-print"></i> Print Receipt</button>
							
						</div>
  </div>
</div>
       
        

<script>
function myFunction() {
    window.print();
}
</script>

          </section>



<?php
}
}
?>