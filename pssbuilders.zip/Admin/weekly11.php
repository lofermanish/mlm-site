 <?php
 session_start();

$page = 1;
include_once '../property/pss_db.php';
$conn = new DB_con();
$con = $conn->connection();
//include_once 'property/function_list.php';
//include_once 'property/default_values.properties';
$functions = new functions();
//include_once 'db.php';

if(!isset($_SESSION['user']))
{
  header("Location: index.php");
}
else
{
?><?php 



if(isset($_REQUEST['jk']))

{
      $jk=$_REQUEST['jk'];  

       $get_date=mysqli_query($con,"select distributor_creation_date from distributor_detail where distributor_company_id='$jk'");
    $distributor_date= mysqli_fetch_array($get_date);
    $begin1=$distributor_date['distributor_creation_date'];
$begin = new DateTime("$begin1");
$end = new DateTime();


                
                function countt($id,$con){
                    $i=0;
                    $query=mysqli_query($con,"select * from tree where parent_id='$id' order by position");
                    while( $rr=  mysqli_fetch_array($query)){
                      
                      $pp[$i]=$rr;
                      $i++;
                  }
                  if($i==2){
                      if($pp[0][1]!='blank'){
                       $count_left=countt($pp[0][0],$con);   
                       $count_left++;
//                       echo $connt_left;
                      }else {
                          $count_left=0;                          
                      }
                      if($pp[1][1]!='blank'){
                           $count_right=countt($pp[1][0],$con); 
                           $count_right++;
                      }else{
                          $count_right=0;    
                      }
                     $counttt= $count_left+$count_right;
                     return $counttt;
                  }if($i==0){
                   return 0;   
                  }
                }
                
                
                
                function countbv($id,$con){
                    $i=0;
                    $query=mysqli_query($con,"select * from tree where parent_id='$id' order by position");
                    while( $rr=  mysqli_fetch_array($query)){
                      
                      $pp[$i]=$rr;
                      $i++;
                  }
                  if($i==2){
                      if($pp[0][1]!='blank'){
                       $count_left_bv=countbv($pp[0][0],$con); 
                       $user_left_idd=$pp[0][0];
                       $sql=  mysqli_query($con, "select distributor_bv from (SELECT distributor_company_id,distributor_direct_distributor_id,distributor_id, distributor_name, distributor_distributor_id, sum(bv_code_value) as distributor_bv,bv_code_used_date FROM bv_code, distributor_detail where bv_code_used_by=distributor_id and bv_code_used_date >='$GLOBALS[from]' and bv_code_used_date <'$GLOBALS[to]' group by distributor_company_id) as d where distributor_id='$user_left_idd'");
                       $rowss=  mysqli_fetch_array($sql);
                       $count_left_bv=$count_left_bv+$rowss['distributor_bv'];
//                       echo $connt_left;
                      }else {
                          $count_left_bv=0;                          
                      }
                      if($pp[1][1]!='blank'){
                           $count_right_bv=countbv($pp[1][0],$con); 
                            $user_right_idd=$pp[1][0];
                       $sql=  mysqli_query($con, "select distributor_bv from (SELECT distributor_company_id,distributor_direct_distributor_id,distributor_id, distributor_name, distributor_distributor_id, sum(bv_code_value) as distributor_bv,bv_code_used_date FROM bv_code, distributor_detail where bv_code_used_by=distributor_id and bv_code_used_date >='$GLOBALS[from]' and bv_code_used_date <'$GLOBALS[to]' group by distributor_company_id) as d where distributor_id='$user_right_idd'");
                       $rowss=  mysqli_fetch_array($sql);
                           $count_right_bv=$count_right_bv+$rowss['distributor_bv'];
//                          echo "<script>alert($rowss[distributor_bv])</script>";
                      }else{
                          $count_right_bv=0;    
                      }
                     $counttt= $count_right_bv+$count_left_bv;
                     return $counttt;
                  }if($i==0){
                   return 0;   
                  }
                }




                $id=$conn->get_admin_dis_id($con,$jk);
                if($id!=1){
                $t_member=countt($id,$con);
                $t_bv=countbv($id,$con); ?>

<?php 

for($next_week1 = $begin; $begin <= $end; $next_week1->modify('+6 days'))
{
   $to=$next_week=$next_week1->format("Y-m-d");
   $from=date('Y-m-d', strtotime($to.'-6 days'));
  
$left=mysqli_query($con,"select * from tree where parent_id = '$id' order by position");
                   
                  $pp=array();
                  $i=0;
                  $count_left=0;
                  $count_right=0;
                  while( $rr=  mysqli_fetch_array($left)){
                     
                      $pp[$i]=$rr;
                       $i++;
                  }
                  if($i==2){
                      if($pp[0][1]!='blank'){
                          $id=$pp[0][0];
                       $count_left=countt($id,$con); 
                       $count_left++;
                      }else {
                          $count_left=0;                          
                      }
                      if($pp[1][1]!='blank'){
                          $idd=$pp[1][0];
                         $count_right=countt($idd,$con); 
                         $count_right++;
                      }else {
                          $count_right=0;                          
                      }
                  }

?>


<?php 
$count_left_bv=0;
                  $count_right_bv=0;
                  
                  if($i==2){
                      if($pp[0][1]!='blank'){
                       $count_left_bv=countbv($pp[0][0],$con); 
                       $user_left_idd=$pp[0][0];
                       $sql=  mysqli_query($con, "select distributor_bv from (SELECT distributor_company_id,distributor_direct_distributor_id,distributor_id, distributor_name, distributor_distributor_id, sum(bv_code_value) as distributor_bv,bv_code_used_date FROM bv_code, distributor_detail where bv_code_used_by=distributor_id and bv_code_used_date >='$GLOBALS[from]' and bv_code_used_date <'$GLOBALS[to]' group by distributor_company_id) as d where distributor_id='$user_left_idd'");
                       $rowss=  mysqli_fetch_array($sql);
                       $count_left_bv=$count_left_bv+$rowss['distributor_bv'];
//                       echo $connt_left;
                      }else {
                          $count_left_bv=0;                          
                      }
                      if($pp[1][1]!='blank'){
                           $count_right_bv=countbv($pp[1][0],$con); 
                            $user_right_idd=$pp[1][0];
                       $sql=  mysqli_query($con, "select distributor_bv from (SELECT distributor_company_id,distributor_direct_distributor_id,distributor_id, distributor_name, distributor_distributor_id, sum(bv_code_value) as distributor_bv,bv_code_used_date FROM bv_code, distributor_detail where bv_code_used_by=distributor_id and bv_code_used_date >='$GLOBALS[from]' and bv_code_used_date <'$GLOBALS[to]' group by distributor_company_id) as d where distributor_id='$user_right_idd'");
                       $rowss=  mysqli_fetch_array($sql);
                           $count_right_bv=$count_right_bv+$rowss['distributor_bv'];
                      }else{
                          $count_right_bv=0;    
                      }
//                     $counttt= $count_right_bv+$count_left_bv;
//                     return $counttt;
                  }?> 
<div class="col-sm-5">
     <div class="panel panel-success" style="background-color: yellowgreen">
        <div class="panel-body" style="text-align: center;" ><h4 style="color: yellow;">Total B.V.</h4></div>
         <table class="table table-bordered" style="margin-top: 0px;">
        <thead>
            <tr>
                <th style="text-align: center;">Left</th>
                <th style="text-align: center;">Right</th>
            </tr>
        </thead>
        <tr style="background-color: whitesmoke;">
                <th style="text-align: center;" onclick="change('left')"><?php echo $count_left_bv; ?></th>
                <th style="text-align: center;" onclick="change('right')"><?php echo $count_right_bv; ?></th>
            </tr>
    </table>
</div>
</div></div>

<?php }
}}
}
?> 