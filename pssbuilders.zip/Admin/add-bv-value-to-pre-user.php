<?php
session_start();
if(!isset($_SESSION['user']))
{
	header("Location: index.php");
}
else
{
?>
<!DOCTYPE html>
<!-- saved from url=(0038)http://flatter.cloudtub.com/index.html -->
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Dashboard</title>
<meta name="description" content="Flatter - Flat Admin Theme">
<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/layout.css">
<link rel="stylesheet" href="css/style3.css">
<script type="text/javascript" src="js/jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.10.4.custom.min.js"></script>
<style>
.imgsize
{
	height:30px; 
	width:30px;
}
</style>
</head>
<body id="body">

		<!-- Header -->
		<?php include './header.php'; ?>

       <?php include './left-menu.php'; ?>
		<!-- Header -->
                
                
                
                
                
<section id="main-wrapper">
    <?php 
                $p=0;
                $q=0;
                if(isset($_POST['save_bv_code'])){
//                    $dis_id=$_POST['dis_id'];
//                    $user_bv=$_POST['user_bv'];
//                    if($dis_id!=""){
//                                $res=$conn->update_admin_distributor_bv($con,$dis_id,$user_bv);
//                                if($res){ $p++;
//                                   echo "<script>$(document).ready(function(){ $('#msg_su').html('<strong>Success!</strong> B.V. Alloted'); });</script>";
//                                }else{ $q++;
//                                    echo "<script>$(document).ready(function(){ $('#msg').html('<strong>Error!</strong>Sql Error'); });</script>";
//                                }
//                            
//                    }else{ $q++;
//                        echo "<script>$(document).ready(function(){ $('#msg').html('<strong>Error!</strong> Please select distributor.'); });</script>";
//                    }
                    
                    
                    $bv_code=$_POST['user_bv_code'];
                     $user_id=$_SESSION['user'];
//                     echo $bv_code;
//        $user_cmpny_id=$conn->get_admin_login_name($con,$user_id);
                     $user_cmpny_id=$_POST['user_id'];
                     $user_id= $conn->get_admin_dis_id($con,$user_cmpny_id);
                    $res=$conn->get_admin_bv_code($con,$bv_code);
                    if($res){
                        $row=  mysqli_fetch_array($res);
                        $bv_value=$row['bv_code_value'];
                        $bv_use=$row['bv_code_use'];
                         $bv_code_number=$row['bv_code_number'];
                        if($bv_use==0){
                            if($bv_code===$bv_code_number){
                                $res=$conn->get_admin_distributor_detail_by_cmpny_id($con,$user_cmpny_id);
                                $rows=mysqli_fetch_array($res);
                                $bv_old_value=$rows['distributor_bv'];
                                $bv_new_value=$bv_old_value+$bv_value;
                                echo "<script>alert($bv_new_value+$user_cmpny_id);</script>";
                        $res=$conn->update_admin_distributor_bv($con,$user_cmpny_id,$bv_new_value);
                        if($res){
                            $bv_code_use=1;
                            $res=$conn->update_admin_bv_code($con,$bv_code_use,$user_id,$date_time,$bv_code);
                            if($res){
                              $p++;
							  
							  			  
//                echo "successful";

$dis_company_id=$user_cmpny_id;
$res1=$conn->update_pre_distributor($con,$dis_company_id);	
$dis_sponsor_id=$rows['distributor_distributor_id'];
$dis_placement_req=$rows['distributor_placement'];
$id_parent=$conn->get_admin_dis_id($con,$dis_sponsor_id);
            $count=$conn->get_admin_num_dis_spon_id($con,$id_parent);
			$dis_name=$rows['distributor_name'];
            if($dis_sponsor_id=='pss100000'){

                $id1=$conn->get_admin_dis_id($con,$dis_company_id);
                 $id2=$conn->get_admin_dis_id($con,$dis_sponsor_id);
                 $res=$conn->insert_admin_dis_in_tree($con,$id1,$dis_name,$id2,"");
              
			}else{
            if($count==2 || $count==0){
               $status=$conn->get_admin_position_dis_spon_id($con,$id_parent,$dis_placement_req);
               if(($count==2 && $status=='blank') || $count==0){
				   $id1=$conn->get_admin_dis_id($con,$dis_company_id);
                 $id2=$conn->get_admin_dis_id($con,$dis_sponsor_id);
                
                 if($dis_placement_req=="right" && $count==2){
                     
                  $res=$conn->update_admin_tree_by_parent($con,$id1,$id2,$dis_name);  
                }
                if($dis_placement_req=="left" && $count==2){
                  $res=$conn->update_admin_tree_by_parent($con,$id1,$id2,$dis_name);  
                }
                if($dis_placement_req=="right" && $count==0){
                    $res=$conn->insert_admin_dis_in_tree($con,$id1,$dis_name,$id2,"right");
                    $b_id=$id1.'001';
                  $res=$conn->insert_admin_dis_in_tree($con,$b_id,"blank",$id2,"left");  
                }
                if($dis_placement_req=="left" && $count==0){
                  $res=$conn->insert_admin_dis_in_tree($con,$id1,$dis_name,$id2,"left");
                    $b_id=$id1.'002';
                  $res=$conn->insert_admin_dis_in_tree($con,$b_id,"blank",$id2,"right");  
                }
                
			}}
                                   include("bv_insert.php");
			} }else{ $q++;
                                    echo "<script>$(document).ready(function(){ $('#msg').html('<strong>Error!</strong> Sql Error'); });</script>";
                                }
                       
                                
                                
                                }
                            }else{ $q++;
                                    echo "<script>$(document).ready(function(){ $('#msg').html('<strong>Code Error!</strong> Code is Case Sensitive please enter it again'); });</script>";
                                }
                        }else{ $q++;
                                    echo "<script>$(document).ready(function(){ $('#msg').html('<strong>Code Error!</strong> This code is already used'); });</script>";
                                }
                                
                                }else{ $q++;
                                    echo "<script>$(document).ready(function(){ $('#msg').html('<strong>Code Error!</strong> Wrong Code'); });</script>";
                                }
//                    echo $res;
                   
                }
                ?>
    <script>
    function generate(){
        bv=$("#user_bv").val();
        if(bv!=""){
        <?php  $ss = substr(str_shuffle(str_repeat("0123456789abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ", 1)), 0, 16); ?>
//                alert("");
    $("#user_gen_code").val("<?php echo $ss; ?>");
    $("#user_bv").css("border-color","none");
    $("#user_bv").prop("readonly",true);
    }else{
        $("#user_bv").css("border-color","red");
        $("#user_bv").attr("placeholder","please fill this field first");
    }
    }
    </script>
      <?php if(isset($_POST['save_bv_code'])){ if($q>0){ ?>
       <div class="alert alert-danger" id="msg">
  
       </div><?php } if($p>0){ ?>
            <div class="alert alert-success" id="msg_su">
  
       </div>
       <?php } } ?>
    
        <?php 
//        $user_id=$_SESSION['user'];
//        $user_cmpny_id=$conn->get_admin_login_name($con,$user_id);
//        $res=$conn->get_admin_distributor_detail_by_cmpny_id($con,$user_cmpny_id);
//        $row=  mysqli_fetch_array($res);
//        $user_bv=$row['distributor_bv'];
        ?>
    
    
		<h3 class="subtitle">Add B.V. to your Account</h3>
          <hr>
         
          <form method="post" action="#">
		  <div class="row">
                      <div class="col-md-12">
                              <div class="col-md-2" style="margin-top:5px;font-size: 18px;" ><strong>User</strong></div>
                              <div class="col-md-8" >
                                  <?php 
                                  $res=$conn->get_admin_distributors1($con);
                                  ?>
                                  <!--<input type="text" name="user_bv_code" class="form-control" id="user_bv_code" placeholder="B.V. Code">-->
                                  <select class="form-control" name="user_id" id="user_id">
                                      <option value="">Select User</option>
                                      <?php while($row=  mysqli_fetch_array($res)){ ?>
                                      <option value="<?php echo $row['distributor_company_id'] ?>"> <?php echo $row['distributor_name']." (".$row['distributor_company_id'].")"; ?></option>
                                      <?php } ?>
                                  </select>
                              
                              </div>
                              <br><br> <br> 
                      </div>
			  <div class="col-md-12">
                              <div class="col-md-2" style="margin-top:5px;font-size: 18px;" ><strong>Code</strong></div>
                              <div class="col-md-8" ><input type="text" name="user_bv_code" class="form-control" id="user_bv_code" placeholder="B.V. Code"></div>
                              <div class="col-md-2" ><input type="submit" name="save_bv_code"  value="ADD B.V." class="btn btn-success" ></div>
                          </div>
				
                  </div></form>
          
</section>


<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<div class="offline-ui offline-ui-up"><div class="offline-ui-content"></div><a href="" class="offline-ui-retry"></a>
</div>
</body>
</html>
<?php
 } 
?>