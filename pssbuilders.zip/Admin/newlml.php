<?php

function in_parent($in_parent, $store_all_id, $con,$p) {
                    $p++;
            if (in_array($in_parent, $store_all_id)) {
                
                $result = mysqli_query($con, "SELECT * FROM tree where parent_id = '$in_parent' order by position ");
                echo $in_parent == 0 ? "<ul class='tree'>" : "<ul>";
                while ($row = mysqli_fetch_array($result)) {
                    $res=  mysqli_query($con, "select * from distributor_detail where distributor_id='".$row['id']."'");
                    $rows=  mysqli_fetch_array($res);
                    $left=mysqli_query($con,"select * from tree where parent_id = '$row[id]' order by position");
                   
                  $pp=array();
                  $i=0;
                  $count_left=0;
                  $count_right=0;
                  while( $rr=  mysqli_fetch_array($left)){
                     
                      $pp[$i]=$rr;
                       $i++;
                  }
                  if($i==2){
                      if($pp[0][1]!='blank'){
                          $id=$pp[0][0];
                       $count_left=countt($id,$con); 
                       $count_left++;
                      }else {
                          $count_left=0;                          
                      }
                      if($pp[1][1]!='blank'){
                          $idd=$pp[1][0];
                         $count_right=countt($idd,$con); 
                         $count_right++;
                      }else {
                          $count_right=0;                          
                      }
                  }
                  $count_left_bv=0;
                  $count_right_bv=0;
                  
                  if($i==2){
                      if($pp[0][1]!='blank'){
                       $count_left_bv=countbv($pp[0][0],$con); 
                       $user_left_idd=$pp[0][0];
                       $sql=  mysqli_query($con, "select distributor_bv from distributor_detail where distributor_id='$user_left_idd'");
                       $rowss=  mysqli_fetch_array($sql);
                       $count_left_bv=$count_left_bv+$rowss['distributor_bv'];
//                       echo $connt_left;
                      }else {
                          $count_left_bv=0;                          
                      }
                      if($pp[1][1]!='blank'){
                           $count_right_bv=countbv($pp[1][0],$con); 
                            $user_right_idd=$pp[1][0];
                       $sql=  mysqli_query($con, "select distributor_bv from distributor_detail where distributor_id='$user_right_idd'");
                       $rowss=  mysqli_fetch_array($sql);
                           $count_right_bv=$count_right_bv+$rowss['distributor_bv'];
                      }else{
                          $count_right_bv=0;    
                      }
//                     $counttt= $count_right_bv+$count_left_bv;
//                     return $counttt;
                  }
                  
                  
                  
//                  $qq=$pp[1][1];
                    echo "<li";
//                    if ($row['hide'])
                    if($p>1)
                           $p++;
//                    echo $p;
                    echo "<td> Left- $count_left_bv  Right- $count_right_bv 
					</td>
                    echo "</li>";
                }
                echo "</ul>";
           
                }
        }
   ?>     