<?php
$page = 1;
include_once '../property/pss_db.php';
$conn = new DB_con();
$con = $conn->connection();
//include_once 'property/function_list.php';
//include_once 'property/default_values.properties';
$functions = new functions();
?><?php
session_start();
if(!isset($_SESSION['user']))
{
	header("Location: index.php");
}
else
{
?>
<!DOCTYPE html>
<!-- saved from url=(0038)http://flatter.cloudtub.com/index.html -->
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title></title>
<meta name="description" content="Flatter - Flat Admin Theme">
<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/layout.css">
<link rel="stylesheet" href="css/style3.css">
<script type="text/javascript" src="js/jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.10.4.custom.min.js"></script>
<style>
.imgsize
{
	height:30px; 
	width:30px;
}
</style>
</head>
<body id="body">

	
		<!-- Header -->
		

<header class="navbar main-header" style="background-color:#3ba0ff;">
     <script src="js/jquery.blockUI.min.js" ></script>  
     <link rel="stylesheet" href="css/spinner.css">
    <a class="navbar-brand" href="">
        <span style="font-size:17px;">Pss Builders&nbsp;</span></div>
    </a>
    <ul class="nav navbar-nav navbar-left sidebar-toggle-ul">
        <li class="navbar-main hidden-lg hidden-md">
            <a href="javascript:void(0);" id="sidebar-toggle">
                <span class="meta">
                    <span class="arrow"><i class="arrow fa fa-angle-right pull-right"></i></span>
                </span>
            </a>
        </li>

        <li class="navbar-main hidden-sm hidden-xs">
            <a href="javascript:void(0);" id="sidebar-collapse">
                <span class="meta">
                    <span class="icon"><i class="fa fa-outdent" style="color:blue;"></i></span>
                </span>
            </a>
        </li>
    </ul>
<?php
	        $id=$_SESSION['user'];
            $name=$conn->get_admin_login_name($con,$id);
            $res=$conn->get_admin_distributor_detail_by_cmpny_id($con,$name);
            $row=  mysqli_fetch_array($res);
            $dis_name=$row['distributor_name'];
            $image_path=$row['distributor_image_path'];
            if($image_path=="../image_uploads/" || $image_path==""){
                $image_path="images/avatar.png";
            }
            ?>
    <ul class="nav navbar-nav navbar-right">
        <li class="dropdown icons-dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><span style="color:blue;">Company Id : <?php echo $name ?></span></a>
<!--            <ul class="dropdown-menu list-group">
                <li class="list-group-item heading"><p>Notification</p></li>
                <a href="http://flatter.cloudtub.com/index.html#" class="list-group-item"><i class="fa fa-user"></i> <p>John sent you friend request</p></a>
                <a href="http://flatter.cloudtub.com/index.html#" class="list-group-item"><i class="fa fa-envelope-o"></i> <p>Sam sent important mail</p></a>
                <a href="http://flatter.cloudtub.com/index.html#" class="list-group-item"><i class="fa fa-calendar"></i> <p>You have pending job</p></a>
                <a href="http://flatter.cloudtub.com/index.html#" class="list-group-item"><i class="fa fa-money"></i> <p>Received $1826 from client</p></a>

            </ul>-->
        </li>
            

        <li class="dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><span  style="color:blue;"><?php echo "$dis_name" ?></span> <img class="img-circle" src="<?php echo $image_path; ?>" alt="avatar"> <b class="caret"></b></a>
            <ul class="dropdown-menu">
<!--                <li><a href="http://flatter.cloudtub.com/index.html#"><i class="fa fa-globe" ></i> Notification <span class="label label-danger"> 5</span></a></li>
                <li><a href="http://flatter.cloudtub.com/index.html#"><i class="fa fa-user"></i> Profile</a></li>
                <li><a href="http://flatter.cloudtub.com/index.html#"><i class="fa fa-gear"></i> Settings</a></li>-->
                <li><a href="logout.php?logout"><i class="fa fa-share"></i> Logout</a></li>
            </ul>
        </li>
    </ul>
</header>

       <?php include './left-menu.php'; ?>
		<!-- Header -->
              
                
<section style="background-color:#2980B9;" id="main-wrapper">
    <?php 
	$fu="dfe_fd@><";
    $jl=base64_decode($_REQUEST['jk']);
	$jk=preg_replace(sprintf('/%s/', $fu),'',$jl);
     if (isset($_POST['save'])) {
         
        $transaction_type="money dispatched";
        $user_id = $_POST['user_id'];
        $amount = $_POST['amount'];
        $mode_of_payment = $_POST['m_o_payment'];
        $payment_type=$_POST['m_payment_type'];
        if(isset($_POST['commodity_type'])){ $commodity_type=$_POST['commodity_type']; }
        if ($user_id != "") {
           
            if ($mode_of_payment != "" && $mode_of_payment != "commodity") {
                 
                $field1=$_POST['field1'];
                $field2=$_POST['field2'];
                if(isset($_POST['field3'])){
                $field3=$_POST['field3'];
                }else{
                    $field3="";
                }
                $date=$_POST['received_date'];
                $res=$conn->insert_admin_payment_mode($con,$mode_of_payment,$field1,$field2,$field3,$date,$date_time,$_SESSION['user']);
//                 echo "<script>alert('$res');</script>";
                if($res){
                   
                    $res=$conn->get_admin_payment_mode_id($con,$mode_of_payment,$field1,$field2,$field3,$date,$date_time,$_SESSION['user']);
//                    echo "<script>consol.log('$res');</script>";
//                    echo $res;
                    $row=  mysqli_fetch_array($res);
                    $mode_id=$row['payment_mode_id'];
                    $res=$conn->insert_into_transactions($con,$transaction_type,$user_id,$amount,$mode_of_payment,$mode_id,$date_time,$_SESSION['user'],$payment_type);
                    if($res){?>
        
		<script type="text/javascript">
       alert("successful !");
          window.location.href = "payment_result.php";
         </script>
		
		<?php
		}
                }
                
                
            }else if($mode_of_payment == "commodity"){
//                echo "hello";
                $mode_id=0;
                $res=$conn->insert_into_transactions($con,$transaction_type,$user_id,$amount,$commodity_type,$mode_id,$date_time,$_SESSION['user'],$payment_type);
                    if($res){
                        echo "<script>alert('successful')</script>";
                    }
            }
        }
    }
    
    
                ?>
    <script>
   $(document).ready(function(){
     
           type="money dispatched";
           if(type==""){
               $("#trans_info").load("get-data2.php");
//               $("#mode_info").load("get-data.php");
           }else{
               $("#trans_info").load("get-data2.php",{"type":type});
//               $("#mode_info").load("get-data.php");
           }
      
   });
   $(document).ready(function(){
       $("form").submit(function(event){
           user_id=$("#user_id").val();
           m_o_payment=$("#m_o_payment").val();
           if(user_id!=""){
                $("#user_id").css("border-color","none");
               if(m_o_payment!=""){
                   $("#m_o_payment").css("border-color","none");
               }else{
                   event.preventDefault();
                   $("#m_o_payment").css("border-color","red");
               }
           }else{
                    event.preventDefault();
                   $("#user_id").css("border-color","red");
               }
       });
   });
   $(document).ready(function(){
       $("#m_payment_type").change(function(){
           payment_type=$("#m_payment_type").val();
           $("#payment_info").load("get-data2.php",{"payment_type":payment_type});
       });
   });
   function commodity_amount(){
          commodity=$("#commodity_type").val();
           payment_type=$("#m_payment_type").val();
         
              $("#amnt").load("get-data2.php",{"commodity":commodity,"commodity_payment_type":payment_type});
          
      }
   
    </script>
      <?php if(isset($_POST['save_bv_code'])){ if($q>0){ ?>
       <div class="alert alert-danger" id="msg">
  
       </div><?php } if($p>0){ ?>
            <div class="alert alert-success" id="msg_su">
  
       </div>
       <?php } } ?>
    
        <?php 
//        $user_id=$_SESSION['user'];
//        $user_cmpny_id=$conn->get_admin_login_name($con,$user_id);
       
//        $user_bv=$row['distributor_bv'];
        ?>
    
    
    
		<h3 class="subtitle">Pay  Here</h3>
          <hr>
         
          <form method="post" action="#">
		  <div class="row">
                     <div class="col-sm-12"><br>
        <label>Payment Type</label>
        <select class="form-control" id="m_payment_type" name="m_payment_type">
            <option value="">Select Payment Type</option>
            <option value="reward">Reward Benefit</option>
            <!--option value="coupon">Coupon Benefit</option>
            <option value="bonanza">Bonanza Benefit</option>
            <option value="direct income">Direct Benefit</option-->
            <option value="pair income">Working Group Benefit</option>
        </select>
    </div>
                      <div id="payment_info"></div>
			  
						 <div class="col-sm-6"><br>
                                  
                                  <!--<input type="text" name="user_bv_code" class="form-control" id="user_bv_code" placeholder="B.V. Code">-->
                                  <label> User</label>
                                  <input type="hidden" name="user_id" value="<?php echo $jk;?>" id="user_id">
								  <?php $res=$conn->get_admin_distributor_detail_by_cmpny_id($con,$jk);
                                    $roww=mysqli_fetch_assoc($res);?>
                                    <input type="text" value="<?php echo $roww['distributor_name']." (".$roww['distributor_company_id'].")";?>" class="form-control" readonly>
                            
                              
                              </div>
                              <div class="col-sm-6" id="amnt"><br>
                                  <label> Amount</label>
                                  <input type="text" name="amount" id="amount" class="form-control" required>
                              </div>
							  <div  id="trans_info">
                             
                            
                          </div>
                      <div class="col-md-12" id="mode_info"><br>
                         
                          
                          
                      </div>
                      
                      <div class="col-md-12"><hr>
                          <input type="submit" value="save" name="save" class="btn btn-success pull-right">
                          
                      </div>
				
                  </div></form>
          
</section>


<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<div class="offline-ui offline-ui-up"><div class="offline-ui-content"></div><a href="" class="offline-ui-retry"></a>
</div>
</body>
</html>
<?php
 } 
?>