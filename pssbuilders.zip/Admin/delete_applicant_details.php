<?php
if(isset($_REQUEST['applicant_id']))
{
@include_once '../property/pss_db.php';
@$conn = new DB_con();
@$con = $conn->connection();
$applicant_id=$_REQUEST['applicant_id'];

//echo"$applicant_id";
		?>						
								<?php
				$res = $conn->get_admin_applicant_delete($con,$applicant_id);
				if($res)
				{
		   // header("location:news-details.php");
				echo"<script>alert('success');
                         window.location.href='applicant_detail.php';
                        </script>";
				}
				else
				{
				echo"<script>alert('Record not deleted');<script>";
				}
				 ?>
			
								
<?php
}
?>