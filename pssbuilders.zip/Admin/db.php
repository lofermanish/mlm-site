<?php
$con=mysqli_connect("localhost", "root", "", "pss_builder") or die("Could not connect");
//mysqli_select_db(,$con) or die("could not connect database");
?>
<?php
//$page=1;
//include_once '../property/dbMySql.php';
//$con = new DB_con();
////include_once 'property/function_list.php';
////include_once 'property/default_values.properties';
//$functions=new functions();
//?>