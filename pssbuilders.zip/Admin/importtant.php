SELECT * from(SELECT bv_code_used_by,SUM(bv_code_value),distributor_creation_date,distributor_company_id FROM bv_code,distributor_detail WHERE bv_code_used_by=distributor_id AND distributor_id=173 AND bv_code_used_date BETWEEN distributor_creation_date AND now())as d



SELECT bv_code_used_date,(bv_code_value) as distributor_bv,distributor_creation_date,distributor_company_id from(SELECT bv_code_used_date,bv_code_value,distributor_creation_date,distributor_company_id FROM bv_code,distributor_detail WHERE bv_code_used_by=distributor_id AND distributor_id=195 AND bv_code_used_date BETWEEN distributor_creation_date AND '2016-09-20 14:20:08')as n




SELECT distributor_company_id, week(bv_code_used_date) as week,sum(bv_code_value) as distributor_bv,distributor_creation_date,distributor_placement,distributor_distributor_id from(SELECT bv_code_used_date,bv_code_value,distributor_placement,distributor_distributor_id,distributor_creation_date,distributor_company_id FROM bv_code,distributor_detail WHERE bv_code_used_by=distributor_id )as n group by distributor_company_id,week  
ORDER BY `n`.`distributor_company_id`  DESC