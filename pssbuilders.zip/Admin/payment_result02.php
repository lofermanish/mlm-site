<?php
 session_start();

$page = 1;
include_once '../property/pss_db.php';
$conn = new DB_con();
$con = $conn->connection();
//include_once 'property/function_list.php';
//include_once 'property/default_values.properties';
$functions = new functions();
//include_once 'db.php';

if(!isset($_SESSION['user']))
{
  header("Location: index.php");
}
else
{
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Dashboard</title>
<meta name="description" content="Flatter - Flat Admin Theme">
<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/layout.css">
<link rel="stylesheet" href="css/style3.css">
<script type="text/javascript" src="js/jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.10.4.custom.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/r/bs-3.3.5/jq-2.1.4,dt-1.10.8/datatables.min.css"/>
 
    <script type="text/javascript" src="https://cdn.datatables.net/r/bs-3.3.5/jqc-1.11.3,dt-1.10.8/datatables.min.js"></script>
      <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/1.2.1/css/buttons.dataTables.min.css"/>
 
    <!--<script type="text/javascript" src="https://cdn.datatables.net/r/bs-3.3.5/jqc-1.11.3,dt-1.10.8/datatables.min.js"></script>-->
                 <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.1/js/dataTables.buttons.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.1/js/buttons.flash.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js"></script>
        <script type="text/javascript" src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/pdfmake.min.js"></script>
        <script type="text/javascript" src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/vfs_fonts.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.1/js/buttons.html5.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.1/js/buttons.print.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.1/js/buttons.colVis.min.js"></script>
        <script type="text/javascript" src="js/jquery-easing.js"></script>
    <script src="js/bootstrap-datepicker.js"></script>
        <link rel="stylesheet" href="css/datepicker.css">

    <script type="text/javascript" charset="utf-8">
      $(document).ready(function() {
        $('.example').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'pageLength',
            {
                extend: 'print',
                autoPrint: false,
                title: 'Report',
                exportOptions: {
                    columns: ':visible'
                }
            },{
                extend: 'pdf',
                title: 'Report',
                exportOptions: {
                    columns: ':visible'
                }
            },{
                extend: 'excel',
                title: 'Report',
                exportOptions: {
                    columns: ':visible'
                }
            },{
                extend: 'csv',
                title: 'Report',
                exportOptions: {
                    columns: ':visible'
                }
            },{
                extend: 'copy',
                exportOptions: {
                    columns: ':visible'
                }
            },
            'colvis'
        ]
    },
    {
        dom: 'Bfrtip',
        lengthMenu: [
            [ 10, 25, 50, -1 ],
            [ '10 rows', '25 rows', '50 rows', 'Show all' ]
        ]
      
    },
    {
        dom: 'Bfrtip',
        buttons: [
            {
                extend: 'collection',
                text: 'Table control',
                buttons: [
                    'colvis'
                ]
            }
        ]
    } 
            
                );
      } );
                        
                        
                        
                        
    </script>
                <script type="text/javascript">
  // For demo to fit into DataTables site builder...
  $('.example')
    .removeClass( 'display' )
    .addClass('table table-striped table-bordered');
</script></head>
<body id="body">

<header class="navbar main-header" style="background-color:#3ba0ff;">
     <script src="js/jquery.blockUI.min.js" ></script>  
     <link rel="stylesheet" href="css/spinner.css">
    <a class="navbar-brand" href="">
        <span style="font-size:17px;">Pss Builders&nbsp;</span></div>
    </a>
    <ul class="nav navbar-nav navbar-left sidebar-toggle-ul">
        <li class="navbar-main hidden-lg hidden-md">
            <a href="javascript:void(0);" id="sidebar-toggle">
                <span class="meta">
                    <span class="arrow"><i class="arrow fa fa-angle-right pull-right"></i></span>
                </span>
            </a>
        </li>

        <li class="navbar-main hidden-sm hidden-xs">
            <a href="javascript:void(0);" id="sidebar-collapse">
                <span class="meta">
                    <span class="icon"><i class="fa fa-outdent" style="color:blue;"></i></span>
                </span>
            </a>
        </li>
    </ul>
<?php
          $id=$_SESSION['user'];
            $name=$conn->get_admin_login_name($con,$id);
            $res=$conn->get_admin_distributor_detail_by_cmpny_id($con,$name);
            $row=  mysqli_fetch_array($res);
            $dis_name=$row['distributor_name'];
            $image_path=$row['distributor_image_path'];
            if($image_path=="../image_uploads/" || $image_path==""){
                $image_path="images/avatar.png";
            }
            ?>
    <ul class="nav navbar-nav navbar-right">
        <li class="dropdown icons-dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><span style="color:blue;">Company Id : <?php echo $name ?></span></a>
<!--            <ul class="dropdown-menu list-group">
                <li class="list-group-item heading"><p>Notification</p></li>
                <a href="http://flatter.cloudtub.com/index.html#" class="list-group-item"><i class="fa fa-user"></i> <p>John sent you friend request</p></a>
                <a href="http://flatter.cloudtub.com/index.html#" class="list-group-item"><i class="fa fa-envelope-o"></i> <p>Sam sent important mail</p></a>
                <a href="http://flatter.cloudtub.com/index.html#" class="list-group-item"><i class="fa fa-calendar"></i> <p>You have pending job</p></a>
                <a href="http://flatter.cloudtub.com/index.html#" class="list-group-item"><i class="fa fa-money"></i> <p>Received $1826 from client</p></a>

            </ul>-->
        </li>
            

        <li class="dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><span  style="color:blue;"><?php echo "$dis_name" ?></span> <img class="img-circle" src="<?php echo $image_path; ?>" alt="avatar"> <b class="caret"></b></a>
            <ul class="dropdown-menu">
<!--                <li><a href="http://flatter.cloudtub.com/index.html#"><i class="fa fa-globe" ></i> Notification <span class="label label-danger"> 5</span></a></li>
                <li><a href="http://flatter.cloudtub.com/index.html#"><i class="fa fa-user"></i> Profile</a></li>
                <li><a href="http://flatter.cloudtub.com/index.html#"><i class="fa fa-gear"></i> Settings</a></li>-->
                <li><a href="logout.php?logout"><i class="fa fa-share"></i> Logout</a></li>
            </ul>
        </li>
    </ul>
</header>
    <!-- Header -->
    <?php //include './header.php'; ?>

       <?php include './left-menu.php'; ?>
    <!-- Header -->

        <section id="main-wrapper">
        <h3 class="subtitle">Weekly Report</h3>
          <hr>
         
          
    <div class="col-sm-12">
    <label>Weekly working Group Report</label></div>
<div class="row" style="padding-right: 30px;padding-left: 30px;">
<div class="col-sm-12">     <table text-align="center" class="table table-bordered display example" id="example">
                                      <thead> 
                          <tr>
                                                  <th rowspan="2"><center>Name</center></th>
                                                  <th rowspan="2"><center>Company Id</center></th>
                                                  <th rowspan="2"><center>Incentive Date</center></th>
                                                  <th rowspan="2">Total Left B V</th>
                                                  <th rowspan="2">Total Right B V</th>
                          <th colspan="4"><center> Working Group</center></th>
                          <th colspan="2"><center> Reward</center></th>                         
                          <th rowspan="2"><center>Position</center></th>
                          <th rowspan="2"><center>Pay</center></th> 
                          </tr>
                         <tr>
                         
                         <th>Remaining Reward Amount</th>
                         <th>10%</th>
                         <th>5%</th>
                         <th>Payable Amount</th>                                          
                             <th>Reward Commodity</th> 
                                                 <th>Reward Amount</th>
                         </tr>
                    </thead>
                    <?php 


      
        $jk=$conn->get_admin_login_name($con,$_SESSION['user']);
       
       $get_date=mysqli_query($con,"select distributor_creation_date from distributor_detail where distributor_company_id='$jk'");
    $distributor_date= mysqli_fetch_array($get_date);
    $begin1=$distributor_date['distributor_creation_date'];
$begin = new DateTime("$begin1");
$end = new DateTime();
      $_REQUEST1['type']='total';   
    $user_name=$conn->get_admin_login_name($con,$user_id);
    $id=$conn->get_admin_dis_id($con,$user_name);
//    $id=1;
    
     function add_array($id,$con,$childs){
                   $count_left=array();
                   $count_right=array();
                    $i=0;
                    $query=mysqli_query($con,"select * from tree where parent_id='$id' order by position");
                    while( $rr=  mysqli_fetch_array($query)){
                      
                      $pp[$i]=$rr;
                      $i++;
                  }
                  if($i==2){
                      if($pp[0][1]!='blank'){
                          array_push($childs, $pp[0][0]);
                       $count_left=add_array($pp[0][0],$con,$childs);  
                      }else{
                          $count_left=['0'];
                      }
                      if($pp[1][1]!='blank'){
                          array_push($childs, $pp[1][0]);
                           $count_right=add_array($pp[1][0],$con,$childs); 
                      }else{
                          $count_right=['0'];
                      }
                      $childs=  array_merge($count_right,$count_left);
                      return $childs;
                  }if($i==0){
                   return $childs;   
                  }
                }
                $childs=array();
    $all_childs=array();
    
     $query=mysqli_query($con,"select * from tree where parent_id='$id' order by position");
       while( $rr=  mysqli_fetch_array($query)){
          
           $idd=$rr['id'];
           $pos=$rr['position'];
            if($_REQUEST1['type']=='total'){
          array_push($all_childs,$idd);
           $all_childs=  array_merge($all_childs,add_array($idd,$con,$childs));
//           echo $idd ."<br>";
//           print_r($all_childs);
           }if($_REQUEST1['type']=='right' && $pos=='right'){
                array_push($all_childs,$idd);
           $all_childs=  array_merge($all_childs,add_array($idd,$con,$childs));
              
           }if($_REQUEST1['type']=='left' && $pos=='left'){
               array_push($all_childs,$idd);
           $all_childs=  array_merge($all_childs,add_array($idd,$con,$childs)); 
           }
           
           
       }
    
    
//    $all_childs= add_array($id,$con,$childs);
    $all_childs=  array_unique($all_childs);
//    $all_childs= array_pop();
//    print_r($all_childs);
    $all=array();
foreach($all_childs as $vv){
    if($vv!=0){
        array_push($all, $vv);
    }
}


function countt($id,$con){
                    $i=0;
                    $query=mysqli_query($con,"select * from tree where parent_id='$id' order by position");
                    while( $rr=  mysqli_fetch_array($query)){
                      
                      $pp[$i]=$rr;
                      $i++;
                  }
                  if($i==2){
                      if($pp[0][1]!='blank'){
                       $count_left=countt($pp[0][0],$con);   
                       $count_left++;
//                       echo $connt_left;
                      }else {
                          $count_left=0;                          
                      }
                      if($pp[1][1]!='blank'){
                           $count_right=countt($pp[1][0],$con); 
                           $count_right++;
                      }else{
                          $count_right=0;    
                      }
                     $counttt= $count_left+$count_right;
                     return $counttt;
                  }if($i==0){
                   return 0;   
                  }
                }

       
        

        function countbv($id,$con){
                    $i=0;
                    $query=mysqli_query($con,"select * from tree where parent_id='$id' order by position");
                    while( $rr=  mysqli_fetch_array($query)){
                      
                      $pp[$i]=$rr;
                      $i++;
                  }
          
       
                   if($i==2){
                      if($pp[0][1]!='blank'){
                       $count_left_bv=countbv($pp[0][0],$con); 
                       $user_left_idd=$pp[0][0];
                       $sql=  mysqli_query($con, "select distributor_bv from (SELECT distributor_company_id,distributor_direct_distributor_id,distributor_id, distributor_name, distributor_distributor_id, sum(bv_code_value) as distributor_bv,bv_code_used_date FROM bv_code, distributor_detail where bv_code_used_by=distributor_id and bv_code_used_date between '$GLOBALS[from]' and '$GLOBALS[to]' group by distributor_company_id) as d where distributor_id='$user_left_idd'");
                       $rowss=  mysqli_fetch_array($sql);
                       $count_left_bv=$count_left_bv+$rowss['distributor_bv'];
//                       echo $connt_left;
                      }else {
                          $count_left_bv=0;                          
                      }
                      if($pp[1][1]!='blank'){
                           $count_right_bv=countbv($pp[1][0],$con); 
                            $user_right_idd=$pp[1][0];
                       $sql=  mysqli_query($con, "select distributor_bv from (SELECT distributor_company_id,distributor_direct_distributor_id,distributor_id, distributor_name, distributor_distributor_id, sum(bv_code_value) as distributor_bv,bv_code_used_date FROM bv_code, distributor_detail where bv_code_used_by=distributor_id and bv_code_used_date between '$GLOBALS[from]' and '$GLOBALS[to]' group by distributor_company_id) as d where distributor_id='$user_right_idd'");
                       $rowss=  mysqli_fetch_array($sql);
                           $count_right_bv=$count_right_bv+$rowss['distributor_bv'];
                      }else{
                          $count_right_bv=0;    
                      }
                     $counttt= $count_right_bv+$count_left_bv;
                     return $counttt;
                  }if($i==0){
                   return 0;   
                  }
                }
?> <?php
//print_r($all);
                       
  for($next_week1 = $begin; $begin <= $end; $next_week1->modify('+14 day'))
{
   $from= $next_week=$next_week1->format("Y-m-d");
    $to=date('Y-m-d', strtotime($from.' + 14 days'));
  
       
        
?>
 
        <?php 
        
        
        
        
        
        
        ?>
<?php
$ii=0;
foreach($all as $vv){
    $query=mysqli_query($con,"select * from distributor_detail where distributor_id='$vv'");
    $row=  mysqli_fetch_array($query);
    $iddd=$row['distributor_distributor_id'];
//    echo $iddd;
   $res=$conn->get_admin_distributor_detail_by_cmpny_id($con,$iddd);
//   echo $res;
   $rows=mysqli_fetch_array($res);
   $sponsor_name=$rows['distributor_name'];
   $res=$conn->get_admin_distributor_detail_by_cmpny_id($con,$row['distributor_direct_distributor_id']);
   $rows=  mysqli_fetch_array($res);
   $direct_sponsor_name=$rows['distributor_name'];
   
   
   $left=mysqli_query($con,"select * from tree where parent_id = '$row[distributor_id]' order by position");
                   
                  $pp=array();
                  $i=0;
                  $count_left=0;
                  $count_right=0;
                  while( $rr=  mysqli_fetch_array($left)){
                     
                      $pp[$i]=$rr;
                       $i++;
                  }
                  if($i==2){
                      if($pp[0][1]!='blank'){
                          $id=$pp[0][0];
                       $count_left=countt($id,$con); 
                       $count_left++;
                      }else {
                          $count_left=0;                          
                      }
                      if($pp[1][1]!='blank'){
                          $idd=$pp[1][0];
                         $count_right=countt($idd,$con); 
                         $count_right++;
                      }else {
                          $count_right=0;                          
                      }
                  }
                  $count_left_bv=0;
                  $count_right_bv=0;
                  
                  if($i==2){
                      if($pp[0][1]!='blank'){
                       $count_left_bv=countbv($pp[0][0],$con); 
                       $user_left_idd=$pp[0][0];
                       //$sql=  mysqli_query($con, "select distributor_bv from distributor_detail where distributor_id='$user_left_idd'");
                       
        
$sql=  mysqli_query($con, "select distributor_bv from (SELECT distributor_company_id,distributor_direct_distributor_id,distributor_id, distributor_name, distributor_distributor_id, sum(bv_code_value) as distributor_bv,bv_code_used_date FROM bv_code, distributor_detail where bv_code_used_by=distributor_id and bv_code_used_date between '$GLOBALS[from]' and '$GLOBALS[to]' group by distributor_company_id) as d where distributor_id='$user_left_idd'");
                       $rowss=  mysqli_fetch_array($sql);
                       $count_left_bv=$count_left_bv+$rowss['distributor_bv'];
//                       echo $connt_left;
                      }else {
                          $count_left_bv=0;                          
                      }
                      if($pp[1][1]!='blank'){
                           $count_right_bv=countbv($pp[1][0],$con); 
                            $user_right_idd=$pp[1][0];
                             
                       $sql=  mysqli_query($con, "select distributor_bv from (SELECT distributor_company_id,distributor_direct_distributor_id,distributor_id, distributor_name, distributor_distributor_id, sum(bv_code_value) as distributor_bv,bv_code_used_date FROM bv_code, distributor_detail where bv_code_used_by=distributor_id and bv_code_used_date between '$GLOBALS[from]' and '$GLOBALS[to]' group by distributor_company_id) as d where distributor_id='$user_right_idd'");
                       $rowss=  mysqli_fetch_array($sql);
                           $count_right_bv=$count_right_bv+$rowss['distributor_bv'];
                      }else{
                          $count_right_bv=0;    
                      }
//                     $counttt= $count_right_bv+$count_left_bv;
//                     return $counttt;
                  }

   if($row['distributor_company_id']==$jk){
    ?>

   
    <tr>
        
     <td><?php echo $row['distributor_name']; ?></td>
        <td><?php echo $row['distributor_company_id']; ?></td>
        <td><?php 
echo $GLOBALS['to']; ?></td>
         <td><?php echo $count_left_bv; ?></td>
       <td><?php echo $count_right_bv; ?></td>      
<td>
                                               <?php 
                      
$paid_res=mysqli_query($con,"select sum(transaction_amount),service_tax from transaction where transaction_type='money dispatched' and transaction_distributor_id='$row[distributor_company_id]'");
        
        while($paid_row=mysqli_fetch_array($paid_res))
    {   
  
    $paid_row1=$paid_row['sum(transaction_amount)'];
$paid_row2=$paid_row['service_tax'];    
                      if($count_left_bv<$count_right_bv){
                        
                        ?>
                                              <?php echo $a=($count_left_bv*20000); ?>
                                          <?php
                      }
                      else{
                         ?>
                                              <?php echo $a=($count_right_bv*20000); ?>
                                          <?php
    }}
                      ?>   
                                          </td>
                       <td><?php echo $b=$a*0.1; ?></td> 
                       <td><?php echo $c=$a*0.05; ?></td>
                      <td><?php echo $p=$a-($b+$c+$paid_row1); ?></td>
                      <?php if($count_left_bv<$count_right_bv){
                        
                        ?>
                                              <?php  $bv=$count_left_bv; ?>
                                          <?php
                      }
                      else{
                         ?>
                                              <?php $bv=$count_right_bv; ?>
                                          <?php
    }
                      ?>
                                                            <?php 
                      
                  $paid_res=mysqli_query($con,"select payment_type_commodity,payment_type_price,payment_type_position FROM `payment_type` where payment_type_to=(SELECT max(payment_type_to) FROM `payment_type` WHERE payment_type_type='reward' and  payment_type_to<=$bv)");
        
                  $paid_row=mysqli_fetch_assoc($paid_res);
    ?>
    
   
                      
                                         
                      
                                          <td>
                                              <?php echo $commodity=$paid_row['payment_type_commodity']; ?>
                                       </td> 
                                          <td>
                                            <?php  echo $paid_row['payment_type_price']; ?>
                                          </td>
                      
                     <td>
                     <?php echo $paid_row['payment_type_position']; ?>
                     
                     </td>
                      <td>
                      
                       <?php if($a==""){
                         echo "";
                       }else{
                         $fu="dfe_fd@><";
                                                                       
                         ?>
                      <a href="money_dispatched2.php?jk=<?php echo base64_encode($row['distributor_company_id'].$fu); ?>" class="btn btn-success">Pay</a><?php } ?>
                      </td>
                                      </tr>
  
    
    
   <?php 
   }
}

?></table></div>
<?php } ?>
 </section>


<!--<script type="text/javascript" src="js/bootstrap.min.js"></script>-->
<script type="text/javascript" src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<div class="offline-ui offline-ui-up"><div class="offline-ui-content"></div><a href="" class="offline-ui-retry"></a>
</div>
</body>
</html>
<?php
 } 
?>