<?php
if(isset($_REQUEST['property_enquiry_id']))
{
@include_once '../property/pss_db.php';
@$conn = new DB_con();
@$con = $conn->connection();
$property_enquiry_id=$_REQUEST['property_enquiry_id'];

//echo"$property_enquiry_id";
		?>						
								<?php
				$res = $conn->get_admin_property_enquiry_details_delete($con,$property_enquiry_id);
				if($res)
				{
		   // header("location:news-details.php");
				echo"<script>alert('success');
                         window.location.href='enquiry_details.php';
                        </script>";
				}
				else
				{
				echo"<script>alert('Record not deleted');<script>";
				}
				 ?>
			
								
<?php
}
?>