<?php
if(isset($_REQUEST['image_id']))
{
@include_once '../property/pss_db.php';
@$conn = new DB_con();
@$con = $conn->connection();
$image_id=$_REQUEST['image_id'];
//echo"$image_id";
		?>						
								<?php
				$res = $conn->get_admin_image_delete($con,$image_id);
				if($res)
				{
			//header("location:all-picture-details.php");
			//echo"<script>alert('success');</script>";
			echo"<script>alert('success');
                         window.location.href='all-picture-details.php';
                        </script>";
				}
				else
				{
				echo"<script>alert('Record not deleted');<script>";
				}
				 ?>
			
								
<?php
}
?>
