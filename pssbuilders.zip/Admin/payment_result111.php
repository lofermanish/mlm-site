<?php
	session_start();
//include_once 'db.php';

if(!isset($_SESSION['user']))
{
	header("Location: index.php");
}
else
{
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Dashboard</title>
<meta name="description" content="Flatter - Flat Admin Theme">
<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/layout.css">
<link rel="stylesheet" href="css/style3.css">
<script type="text/javascript" src="js/jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.10.4.custom.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/r/bs-3.3.5/jq-2.1.4,dt-1.10.8/datatables.min.css"/>
 
		<script type="text/javascript" src="https://cdn.datatables.net/r/bs-3.3.5/jqc-1.11.3,dt-1.10.8/datatables.min.js"></script>
		  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/1.2.1/css/buttons.dataTables.min.css"/>
 
		<!--<script type="text/javascript" src="https://cdn.datatables.net/r/bs-3.3.5/jqc-1.11.3,dt-1.10.8/datatables.min.js"></script>-->
                 <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.1/js/dataTables.buttons.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.1/js/buttons.flash.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js"></script>
        <script type="text/javascript" src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/pdfmake.min.js"></script>
        <script type="text/javascript" src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/vfs_fonts.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.1/js/buttons.html5.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.1/js/buttons.print.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.1/js/buttons.colVis.min.js"></script>
        <script type="text/javascript" src="js/jquery-easing.js"></script>
		<script src="js/bootstrap-datepicker.js"></script>
        <link rel="stylesheet" href="css/datepicker.css">

		<script type="text/javascript" charset="utf-8">
			$(document).ready(function() {
				$('.example').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'pageLength',
            {
                extend: 'print',
                autoPrint: false,
                title: 'Report',
                exportOptions: {
                    columns: ':visible'
                }
            },{
                extend: 'pdf',
                title: 'Report',
                exportOptions: {
                    columns: ':visible'
                }
            },{
                extend: 'excel',
                title: 'Report',
                exportOptions: {
                    columns: ':visible'
                }
            },{
                extend: 'csv',
                title: 'Report',
                exportOptions: {
                    columns: ':visible'
                }
            },{
                extend: 'copy',
                exportOptions: {
                    columns: ':visible'
                }
            },
            'colvis'
        ]
    },
    {
        dom: 'Bfrtip',
        lengthMenu: [
            [ 10, 25, 50, -1 ],
            [ '10 rows', '25 rows', '50 rows', 'Show all' ]
        ]
      
    },
    {
        dom: 'Bfrtip',
        buttons: [
            {
                extend: 'collection',
                text: 'Table control',
                buttons: [
                    'colvis'
                ]
            }
        ]
    } 
            
                );
			} );
                        
                        
                        
                        
		</script>
                <script type="text/javascript">
	// For demo to fit into DataTables site builder...
	$('.example')
		.removeClass( 'display' )
		.addClass('table table-striped table-bordered');
</script>
</head>
<body id="body">

		<!-- Header -->
		<?php include './header.php'; ?>

       <?php include './left-menu.php'; ?>
		<!-- Header -->

        <section id="main-wrapper">
		
		<h3 class="subtitle">Payment Report</h3>
          <hr>
         
          
		<div class="col-sm-12">
		<label>Payment Type</label>
        <select class="form-control" id="m_payment_type" name="type" onchange="change('total');">
            <option value="">Select Payment Type</option>
            <option value="type">Reward Benefit</option>
            <!--option value="type">Coupon Benefit</option>
            <option value="type">Bonanza Benefit</option>
            <option value="type">Direct Benefit</option-->
            <option value="type">Working Group Benefit</option>
        </select><br><hr></div><form method="POST">


<!--center><input type="text"  id="begin12">
    
 <input type="text"  id="next_week1">
<input type="text"  id="jk1">
<input type="text"  id="type1">
</center-->
	<script>
     function change1(){
   
var type=document.getElementById("type").value;
var jk =document.getElementById("jk").value; 
var from1 = document.getElementById("begin1").value; 
var to1 = document.getElementById("next_week").value; 

//document.getElementById("type1").value=type;
 //document.getElementById("jk1").value=jk; 
 //document.getElementById("begin12").value=from1; 
 //document.getElementById("next_week1").value=to1; 
   
           $("#all").load("payee1.php",{"type":type,"jk":jk,"from":from1,"to":to1})
          
            
}
var $loading = $('.loading').hide();
$(document)
  .ajaxStart(function () {
    $loading.show();
    $("#all").css("opacity","0");
    $.blockUI({ message: '' });
  })
  .ajaxStop(function () {
    $loading.hide();
     $("#all").css("opacity","1");
     $.unblockUI();
  });

</script>    
                
<script>
     function pay(type){
            $("#all").load("payment_result02.php",{"jk":type})
        }  
         

     function change(type){
		   $("#all").load("payee.php",{"type":type})
            
        }
//        $.blockUI();
//        $(document).ready(function(){
//            $.unblockUI();
//        });

var $loading = $('.loading').hide();
$(document)
  .ajaxStart(function () {
    $loading.show();
    $("#all").css("opacity","0");
    $.blockUI({ message: '' });
  })
  .ajaxStop(function () {
    $loading.hide();
     $("#all").css("opacity","1");
     $.unblockUI();
  });

</script>   
	   <div id="all"> </div> 
         </form>
       </section>


<!--<script type="text/javascript" src="js/bootstrap.min.js"></script>-->
<script type="text/javascript" src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<div class="offline-ui offline-ui-up"><div class="offline-ui-content"></div><a href="" class="offline-ui-retry"></a>
</div>
</body>
</html>
<?php
 } 
?>