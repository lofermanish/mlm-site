<?php
session_start();
//include_once 'db.php';

if(!isset($_SESSION['user']))
{
	header("Location: index.php");
}
else
{
?>
 
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Dashboard</title>
<meta name="description" content="Flatter - Flat Admin Theme">
<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/layout.css">
<link rel="stylesheet" href="css/style3.css">
<script type="text/javascript" src="js/jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.10.4.custom.min.js"></script>
<link rel="stylesheet" href="css/library.css">
<link rel="stylesheet" href="css/layout.css">
<link rel="stylesheet" href="css/style-wizard.css">
<script src="js/bootstrap-datepicker.js"></script>
 <link rel="stylesheet" href="css/datepicker.css">
</head>
<body id="body">

		<!-- Header -->
		<?php include './header.php'; ?>

       <?php include './left-menu.php'; ?>
		<!-- Header -->
<style type="text/css">
.stepwizard-step p {
	margin-top: 10px;
}
.stepwizard-row {
	display: table-row;
}
.stepwizard {
	display: table;
	width: 50%;
	position: relative;
}
.stepwizard-step button[disabled] {
	opacity: 1 !important;
	filter: alpha(opacity=100) !important;
}
.stepwizard-row:before {
	top: 14px;
	bottom: 0;
	position: absolute;
	content: " ";
	width: 100%;
	height: 1px;
	background-color: #ccc;
	z-order: 0;
}
.stepwizard-step {
	display: table-cell;
	text-align: center;
	position: relative;
}
.btn-circle {
	width: 30px;
	height: 30px;
	text-align: center;
	padding: 6px 0;
	font-size: 12px;
	line-height: 1.428571429;
	border-radius: 15px;
}
</style>

        <?php
//      $count="";
//        $res="";
      $msg="";
        $dis_company_id="";
//        $id1="";
//        $id2="";
        if(isset($_POST['dis_form'])){
              $p=0;
            $dis_name=$_POST['dis_name'];
            $dis_fa_name=$_POST['dis_fa_name'];
            $dis_dob=$_POST['dis_dob'];
//            echo "<script>alert($dis_dob)</script>";
            $dis_gender=$_POST['dis_gender'];
            $dis_m_status=$_POST['dis_m_status'];
            $dis_n_name=$_POST['dis_n_name'];
            $dis_n_relationship=$_POST['dis_n_relationship'];
            $dis_c_address=$_POST['dis_c_address'];
            $dis_p_address=$_POST['dis_p_address'];
            $dis_district=$_POST['dis_district'];
            $dis_state=$_POST['dis_state'];
            $dis_city=$_POST['dis_city'];
            $dis_pin=$_POST['dis_pin'];
            $dis_mobile=$_POST['dis_mobile'];
            $dis_phone=$_POST['dis_phone'];
            $dis_email=$_POST['dis_email'];
            $dis_p_a_amount=$_POST['dis_p_a_amount'];
            $dis_id_proof=$_POST['dis_id_proof'];
            $dis_add_proof=$_POST['dis_add_proof'];
            $dis_acc_bank_name=$_POST['dis_acc_bank_name'];
            $dis_acc_branch=$_POST['dis_acc_branch'];
            $dis_acc_ifsc=$_POST['dis_acc_ifsc'];
            $dis_acc_no=$_POST['dis_acc_no'];
            $dis_acc_name=$_POST['dis_acc_name'];
            $dis_qualification=$_POST['dis_qualification'];
            $dis_business=$_POST['dis_business'];
            $dis_emp_name=$_POST['dis_emp_name'];
            $dis_buss_no=$_POST['dis_buss_no'];
            $dis_annual_inc=$_POST['dis_annual_inc'];
            $dis_rd_1=$_POST['dis_rd_1'];
            $dis_rd_2=$_POST['dis_rd_2'];
            $dis_rd_3=$_POST['dis_rd_3'];
            $dis_rd_4=$_POST['dis_rd_4'];
           // $dis_coupon_number=$_POST['dis_coupon_number'];
            $dis_pass_no=$_POST['dis_pass_no'];
            $dis_placement_req=$_POST['dis_placement_req'];
            $dis_sponsor_id=$_POST['dis_sponsor_id'];
            $login_id=$_SESSION['user'];
            $random=rand(100001,999999);
            $dis_company_id="pss".$random;
            $direct_id=$_POST['dis_d_person_id'];
            	$password=md5(1234);
	//echo"$password";
            
	 move_uploaded_file($_FILES['files']['tmp_name'],"../image_uploads/".$_FILES['files']['name']);
	$file="../image_uploads/".$_FILES['files']['name'];

if($_FILES['files']!=""){
$dis_image_path=$file;
    
}else{
    $dis_image_path="";
}               
            $id_parent=$conn->get_admin_dis_id($con,$dis_sponsor_id);
            $count=$conn->get_admin_num_dis_spon_id($con,$id_parent);
            if($dis_sponsor_id=='pss100000'){
               
                 $res = $conn->insert_admin_pre_distributor_detail1($con,$dis_company_id,$dis_name,$dis_fa_name,$dis_dob,$dis_gender,$dis_m_status,$dis_n_name,$dis_n_relationship,$dis_c_address,
                    $dis_p_address,$dis_district,$dis_state,$dis_city,$dis_pin,$dis_mobile,$dis_phone,$dis_email,$dis_p_a_amount,$dis_id_proof,
                    $dis_add_proof,$dis_acc_bank_name,$dis_acc_branch,
                    $dis_acc_ifsc,$dis_acc_no,$dis_acc_name,$dis_qualification,$dis_business,$dis_emp_name,$dis_buss_no,$dis_annual_inc,
                    $dis_rd_1,$dis_rd_2,$dis_rd_3,$dis_rd_4,$dis_pass_no,$dis_placement_req,$dis_sponsor_id,$login_id,$date_time,$dis_image_path,$direct_id);
                
                 if($res){
//                echo "successful";
                 $id1=$conn->get_admin_dis_id($con,$dis_company_id);
                 $id2=$conn->get_admin_dis_id($con,$dis_sponsor_id);
                 $res=$conn->insert_admin_dis_in_tree($con,$id1,$dis_name,$id2,"");
				 $res=$conn->insert_admin_login($con,$dis_company_id,$password,$login_id,$date_time);
                 if($res)
                $p++;
                 }
                 
                 
                
            }else{
            if($count==2 || $count==0){
               $status=$conn->get_admin_position_dis_spon_id($con,$id_parent,$dis_placement_req);
               if(($count==2 && $status=='blank') || $count==0){
            $res = $conn->insert_admin_pre_distributor_detail1($con,$dis_company_id,$dis_name,$dis_fa_name,$dis_dob,$dis_gender,$dis_m_status,$dis_n_name,$dis_n_relationship,$dis_c_address,
                    $dis_p_address,$dis_district,$dis_state,$dis_city,$dis_pin,$dis_mobile,$dis_phone,$dis_email,$dis_p_a_amount,$dis_id_proof,
                    $dis_add_proof,$dis_acc_bank_name,$dis_acc_branch,
                    $dis_acc_ifsc,$dis_acc_no,$dis_acc_name,$dis_qualification,$dis_business,$dis_emp_name,$dis_buss_no,$dis_annual_inc,
                    $dis_rd_1,$dis_rd_2,$dis_rd_3,$dis_rd_4,$dis_pass_no,$dis_placement_req,$dis_sponsor_id,$login_id,$date_time,$dis_image_path,$direct_id);
        
            if($res){
			$res=$conn->insert_admin_login($con,$dis_company_id,$password,$login_id,$date_time);
//                echo "successful";
                $id1=$conn->get_admin_dis_id($con,$dis_company_id);
                 $id2=$conn->get_admin_dis_id($con,$dis_sponsor_id);
                
                 if($dis_placement_req=="right" && $count==2){
                     
                  $res=$conn->update_admin_tree_by_parent($con,$id1,$id2,$dis_name);  
                }
                if($dis_placement_req=="left" && $count==2){
                  $res=$conn->update_admin_tree_by_parent($con,$id1,$id2,$dis_name);  
                }
                if($dis_placement_req=="right" && $count==0){
                    $res=$conn->insert_admin_dis_in_tree($con,$id1,$dis_name,$id2,"right");
                    $b_id=$id1.'001';
                  $res=$conn->insert_admin_dis_in_tree($con,$b_id,"blank",$id2,"left");  
                }
                if($dis_placement_req=="left" && $count==0){
                  $res=$conn->insert_admin_dis_in_tree($con,$id1,$dis_name,$id2,"left");
                    $b_id=$id1.'002';
                  $res=$conn->insert_admin_dis_in_tree($con,$b_id,"blank",$id2,"right");  
                }
                
                
                
                 
//                $res=$conn->insert_admin_dis_in_tree($con,$id1,$dis_name,$id2);
                if($res)
                $p++;
            }
               }else{
                   $msg="selected position is already filled";
               }
            }
        }
        }
        
        
        
        ?>


        <section id="main-wrapper">
            
            <script>
                $(document).ready(function(){
            $("#dis_sponsor_id").change(function(){
                cmp_id=$("#dis_sponsor_id").val();
                $("#per_name").load("get-data.php",{"cmp_id":cmp_id});
            });
            $("#dis_d_person_id").change(function(){
                cmp_id=$("#dis_d_person_id").val();
                $("#d_per_name").load("get-data.php",{"d_cmp_id":cmp_id});
            });
        });
            </script>
            
            <?php 
            if(isset($p) && $p>0){
            
                echo 'success<br>';
                echo "user id is".$dis_company_id;
//                echo $res;
            }if(isset($p) && $p<1){
               echo "failed "." ".$msg;
//                echo $res;
            }
//            echo $res;
            ?>
		<h3 class="subtitle">Dashboard</h3>
          <hr>
          <div class="row" style=" margin-left:20px; ">
		  
		<?php //  include './app-form.php'; ?> 
              
               <div class="stepwizard col-md-offset-3">
    <div class="stepwizard-row setup-panel">
          <div class="stepwizard-step">
        <a href="#step-1" type="button" class="btn btn-primary btn-circle">1</a>
        <p>Step 1</p>
      </div>
          <div class="stepwizard-step">
        <a href="#step-2" type="button" class="btn btn-default btn-circle" disabled="disabled">2</a>
        <p>Step 2</p>
      </div>
          <div class="stepwizard-step">
        <a href="#step-3" type="button" class="btn btn-default btn-circle" disabled="disabled">3</a>
        <p>Step 3</p>
      </div>
         <div class="stepwizard-step">
        <a href="#step-4" type="button" class="btn btn-default btn-circle" disabled="disabled">4</a>
        <p>Step 4</p>
      </div>
         <div class="stepwizard-step">
        <a href="#step-5" type="button" class="btn btn-default btn-circle" disabled="disabled">5</a>
        <p>Step 5</p>
      </div>

         
        </div>
  </div>
      <form role="form" action="#" method="post" enctype="multipart/form-data">
    <div class="row setup-content" id="step-1">
          <div class="col-xs-12">
        <div class="col-md-12">
            <h3> Personal Information</h3><hr>
              <div class="col-md-6 form-group">
                  <label class="control-label" for="dis_name">Name</label>
            <input  type="text"  class="form-control" placeholder="Name" id="dis_name" name="dis_name" required/>
          </div>
               <div class="col-md-6 form-group">
            <label class="control-label">Father's /Husband Name </label>
            <input  type="text"  class="form-control" placeholder="Father's /Husband Name" id="dis_fa_name" name="dis_fa_name" />
          </div>
              <div class="col-md-6 form-group">
            <label class="control-label">Date of Birth</label>
          <!--  <input type="date"  class="form-control" placeholder="Date of Birth" id="dis_dob" name="dis_dob"/> -->
			<input type="text" class="form-control" placeholder="Date of Birth" name="dis_dob"  id="example1" required>
          </div>
		  <script type="text/javascript">
            // When the document is ready
            $(document).ready(function () {
                
                $('#example1').datepicker({
                    format: "yyyy-mm-dd"
                });  
            
            });
        </script>
               <div class="col-md-6 form-group">
            <label class="control-label">Gender</label>
            <!--<input type="text"  class="form-control" placeholder="Nationality" />-->
            <select class="form-control" id="dis_gender" name="dis_gender">
                <option value="">Select
                </option>
                <option value="male">Male</option>
                <option value="female">Female</option>
            </select>
          </div>
            <div class="col-md-6 form-group" >
            <label class="control-label">Marital Status</label>
            <!--<input  type="text"  class="form-control" placeholder="Address"  />-->
            <select class="form-control" id="dis_m_status" name="dis_m_status">
                <option value="">Select
                </option>
                <option value="male">Single</option>
                <option value="female">Married</option>
            </select>
          </div>
               <div class="col-md-6 form-group">
            <label class="control-label">Nominee Name</label>
            <input  type="text"  class="form-control" placeholder="Nominee Name" id="dis_n_name"  name="dis_n_name" required/>
          </div>
              <div class="col-md-6 form-group">
            <label class="control-label">Relationship(with Nominee) </label>
            <input type="text"  class="form-control" placeholder="Relationship(with Nominee)" id="dis_n_relationship" name="dis_n_relationship"/>
          </div>
               <div class="col-md-6 form-group">
            <label class="control-label">Current Address  </label>
            <input type="text"  class="form-control" placeholder="Current Address" id="dis_c_address" name="dis_c_address"/>
          </div>
              <div class="col-md-6 form-group">
            <label class="control-label">Permanent Address  </label>
            <input  type="text"  class="form-control" placeholder="Permanent Address" id="dis_p_address" name="dis_p_address" />
          </div>
              <div class="col-md-6 form-group">
            <label class="control-label">District</label>
            <!--<input id="" type="file" class="form-control" style="border: none;">-->
            <input type="text"  class="form-control" placeholder="District" id="dis_district" name="dis_district"/>
          </div>
           
             <div class="col-md-6 form-group">
            <label class="control-label">State</label>
            <input  type="text"  class="form-control" placeholder="State" id="dis_state" name="dis_state" />
          </div>
              <div class="col-md-6 form-group">
                  <label class="control-label">City/Town/Village</label>
                  <input  type="text"  class="form-control" placeholder="City/Town/Village" id="dis_city" name="dis_city" />
          </div>
              <div class="col-md-6 form-group">
            <label class="control-label">Pin Code</label>
            <input  type="text"  class="form-control" placeholder="Pin Code" id="dis_pin" name="dis_pin" />
          </div>
               <div class="col-md-6 form-group">
            <label class="control-label">Mobile </label>
            <input type="text"  class="form-control" placeholder="Mobile" id="dis_mobile" name="dis_mobile" required/>
          </div>
              <div class="col-md-6 form-group">
            <label class="control-label">Phone</label>
            <input type="text"  class="form-control" placeholder="Phone" id="dis_phone" name="dis_phone" />
          </div>              
               <div class="col-md-6 form-group">
            <label class="control-label">Email </label>
            <input type="text"  class="form-control" placeholder="Email" id="dis_email" name="dis_email" />
          </div>
               <div class="col-md-6 form-group">
            <label class="control-label">Permanent Account number </label>
            <input type="text"  class="form-control" placeholder="Permanent Account number" id="dis_p_a_amount" name="dis_p_a_amount" required />
          </div>
              <div class="col-md-6 form-group">
            <label class="control-label">ID proof document name and number </label>
            <input  type="text"  class="form-control" placeholder="ID proof document name and number" id="dis_id_proof" name="dis_id_proof" />
          </div>
              
              <div class="col-md-6 form-group">
            <label class="control-label">Address proof document name and number </label>
            <input  type="text"  class="form-control" placeholder="Address proof document name and number" id="dis_add_proof" name="dis_add_proof" />
          </div>
             <div class="col-md-6 form-group">
            <label class="control-label">Upload Picture</label>
            <input id="" type="file" class="form-control" name="files" style="border: none;" accept="image/*">
            <!--<input type="text"  class="form-control" placeholder="Enter Last Name" />-->
          </div>
              
              
              <div class="col-md-12 form-group" style="text-align: right"> <br>
             <button class="btn btn-primary nextBtn  pull-right" type="button" >Next</button>
          </div>
              
         
              
            
            </div>
      </div>
        </div>

          <div class="row setup-content" id="step-2">
          <div class="col-xs-12">
        <div class="col-md-12">
            <h3>Account Detail</h3><hr>
                 <div class="col-md-6 form-group">
                     <label class="control-label" style="text-align: left;">Bank Name
                     </label> <input  type="text"  class="form-control" placeholder="Bank Name" id="dis_bank_name" name="dis_acc_bank_name" />
          </div>
              <div class="col-md-6 form-group">
            <label class="control-label">Branch 
            </label> <input  type="text"  class="form-control" placeholder="Branch" id="dis_branch" name="dis_acc_branch" />
          </div>
            <!--<h3> Payment Plan </h3><hr>-->
                 <div class="col-md-6 form-group">
                     <label class="control-label" style="text-align: left;">IFSC Code: </label>
                      <input  type="text"  class="form-control" placeholder="IFSC Code" id="dis_ifsc" name="dis_acc_ifsc" />
          </div>
              <div class="col-md-6 form-group">
            <label class="control-label">Account Number : </label>
             <input  type="text"  class="form-control" placeholder="Account Number" id="dis_acc_no" name="dis_acc_no" />
          </div>
             <div class="col-md-6 form-group">
            <label class="control-label">Account Name : </label>
             <input  type="text"  class="form-control" placeholder="Account Name" id="dis_acc_name" name="dis_acc_name" />
          </div>
              
              
              <div class="col-md-6 form-group" style="text-align: right"> <br>
             <button class="btn btn-primary nextBtn  pull-right" type="button" >Next</button>
          </div>
            </div>
      </div>
        </div>
          
          <div class="row setup-content" id="step-3">
          <div class="col-xs-12">
        <div class="col-md-12">
              <h3> Personal Detail </h3><hr>
                 <div class="col-md-6 form-group">
                     <label class="control-label" style="text-align: left;">Qualification:</label>
            <input  type="text"  class="form-control" placeholder="Qualification" id="dis_qualification" name="dis_qualification" />
          </div>
               <div class="col-md-6 form-group">
                     <label class="control-label" style="text-align: left;">Occupation/Business</label>
            <input  type="text"  class="form-control" placeholder="Occupation/Business" id="dis_business" name="dis_business" />
          </div>
              <div class="col-md-6 form-group">
            <label class="control-label">Name of employer:</label>
            <input type="text"  class="form-control" placeholder="Name of employer" id="dis_emp_name" name="dis_emp_name" />
          </div>
              <div class="col-md-6 form-group">
            <label class="control-label">Business contact No.</label>
            <input type="text"  class="form-control" placeholder="Business contact No." id="dis_buss_no" name="dis_buss_no" />
          </div>
               <div class="col-md-6 form-group">
                     <label class="control-label" style="text-align: left;">Annual income:</label>
            <input  type="text"  class="form-control" placeholder="Annual income" id="dis_annual_inc" name="dis_annual_inc" />
          </div>
              
              <div class="col-md-6 form-group" style="text-align: right"> <br>
             <button class="btn btn-primary nextBtn  pull-right" type="button" >Next</button>
          </div>
            </div>
      </div>
        </div>
          
           <div class="row setup-content" id="step-4">
          <div class="col-xs-12">
        <div class="col-md-12">
              <h3> Reference Detail</h3><hr>
                 <!--<div class="col-md-12 form-group">-->
                     <!--<h3>Car Parking Space:</h3><hr>-->
            <div class="col-md-6 form-group">
                     <label class="control-label" style="text-align: left;">(1):</label>
                     <input  type="text"  class="form-control" placeholder="(1)" id="dis_rd_1" name="dis_rd_1" />
          </div>
             
          
            <div class="col-md-6 form-group">
                     <label class="control-label" style="text-align: left;">(2): </label>
                     <input  type="text"  class="form-control" placeholder="(2)" id="dis_rd_2" name="dis_rd_2" />
          </div>
              
          
                  <!--<h3>Club Membership</h3><hr>-->
             <div class="col-md-6 form-group">
                     <label class="control-label" style="text-align: left;">(3): </label>
                     <input  type="text"  class="form-control" placeholder="(3)" id="dis_rd_3" name="dis_rd_3" />
          </div>
             
         
                <div class="col-md-6 form-group">
                     <label class="control-label" style="text-align: left;">(4)</label>
            <input  type="text"  class="form-control" placeholder="(4)" id="dis_rd_4" name="dis_rd_4" />
          </div> 
        <!--</div>-->
              
              
            
             
              <div class="col-md-12 form-group" style="text-align: right"> <br>
           <button class="btn btn-primary nextBtn  pull-right" type="button" >Next</button>
          </div>
            </div>
      </div>
        </div>
          
          
          
          
          <div class="row setup-content" id="step-5">
          <div class="col-xs-12">
        <div class="col-md-12">
              <h3> Other Detail</h3><hr>
                 <!--<div class="col-md-12 form-group">-->
                     <!--<h3>Car Parking Space:</h3><hr>-->
            <div class="col-md-6 form-group">
                     <label class="control-label" style="text-align: left;">Passport number(in case you have):</label>
                     <input  type="text"  class="form-control" placeholder="Passport number(in case you have)" id="dis_pass_no" name="dis_pass_no" />
          </div>
             
          
            <div class="col-md-6 form-group">
                <label class="control-label" style="text-align: left;">Placement Request: </label><br>
                     <!--<input  type="text"  class="form-control" placeholder="Placement Request" id="dis_placement_req" name="dis_placement_req" />-->
                     <div class="col-md-6 form-group">
                         <label class="control-label" style="text-align: left;">Left: <input  type="radio" name="dis_placement_req" id="dis_placement_req" value="left" required/></label>
          </div> 
          <div class="col-md-6 form-group">
                     <label class="control-label" style="text-align: left;">Right: <input  type="radio" name="dis_placement_req" value="right" id="dis_placement_req"/></label>
          </div> 
          </div>
              
          
                  <h3>Sponsor's Details</h3><hr>
             <div class="col-md-6 form-group">
                     <label class="control-label" style="text-align: left;">Sponsor's Id: </label>
                     <input  type="text"  class="form-control" placeholder="Sponsor's Id" id="dis_sponsor_id" name="dis_sponsor_id" required/>
          </div>
             
         
                <div class="col-md-6 form-group" id="per_name">
                     <label class="control-label" style="text-align: left;">Sponsor's Name</label>
            <input  type="text"  class="form-control" placeholder="Sponsor's Name" id="dis_sponsor_name" name="dis_sponsor_name"   />
          </div> 
                   <div class="col-md-6 form-group">
                     <label class="control-label" style="text-align: left;">Direct Person's Id: </label>
                     <input  type="text"  class="form-control" placeholder="Direct Person's Id" id="dis_d_person_id" name="dis_d_person_id" required/>
          </div>
             
         
                <div class="col-md-6 form-group" id="d_per_name">
                     <label class="control-label" style="text-align: left;">Direct Person's Name</label>
            <input  type="text"  class="form-control" placeholder="Direct Person's Name" id="dis_d_person_name" name="dis_d_person_name"   />
          </div> 
                  
                  
                  
                  <div class="col-md-6 form-group">
                     <label class="control-label" style="text-align: left;">V.B. Code</label>
                  <input  type="text"  class="form-control" placeholder="V.B. Code" id="vb_check" name="vb_code"  required />
                 <span id="get_vb_code"></span>
				 </div>
				 
				  <div class="col-md-6 form-group">
              <br><br><br><br>
          </div> 
        <!--</div>-->

              <div class="col-md-12 form-group" style="text-align: right"> <br>
                  <button class="btn btn-success pull-right" name="dis_form" type="submit">Submit</button>
          </div>
            </div>
      </div>
        </div>

  </form>
       
              
         <script type="text/javascript">
  $(document).ready(function () {
  var navListItems = $('div.setup-panel div a'),
		  allWells = $('.setup-content'),
		  allNextBtn = $('.nextBtn');

  allWells.hide();

  navListItems.click(function (e) {
	  e.preventDefault();
	  var $target = $($(this).attr('href')),
			  $item = $(this);

	  if (!$item.hasClass('disabled')) {
		  navListItems.removeClass('btn-primary').addClass('btn-default');
		  $item.addClass('btn-primary');
		  allWells.hide();
		  $target.show();
		  $target.find('input:eq(0)').focus();
	  }
  });

  allNextBtn.click(function(){
	  var curStep = $(this).closest(".setup-content"),
		  curStepBtn = curStep.attr("id"),
		  nextStepWizard = $('div.setup-panel div a[href="#' + curStepBtn + '"]').parent().next().children("a"),
		  curInputs = curStep.find("input[type='text'],input[type='url'],textarea[textarea]"),
		  isValid = true;

	  $(".form-group").removeClass("has-error");
	  for(var i=0; i<curInputs.length; i++){
		  if (!curInputs[i].validity.valid){
			  isValid = false;
			  $(curInputs[i]).closest(".form-group").addClass("has-error");
		  }
	  }

	  if (isValid)
		  nextStepWizard.removeAttr('disabled').trigger('click');
  });

  $('div.setup-panel div a.btn-primary').trigger('click');
});
  </script> 
       
	    </div>

       <script>
            $(document).ready(function() {
                $("#vb_check").blur(function() {
				alert("This input field has lost its focus.");
                    var user = $("#vb_check").val();
					if(user=="")
					{
						$("#get_vb_code").load('get-data.php');
						}
						else
						{
                    $("#get_vb_code").load('get-data.php', {"vb_check_code": user});
						}
                });
            });
       </script>





       </section>


<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<div class="offline-ui offline-ui-up"><div class="offline-ui-content"></div><a href="" class="offline-ui-retry"></a>
</div>
</body>
</html>
<?php
 } 
?>