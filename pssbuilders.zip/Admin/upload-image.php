<?php
session_start();
if(!isset($_SESSION['user']))
{
	header("Location: index.php");
}
else
{
?>
<!DOCTYPE html>
<!-- saved from url=(0038)http://flatter.cloudtub.com/index.html -->
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Dashboard</title>
<meta name="description" content="Flatter - Flat Admin Theme">
<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/layout.css">
<link rel="stylesheet" href="css/style3.css">
<script type="text/javascript" src="js/jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.10.4.custom.min.js"></script>
</head>
<body id="body">

		<!-- Header -->
		<?php include './header.php'; ?>

       <?php include './left-menu.php'; ?>
		<!-- Header -->
		<?php
$valid_formats = array("jpg", "png", "gif", "bmp");
$path = "../image_uploads/"; // Upload directory
$img_path="image_uploads/";
$count = 0;

if(isset($_POST) and $_SERVER['REQUEST_METHOD'] == "POST"){
	// Loop $_FILES to execute all files
	foreach ($_FILES['files']['name'] as $f => $name) { 
	    if ($_FILES['files']['error'][$f] == 4) {
	        continue; // Skip file if any error found
			    
	    }	       

	        else{ // No error found! Move uploaded files 
	            if(move_uploaded_file($_FILES["files"]["tmp_name"][$f], $path.$name)) {
	            $count++; // Number of successfully uploaded files
				$image_title=$_POST['upload_image'];
	            $upload_type=$_POST['upload_type'];
				$upload_address=$_POST['address'];
	            $upload_path=$img_path.$name;
			    $res = $conn->insert_admin_image($con,$image_title,$upload_address,$upload_path,$upload_type,$upload_type);
	            }
	        }
	}
}
?>
<section id="main-wrapper">
		<h3 class="subtitle">Dashboard</h3>
          <hr>

		  <div class="row">
			  <div class="col-md-12">
				  	<div class="panel panel-default">
					  <div class="panel-heading">
					    <h3 class="panel-title"><strong>Image Upload</strong></h3>
						
					    			<?php
		# error messages
		if (isset($message)) {
			foreach ($message as $msg) {
				//printf("<p class='status'>%s</p></ br>\n", $msg);
				printf("<br><div class='alert alert-danger'>
              <strong>%s</strong></div>\n", $msg);
			}
		}
		# success message
		if($count !=0){
			//printf("<p class='status'>%d files added successfully!</p>\n", $count);
			printf("<br><div class='alert alert-success'>
           <strong> %d files Uploaded successfully!</strong></div>\n", $count); 
		}
		//$max_file_size = 1024*2048; //2mb
		//echo"$max_file_size";
		?>


		<p align="center"><strong>Valid image formats jpg, png, gif</strong></p>	
					  </div>
					  <div class="panel-body">
					  <form method="POST" enctype="multipart/form-data" name="image_upload">
						<table class="table">
					        <tr>
							  <td><strong>Image Upload Type</strong></td>
							  <td>
							  <select name="upload_type" class="form-control" required="required">
							  <option value="">Select Image Upload Type</option>
							  <option value="Legals">Legals</option>
							  <option value="Bankers">Bankers</option>
							  <option value="Event">Events</option>
							  <option value="Branch">Branch</option>
							  <option value="Picture_gallery">Picture Gallery</option>
							  </select>
							  </td>
					        </tr>
					        <tr>
							  <td><strong>Image Upload</strong></strong></td>
							  <td>
							 <input type="file" name="files[]" multiple="multiple" accept="image/*" required="required">
							  </td>
					        </tr>
							 <tr>
							  <td><strong>Enter Your Title</strong></td>
							  <td>
							 <input type="text" name="upload_image" class="form-control" required="required">
							  </td>
					        </tr>
							 <tr>
							  <td><strong>Enter Description</strong></td>
							  <td>
							 <textarea rows="5" name="address" class="form-control"></textarea>
							  </td>
					        </tr>
							 <tr>
							  <td></td>
							  <td>
<button type="submit" name="btn_upload" class="btn btn-info" style="background-color:#3ba0ff;"><i class="fa fa-upload"></i> Upload</button>
<button type="reset" name="cancel" class="btn btn-info" style="background-color:#3ba0ff;"><i class="fa fa-refresh"></i> Reset</button>
							  </td>
					        </tr>
					    </table>
						</form>
					  </div>
					</div>
				</div>
</div>

				

</section>


<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<div class="offline-ui offline-ui-up"><div class="offline-ui-content"></div><a href="" class="offline-ui-retry"></a>
</div>
</body>
</html>
<?php
 } 
?>