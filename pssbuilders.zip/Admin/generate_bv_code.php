<?php
session_start();
if(!isset($_SESSION['user']))
{
	header("Location: index.php");
}
else
{
?>
<!DOCTYPE html>
<!-- saved from url=(0038)http://flatter.cloudtub.com/index.html -->
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Dashboard</title>
<meta name="description" content="Flatter - Flat Admin Theme">
<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/layout.css">
<link rel="stylesheet" href="css/style3.css">
<script type="text/javascript" src="js/jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.10.4.custom.min.js"></script>
<style>
.imgsize
{
	height:30px; 
	width:30px;
}
</style>
</head>
<body id="body">

		<!-- Header -->
		<?php include './header.php'; ?>

       <?php include './left-menu.php'; ?>
		<!-- Header -->
                
                
                
                
                
<section id="main-wrapper">
    <?php 
                $p=0;
               $q=0;
               // if(isset($_POST['save_generate_code'])){
//                    $dis_id=$_POST['dis_id'];
//                    $user_bv=$_POST['user_bv'];
//                    if($dis_id!=""){
//                                $res=$conn->update_admin_distributor_bv($con,$dis_id,$user_bv);
//                                if($res){ $p++;
//                                   echo "<script>$(document).ready(function(){ $('#msg_su').html('<strong>Success!</strong> B.V. Alloted'); });</script>";
//                                }else{ $q++;
//                                    echo "<script>$(document).ready(function(){ $('#msg').html('<strong>Error!</strong>Sql Error'); });</script>";
//                                }
//                            
//                    }else{ $q++;
//                        echo "<script>$(document).ready(function(){ $('#msg').html('<strong>Error!</strong> Please select distributor.'); });</script>";
//                    }
                    
                    
                   // $bv_value=$_POST['user_bv'];
                   // $bv_code=$_POST['user_gen_code'];
                   // $res=$conn->insert_admin_bv_code($con,$bv_code,$bv_value,$date_time);
//                    echo $res;
                   // if($res){ $p++;
                                 //  echo "<script>$(document).ready(function(){ $('#msg_su').html('<strong>Success!</strong> Code Saved Now you can give it to any one. It can be used one time only.'); });</script>";
                               // }else{ $q++;
                                //    echo "<script>$(document).ready(function(){ $('#msg').html('<strong>Error!</strong>Sql Error'); });</script>";
                              //  }
             //   }
                ?>
    <script>
    function generate(){
        bv=$("#user_bv").val();
        if(bv!=""){
            var float= /^\s*(\+|-)?((\d+(\.\d+)?)|(\.\d+))\s*$/;
            if(float.test(bv)){
        <?php  $ss = substr(str_shuffle(str_repeat("0123456789abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ", 5)), 0, 16); ?>
//                alert("");
    $("#user_gen_code").val("<?php echo $ss; ?>");
    $("#user_bv").css("border-color","none");
    $("#user_bv").prop("readonly",true);
    }else{ alert("Enter value should be number");
    }
    }else{
        $("#user_bv").css("border-color","red");
        $("#user_bv").attr("placeholder","please fill this field first");
    }
    }
    </script>
      
		<h3 class="subtitle">Generate BV Code</h3>
          <hr>
          <form method="post" action="#">
		  <div class="row">
			  <div class="col-md-12">
                              
                              <div class="col-md-1" style="margin-top:5px;font-size: 18px;" ><strong>B.V.</strong></div>

                              <div class="col-md-6" ><input type="text" name="user_bv" class="form-control" id="user_bv" placeholder="B.V."  ></div>
                               <div class="col-md-3" ><input type="text" name="no_of_bv" class="form-control" id="no_of_bv" placeholder="Total No of BV"  ></div>
							  <div class="col-md-2" style="margin-bottom:10px;"><input type="submit" name="generate_code"  value="Generate Code"  class="btn btn-success "></div>

                             
                              
                              
                             
                          </div>
				
                  </div></form>


				  
				  <?php 
               // $p=0;
             //   $q=0;
			
			    
                if(isset($_POST['generate_code'])){
                     $no_of_bv=$_POST['no_of_bv'];
                  $user_bv=$_POST['user_bv'];
                    if($user_bv!=""&& $no_of_bv!="")
					{
						$i=1;
			while($i<= $no_of_bv)
			{
			?>	
     <script>  var float= /^\s*(\+|-)?((\d+(\.\d+)?)|(\.\d+))\s*$/;
            if(float.test(<?php echo $user_bv?>))
			{
				</script>
				
        <?php  $ss = substr(str_shuffle(str_repeat("0123456789abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ", 5)), 0, 16); ?>
 <form method="POST"><table class="table display"><tr><td><?php echo $i ?></td><td>BV code&nbsp&nbsp<?php echo $user_bv?></td> <td><input type="text" name="user_gen_code[]" class="form-control" id="user_gen_code" placeholder="Generated Code" value="<?php echo $ss?>" readonly></td></tr></table>
		<?php// echo @$bv_code=$_POST['user_gen_code'];?>
			<script>}</script>
			<?php 
			//$bv_code=$_POST['user_gen_code'];
			$i++;	
			}
		}
		else{
			?>
			<script>alert("Please Enter value");</script>
	<?php	}
		?>
		<input type="hidden" value="<?php echo $no_of_bv ?>" name="demo1">
		<input type="hidden" value="<?php echo $user_bv ?>" name="demo2">
		 <div class="col-md-2" ><input type="submit" name="save_generate_code"  value="Save Code" class="btn btn-success" ></div>
		</form>	<?php	
			


			
			
			
			}                          
                          
      			
 ?>
          <?php 
      			if(isset($_POST['save_generate_code']))
{
	$a=0;
	$bv_code=$_POST['user_gen_code'];
	//$demo1=$_POST['demo1'];
	$demo2=$_POST['demo2'];
	
	//echo $bv_code;
	
	foreach($bv_code as $code)
	//implode(",",$code);
		$result=$conn->insert_admin_bv_code($con,$demo2,$code,$date_time);
		$a++;
		//echo "sucess";
		if($result)
		{
		?>	<div class="alert alert-success">
		<strong>SUCCESS!!</strong></div>
		<?php	
		}
		else
		{
			?>
		<div class="alert alert-warning">
		<strong>ERROR!!</strong></div>
		<?php
		}
}      
?>     
</section>


<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<div class="offline-ui offline-ui-up"><div class="offline-ui-content"></div><a href="" class="offline-ui-retry"></a>
</div>
</body>
</html>
<?php
 } 
?>