
<!DOCTYPE html>
<!-- saved from url=(0038)http://flatter.cloudtub.com/index.html -->
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Dashboard</title>
<meta name="description" content="Flatter - Flat Admin Theme">
<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/layout.css">
<link rel="stylesheet" href="css/style3.css">
<script type="text/javascript" src="js/jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.10.4.custom.min.js"></script>


<style>
.imgsize
{
	height:30px; 
	width:30px;
}
.table-container {
    border:1px solid #ccc;
    border-radius: 3px;
    width:50%;
}
.table-container table {
    width: 100%;
}
.scroll-container{
    max-height: 500px;
   
}
body {
  font-family: Arial, sans-serif;
  background: url(4.jpg);
  background-size: cover;
}

h1 {
  text-align: center;
  font-family: Tahoma, Arial, sans-serif;
  color: orange;
  margin: 100px 0;
}

.box {
  width: 20%;
  margin: 0 auto;
  background: rgba(255,255,255,0.2);
  padding: 35px;
  border: 2px solid #fff;
  border-radius: 20px/50px;
  background-clip: padding-box;
  text-align: center;
}

.button {
  font-size: 1em;
  padding: 10px;
  color: #fff;
  border: 2px solid orange;
  border-radius: 20px/50px;
  text-decoration: none;
  cursor: pointer;
  transition: all 0.3s ease-out;
}
.button:hover {
  background: orange;
}

.overlay {
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  background: rgba(0, 0, 0, 0.7);
  transition: opacity 500ms;
  visibility: hidden;
  opacity: 0;
}
.overlay:target {
  visibility: visible;
  opacity: 1;
}

.popup {
  margin: 70px auto;
  padding: 20px;
  background: #fff;
  border-radius: 5px;
  width: 30%;
  position: relative;
  transition: all 5s ease-in-out;
}

.popup h2 {
  margin-top: 0;
  color: #333;
  font-family: Tahoma, Arial, sans-serif;
}
.popup .close {
  position: absolute;
  top: 20px;
  right: 30px;
  transition: all 200ms;
  font-size: 30px;
  font-weight: bold;
  text-decoration: none;
  color: #333;
}
.popup .close:hover {
  color: orange;
}
.popup .content {
  max-height: 30%;
  
}



</style>

</head>
<body id="body">

		<!-- Header -->
		<?php include './header.php'; ?>

       <?php include './left-menu.php'; 
		   //$msg="";
		   ?>
		<!-- Header -->
		
<section id="main-wrapper">
		<h3 class="subtitle">Client Details</h3>
          <hr>

		  <div class="row">
		  <?php //echo"$msg"; ?>
			  <div class="col-md-12">
				  	<div class="panel panel-default">
					  <div class="panel-heading">
					    <h3 class="panel-title"><strong>Distributer Pre Details</strong></h3> 
					  </div>

					  <div class="panel-body">
					
					  		<table>

									<thead>
									<tr>
									    <th>S.No.</th>
										<th>Image</th>
									    <th>Distributor Company Id</th>
									    <th>Distributor Name</th>
										<th>Distributor Fathers name</th>
										<th>Distributor Dob</th>
										<th>Distributor Gender</th>
										<th>Distributor Marriage Status</th>
										<th>Distributor Nominee name</th>
										<th>Distributor relationship</th>
										<th>Distributor Current Address</th>
										<th>Distributor permanent address</th>
										<th>Distributor state</th>
										<th>Distributor city</th>
										<th>Distributor district</th>
										<th>Distributor pincode</th>
										<th>Distributor mobile No</th>
										<th>Distributor phone No.</th>
										<th>Distributor email</th>
										<th>Distributor pan</th>
										<th>Distributor id proof</th>
										<th>Distributor Address proof</th>
								
										<th>Distributor payment mode</th>
										<th>Distributor bank</th>
										<th>Distributor bank branch</th>
										<th>Distributor amount</th>
										<th>Distributor amount word</th>
										<th>Distributor account IFSC code</th>
										<th>Distributor account no.</th>
										<th>Distributor account name	</th>
										<th>Distributor qualification</th>
										<th>Distributor bussiness</th>
										<th>Distributor employee name</th>
										<th>Distributor business no.</th>
										<th>Distributor annual income</th>
										<th>Distributor ref1</th>
										<th>Distributor ref2</th>
										<th>Distributor ref3</th>
										<th>Distributor ref4</th>
										<th>Distributor passport no.</th>
										<th>Distributor placement</th>
										<th>Distributor placement id</th>
										<th>Distributor direct distributer id</th>
										<th>Distributor coupan</th>
										<th>Distributor coupan no.</th>
										<th>Distributor Shagun</th>
										<th>Distributor defence</th>
										<th>Distributor bv</th>
										<th>Distributor created date</th>
										<th>Distributor user unique code</th>
										<th>Action</th>
									</tr>
								</thead>
								<tbody>
								
									<tr>
									   
										<td><img src="../<?php echo $row['distributor_image_path']; ?>" class="imgsize" ></td>
										<td><input type="text" value="<?php echo $row['distributor_company_id']?>" name="distributor_company_id"></td>
										<td><input type="text" value="<?php echo $row['distributor_name']; ?>" name="distributor_name"></td>
										<td><input type="text" value="<?php echo $row['distributor_father_name']; ?>" name="distributor_father_name"></td>
										<td><input type="text" value="<?php echo $row['distributor_dob']; ?>" name="distributor_dob"></td>
										<td><input type="text" value="<?php echo $row['distributor_gender']; ?>" name="distributor_gender"></td>
										<td><input type="text" value="<?php echo $row['distributor_m_status']; ?>" name="distributor_m_status"></td>
										<td><input type="text" value="<?php echo $row['distributor_nominee_name']; ?>" name="distributor_nominee_name"></td>
										<td><input type="text" value="<?php echo $row['distributor_relationship']; ?>" name="distributor_relationship"></td>
										<td><input type="text" value="<?php echo $row['distributor_current_address']; ?>" name="distributor_current_address"></td>
										<td><input type="text" value="<?php echo $row['distributor_permanent_address']; ?>" name="distributor_permanent_address"></td>
										<td><input type="text" value="<?php echo $row['distributor_state']; ?>" name="distributor_state"></td>
										<td><input type="text" value="<?php echo $row['distributor_city']; ?>" name="distributor_city"></td>
										<td><input type="text" value="<?php echo $row['distributor_district']; ?>" name="distributor_district"></td>
										<td><input type="text" value="<?php echo $row['distributor_pincode']; ?>" name="distributor_pincode"></td>
										<td><input type="text" value="<?php echo $row['distributor_mobile']; ?>" name="distributor_mobile"></td>
										<td><input type="text" value="<?php echo $row['distributor_phone']; ?>" name="distributor_phone"></td>
										<td><input type="text" value="<?php echo $row['distributor_email']; ?>" name="distributor_email"></td>
										<td><input type="text" value="<?php echo $row['distributor_pan']; ?>" name="distributor_pan"></td>
										<td><input type="text" value="<?php echo $row['distributor_id_proof']; ?>" name="distributor_id_proof"></td>
										<td><input type="text" value="<?php echo $row['distributor_add_proof']; ?>" name="distributor_add_proof"></td>
								
										<td><input type="text" value="<?php echo $row['distributor_payment_mode']; ?>" name="distributor_payment_mode"></td>
										<td><input type="text" value="<?php echo $row['distributor_bank']; ?>" name="distributor_bank"></td>
										<td><input type="text" value="<?php echo $row['distributor_bank_branch']; ?>" name="distributor_bank_branch"></td>
										<td><input type="text" value="<?php echo $row['distributor_amount']; ?>" name="distributor_amount"></td>
										<td><input type="text" value="<?php echo $row['distributor_amoun_word']; ?>" name="distributor_amoun_word"></td>
										<td><input type="text" value="<?php echo $row['distributor_account_ifsc']; ?>" name="distributor_account_ifsc"></td>
										
										
										<td><input type="text" value="<?php echo $row['distributor_account_acc_no']; ?>" name="distributor_account_acc_no"></td>
										<td><input type="text" value="<?php echo $row['distributor_account_acc_name']; ?>" name="distributor_account_acc_name"></td>
										<td><input type="text" value="<?php echo $row['distributor_qualification']; ?>" name="distributor_qualification"></td>
										<td><input type="text" value="<?php echo $row['distributor_business']; ?>" name="distributor_business"></td>
										<td><input type="text" value="<?php echo $row['distributor_name_employer']; ?>" name="distributor_name_employer"></td>
										<td><input type="text" value="<?php echo $row['distributor_business_no']; ?>" name="distributor_business_no"></td>
										<td><input type="text" value="<?php echo $row['distributor_anual_income']; ?>" name="distributor_anual_income"></td>
										<td><input type="text" value="<?php echo $row['distributor_ref1']; ?>" name="distributor_ref1"></td>
										<td><input type="text" value="<?php echo $row['distributor_ref2']; ?>" name="distributor_ref2"></td>
										<td><input type="text" value="<?php echo $row['distributor_ref3']; ?>" name="distributor_ref3"></td>
										<td><input type="text" value="<?php echo $row['distributor_ref4']; ?>" name="distributor_ref4"></td>
										<td><input type="text" value="<?php echo $row['distributor_passport_no']; ?>" name="distributor_passport_no"></td>
										<td><input type="text" value="<?php echo $row['distributor_placement']; ?>" name="distributor_placement"></td>
										<td><input type="text" value="<?php echo $row['distributor_distributor_id']; ?>" name="distributor_distributor_id"></td>
										<td><input type="text" value="<?php echo $row['distributor_direct_distributor_id']; ?>" name="distributor_direct_distributor_id"></td>
										<td><input type="text" value="<?php echo $row['distributor_coupon']; ?>" name="distributor_coupon"></td>
										<td><input type="text" value="<?php echo $row['distributor_coupon_number']; ?>" name="distributor_coupon_number"></td>
										<td><input type="text" value="<?php echo $row['distributor_shagun']; ?>" name="distributor_shagun"></td>
										<td><input type="text" value="<?php echo $row['distributor_defense']; ?>" name="distributor_defense"></td>
										<td><input type="text" value="<?php echo $row['distributor_bv']; ?>" name="distributor_bv"></td>
										<td><input type="text" value="<?php echo $row['distributor_creation_date']; ?>" name="distributor_creation_date"></td>
										<td><input type="text" value="<?php echo $row['distributor_user_unique_code']; ?>" name="distributor_user_unique_code"></td>
								</tr>
													
									
									
									
								</tbody>

								</table>
</div>
					  </div>
					</div>
				</div>
				
</div>

</section>




 
<script>

   function distributor_detail(dist_id){

        $("#distributor_value").load('get-data.php', {"distributor_id": dist_id});
		//alert('welcome icon');
    }
	
</script>
		

<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<div class="offline-ui offline-ui-up"><div class="offline-ui-content"></div><a href="" class="offline-ui-retry"></a>
</div>
</body>
</html>
