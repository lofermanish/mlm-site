<?php
if(isset($_REQUEST['news_id']))
{
@include_once '../property/pss_db.php';
@$conn = new DB_con();
@$con = $conn->connection();
$news_id=$_REQUEST['news_id'];

//echo"$news_id";
		?>						
								<?php
				$res = $conn->get_admin_news_delete($con,$news_id);
				if($res)
				{
		   // header("location:news-details.php");
				echo"<script>alert('success');
                         window.location.href='news-details.php';
                        </script>";
				}
				else
				{
				echo"<script>alert('Record not deleted');<script>";
				}
				 ?>
			
								
<?php
}
?>