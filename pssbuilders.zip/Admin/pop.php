<form>
<select onchange="getval(this);">
    <option value="1">One</option>
    <option value="2">Two</option>
</select>

</form>
<script type="text/javascript">
    function getval(sel) {
       alert(sel.value);
    }
</script>
<form action="" method="post">
<input type="text" name="foo[]" value="A" />
<input type="text" name="foo[]" value="B" />
<input type="text" name="foo[]" value="C" />
<input type="text" name="foo[]" value="D" />
<input type="submit" name="submit">
</form>

<?php
if(isset($_POST['submit']))
{
  $letters = $_POST['foo'];
  foreach($letters as $q)
  echo $q;
}
?>
<?php echo $ss = substr(str_shuffle(str_repeat("0123456789abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ", 5)), 0, 16); ?>
   //alert("");