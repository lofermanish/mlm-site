<?php
session_start();
if(!isset($_SESSION['user']))
{
	header("Location: index.php");
}
else
{
?>
<!DOCTYPE html>
<!-- saved from url=(0038)http://flatter.cloudtub.com/index.html -->
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Dashboard</title>
<meta name="description" content="Flatter - Flat Admin Theme">
<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/layout.css">
<link rel="stylesheet" href="css/style3.css">
<script type="text/javascript" src="js/jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.10.4.custom.min.js"></script>
</head>
<body id="body">

		<!-- Header -->
		<?php include './header.php'; ?>

       <?php include './left-menu.php'; ?>
		<!-- Header -->
		<?php 
		if(isset($_POST['btn_upload']))
{
	
	$upload_type =$_POST['upload_type'];
	$achiever_name =$_POST['achiever_name'];
	$description =$_POST['description'];
	move_uploaded_file($_FILES['files']['tmp_name'],"../image_uploads/".$_FILES['files']['name']);
	$upload_path="image_uploads/".$_FILES['files']['name'];
	//echo"$upload_path";
	$res = $conn->insert_admin_achiever_team($con,$achiever_name,$description,$upload_type,$upload_path,$date_time);	
		if($res)
		{
			?>
			<div class="alert alert-success">
  <strong>Achiever Team Updated successfully</strong>
</div>
			<?php
		}
		else
		{
			?>
			<div class="alert alert-danger">
  <strong>Achiever Team Updated</strong>
          </div>
			<?php
		}		
	
}
?>
<section id="main-wrapper">
		<h3 class="subtitle">Upload Achiever Team Details</h3>
          <hr>

		  <div class="row">
			  <div class="col-md-12">
				  	<div class="panel panel-default">
					  <div class="panel-heading">
					    <h3 class="panel-title"><strong>Achiever Team Details</strong></h3>
						
		<p align="right"><strong><button type="button" class="btn btn-info" style="background-color:#3ba0ff;" data-toggle="modal" data-target="#myModal">Add Achiever Product</button></strong></p>	
					  </div>
					  <div class="panel-body">
					  <form method="POST" enctype="multipart/form-data" name="image_upload">
						<table class="table">
					        <tr>
							  <td><strong>Achiever Team Product Type</strong></td>
							  <td>
							  <select name="upload_type" class="form-control" required="required">
							  <option value="">Select Achiever Team Product Type</option>       
								<?php 
				 $res = $conn->get_admin_achiever_product($con);
				 while ($row = mysqli_fetch_array($res)) {
				 $achiever_product_name=$row['achiever_product_name'];
				 ?>
				 <option value="<?php echo"$achiever_product_name"; ?>"><?php echo"$achiever_product_name"; ?></option> 
				 <?php } ?>
							  </select>
							  </td>
					        </tr>
					        <tr>
							  <td><strong>Achiever Team Image Upload </strong></strong></td>
							  <td>
							 <input type="file" name="files" accept="image/*" required="required">
							  </td>
					        </tr>
							 <tr>
							  <td><strong>Achiever Team Name</strong></td>
							  <td>
							 <input type="text" name="achiever_name" class="form-control" required="required">
							  </td>
					        </tr>
							 <tr>
							  <td><strong>Achiever Team Description</strong></td>
							  <td>
							 <textarea rows="5" name="description" class="form-control"></textarea>
							  </td>
					        </tr>
							 <tr>
							  <td></td>
							  <td>
<button type="submit" name="btn_upload" class="btn btn-info" style="background-color:#3ba0ff;"><i class="fa fa-upload"></i> Upload</button>
<button type="reset" name="cancel" class="btn btn-info" style="background-color:#3ba0ff;"><i class="fa fa-refresh"></i> Reset</button>
							  </td>
					        </tr>
					    </table>
						</form>
					  </div>
					</div>
				</div>
</div>

				

</section>


  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-md">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
         <h5 class="modal-title" style="color:black;"><strong>Add Achiever Product</strong></h5>
        </div>
		<?php 
		if(isset($_POST['btn-save']))
           {
	   $achiever_product=$_REQUEST['achiever_product'];
	   $type_achiever_product='achiever_product';
	  // echo"123    $achiever_product";
	   $res = $conn->insert_admin_achiever_product($con,$achiever_product,$type_achiever_product,$date_time);
	   if($res)
	       {
	  echo" <script>alert('Product Added successfully');</script>";
		   }
           }
	?>
        <div class="modal-body">
          <p><form method="POST">
						<table class="table">
					        
							 <tr>
							  <td><strong>Enter Achiever Product</strong></td>
							  <td>
							 <input type="text" name="achiever_product" class="form-control" required="required">
							  </td>
					        </tr>
							 
							 <tr>
							  <td></td>
							  <td>
<button type="submit" name="btn-save" class="btn btn-info" style="background-color:#3ba0ff;"><i class="fa fa-upload"></i> Save</button>
<button type="reset" name="cancel" class="btn btn-info" style="background-color:#3ba0ff;"><i class="fa fa-refresh"></i> Reset</button>
							  </td>
					        </tr>
					    </table>
						</form></p>
        </div>
       
      </div>
    </div>
  </div>



<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<div class="offline-ui offline-ui-up"><div class="offline-ui-content"></div><a href="" class="offline-ui-retry"></a>
</div>
</body>
</html>
<?php
 } 
?>