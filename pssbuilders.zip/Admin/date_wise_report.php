<?php
$page = 1;
include_once '../property/pss_db.php';
$conn = new DB_con();
$con = $conn->connection();
//include_once 'property/function_list.php';
//include_once 'property/default_values.properties';
$functions = new functions();
?><?php
session_start();
if(!isset($_SESSION['user']))
{
	header("Location: index.php");
}
else
{
?>
<!DOCTYPE html>
<!-- saved from url=(0038)http://flatter.cloudtub.com/index.html -->
<html>
<head>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Dashboard</title>
<meta name="description" content="Flatter - Flat Admin Theme">
<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/layout.css">
<link rel="stylesheet" href="css/style3.css">
<script type="text/javascript" src="js/jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.10.4.custom.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/r/bs-3.3.5/jq-2.1.4,dt-1.10.8/datatables.min.css"/>
 
		<script type="text/javascript" src="https://cdn.datatables.net/r/bs-3.3.5/jqc-1.11.3,dt-1.10.8/datatables.min.js"></script>
		  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/1.2.1/css/buttons.dataTables.min.css"/>
 
		<!--<script type="text/javascript" src="https://cdn.datatables.net/r/bs-3.3.5/jqc-1.11.3,dt-1.10.8/datatables.min.js"></script>-->
                 <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.1/js/dataTables.buttons.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.1/js/buttons.flash.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js"></script>
        <script type="text/javascript" src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/pdfmake.min.js"></script>
        <script type="text/javascript" src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/vfs_fonts.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.1/js/buttons.html5.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.1/js/buttons.print.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.1/js/buttons.colVis.min.js"></script>
        <script type="text/javascript" src="js/jquery-easing.js"></script>
		<script src="js/bootstrap-datepicker.js"></script>
        <link rel="stylesheet" href="css/datepicker.css">

		<script type="text/javascript" charset="utf-8">
			$(document).ready(function() {
				$('.example').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'pageLength',
            {
                extend: 'print',
                autoPrint: false,
                title: 'Report',
                exportOptions: {
                    columns: ':visible'
                }
            },{
                extend: 'pdf',
                title: 'Report',
                exportOptions: {
                    columns: ':visible'
                }
            },{
                extend: 'excel',
                title: 'Report',
                exportOptions: {
                    columns: ':visible'
                }
            },{
                extend: 'csv',
                title: 'Report',
                exportOptions: {
                    columns: ':visible'
                }
            },{
                extend: 'copy',
                exportOptions: {
                    columns: ':visible'
                }
            },
            'colvis'
        ]
    },
    {
        dom: 'Bfrtip',
        lengthMenu: [
            [ 10, 25, 50, -1 ],
            [ '10 rows', '25 rows', '50 rows', 'Show all' ]
        ]
      
    },
    {
        dom: 'Bfrtip',
        buttons: [
            {
                extend: 'collection',
                text: 'Table control',
                buttons: [
                    'colvis'
                ]
            }
        ]
    } 
            
                );
			} );
                        
                        
                        
                        
		</script>
                <script type="text/javascript">
	// For demo to fit into DataTables site builder...
	$('.example')
		.removeClass( 'display' )
		.addClass('table table-striped table-bordered');
</script>
</head>
<body id="body">

		<!-- Header -->
		

<header class="navbar main-header" style="background-color:#3ba0ff;">
     <script src="js/jquery.blockUI.min.js" ></script>  
     <link rel="stylesheet" href="css/spinner.css">
    <a class="navbar-brand" href="">
        <span style="font-size:17px;">Pss Builders&nbsp;</span></div>
    </a>
    <ul class="nav navbar-nav navbar-left sidebar-toggle-ul">
        <li class="navbar-main hidden-lg hidden-md">
            <a href="javascript:void(0);" id="sidebar-toggle">
                <span class="meta">
                    <span class="arrow"><i class="arrow fa fa-angle-right pull-right"></i></span>
                </span>
            </a>
        </li>

        <li class="navbar-main hidden-sm hidden-xs">
            <a href="javascript:void(0);" id="sidebar-collapse">
                <span class="meta">
                    <span class="icon"><i class="fa fa-outdent" style="color:blue;"></i></span>
                </span>
            </a>
        </li>
    </ul>
<?php
	        $id=$_SESSION['user'];
            $name=$conn->get_admin_login_name($con,$id);
            $res=$conn->get_admin_distributor_detail_by_cmpny_id($con,$name);
            $row=  mysqli_fetch_array($res);
            $dis_name=$row['distributor_name'];
            $image_path=$row['distributor_image_path'];
            if($image_path=="../image_uploads/" || $image_path==""){
                $image_path="images/avatar.png";
            }
            ?>
    <ul class="nav navbar-nav navbar-right">
        <li class="dropdown icons-dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><span style="color:blue;">Company Id : <?php echo $name ?></span></a>
<!--            <ul class="dropdown-menu list-group">
                <li class="list-group-item heading"><p>Notification</p></li>
                <a href="http://flatter.cloudtub.com/index.html#" class="list-group-item"><i class="fa fa-user"></i> <p>John sent you friend request</p></a>
                <a href="http://flatter.cloudtub.com/index.html#" class="list-group-item"><i class="fa fa-envelope-o"></i> <p>Sam sent important mail</p></a>
                <a href="http://flatter.cloudtub.com/index.html#" class="list-group-item"><i class="fa fa-calendar"></i> <p>You have pending job</p></a>
                <a href="http://flatter.cloudtub.com/index.html#" class="list-group-item"><i class="fa fa-money"></i> <p>Received $1826 from client</p></a>

            </ul>-->
        </li>
            

        <li class="dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><span  style="color:blue;"><?php echo "$dis_name" ?></span> <img class="img-circle" src="<?php echo $image_path; ?>" alt="avatar"> <b class="caret"></b></a>
            <ul class="dropdown-menu">
<!--                <li><a href="http://flatter.cloudtub.com/index.html#"><i class="fa fa-globe" ></i> Notification <span class="label label-danger"> 5</span></a></li>
                <li><a href="http://flatter.cloudtub.com/index.html#"><i class="fa fa-user"></i> Profile</a></li>
                <li><a href="http://flatter.cloudtub.com/index.html#"><i class="fa fa-gear"></i> Settings</a></li>-->
                <li><a href="logout.php?logout"><i class="fa fa-share"></i> Logout</a></li>
            </ul>
        </li>
    </ul>
</header>

       <?php include './left-menu.php'; ?>
		<!-- Header -->
                
                
                
                
                
<section id="main-wrapper">
    <?php 
    if(isset($_POST['save'])){
        $payment_type=$_POST['m_payment_type'];
        $no_entries=$_POST['no_entries'];
        $amount=$_POST['amount'];
        $from=$_POST['from'];
        $to=$_POST['to'];
        $i=0;
        $commodity=$_POST['commodity'];
        foreach ($to as $val){
//            echo $val.$from[$i].$amount[$i]."<br>";
            $res=$conn->insert_admin_initial_payment_type($con,$payment_type,$commodity[$i],$amount[$i],$from[$i],$to[$i],$no_entries,$date_time);
            $i++;
        }
    }
     
    
    
                ?>
    <script>
       function get_report(){
        reward_type=$("#m_payment_type").val();
        from1=$("#from1").val();
        to1=$("#to1").val();
//        alert(reward_type);
        $("#type_info").load("payee2.php",{"paid_reward_type":reward_type,"from":from1,"to":to1});
       }
   
    </script>
      
		<h3 class="subtitle">Payment Report</h3>
          <hr>
         
          <form method="post" action="#">
		  <div class="row">
                     
	    <div class="col-sm-12">
		
		</div>
		
		<div class="col-sm-4">
		<label>From</label>
		<input type="text" name="from1" id="from1" class="form-control" required> <br></div>
		<div class="col-sm-4"></div>
		<div class="col-sm-4">
		<label>To</label>
		<input type="text" name="to1" id="to1" class="form-control" required> <br></div>
		
		<script type="text/javascript">
            // When the document is ready
            $(document).ready(function () {
                
                $('#from1').datepicker({
                    format: "yyyy-mm-dd"
                });$('#to1').datepicker({
                    format: "yyyy-mm-dd"
                });  
            
            });
        </script><div class="col-sm-12">
		<label>Payment Type</label>
        <select class="form-control" id="m_payment_type" name="m_payment_type" onchange="get_report()">
            <option value="">Select Payment Type</option>
            <option value="reward">Reward Benefit</option>
            <option value="coupon">Coupon Benefit</option>
            <option value="bonanza">Bonanza Benefit</option>
            <option value="pair income">Working Group Benefit</option>
            <option value="direct income">Direct Benefit</option>
        </select>
        
		
		<br><br><hr>
                           </div>
                      
                      <div id="type_info"><br>
                         
                          
                          
                      </div>
                      
                      <div class="col-md-12">
                          
                          
                      </div>
				
                  </div></form>
          
</section>


<!--<script type="text/javascript" src="js/bootstrap.min.js"></script>-->
<script type="text/javascript" src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<div class="offline-ui offline-ui-up"><div class="offline-ui-content"></div><a href="" class="offline-ui-retry"></a>
</div>
</body>
</html>
<?php
 } 
?>