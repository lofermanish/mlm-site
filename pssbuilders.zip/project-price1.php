<!DOCTYPE html>
<html lang="en">
<head>
  <title>PSS Builder || Home</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php include"script-css.php"; ?>
  <style>
  a:hover
  {
    color: white !important;
  }
  </style>
</head>
<body>
	<?php include"menu.php"; ?>
	 <div class="pg-opt"  style="background-color:#3ba0ff;">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h2 style="color:white !important;">Customer Zone</h2>
                </div>
                <div class="col-md-6">
                    <ol class="breadcrumb">
                        <li><a href="index.php">Home</a></li>
                        <li style="color:white !important;" class="active">Customer Zone</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
   
	<section class="slice bg-white">
        <div class="wp-section">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-sm-12">
                        <div class="wp-block default user-form">
					
                            <table class="table table-bordered">
    <thead>
      <tr>                              <th>S.No.</th>
                                        <th>Plot No.</th>
										<th>Plot Name</th>
										<th>Plot Length</th>
										<th>Plot Breadth</th>
										<th>Area</th>
										<th>Corner</th>
					
										<th>Plot Availability</th>
		</tr>
		
    </thead>
    <tbody>
      				<?php
				 
                    include_once 'property/pss_db.php';
                    $conn = new DB_con();
                    $con = $conn->connection();
                    $functions = new functions();
                    
				 $count=0;
				 $res = $conn->get_admin_get_admin_plot_details1($con);
				 while ($row = mysqli_fetch_array($res)) {
				 $plot_price_details_id=$row['plot_price_details_id'];
				 $count=$count+1;
				 ?>
	<tr class="1">
	<td><?php echo $count; ?></td>
	<td><?php echo $row['plot_price_details_plot_no']; ?></td>
	<td><?php echo $row['plot_price_details_name']; ?></td>
	<td><?php echo $row['plot_price_details_height']; ?></td>
	<td><?php echo $row['plot_price_details_width']; ?></td>
	<?php $area=$row['plot_price_details_height']*$row['plot_price_details_width']; ?>
	<td><?php echo $area; //echo $row['plot_price_details_amount']; ?></td>
	<td></td>
	<td><?php echo $row['plot_price_details_plot_availability']; ?></td>
	
	</tr>
				<?php }?>
    </tbody>
  </table>
 
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
	
    <?php include"footer.php"; ?>

</body>
</html>
