<header class="header-standard-2">     
    <!-- MAIN NAV -->
    <div class="navbar navbar-wp navbar-arrow mega-nav" role="navigation">
        <div class="container">
            <div class="navbar-header">

                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <i class="fa fa-bars icon-custom"></i>
                </button>

                <a class="navbar-brand" href="" title="Boomerang | One template. Infinite solutions">
                    <img src="images/boomerang-logo-black.png" alt="Boomerang | One template. Infinite solutions" style="height:75px; width:190px;">

                </a> </div><div align="right">
				
				<a href="verify_bv.php" ><img src="images/register.gif" style="width:150px;height:60px;"></a>
            
			
			</div>
			
			
            <div class="navbar-collapse collapse">
                <ul class="nav navbar-nav navbar-right">
                    <?php
                    include_once 'property/pss_db.php';
                    $conn = new DB_con();
                    $con = $conn->connection();
                    $functions = new functions();
                    ?>    
                    <?php
		
                    $res = $conn->get_website_parent_menu($con);
                    while ($row = mysqli_fetch_array($res)) {
                        ?>   
						
                        <li class="dropdown">
                            <a href="<?php echo $row['website_menu_link']; ?>" class="dropdown-toggle" data-toggle="dropdown"><?php echo $row['website_menu_name']; ?></a>
                        <?php
                        $menu_id = $row['website_menu_id'];
//echo"$menu_id";
                        $res_pro = $conn->get_website_sub_menu($con, $menu_id);                      
					    ?>
                            <ul class="dropdown-menu">
                            <?php
                            while ($pro_row = mysqli_fetch_array($res_pro)) {
							 $all_menu_id=$pro_row['website_menu_id'];
							 $website_menu_link=$pro_row['website_menu_link'];
					  // echo"$all_menu_id";
                                ?>
                                    <li><a href="<?php echo"$website_menu_link"; ?>"><?php echo $pro_row['website_menu_name']; ?></a></li>
                                    <?php
                                }
                                ?>
                            </ul>
                        </li>

                                <?php
                            }
                            ?>




                </ul>

            </div><!--/.nav-collapse -->
        </div>
    </div>
</header>      
<a href=" id="toTop" style="display: none;"><span id="toTopHover"></span>To Top</a>