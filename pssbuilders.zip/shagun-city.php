<!DOCTYPE html>
<html lang="en">
<head>
  <title>PSS Builder || Home</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php include"script-css.php"; ?>
  <style>
 .imgwdh
  {
    height:50px !important;
  }
    a:hover
  {
    color: white !important;
  }
  </style>
</head>
<body>
	<?php include"menu.php"; ?>
	 <div class="pg-opt"  style="background-color:#3ba0ff;">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h2 style="color:white !important;">Shagun City</h2>
                </div>
                <div class="col-md-6">
                    <ol class="breadcrumb">
                        <li><a href="index.php">Home</a></li>
                        <li style="color:white !important;" class="active">Shagun City</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

	
	 <section class="slice bg-white bb">
        <div class="wp-section estate">
            <div class="container">
                <div class="row">        
                    <div class="col-md-6">
                       <div class="row">
                            <div class="col-md-12">
                                <div class="product-gallery">
                                    <div class="primary-image">
                                        <a href="images/layout.jpg" class="theater" rel="group" hidefocus="true">
                                            <img src="images/layout.jpg" class="img-responsive" alt="">
                                        </a>
                                    </div>
                                    <div class="thumbnail-images">
                                        <a href="images/layout1.jpg" class="theater" rel="group" hidefocus="true">
                                            <img src="images/layout1.jpg" alt="" class="imgwdh">
                                        </a>
                                        <a href="images/layout2.jpg" class="theater" rel="group" hidefocus="true">
                                            <img src="images/layout2.jpg" alt="" class="imgwdh">
                                        </a>
                                        <a href="images/layout3.jpg" class="theater" rel="group" hidefocus="true">
                                            <img src="images/layout3.jpg" alt="" class="imgwdh">
                                        </a>
                                        <a href="images/layout4.jpg" class="theater" rel="group" hidefocus="true">
                                            <img src="images/layout4.jpg" alt="" class="imgwdh">
                                        </a>
										<a href="images/layout5.jpg" class="theater" rel="group" hidefocus="true">
                                            <img src="images/layout5.jpg" alt="" class="imgwdh">
                                        </a>
										<a href="images/layout.jpg" class="theater" rel="group" hidefocus="true">
                                            <img src="images/layout.jpg" alt="" class="imgwdh">
                                        </a>
                                    </div>
                                </div>
                            </div>
                       
                        </div>

                       
                    </div>
                        <div class="col-md-6">
                                <div class="product-info">
                                   
                                    <div class="wp-block property list no-border">
                                        <div class="wp-block-content clearfix">
                                            
                                            <h4 class="content-title">LAY OUT OF "SHAGUN CITY" AT CHAKULI NEAR TSM HOSPITAL, AMAUSI RAILWAY STATION</h4>
                                            <p class="description mb-15"></p>
We offer an exhaustive range of multiple Home and commercialbase area and property. Choose a refined search option according to your requirements from all city and sub-city in India. Search your desired property by Entering your needs.
                                        </div>
                                        
                                    </div>
                                </div>
                        </div>
                        </div>
                </div>
            </div>
        </div>
    </section>

    <?php include"footer.php"; ?>

</body>
</html>
