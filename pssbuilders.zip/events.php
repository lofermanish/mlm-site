<!DOCTYPE html>
<html lang="en">
<head>
  <title>PSS Builder || Home</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php include"script-css.php"; ?>
  <link rel="stylesheet" href="css/bootstrap-override.css">
 <link rel="stylesheet" href="css/blueimp-gallery.min.css">
 <link rel="stylesheet" href="css/bootstrap-image-gallery.min.css">
  <style>
  a:hover
  {
    color: white !important;
  }
  .imgsize
  {
   height:200px;
   width:220px;
  }
  </style>
  <script>

   function pic_detail(img_date){
        //alert(img_date);
		//var user = $("#position").val();
        $("#hello").load('event_image_details.php', {"picture_date": img_date});
    }

</script>
</head>
<body>
	<?php include"menu.php"; ?>
	 <div class="pg-opt"  style="background-color:#3ba0ff;">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h2 style="color:white !important;">Event</h2>
                </div>
                <div class="col-md-6">
                    <ol class="breadcrumb">
                        <li><a href="index.php">Home</a></li>
                        <li style="color:white !important;" class="active">Event</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
	

<section class="slice light-gray bb">
        <div class="wp-section">
            <div class="container">
                <div class="row" id="hello">
				<?php
				 $res = $conn->get_website_event_image($con);
				 while ($row = mysqli_fetch_array($res)) { 
				 $picture_date= $row['image_details_date'];
				 ?>
				  <div class="col-lg-3 col-md-3">
                         <div class="wp-block hero">
						 <section class="panel panel-default">
                         <div class="thmb-img">
                         <a href="#" onclick="pic_detail('<?php echo $picture_date; ?>')">
						 <div style="color:#3ba0ff; font-size:18px;"><?php echo $row['image_details_title']; ?></div>
						 <hr>
						 <img src="<?php echo $row['image_details_path']; ?>" class="imgsize"></a>
						 <hr>
						 <div style="color:black; font-size:12px;"><?php echo $row['image_details_address'];?> </div>						 
                </div> 
</section>
                             </div>
							
                             </div>
				 <?php }?>
				 </div>
			</div>
		</div>



					  <!-- The Bootstrap Image Gallery lightbox, should be a child element of the document body -->
							<div id="blueimp-gallery" class="blueimp-gallery">
							    <!-- The container for the modal slides -->
							    <div class="slides"></div>
							    
							    <!-- The modal dialog, which will be used to wrap the lightbox content -->
							    <div class="modal fade">
							        <div class="modal-dialog">
							            <div class="modal-content">
							                <div class="modal-header">
							                    <button type="button" class="close" aria-hidden="true">&times;</button>
							                    <h4 class="modal-title"></h4>
							                </div>
							                <div class="modal-body next"></div>
							                <div class="modal-footer">
							                    <button type="button" class="btn btn-default pull-left prev">
							                        <i class="glyphicon glyphicon-chevron-left"></i>
							                        Previous
							                    </button>
							                    <button type="button" class="btn btn-primary next">
							                        Next
							                        <i class="glyphicon glyphicon-chevron-right"></i>
							                    </button>
							                </div>
							            </div>
							        </div>
							    </div>
							</div>

</div>


			
</section>

<script type="text/javascript" src="js/jquery.blueimp-gallery.min.js"></script>
<script type="text/javascript" src="js/bootstrap-image-gallery.min.js"></script>
<div class="offline-ui offline-ui-up"><div class="offline-ui-content"></div><a href="" class="offline-ui-retry"></a></div>
    <?php include"footer.php"; ?>

</body>
</html>
