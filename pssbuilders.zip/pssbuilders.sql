-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 08, 2016 at 01:47 PM
-- Server version: 5.7.9
-- PHP Version: 5.6.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pssbuilders`
--

-- --------------------------------------------------------

--
-- Table structure for table `achiever_poject_details`
--

DROP TABLE IF EXISTS `achiever_poject_details`;
CREATE TABLE IF NOT EXISTS `achiever_poject_details` (
  `achiever_team_id` int(11) NOT NULL AUTO_INCREMENT,
  `achiever_team_name` varchar(100) NOT NULL,
  `achiever_team_description` longtext NOT NULL,
  `achiever_team_type` varchar(100) NOT NULL,
  `achiever_team_image` varchar(100) NOT NULL,
  `achiever_team_date` datetime NOT NULL,
  PRIMARY KEY (`achiever_team_id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `achiever_poject_details`
--

INSERT INTO `achiever_poject_details` (`achiever_team_id`, `achiever_team_name`, `achiever_team_description`, `achiever_team_type`, `achiever_team_image`, `achiever_team_date`) VALUES
(11, 'Manu Singh', '5437567656', 'kallu', 'image_uploads/08.jpg', '2016-04-14 12:27:24'),
(8, 'Ranjana', 'hello', 'Samsung Mobile', 'image_uploads/avatar.jpg', '2016-04-11 18:44:59'),
(9, 'rajan', '234354657', 'Mobile', 'image_uploads/logo-200.png', '2016-04-11 18:45:31'),
(10, 'Manu Singh4575667', '67576756744564756', 'Mobile', 'image_uploads/09.jpg', '2016-04-14 12:22:11'),
(12, 'hello Kedar', '547568686786', 'hellohello', 'image_uploads/ajax-loader.gif', '2016-04-14 16:49:15');

-- --------------------------------------------------------

--
-- Table structure for table `achiever_product`
--

DROP TABLE IF EXISTS `achiever_product`;
CREATE TABLE IF NOT EXISTS `achiever_product` (
  `achiever_product_id` int(11) NOT NULL AUTO_INCREMENT,
  `achiever_product_name` varchar(100) NOT NULL,
  `achiver_product_date` datetime NOT NULL,
  PRIMARY KEY (`achiever_product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `achiever_product`
--

INSERT INTO `achiever_product` (`achiever_product_id`, `achiever_product_name`, `achiver_product_date`) VALUES
(1, 'Mobile', '2016-04-08 17:53:41'),
(2, 'Laptop', '2016-04-08 18:42:41'),
(3, 'notebook', '2016-04-08 18:44:03');

-- --------------------------------------------------------

--
-- Table structure for table `achiever_project`
--

DROP TABLE IF EXISTS `achiever_project`;
CREATE TABLE IF NOT EXISTS `achiever_project` (
  `achiever_product_id` int(11) NOT NULL AUTO_INCREMENT,
  `achiever_product_name` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  `achiver_product_date` datetime NOT NULL,
  PRIMARY KEY (`achiever_product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=41 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `achiever_project`
--

INSERT INTO `achiever_project` (`achiever_product_id`, `achiever_product_name`, `type`, `achiver_product_date`) VALUES
(1, 'Mobile', 'achiever_product', '2016-04-08 17:53:41'),
(2, 'Laptop', 'achiever_product', '2016-04-08 18:42:41'),
(3, 'notebook', 'achiever_product', '2016-04-08 18:44:03'),
(4, 'Samsung Mobile', 'achiever_product', '2016-04-11 12:52:12'),
(40, 'kedar', 'Diwakar Inclave City', '2016-04-14 19:54:55'),
(39, 'SaaS', 'Diwakar Inclave City', '2016-04-14 19:53:22');

-- --------------------------------------------------------

--
-- Table structure for table `achiever_team`
--

DROP TABLE IF EXISTS `achiever_team`;
CREATE TABLE IF NOT EXISTS `achiever_team` (
  `achiever_team_id` int(11) NOT NULL AUTO_INCREMENT,
  `achiever_team_name` varchar(100) NOT NULL,
  `achiever_team_description` varchar(255) NOT NULL,
  `achiever_team_type` varchar(100) NOT NULL,
  `achiever_team_image` varchar(100) NOT NULL,
  `achiever_team_date` datetime NOT NULL,
  PRIMARY KEY (`achiever_team_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `achiever_team`
--

INSERT INTO `achiever_team` (`achiever_team_id`, `achiever_team_name`, `achiever_team_description`, `achiever_team_type`, `achiever_team_image`, `achiever_team_date`) VALUES
(1, 'rajan', 'hello', 'image_uploads/AppleLogo.png', 'Mobile', '2016-04-08 18:42:29'),
(2, 'Manu Singh', 'hello', 'image_uploads/IOS-icon-1105160809.png', 'notebook', '2016-04-08 18:44:30');

-- --------------------------------------------------------

--
-- Table structure for table `applicant_detail`
--

DROP TABLE IF EXISTS `applicant_detail`;
CREATE TABLE IF NOT EXISTS `applicant_detail` (
  `applicant_id` int(10) NOT NULL AUTO_INCREMENT,
  `applicant_name` varchar(100) NOT NULL,
  `applicant_fa_name` varchar(100) NOT NULL,
  `applicant_dob` date NOT NULL,
  `applicant_nationality` varchar(100) NOT NULL,
  `applicant_address` varchar(255) NOT NULL,
  `applicant_pincode` varchar(10) NOT NULL,
  `applicant_tel_no` varchar(20) NOT NULL,
  `applicant_fax_no` varchar(20) NOT NULL,
  `applicant_email` varchar(100) NOT NULL,
  `applicant_image_path` varchar(150) NOT NULL,
  `applicant_mobile_no` varchar(15) NOT NULL,
  `applicant_qualification` varchar(100) NOT NULL,
  `applicant_bussiness` varchar(100) NOT NULL,
  `applicant_employeer_name` varchar(100) NOT NULL,
  `applicant_business_no` varchar(20) NOT NULL,
  `applicant_annual_inc` varchar(50) NOT NULL,
  `applicant_fund_detail` varchar(255) NOT NULL,
  `applicant_scnd_name` varchar(100) NOT NULL,
  `applicant_scnd_fa_name` varchar(100) NOT NULL,
  `applicant_scnd_dob` date NOT NULL,
  `applicant_scnd_nationality` varchar(50) NOT NULL,
  `applicant_scnd_pincode` varchar(12) NOT NULL,
  `applicant_scnd_tel_no` varchar(20) NOT NULL,
  `applicant_scnd_address` varchar(255) NOT NULL,
  `applicant_scnd_fax_no` varchar(20) NOT NULL,
  `applicant_scnd_email` varchar(100) NOT NULL,
  `applicant_scnd_mobile_no` varchar(20) NOT NULL,
  `applicant_residential` varchar(20) NOT NULL,
  `applicant_payment_plan` varchar(20) NOT NULL,
  `applicant_property_type` varchar(100) NOT NULL,
  `applicant_sector` varchar(100) NOT NULL,
  `applicant_pocket_no` varchar(100) NOT NULL,
  `applicant_unit_no` varchar(100) NOT NULL,
  `applicant_floor` varchar(100) NOT NULL,
  `applicant_requirement_area` varchar(100) NOT NULL,
  `applicant_prop_base_rate` varchar(100) NOT NULL,
  `applicant_prop_basic_sale_price` varchar(100) NOT NULL,
  `applicant_car_parking` varchar(20) NOT NULL,
  `applicant_storage_space` varchar(20) NOT NULL,
  `applicant_club` varchar(20) NOT NULL,
  `applicant_acc_no` varchar(100) NOT NULL,
  `applicant_agent_name` varchar(100) NOT NULL,
  `applicant_agent_phone_no` varchar(20) NOT NULL,
  `applicant_login_id` int(10) NOT NULL,
  `applicant_creation_date` datetime NOT NULL,
  PRIMARY KEY (`applicant_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `applicant_detail`
--

INSERT INTO `applicant_detail` (`applicant_id`, `applicant_name`, `applicant_fa_name`, `applicant_dob`, `applicant_nationality`, `applicant_address`, `applicant_pincode`, `applicant_tel_no`, `applicant_fax_no`, `applicant_email`, `applicant_image_path`, `applicant_mobile_no`, `applicant_qualification`, `applicant_bussiness`, `applicant_employeer_name`, `applicant_business_no`, `applicant_annual_inc`, `applicant_fund_detail`, `applicant_scnd_name`, `applicant_scnd_fa_name`, `applicant_scnd_dob`, `applicant_scnd_nationality`, `applicant_scnd_pincode`, `applicant_scnd_tel_no`, `applicant_scnd_address`, `applicant_scnd_fax_no`, `applicant_scnd_email`, `applicant_scnd_mobile_no`, `applicant_residential`, `applicant_payment_plan`, `applicant_property_type`, `applicant_sector`, `applicant_pocket_no`, `applicant_unit_no`, `applicant_floor`, `applicant_requirement_area`, `applicant_prop_base_rate`, `applicant_prop_basic_sale_price`, `applicant_car_parking`, `applicant_storage_space`, `applicant_club`, `applicant_acc_no`, `applicant_agent_name`, `applicant_agent_phone_no`, `applicant_login_id`, `applicant_creation_date`) VALUES
(1, 'dgs', 'jkjhi', '2016-12-31', 'jkhkj', 'jkhjk', '2546', 'jhjk', 'hk', 'hghj', '../image_uploads/defence-inclave2.jpg', 'kjhk', 'khjh', 'khkj', 'kjhkjh', 'jkhkjh', '65454', '54654', 'gjh', 'jkjh', '2016-12-31', 'jhjk', '54654', '54564', '545', 'hjgjk', 'kjhjk', 'jhkj', 'Residential Indian', 'Installment', 'hbgjkh', 'kjhjh', 'jkhj', 'khkjhk', 'jhkjh', 'jhjk', 'khkjh', 'kjhkjh', 'covered', 'Yes', 'Yes', '254154', 'hjjh', '54564', 16, '2016-04-04 18:24:20');

-- --------------------------------------------------------

--
-- Table structure for table `bv_code`
--

DROP TABLE IF EXISTS `bv_code`;
CREATE TABLE IF NOT EXISTS `bv_code` (
  `bv_code_id` int(10) NOT NULL AUTO_INCREMENT,
  `bv_code_number` varchar(100) NOT NULL,
  `bv_code_value` varchar(10) DEFAULT NULL,
  `bv_code_use` int(10) NOT NULL DEFAULT '0',
  `bv_code_used_by` int(10) NOT NULL,
  `bv_code_used_date` datetime NOT NULL,
  `bv_code_creation_date` datetime NOT NULL,
  PRIMARY KEY (`bv_code_id`),
  UNIQUE KEY `bv_code_number` (`bv_code_number`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bv_code`
--

INSERT INTO `bv_code` (`bv_code_id`, `bv_code_number`, `bv_code_value`, `bv_code_use`, `bv_code_used_by`, `bv_code_used_date`, `bv_code_creation_date`) VALUES
(1, '8P0ZumjrdUnAS7D0', '1', 1, 2, '2016-04-15 14:54:13', '2016-04-13 15:22:49'),
(2, 'X4YRiz569g89A3WF', '2', 1, 1, '2016-04-13 15:27:59', '2016-04-13 15:27:52'),
(3, '0k5atxDfnoC6vjEr', '3.5', 1, 3, '2016-04-18 14:12:12', '2016-04-18 14:11:38'),
(4, 'H6xi829cI3915Fh7', '5', 1, 5, '2016-04-18 14:29:58', '2016-04-18 14:29:29');

-- --------------------------------------------------------

--
-- Table structure for table `career_details`
--

DROP TABLE IF EXISTS `career_details`;
CREATE TABLE IF NOT EXISTS `career_details` (
  `career_details_id` int(11) NOT NULL AUTO_INCREMENT,
  `career_details_position` varchar(50) NOT NULL,
  `career_details_qualification` varchar(200) NOT NULL,
  `career_details_resume` varchar(100) NOT NULL,
  `career_details_email` varchar(100) NOT NULL,
  `career_details_phone` varchar(15) NOT NULL,
  `career_details_address` varchar(250) NOT NULL,
  `career_details_date` datetime NOT NULL,
  PRIMARY KEY (`career_details_id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `client_payment_mode`
--

DROP TABLE IF EXISTS `client_payment_mode`;
CREATE TABLE IF NOT EXISTS `client_payment_mode` (
  `client_payment_mode_id` int(10) NOT NULL AUTO_INCREMENT,
  `client_payment_mode_mode` varchar(30) NOT NULL,
  `client_payment_mode_field1` varchar(255) NOT NULL COMMENT 'cash:-accepted by. cheque: cheque no. b.t: transaction no. dd: dd no',
  `client_payment_mode_field2` varchar(255) NOT NULL COMMENT 'cash:-paid by. cheque: bank name b.t: transaction account. dd:  bank name',
  `client_payment_mode_field3` varchar(255) NOT NULL COMMENT 'cheque: acc holder name. dd: genrated by',
  `client_payment_mode_date` date NOT NULL,
  `client_payment_mode_date_time` datetime NOT NULL,
  `client_payment_mode_login_id` int(10) NOT NULL,
  PRIMARY KEY (`client_payment_mode_id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `client_payment_type`
--

DROP TABLE IF EXISTS `client_payment_type`;
CREATE TABLE IF NOT EXISTS `client_payment_type` (
  `client_payment_type_id` int(10) NOT NULL AUTO_INCREMENT,
  `client_payment_type_type` varchar(100) NOT NULL,
  `client_payment_type_commodity` varchar(100) NOT NULL,
  `client_payment_type_price` double NOT NULL,
  `client_payment_type_from` varchar(100) NOT NULL,
  `client_payment_type_to` varchar(100) NOT NULL,
  `client_payment_type_no_of_entries` int(10) NOT NULL,
  `client_payment_type_date` datetime NOT NULL,
  PRIMARY KEY (`client_payment_type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `distributor_detail`
--

DROP TABLE IF EXISTS `distributor_detail`;
CREATE TABLE IF NOT EXISTS `distributor_detail` (
  `distributor_id` int(10) NOT NULL AUTO_INCREMENT,
  `distributor_company_id` varchar(50) NOT NULL,
  `distributor_name` varchar(100) NOT NULL,
  `distributor_father_name` varchar(100) NOT NULL,
  `distributor_dob` date NOT NULL,
  `distributor_gender` varchar(20) NOT NULL,
  `distributor_m_status` varchar(30) NOT NULL,
  `distributor_nominee_name` varchar(100) NOT NULL,
  `distributor_relationship` varchar(100) NOT NULL,
  `distributor_current_address` varchar(255) NOT NULL,
  `distributor_permanent_address` varchar(255) NOT NULL,
  `distributor_district` varchar(100) NOT NULL,
  `distributor_state` varchar(100) NOT NULL,
  `distributor_city` varchar(100) NOT NULL,
  `distributor_pincode` varchar(20) NOT NULL,
  `distributor_mobile` varchar(20) NOT NULL,
  `distributor_phone` varchar(20) NOT NULL,
  `distributor_email` varchar(100) NOT NULL,
  `distributor_pan` varchar(100) NOT NULL,
  `distributor_id_proof` varchar(255) NOT NULL,
  `distributor_add_proof` varchar(255) NOT NULL,
  `distributor_image_path` varchar(255) NOT NULL,
  `distributor_payment_mode` varchar(100) NOT NULL,
  `distributor_bank` varchar(150) NOT NULL,
  `distributor_bank_branch` varchar(150) NOT NULL,
  `distributor_amount` double NOT NULL,
  `distributor_amoun_word` varchar(150) NOT NULL,
  `distributor_account_bank` varchar(150) NOT NULL,
  `distributor_account_branch` varchar(150) NOT NULL,
  `distributor_account_ifsc` varchar(150) NOT NULL,
  `distributor_account_acc_no` varchar(150) NOT NULL,
  `distributor_account_acc_name` varchar(200) NOT NULL,
  `distributor_qualification` varchar(150) NOT NULL,
  `distributor_business` varchar(150) NOT NULL,
  `distributor_name_employer` varchar(150) NOT NULL,
  `distributor_business_no` varchar(20) NOT NULL,
  `distributor_anual_income` varchar(30) NOT NULL,
  `distributor_ref1` varchar(150) NOT NULL,
  `distributor_ref2` varchar(150) NOT NULL,
  `distributor_ref3` varchar(150) NOT NULL,
  `distributor_ref4` varchar(150) NOT NULL,
  `distributor_passport_no` varchar(150) NOT NULL,
  `distributor_placement` varchar(15) NOT NULL,
  `distributor_distributor_id` varchar(20) NOT NULL,
  `distributor_direct_distributor_id` varchar(20) NOT NULL,
  `distributor_coupon` varchar(20) NOT NULL,
  `distributor_coupon_number` varchar(20) NOT NULL,
  `distributor_shagun` varchar(20) NOT NULL,
  `distributor_defense` varchar(20) NOT NULL,
  `distributor_login_id` int(10) NOT NULL,
  `distributor_bv` varchar(20) NOT NULL DEFAULT '0',
  `distributor_creation_date` datetime NOT NULL,
  PRIMARY KEY (`distributor_id`),
  UNIQUE KEY `distributor_company_id` (`distributor_company_id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `distributor_detail`
--

INSERT INTO `distributor_detail` (`distributor_id`, `distributor_company_id`, `distributor_name`, `distributor_father_name`, `distributor_dob`, `distributor_gender`, `distributor_m_status`, `distributor_nominee_name`, `distributor_relationship`, `distributor_current_address`, `distributor_permanent_address`, `distributor_district`, `distributor_state`, `distributor_city`, `distributor_pincode`, `distributor_mobile`, `distributor_phone`, `distributor_email`, `distributor_pan`, `distributor_id_proof`, `distributor_add_proof`, `distributor_image_path`, `distributor_payment_mode`, `distributor_bank`, `distributor_bank_branch`, `distributor_amount`, `distributor_amoun_word`, `distributor_account_bank`, `distributor_account_branch`, `distributor_account_ifsc`, `distributor_account_acc_no`, `distributor_account_acc_name`, `distributor_qualification`, `distributor_business`, `distributor_name_employer`, `distributor_business_no`, `distributor_anual_income`, `distributor_ref1`, `distributor_ref2`, `distributor_ref3`, `distributor_ref4`, `distributor_passport_no`, `distributor_placement`, `distributor_distributor_id`, `distributor_direct_distributor_id`, `distributor_coupon`, `distributor_coupon_number`, `distributor_shagun`, `distributor_defense`, `distributor_login_id`, `distributor_bv`, `distributor_creation_date`) VALUES
(1, 'pss100000', 'kailash chandra', '', '2016-12-31', 'male', 'single', 'Santosh Gupta', 'ngjhg', '', 'hjgjh', '545', 'Uttar Pradesh', 'Lucknow', '226000', '07499588490', '07499588490', 'xyz@gmail.com', '4151251', '52151', '2121', '', '5151', '15151', '12121', 51351, 'juhgffhjh', 'gfhggh', 'hghgh', 'hghvhv', 'ghgvhfg', 'fhfghgh', 'hghg', 'hggghyghgff', 'hghjghjg', 'jhghg', 'hfghgh', 'jhgvbhv', 'hghgvhgf', 'fghfhfghf', 'fhfhfhf', 'jhjh', 'hghg', '1', '1', '1', '', '0', '0', 16, '3', '2016-04-04 14:22:47'),
(2, 'pss817325', 'Amar Mishra', 'Gyanendra Mishra', '1993-06-21', 'male', 'single', 'Rajnish niranjan', '', 'E-8, Sec-C1, LDA Colony, Kanpur road, Lucknow', '', '', 'Uttar Pradesh', 'Lucknow', '226000', '09454211972', '09454211972', 'xyz@gmail.com', 'sdfsd', '', '', '../image_uploads/A.png', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'asdsa', 'left', 'pss100000', 'pss100000', '', '241652', 'Full Payment', '', 1, '3', '2016-04-15 11:57:54'),
(3, 'pss873520', 'Diwakar', 'ksjdf', '2016-04-15', 'male', 'male', 'Rajnish niranjan', '', 'E-8, Sec-C1, LDA Colony, Kanpur road, Lucknow', '', '', 'Uttar Pradesh', 'Lucknow', '226000', '09454211972', '09454211972', 'xyz@gmail.com', '45654', '', '', '../image_uploads/', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'left', 'pss817325', 'pss817325', '', '123', '30%', '', 1, '3.5', '2016-04-18 12:45:48'),
(4, 'pss592078', 'B.D. Chaurasia', 'jhkjh', '2016-04-05', 'male', 'female', 'nandan kumar', '', 'sdfs', '', '', 'Uttar Pradesh', 'Lucknow', '226012', '09454211972', '09454211972', 'test@gmail.com', '45654', '', '', '../image_uploads/', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'right', 'pss817325', 'pss817325', '', '12354', 'Full Payment', '', 1, '0', '2016-04-18 14:21:16'),
(5, 'pss499820', 'puneet', 'dsd', '2016-03-08', 'male', 'single', 'Ambrish Dwivedi', '', 'E-208, Sec-C1, LDA Colony, Kanpur road, Lucknow', '', '', 'Uttar Pradesh', 'Lucknow', '226000', '09936409846', '09936409846', 'xyz@gmail.com', '45654', '', '', '../image_uploads/', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'right', 'pss592078', 'pss592078', '', '213', '', 'Full Payment', 1, '5', '2016-04-18 14:27:16'),
(11, 'pss667526', 'kk', 'kk', '2016-04-14', 'male', 'female', 'Santosh Gupta', '', '138/13, Fatehganj, Galla Mandy, Lucknow', '', '', 'Uttar Pradesh', 'Lucknow', '226000', '07499588490', '07499588490', 'xyz@gmail.com', '45654', '', '', '../image_uploads/', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'left', 'pss100000', 'pss100000', '', '22', '30%', '', 1, '0', '2016-04-19 16:43:37'),
(9, 'pss277347', 'pp', 'pp', '2016-04-20', 'female', 'male', 'Atul Yadav', '', 'lko', '', '', 'Uttar Pradesh', 'Lakhimpur', '226023', '08948973793', '08948973793', 'test@gmail.com', '45654', '', '', '../image_uploads/', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'right', 'pss100000', 'pss100000', '', '123', 'Full Payment', '', 1, '0', '2016-04-18 19:00:49'),
(10, 'pss499875', 'ppp', 'dsd', '2016-04-07', 'male', '', 'Mamta Mishra', '', '233, hind nagar', '', '', 'Uttar Pradesh', 'Lucknow', '226012', '09044819926', '09044819926', 'angleaku22@gmail.com', '45654', '', '', '../image_uploads/', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'left', 'pss277347', 'pss277347', '', '123', '30%', '', 1, '0', '2016-04-18 19:04:43'),
(12, 'pss663489', 'll', 'pp', '2016-04-11', 'male', '', 'Santosh Gupta', '', '138/13, Fatehganj, Galla Mandy, Lucknow', '', '', 'Uttar Pradesh', 'Lucknow', '226000', '07499588490', '07499588490', 'xyz@gmail.com', '45654', '', '', '../image_uploads/', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'right', 'pss100000', 'pss100000', '', '222', '30%', '', 1, '0', '2016-04-19 16:44:38'),
(13, 'pss734872', 'Ambrish Dwivedi', 'dsd', '2016-05-17', 'male', '', 'ashwani singh', '', 'gomti nagar', '', '', 'Uttar Pradesh', 'Lucknow', '226045', '09854658721', '09854658721', 'its.singh.ashwani3@gmail.com', '45654', '', '', '../image_uploads/', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'left', 'pss663489', 'pss663489', '2000 RS COUPON', '220', '', '', 1, '0', '2016-05-03 16:55:37'),
(14, 'pss462192', 'Ambrish Dwivedi', 'dsd', '2016-05-17', 'male', '', 'ashwani singh', '', 'gomti nagar', '', '', 'Uttar Pradesh', 'Lucknow', '226045', '09854658721', '09854658721', 'its.singh.ashwani3@gmail.com', '45654', '', '', '../image_uploads/', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'right', 'pss663489', 'pss663489', '2000 RS COUPON', '220', '', '', 1, '0', '2016-05-03 16:57:42'),
(15, 'pss847180', 'Rajnish niranjan', 'safd', '2016-05-18', 'male', '', 'Santosh Gupta', '', '138/13, Fatehganj, Galla Mandy, Lucknow', '', '', 'Uttar Pradesh', 'Lucknow', '226000', '07499588490', '07499588490', 'xyz@gmail.com', '45654', '', '', '../image_uploads/', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'right', 'pss667526', 'pss667526', '2000 RS COUPON', '123', '', '', 1, '0', '2016-05-03 17:00:48'),
(16, 'pss824905', 'Rajesh Kr. Shukla', 'pp', '2016-05-25', 'male', 'single', 'Mamta Mishra', '', '233, hind nagar', '', '', 'Uttar Pradesh', 'Lucknow', '226012', '09044819926', '09044819926', 'angleaku22@gmail.com', '45654', '', '', '../image_uploads/', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'left', 'pss667526', 'pss667526', '2000 RS COUPON', '223', '', '', 1, '0', '2016-05-03 17:55:48'),
(17, 'pss974292', 'uttam', 'sdkf', '2016-05-12', 'female', '', 'Ambrish Dwivedi', '', 'E-208, Sec-C1, LDA Colony, Kanpur road, Lucknow', '', '', 'Uttar Pradesh', 'Lucknow', '226000', '09936409846', '09936409846', 'xyz@gmail.com', '45654', '', '', '../image_uploads/', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'jhjh', 'left', 'pss873520', 'pss873520', '2000 RS COUPON', '266', '', '', 1, '0', '2016-05-07 12:32:54');

-- --------------------------------------------------------

--
-- Table structure for table `distributor_pre_detail`
--

DROP TABLE IF EXISTS `distributor_pre_detail`;
CREATE TABLE IF NOT EXISTS `distributor_pre_detail` (
  `distributor_id` int(10) NOT NULL AUTO_INCREMENT,
  `distributor_company_id` varchar(50) NOT NULL,
  `distributor_name` varchar(100) NOT NULL,
  `distributor_father_name` varchar(100) NOT NULL,
  `distributor_dob` date NOT NULL,
  `distributor_gender` varchar(20) NOT NULL,
  `distributor_m_status` varchar(30) NOT NULL,
  `distributor_nominee_name` varchar(100) NOT NULL,
  `distributor_relationship` varchar(100) NOT NULL,
  `distributor_current_address` varchar(255) NOT NULL,
  `distributor_permanent_address` varchar(255) NOT NULL,
  `distributor_district` varchar(100) NOT NULL,
  `distributor_state` varchar(100) NOT NULL,
  `distributor_city` varchar(100) NOT NULL,
  `distributor_pincode` varchar(20) NOT NULL,
  `distributor_mobile` varchar(20) NOT NULL,
  `distributor_phone` varchar(20) NOT NULL,
  `distributor_email` varchar(100) NOT NULL,
  `distributor_pan` varchar(100) NOT NULL,
  `distributor_id_proof` varchar(255) NOT NULL,
  `distributor_add_proof` varchar(255) NOT NULL,
  `distributor_image_path` varchar(255) NOT NULL,
  `distributor_payment_mode` varchar(100) NOT NULL,
  `distributor_bank` varchar(150) NOT NULL,
  `distributor_bank_branch` varchar(150) NOT NULL,
  `distributor_amount` double NOT NULL,
  `distributor_amoun_word` varchar(150) NOT NULL,
  `distributor_account_bank` varchar(150) NOT NULL,
  `distributor_account_branch` varchar(150) NOT NULL,
  `distributor_account_ifsc` varchar(150) NOT NULL,
  `distributor_account_acc_no` varchar(150) NOT NULL,
  `distributor_account_acc_name` varchar(200) NOT NULL,
  `distributor_qualification` varchar(150) NOT NULL,
  `distributor_business` varchar(150) NOT NULL,
  `distributor_name_employer` varchar(150) NOT NULL,
  `distributor_business_no` varchar(20) NOT NULL,
  `distributor_anual_income` varchar(30) NOT NULL,
  `distributor_ref1` varchar(150) NOT NULL,
  `distributor_ref2` varchar(150) NOT NULL,
  `distributor_ref3` varchar(150) NOT NULL,
  `distributor_ref4` varchar(150) NOT NULL,
  `distributor_passport_no` varchar(150) NOT NULL,
  `distributor_placement` varchar(15) NOT NULL,
  `distributor_distributor_id` varchar(20) NOT NULL,
  `distributor_direct_distributor_id` varchar(20) NOT NULL,
  `distributor_coupon` varchar(20) NOT NULL,
  `distributor_coupon_number` varchar(20) NOT NULL,
  `distributor_shagun` varchar(20) NOT NULL,
  `distributor_defense` varchar(20) NOT NULL,
  `distributor_bv` varchar(20) NOT NULL DEFAULT '0',
  `distributor_login_id` int(10) NOT NULL,
  `distributor_creation_date` datetime NOT NULL,
  `distributor_user_unique_code` varchar(50) NOT NULL,
  `distributor_aprove_code_use` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`distributor_id`),
  UNIQUE KEY `distributor_company_id` (`distributor_company_id`),
  UNIQUE KEY `distributor_user_unique_code` (`distributor_user_unique_code`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `distributor_pre_detail`
--

INSERT INTO `distributor_pre_detail` (`distributor_id`, `distributor_company_id`, `distributor_name`, `distributor_father_name`, `distributor_dob`, `distributor_gender`, `distributor_m_status`, `distributor_nominee_name`, `distributor_relationship`, `distributor_current_address`, `distributor_permanent_address`, `distributor_district`, `distributor_state`, `distributor_city`, `distributor_pincode`, `distributor_mobile`, `distributor_phone`, `distributor_email`, `distributor_pan`, `distributor_id_proof`, `distributor_add_proof`, `distributor_image_path`, `distributor_payment_mode`, `distributor_bank`, `distributor_bank_branch`, `distributor_amount`, `distributor_amoun_word`, `distributor_account_bank`, `distributor_account_branch`, `distributor_account_ifsc`, `distributor_account_acc_no`, `distributor_account_acc_name`, `distributor_qualification`, `distributor_business`, `distributor_name_employer`, `distributor_business_no`, `distributor_anual_income`, `distributor_ref1`, `distributor_ref2`, `distributor_ref3`, `distributor_ref4`, `distributor_passport_no`, `distributor_placement`, `distributor_distributor_id`, `distributor_direct_distributor_id`, `distributor_coupon`, `distributor_coupon_number`, `distributor_shagun`, `distributor_defense`, `distributor_bv`, `distributor_login_id`, `distributor_creation_date`, `distributor_user_unique_code`, `distributor_aprove_code_use`) VALUES
(8, 'pss552609', 'kk', 'dsd', '0000-00-00', 'male', 'single', 'Ambrish Dwivedi', '', 'E-208, Sec-C1, LDA Colony, Kanpur road, Lucknow', '', '', 'Uttar Pradesh', 'Lucknow', '226000', '09936409846', '09936409846', 'xyz@gmail.com', 'dsdf', '', '', '../image_uploads/02.jpg', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'jhjh', 'right', 'pss622922', '', '2000 RS COUPON', 'sdfds', '', '', '0', 1, '2016-04-14 16:17:49', 'f8Tqi2M7t2ygeP59', 0),
(9, 'pss199619', 'Diwakar', 'ksjdkf', '0000-00-00', 'male', 'single', 'Rajnish niranjan', '', 'E-8, Sec-C1, LDA Colony, Kanpur road, Lucknow', '', '', 'Uttar Pradesh', 'Lucknow', '226000', '09454211972', '09454211972', 'xyz@gmail.com', 'fdgdf', '', '', '../image_uploads/asp-net.jpg', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'left', 'pss281302', '', '', 'sdfsadf', '30%', '', '0', 1, '2016-04-14 18:28:19', 'vn4Uzgu83UAL92rn', 1),
(10, 'pss914306', 'prateek kr', 'klk', '0000-00-00', 'male', 'married', 'Vinod Tomar', '', 'Sec-C1, E-136, LDA Colony, Kanpur road, Lucknow', '', '', 'Uttar Pradesh', 'Lucknow', '226000', '09984141858', '09984141858', 'xyz@gmail.com', 'sdfs', '', '', '../image_uploads/about-us1.png', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'left', 'pss397153', '', '', '123', 'Full Payment', '', '0', 1, '2016-04-14 18:38:39', 'tRgBJnL6kMYnAWXj', 1),
(11, 'pss723501', 'Amar Mishra', 'Gyanendra Mishra', '1993-06-21', 'male', 'single', 'Rajnish niranjan', '', 'E-8, Sec-C1, LDA Colony, Kanpur road, Lucknow', '', '', 'Uttar Pradesh', 'Lucknow', '226000', '09454211972', '09454211972', 'xyz@gmail.com', 'sdfsd', '', '', '../image_uploads/A.png', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'asdsa', 'left', 'pss100000', '', '', '241652', 'Full Payment', '', '0', 1, '2016-04-15 11:56:56', 'dZ9Nt0BO189Fm1aK', 1),
(12, 'pss581778', 'puneet', 'dsd', '2016-03-08', 'male', 'single', 'Ambrish Dwivedi', '', 'E-208, Sec-C1, LDA Colony, Kanpur road, Lucknow', '', '', 'Uttar Pradesh', 'Lucknow', '226000', '09936409846', '09936409846', 'xyz@gmail.com', '45654', '', '', '../image_uploads/', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'right', 'pss592078', '', '', '213', '', 'Full Payment', '0', 9, '2016-04-18 14:25:41', 'kMSuofqYB8rem7A3', 1),
(13, 'pss350983', 'anant', 'safd', '2016-03-08', 'male', 'married', 'Ambrish Dwivedi', '', 'E-208, Sec-C1, LDA Colony, Kanpur road, Lucknow', '', '', 'Uttar Pradesh', 'Lucknow', '226000', '09936409846', '09936409846', 'xyz@gmail.com', '45654', '', '', '../image_uploads/', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2000 RS COUPON', '', '', '', '0', 1, '2016-04-20 17:42:32', '6H1XL236t72CXs6U', 0),
(14, 'pss129279', 'aditya', 'kjkl', '2016-04-05', 'male', 'single', 'ashwani singh', '', 'gomti nagar', '', '', 'Uttar Pradesh', 'Lucknow', '226045', '09854658721', '09854658721', 'its.singh.ashwani3@gmail.com', '45654', '', '', '../image_uploads/', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2000 RS COUPON', '', '', '', '0', 1, '2016-04-20 17:45:21', '86GTRY5nh1hiVI1M', 0),
(15, 'pss672278', 'jhsfdj', 'jhk', '2016-05-12', 'male', 'single', 'nandan kumar', '', 'sdfs', '', '', 'Uttar Pradesh', 'Lucknow', '226012', '09454211972', '09454211972', 'test@gmail.com', '45654', '', '', '../image_uploads/HD-Wallpapers1_FOSmVKg.jpeg', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'Full Payment', '', '0', 1, '2016-05-03 12:34:31', 'hdY30GZqu2H1lBEa', 0),
(16, 'pss972973', 'Rajesh Kr. Shukla', 'pp', '2016-05-25', 'male', 'single', 'Mamta Mishra', '', '233, hind nagar', '', '', 'Uttar Pradesh', 'Lucknow', '226012', '09044819926', '09044819926', 'angleaku22@gmail.com', '45654', '', '', '../image_uploads/', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'pss100000', '2000 RS COUPON', '', '', '', '0', 1, '2016-05-03 17:34:22', 'ait0i8F1yIjq1LhZ', 1);

-- --------------------------------------------------------

--
-- Table structure for table `image_details`
--

DROP TABLE IF EXISTS `image_details`;
CREATE TABLE IF NOT EXISTS `image_details` (
  `image_details_id` int(11) NOT NULL AUTO_INCREMENT,
  `image_details_title` varchar(255) NOT NULL,
  `image_details_address` longtext NOT NULL,
  `image_details_path` varchar(255) NOT NULL,
  `image_details_type` varchar(50) NOT NULL,
  `image_details_date` datetime NOT NULL,
  `image_details_hide_show` int(11) NOT NULL,
  PRIMARY KEY (`image_details_id`)
) ENGINE=MyISAM AUTO_INCREMENT=355 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `image_details`
--

INSERT INTO `image_details` (`image_details_id`, `image_details_title`, `image_details_address`, `image_details_path`, `image_details_type`, `image_details_date`, `image_details_hide_show`) VALUES
(279, ' JSM Infotech is a leading, global provider of comprehensive and integrated SaaS & ITES solutions. We are also engaged in catering incredible web development & designing services', 'JSM InfoTech is a leading IT solution and service provider, dedicated to provides innovative solutions and professional services to customers across the world. It is comprised with dedicated, experienced and certified professionals. Our extremely trained engineers and developers meet all the demands and needs of every class of customer. Via our customer centric approach we have achieved a position of trust and respect from our valued customers. We pursue proven practices and always keep ourselves re-inventing for improvement in accordance to the new technologies for helping our clients efficiently.\r\n\r\n\r\nTrain Station -> 2KM\r\n', 'image_uploads/02.jpg', 'Dharma', '2016-04-13 15:59:04', 1),
(280, ' JSM Infotech is a leading, global provider of comprehensive and integrated SaaS & ITES solutions. We are also engaged in catering incredible web development & designing services', 'JSM InfoTech is a leading IT solution and service provider, dedicated to provides innovative solutions and professional services to customers across the world. It is comprised with dedicated, experienced and certified professionals. Our extremely trained engineers and developers meet all the demands and needs of every class of customer. Via our customer centric approach we have achieved a position of trust and respect from our valued customers. We pursue proven practices and always keep ourselves re-inventing for improvement in accordance to the new technologies for helping our clients efficiently.\r\n\r\n\r\nTrain Station -> 2KM\r\n', 'image_uploads/03.jpg', 'Dharma', '2016-04-13 15:59:04', 1),
(281, ' JSM Infotech is a leading, global provider of comprehensive and integrated SaaS & ITES solutions. We are also engaged in catering incredible web development & designing services', 'JSM InfoTech is a leading IT solution and service provider, dedicated to provides innovative solutions and professional services to customers across the world. It is comprised with dedicated, experienced and certified professionals. Our extremely trained engineers and developers meet all the demands and needs of every class of customer. Via our customer centric approach we have achieved a position of trust and respect from our valued customers. We pursue proven practices and always keep ourselves re-inventing for improvement in accordance to the new technologies for helping our clients efficiently.\r\n\r\n\r\nTrain Station -> 2KM\r\n', 'image_uploads/04.jpg', 'Dharma', '2016-04-13 15:59:04', 1),
(282, ' JSM Infotech is a leading, global provider of comprehensive and integrated SaaS & ITES solutions. We are also engaged in catering incredible web development & designing services', 'JSM InfoTech is a leading IT solution and service provider, dedicated to provides innovative solutions and professional services to customers across the world. It is comprised with dedicated, experienced and certified professionals. Our extremely trained engineers and developers meet all the demands and needs of every class of customer. Via our customer centric approach we have achieved a position of trust and respect from our valued customers. We pursue proven practices and always keep ourselves re-inventing for improvement in accordance to the new technologies for helping our clients efficiently.\r\n\r\n\r\nTrain Station -> 2KM\r\n', 'image_uploads/05.jpg', 'Dharma', '2016-04-13 15:59:04', 0),
(283, ' JSM Infotech is a leading, global provider of comprehensive and integrated SaaS & ITES solutions. We are also engaged in catering incredible web development & designing services', 'JSM InfoTech is a leading IT solution and service provider, dedicated to provides innovative solutions and professional services to customers across the world. It is comprised with dedicated, experienced and certified professionals. Our extremely trained engineers and developers meet all the demands and needs of every class of customer. Via our customer centric approach we have achieved a position of trust and respect from our valued customers. We pursue proven practices and always keep ourselves re-inventing for improvement in accordance to the new technologies for helping our clients efficiently.\r\n\r\n\r\nTrain Station -> 2KM\r\n', 'image_uploads/06.jpg', 'Dharma', '2016-04-13 15:59:04', 0),
(284, ' JSM Infotech is a leading, global provider of comprehensive and integrated SaaS & ITES solutions. We are also engaged in catering incredible web development & designing services', 'JSM InfoTech is a leading IT solution and service provider, dedicated to provides innovative solutions and professional services to customers across the world. It is comprised with dedicated, experienced and certified professionals. Our extremely trained engineers and developers meet all the demands and needs of every class of customer. Via our customer centric approach we have achieved a position of trust and respect from our valued customers. We pursue proven practices and always keep ourselves re-inventing for improvement in accordance to the new technologies for helping our clients efficiently.\r\n\r\n\r\nTrain Station -> 2KM\r\n', 'image_uploads/07.jpg', 'Dharma', '2016-04-13 15:59:04', 1),
(285, ' JSM Infotech is a leading, global provider of comprehensive and integrated SaaS & ITES solutions. We are also engaged in catering incredible web development & designing services', 'JSM InfoTech is a leading IT solution and service provider, dedicated to provides innovative solutions and professional services to customers across the world. It is comprised with dedicated, experienced and certified professionals. Our extremely trained engineers and developers meet all the demands and needs of every class of customer. Via our customer centric approach we have achieved a position of trust and respect from our valued customers. We pursue proven practices and always keep ourselves re-inventing for improvement in accordance to the new technologies for helping our clients efficiently.\r\n\r\n\r\nTrain Station -> 2KM\r\n', 'image_uploads/08.jpg', 'Dharma', '2016-04-13 15:59:04', 0),
(354, 'hello', '45646546', 'image_uploads/download.jpg', 'Diwakar Inclave City', '2016-04-14 19:54:55', 1),
(353, 'hello', '45646546', 'image_uploads/defence-inclave.jpg', 'Diwakar Inclave City', '2016-04-14 19:54:55', 1),
(351, 'hello', '45646546', 'image_uploads/439px-Rupee.png', 'Diwakar Inclave City', '2016-04-14 19:54:55', 0),
(352, 'hello', '45646546', 'image_uploads/273157-festival-of-colours-holi-for-save-water-campaign-and-safe-holi.jpg', 'Diwakar Inclave City', '2016-04-14 19:54:55', 0),
(350, 'You were mixing up two different worlds.', '345345345', 'image_uploads/Untitled-22 copy.png', 'Diwakar Inclave City', '2016-04-14 19:53:22', 0),
(349, 'You were mixing up two different worlds.', '345345345', 'image_uploads/Untitled-2 copy.png', 'Diwakar Inclave City', '2016-04-14 19:53:22', 0),
(348, 'You were mixing up two different worlds.', '345345345', 'image_uploads/Untitled-2 copy.jpg', 'Diwakar Inclave City', '2016-04-14 19:53:22', 0),
(347, 'You were mixing up two different worlds.', '345345345', 'image_uploads/Untitled-1 copy.jpg', 'Diwakar Inclave City', '2016-04-14 19:53:22', 0),
(346, 'You were mixing up two different worlds.', '345345345', 'image_uploads/special-offer-tag.png', 'Diwakar Inclave City', '2016-04-14 19:53:22', 0),
(345, 'You were mixing up two different worlds.', '345345345', 'image_uploads/special-offers.png', 'Diwakar Inclave City', '2016-04-14 19:53:22', 0);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

DROP TABLE IF EXISTS `login`;
CREATE TABLE IF NOT EXISTS `login` (
  `login_id` int(22) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `login_email` varchar(100) NOT NULL,
  `login_phone` varchar(15) NOT NULL,
  `login_type` varchar(50) NOT NULL,
  `login_status` varchar(50) NOT NULL,
  `login_profile_picture` varchar(100) NOT NULL,
  `login_creation_date` datetime NOT NULL,
  `login_login_id` int(10) NOT NULL,
  PRIMARY KEY (`login_id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`login_id`, `username`, `password`, `login_email`, `login_phone`, `login_type`, `login_status`, `login_profile_picture`, `login_creation_date`, `login_login_id`) VALUES
(1, 'pss100000', '1a57e0bcdeb551acf8b8aac651b5c6ee', '', '', '', '', '', '2016-04-08 17:10:21', 16),
(2, 'pss817325', '1a57e0bcdeb551acf8b8aac651b5c6ee', '', '', '', '', '', '2016-04-15 11:59:07', 1),
(6, 'pss873520', '1a57e0bcdeb551acf8b8aac651b5c6ee', '', '', '', '', '', '2016-04-18 14:08:38', 1),
(9, 'pss592078', '1a57e0bcdeb551acf8b8aac651b5c6ee', '', '', '', '', '', '2016-04-18 14:22:23', 1),
(10, 'pss499820', '1a57e0bcdeb551acf8b8aac651b5c6ee', '', '', '', '', '', '2016-04-18 14:56:26', 1),
(11, 'pss667526', '1a57e0bcdeb551acf8b8aac651b5c6ee', '', '', '', '', '', '2016-04-22 19:38:04', 1),
(12, 'pss499875', '1a57e0bcdeb551acf8b8aac651b5c6ee', '', '', '', '', '', '2016-04-22 19:52:33', 1),
(13, 'pss277347', '1a57e0bcdeb551acf8b8aac651b5c6ee', '', '', '', '', '', '2016-05-04 16:50:58', 1);

-- --------------------------------------------------------

--
-- Table structure for table `login_rights`
--

DROP TABLE IF EXISTS `login_rights`;
CREATE TABLE IF NOT EXISTS `login_rights` (
  `login_rights_id` int(10) NOT NULL,
  `login_rights_login_id` int(10) NOT NULL,
  `login_rights_menu_id` int(10) NOT NULL,
  `login_rights_creation_date` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login_rights`
--

INSERT INTO `login_rights` (`login_rights_id`, `login_rights_login_id`, `login_rights_menu_id`, `login_rights_creation_date`) VALUES
(0, 1, 20, '2016-04-14 13:36:15'),
(0, 1, 11, '2016-04-14 13:36:15'),
(0, 1, 4, '2016-04-14 13:36:15'),
(0, 1, 21, '2016-04-14 13:36:15'),
(0, 1, 17, '2016-04-14 13:36:15'),
(0, 1, 15, '2016-04-14 13:36:15'),
(0, 1, 5, '2016-04-14 13:36:15'),
(0, 1, 3, '2016-04-14 13:36:15'),
(0, 1, 19, '2016-04-14 13:36:15'),
(0, 1, 13, '2016-04-14 13:36:15'),
(0, 1, 12, '2016-04-14 13:36:15'),
(0, 1, 9, '2016-04-14 13:36:15'),
(0, 1, 23, '2016-04-14 13:36:15'),
(0, 1, 7, '2016-04-14 13:36:15'),
(0, 2, 5, '2016-04-14 13:55:19'),
(0, 2, 20, '2016-04-14 13:56:18'),
(0, 2, 5, '2016-04-14 13:56:18'),
(0, 2, 20, '2016-04-14 13:56:38'),
(0, 2, 17, '2016-04-14 13:56:38'),
(0, 2, 5, '2016-04-14 13:56:38'),
(0, 1, 23, '2016-04-14 15:43:17'),
(0, 1, 20, '2016-04-14 15:43:47'),
(0, 1, 11, '2016-04-14 15:43:47'),
(0, 1, 4, '2016-04-14 15:43:47'),
(0, 1, 21, '2016-04-14 15:43:47'),
(0, 1, 17, '2016-04-14 15:43:47'),
(0, 1, 15, '2016-04-14 15:43:47'),
(0, 1, 5, '2016-04-14 15:43:47'),
(0, 1, 3, '2016-04-14 15:43:47'),
(0, 1, 19, '2016-04-14 15:43:47'),
(0, 1, 13, '2016-04-14 15:43:47'),
(0, 1, 12, '2016-04-14 15:43:47'),
(0, 1, 9, '2016-04-14 15:43:47'),
(0, 1, 23, '2016-04-14 15:43:47'),
(0, 1, 7, '2016-04-14 15:43:47'),
(0, 1, 20, '2016-04-14 15:56:40'),
(0, 1, 11, '2016-04-14 15:56:40'),
(0, 1, 4, '2016-04-14 15:56:40'),
(0, 1, 21, '2016-04-14 15:56:40'),
(0, 1, 17, '2016-04-14 15:56:40'),
(0, 1, 15, '2016-04-14 15:56:40'),
(0, 1, 5, '2016-04-14 15:56:40'),
(0, 1, 24, '2016-04-14 15:56:40'),
(0, 1, 3, '2016-04-14 15:56:40'),
(0, 1, 19, '2016-04-14 15:56:40'),
(0, 1, 13, '2016-04-14 15:56:40'),
(0, 1, 12, '2016-04-14 15:56:40'),
(0, 1, 9, '2016-04-14 15:56:40'),
(0, 1, 23, '2016-04-14 15:56:40'),
(0, 1, 7, '2016-04-14 15:56:40'),
(0, 1, 20, '2016-04-14 16:29:27'),
(0, 1, 11, '2016-04-14 16:29:27'),
(0, 1, 4, '2016-04-14 16:29:27'),
(0, 1, 21, '2016-04-14 16:29:27'),
(0, 1, 17, '2016-04-14 16:29:27'),
(0, 1, 15, '2016-04-14 16:29:27'),
(0, 1, 5, '2016-04-14 16:29:27'),
(0, 1, 25, '2016-04-14 16:29:27'),
(0, 1, 24, '2016-04-14 16:29:27'),
(0, 1, 3, '2016-04-14 16:29:27'),
(0, 1, 19, '2016-04-14 16:29:27'),
(0, 1, 13, '2016-04-14 16:29:27'),
(0, 1, 12, '2016-04-14 16:29:27'),
(0, 1, 9, '2016-04-14 16:29:27'),
(0, 1, 23, '2016-04-14 16:29:27'),
(0, 1, 7, '2016-04-14 16:29:27'),
(0, 2, 20, '2016-04-15 12:00:56'),
(0, 2, 17, '2016-04-15 12:00:56'),
(0, 2, 5, '2016-04-15 12:00:56'),
(0, 2, 13, '2016-04-15 12:00:56'),
(0, 1, 20, '2016-04-15 14:12:26'),
(0, 1, 26, '2016-04-15 14:12:26'),
(0, 1, 11, '2016-04-15 14:12:26'),
(0, 1, 4, '2016-04-15 14:12:26'),
(0, 1, 21, '2016-04-15 14:12:26'),
(0, 1, 17, '2016-04-15 14:12:26'),
(0, 1, 15, '2016-04-15 14:12:26'),
(0, 1, 5, '2016-04-15 14:12:26'),
(0, 1, 25, '2016-04-15 14:12:26'),
(0, 1, 24, '2016-04-15 14:12:26'),
(0, 1, 3, '2016-04-15 14:12:26'),
(0, 1, 19, '2016-04-15 14:12:26'),
(0, 1, 13, '2016-04-15 14:12:26'),
(0, 1, 12, '2016-04-15 14:12:26'),
(0, 1, 9, '2016-04-15 14:12:26'),
(0, 1, 23, '2016-04-15 14:12:26'),
(0, 1, 7, '2016-04-15 14:12:26'),
(0, 2, 5, '2016-04-15 16:01:30'),
(0, 2, 17, '2016-04-15 16:01:30'),
(0, 2, 20, '2016-04-15 16:01:30'),
(0, 1, 20, '2016-04-15 17:31:37'),
(0, 1, 26, '2016-04-15 17:31:37'),
(0, 1, 11, '2016-04-15 17:31:37'),
(0, 1, 4, '2016-04-15 17:31:37'),
(0, 1, 21, '2016-04-15 17:31:37'),
(0, 1, 17, '2016-04-15 17:31:37'),
(0, 1, 15, '2016-04-15 17:31:37'),
(0, 1, 5, '2016-04-15 17:31:37'),
(0, 1, 25, '2016-04-15 17:31:37'),
(0, 1, 24, '2016-04-15 17:31:37'),
(0, 1, 3, '2016-04-15 17:31:37'),
(0, 1, 19, '2016-04-15 17:31:37'),
(0, 1, 13, '2016-04-15 17:31:37'),
(0, 1, 12, '2016-04-15 17:31:37'),
(0, 1, 28, '2016-04-15 17:31:37'),
(0, 1, 9, '2016-04-15 17:31:37'),
(0, 1, 23, '2016-04-15 17:31:37'),
(0, 1, 7, '2016-04-15 17:31:37'),
(0, 1, 20, '2016-04-16 16:43:33'),
(0, 1, 26, '2016-04-16 16:43:33'),
(0, 1, 11, '2016-04-16 16:43:33'),
(0, 1, 4, '2016-04-16 16:43:33'),
(0, 1, 21, '2016-04-16 16:43:33'),
(0, 1, 17, '2016-04-16 16:43:33'),
(0, 1, 15, '2016-04-16 16:43:33'),
(0, 1, 5, '2016-04-16 16:43:33'),
(0, 1, 25, '2016-04-16 16:43:33'),
(0, 1, 24, '2016-04-16 16:43:33'),
(0, 1, 3, '2016-04-16 16:43:33'),
(0, 1, 19, '2016-04-16 16:43:33'),
(0, 1, 30, '2016-04-16 16:43:33'),
(0, 1, 29, '2016-04-16 16:43:33'),
(0, 1, 13, '2016-04-16 16:43:33'),
(0, 1, 12, '2016-04-16 16:43:33'),
(0, 1, 28, '2016-04-16 16:43:33'),
(0, 1, 9, '2016-04-16 16:43:33'),
(0, 1, 23, '2016-04-16 16:43:33'),
(0, 1, 7, '2016-04-16 16:43:33'),
(0, 1, 3, '2016-04-16 18:36:42'),
(0, 1, 4, '2016-04-16 18:36:42'),
(0, 1, 5, '2016-04-16 18:36:42'),
(0, 1, 7, '2016-04-16 18:36:42'),
(0, 1, 9, '2016-04-16 18:36:42'),
(0, 1, 11, '2016-04-16 18:36:42'),
(0, 1, 12, '2016-04-16 18:36:42'),
(0, 1, 13, '2016-04-16 18:36:42'),
(0, 1, 15, '2016-04-16 18:36:42'),
(0, 1, 17, '2016-04-16 18:36:42'),
(0, 1, 19, '2016-04-16 18:36:42'),
(0, 1, 20, '2016-04-16 18:36:42'),
(0, 1, 21, '2016-04-16 18:36:42'),
(0, 1, 23, '2016-04-16 18:36:42'),
(0, 1, 24, '2016-04-16 18:36:42'),
(0, 1, 25, '2016-04-16 18:36:42'),
(0, 1, 26, '2016-04-16 18:36:42'),
(0, 1, 29, '2016-04-16 18:36:42'),
(0, 1, 30, '2016-04-16 18:36:42'),
(0, 9, 20, '2016-04-18 14:24:09'),
(0, 9, 17, '2016-04-18 14:24:09'),
(0, 9, 5, '2016-04-18 14:24:09'),
(0, 9, 24, '2016-04-18 14:24:09'),
(0, 2, 20, '2016-04-18 15:18:17'),
(0, 2, 17, '2016-04-18 15:18:17'),
(0, 2, 5, '2016-04-18 15:18:17'),
(0, 2, 24, '2016-04-18 15:18:17'),
(0, 1, 20, '2016-04-18 17:09:03'),
(0, 1, 26, '2016-04-18 17:09:03'),
(0, 1, 11, '2016-04-18 17:09:03'),
(0, 1, 4, '2016-04-18 17:09:03'),
(0, 1, 21, '2016-04-18 17:09:03'),
(0, 1, 17, '2016-04-18 17:09:03'),
(0, 1, 15, '2016-04-18 17:09:03'),
(0, 1, 5, '2016-04-18 17:09:03'),
(0, 1, 25, '2016-04-18 17:09:03'),
(0, 1, 24, '2016-04-18 17:09:03'),
(0, 1, 3, '2016-04-18 17:09:03'),
(0, 1, 19, '2016-04-18 17:09:03'),
(0, 1, 30, '2016-04-18 17:09:03'),
(0, 1, 29, '2016-04-18 17:09:03'),
(0, 1, 13, '2016-04-18 17:09:03'),
(0, 1, 12, '2016-04-18 17:09:03'),
(0, 1, 31, '2016-04-18 17:09:03'),
(0, 1, 9, '2016-04-18 17:09:03'),
(0, 1, 23, '2016-04-18 17:09:03'),
(0, 1, 7, '2016-04-18 17:09:03'),
(0, 1, 20, '2016-05-05 12:41:03'),
(0, 1, 26, '2016-05-05 12:41:03'),
(0, 1, 11, '2016-05-05 12:41:03'),
(0, 1, 4, '2016-05-05 12:41:03'),
(0, 1, 21, '2016-05-05 12:41:03'),
(0, 1, 17, '2016-05-05 12:41:03'),
(0, 1, 15, '2016-05-05 12:41:03'),
(0, 1, 5, '2016-05-05 12:41:03'),
(0, 1, 25, '2016-05-05 12:41:03'),
(0, 1, 24, '2016-05-05 12:41:03'),
(0, 1, 3, '2016-05-05 12:41:03'),
(0, 1, 19, '2016-05-05 12:41:03'),
(0, 1, 30, '2016-05-05 12:41:03'),
(0, 1, 29, '2016-05-05 12:41:03'),
(0, 1, 13, '2016-05-05 12:41:03'),
(0, 1, 12, '2016-05-05 12:41:03'),
(0, 1, 33, '2016-05-05 12:41:03'),
(0, 1, 31, '2016-05-05 12:41:03'),
(0, 1, 9, '2016-05-05 12:41:03'),
(0, 1, 23, '2016-05-05 12:41:03'),
(0, 1, 7, '2016-05-05 12:41:03'),
(0, 1, 20, '2016-05-06 17:21:54'),
(0, 1, 26, '2016-05-06 17:21:54'),
(0, 1, 11, '2016-05-06 17:21:54'),
(0, 1, 4, '2016-05-06 17:21:54'),
(0, 1, 21, '2016-05-06 17:21:54'),
(0, 1, 17, '2016-05-06 17:21:54'),
(0, 1, 15, '2016-05-06 17:21:54'),
(0, 1, 5, '2016-05-06 17:21:54'),
(0, 1, 25, '2016-05-06 17:21:54'),
(0, 1, 24, '2016-05-06 17:21:54'),
(0, 1, 3, '2016-05-06 17:21:54'),
(0, 1, 19, '2016-05-06 17:21:54'),
(0, 1, 30, '2016-05-06 17:21:54'),
(0, 1, 29, '2016-05-06 17:21:54'),
(0, 1, 13, '2016-05-06 17:21:54'),
(0, 1, 35, '2016-05-06 17:21:54'),
(0, 1, 12, '2016-05-06 17:21:54'),
(0, 1, 33, '2016-05-06 17:21:54'),
(0, 1, 31, '2016-05-06 17:21:54'),
(0, 1, 9, '2016-05-06 17:21:54'),
(0, 1, 23, '2016-05-06 17:21:54'),
(0, 1, 7, '2016-05-06 17:21:54');

-- --------------------------------------------------------

--
-- Table structure for table `main_menu`
--

DROP TABLE IF EXISTS `main_menu`;
CREATE TABLE IF NOT EXISTS `main_menu` (
  `m_menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `m_menu_name` varchar(255) NOT NULL,
  `m_menu_link` varchar(255) NOT NULL,
  `icon` varchar(100) NOT NULL DEFAULT 'fa fa-circle-o',
  `parent_menu_id` int(11) NOT NULL,
  PRIMARY KEY (`m_menu_id`)
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `main_menu`
--

INSERT INTO `main_menu` (`m_menu_id`, `m_menu_name`, `m_menu_link`, `icon`, `parent_menu_id`) VALUES
(1, 'Application Form', '', '', 0),
(2, 'Tree Structure', '', '', 0),
(3, 'Distributor Reg. Form', 'distributor_reg_form.php', '', 1),
(4, 'Application Form', 'application_form.php', '', 1),
(5, 'Customer Tree', 'customer_tree.php', '', 2),
(6, 'Picture Management', '', '', 0),
(7, 'upload Website Picture', 'upload-image.php', '', 6),
(8, 'News Update', '', '', 0),
(9, 'Update News', 'news-update.php', '', 8),
(10, 'Menu Management', '', '', 0),
(11, 'Add Menu', 'add-menu.php', '', 10),
(12, 'Picture Details', 'all-picture-details.php', '', 6),
(13, 'News Details', 'news-details.php', '', 8),
(14, 'Create Login', '', '', 0),
(15, 'Create Login', 'create-login.php', '', 14),
(16, 'Change Password', '', '', 0),
(17, 'Change Password', 'change_password.php', '', 16),
(18, 'B.V.', '', '', 0),
(19, 'Generate B.V. Code', 'generate_bv_code.php', '', 18),
(20, 'Add B.V. Value', 'add_bv_value.php', '', 18),
(21, 'Available B.V.', 'available_bv.php', '', 18),
(22, 'User Rights', '', '', 0),
(23, 'User Rights', 'user_rights.php', '', 22),
(24, 'Distributor Pre Reg. Form', 'distributor_pre_reg_form.php', '', 1),
(25, 'Distributor Approve By Code', 'distributor_approve_by_code.php', '', 1),
(26, 'Add B.V. value to User', 'add-bv-value-to-user.php', '', 18),
(27, 'Transactions', '', '', 0),
(28, 'Transactions', 'transactions.php', '', 27),
(29, 'Money Received', 'money_received.php', '', 27),
(30, 'Money Dispatched', 'money_dispatched.php', '', 27),
(31, 'Transactions Detail ', 'transactions_detail.php', '', 27),
(32, 'Initial Value', '', '', 0),
(33, 'Set Initial Values', 'initial-values.php', '', 32),
(34, 'Report', '', '', 0),
(35, 'Payment Report', 'payment_report.php', '', 34);

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

DROP TABLE IF EXISTS `news`;
CREATE TABLE IF NOT EXISTS `news` (
  `news_id` int(11) NOT NULL AUTO_INCREMENT,
  `news_title` varchar(100) NOT NULL,
  `news_image` varchar(100) NOT NULL,
  `news_description` varchar(255) NOT NULL,
  `news_link` varchar(100) NOT NULL,
  `news_date` datetime NOT NULL,
  `news_hide_show` int(11) NOT NULL,
  PRIMARY KEY (`news_id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`news_id`, `news_title`, `news_image`, `news_description`, `news_link`, `news_date`, `news_hide_show`) VALUES
(9, 'latest news', 'image_uploads/avatar.png', 'a set of functions and procedures that allow the creation of applications which access the features or data of an operating system, application, or other service.', 'www.google.com', '2016-04-09 19:08:49', 1),
(10, 'Hi', 'image_uploads/13969780096_5080da7235_m.jpg', 'API (application program interface) is a set of routines, protocols, and tools for building software applications. The API specifies how software ', 'www.yahoo.com', '2016-04-09 19:13:20', 1),
(12, 'hello duniya walo', 'image_uploads/$.png', 'suno gaur se duniya walo', 'www.google.com', '2016-04-15 15:57:17', 1),
(13, 'hello duniya walo', 'image_uploads/A.png', 'suno gaur se duniya walo', 'www.google.com', '2016-04-15 15:57:17', 1),
(14, 'hello duniya walo', 'image_uploads/B.png', 'suno gaur se duniya walo', 'www.google.com', '2016-04-15 15:57:17', 1),
(15, 'hello duniya walo', 'image_uploads/C.png', 'suno gaur se duniya walo', 'www.google.com', '2016-04-15 15:57:17', 1),
(16, 'hello duniya walo', 'image_uploads/D.png', 'suno gaur se duniya walo', 'www.google.com', '2016-04-15 15:57:17', 0),
(17, 'hello duniya walo', 'image_uploads/E.png', 'suno gaur se duniya walo', 'www.google.com', '2016-04-15 15:57:17', 0),
(18, 'hello duniya walo', 'image_uploads/F.png', 'suno gaur se duniya walo', 'www.google.com', '2016-04-15 15:57:17', 0),
(19, 'hello duniya walo', 'image_uploads/G.png', 'suno gaur se duniya walo', 'www.google.com', '2016-04-15 15:57:17', 0),
(20, 'hello duniya walo', 'image_uploads/H.png', 'suno gaur se duniya walo', 'www.google.com', '2016-04-15 15:57:17', 0);

-- --------------------------------------------------------

--
-- Table structure for table `payment_mode`
--

DROP TABLE IF EXISTS `payment_mode`;
CREATE TABLE IF NOT EXISTS `payment_mode` (
  `payment_mode_id` int(10) NOT NULL AUTO_INCREMENT,
  `payment_mode_mode` varchar(30) NOT NULL,
  `payment_mode_field1` varchar(255) NOT NULL COMMENT 'cash:-accepted by. cheque: cheque no. b.t: transaction no. dd: dd no',
  `payment_mode_field2` varchar(255) NOT NULL COMMENT 'cash:-paid by. cheque: bank name b.t: transaction account. dd:  bank name',
  `payment_mode_field3` varchar(255) NOT NULL COMMENT 'cheque: acc holder name. dd: genrated by',
  `payment_mode_date` date NOT NULL,
  `payment_mode_date_time` datetime NOT NULL,
  `payment_mode_login_id` int(10) NOT NULL,
  PRIMARY KEY (`payment_mode_id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment_mode`
--

INSERT INTO `payment_mode` (`payment_mode_id`, `payment_mode_mode`, `payment_mode_field1`, `payment_mode_field2`, `payment_mode_field3`, `payment_mode_date`, `payment_mode_date_time`, `payment_mode_login_id`) VALUES
(1, 'cash', 'prakeet', 'pss', '', '2016-04-16', '2016-04-16 18:27:58', 1),
(2, 'cash', 'amar', 'pss', '', '2016-04-16', '2016-04-16 18:34:22', 1),
(3, 'cash', 'puneet', 'pss', '', '2016-04-30', '2016-04-30 12:47:01', 1),
(4, 'cash', 'b.d. chaurasia', 'pss', '', '2016-04-30', '2016-04-30 12:48:13', 1),
(5, 'cash', 'pss', 'diwakar', '', '2016-04-30', '2016-04-30 12:49:11', 1),
(6, 'cash', 'pss', 'amar', '', '2016-04-30', '2016-04-30 12:49:58', 1),
(7, 'cash', 'KK', 'PSS', '', '2016-05-04', '2016-05-04 11:40:26', 1),
(8, 'cash', 'KK', 'PSS', '', '2016-05-04', '2016-05-04 11:41:45', 1),
(9, 'cash', 'diwakar', 'pss', '', '2016-05-04', '2016-05-04 11:42:32', 1);

-- --------------------------------------------------------

--
-- Table structure for table `payment_type`
--

DROP TABLE IF EXISTS `payment_type`;
CREATE TABLE IF NOT EXISTS `payment_type` (
  `payment_type_id` int(10) NOT NULL AUTO_INCREMENT,
  `payment_type_type` varchar(100) NOT NULL,
  `payment_type_commodity` varchar(100) NOT NULL,
  `payment_type_price` double NOT NULL,
  `payment_type_from` varchar(100) NOT NULL,
  `payment_type_to` varchar(100) NOT NULL,
  `payment_type_no_of_entries` int(10) NOT NULL,
  `payment_type_date` datetime NOT NULL,
  PRIMARY KEY (`payment_type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment_type`
--

INSERT INTO `payment_type` (`payment_type_id`, `payment_type_type`, `payment_type_commodity`, `payment_type_price`, `payment_type_from`, `payment_type_to`, `payment_type_no_of_entries`, `payment_type_date`) VALUES
(1, 'coupon', '', 10000, 'Default', 'Default', 4, '2016-05-06 10:58:41'),
(2, 'coupon', '', 21000, '0', '30', 4, '2016-05-06 10:58:41'),
(3, 'coupon', '', 31000, '30', '100', 4, '2016-05-06 10:58:41'),
(4, 'coupon', '', 51000, '100', '100', 4, '2016-05-06 10:58:41'),
(5, 'bonanza', 'Laptop', 25000, '1', '2', 4, '2016-05-06 11:04:08'),
(6, 'bonanza', 'Bike', 55000, '2', '4', 4, '2016-05-06 11:04:08'),
(7, 'bonanza', 'Alto', 250000, '4', '8', 4, '2016-05-06 11:04:08'),
(8, 'bonanza', 'Mahindra KUV', 600000, '8', '15', 4, '2016-05-06 11:04:08'),
(9, 'reward', 'Mobile', 10000, '1', '1', 10, '2016-05-06 11:13:35'),
(10, 'reward', 'iPad', 50000, '3', '3', 10, '2016-05-06 11:13:35'),
(11, 'reward', 'Laptop', 80000, '7', '7', 10, '2016-05-06 11:13:35'),
(12, 'reward', 'Eon Finanace', 200000, '15', '15', 10, '2016-05-06 11:13:35'),
(13, 'reward', 'Eon full', 500000, '25', '25', 10, '2016-05-06 11:13:35'),
(14, 'reward', 'i10 grand', 600000, '50', '50', 10, '2016-05-06 11:13:35'),
(15, 'reward', 'Safari', 800000, '100', '100', 10, '2016-05-06 11:13:35'),
(16, 'reward', 'Audi A3', 2500000, '250', '250', 10, '2016-05-06 11:13:35'),
(17, 'reward', 'Audi A5', 3500000, '500', '500', 10, '2016-05-06 11:13:35'),
(18, 'reward', 'Banglow', 8000000, '1000', '1000', 10, '2016-05-06 11:13:35'),
(20, 'direct income', '', 30000, '', '', 1, '2016-05-06 11:38:38'),
(21, 'pair income', '', 20000, '1', '1', 1, '2016-05-06 11:39:03'),
(22, 'reward', 'Mobile', 17000, '1', '1', 2, '2016-05-06 16:31:19'),
(23, 'reward', 'iPad', 60000, '2', '3', 2, '2016-05-06 16:31:19');

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

DROP TABLE IF EXISTS `transaction`;
CREATE TABLE IF NOT EXISTS `transaction` (
  `transaction_id` int(10) NOT NULL AUTO_INCREMENT,
  `transaction_type` varchar(50) NOT NULL,
  `transaction_distributor_id` varchar(50) NOT NULL,
  `transaction_amount` varchar(50) NOT NULL,
  `transaction_payment_mode` varchar(30) NOT NULL,
  `transaction_payment_mode_id` int(10) NOT NULL,
  `payment_type` varchar(50) NOT NULL,
  `transaction_date` datetime NOT NULL,
  `transaction_login_id` int(10) NOT NULL,
  PRIMARY KEY (`transaction_id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`transaction_id`, `transaction_type`, `transaction_distributor_id`, `transaction_amount`, `transaction_payment_mode`, `transaction_payment_mode_id`, `payment_type`, `transaction_date`, `transaction_login_id`) VALUES
(1, 'money received', 'pss100000', '10', 'cash', 1, '', '2016-04-16 18:27:58', 1),
(2, 'money dispatched', 'pss817325', '11', 'cash', 2, '', '2016-04-16 18:34:22', 1),
(3, 'money dispatched', 'pss499820', '100', 'cash', 3, '', '2016-04-30 12:47:01', 1),
(4, 'money dispatched', 'pss592078', '103', 'cash', 4, '', '2016-04-30 12:48:13', 1),
(5, 'money received', 'pss873520', '609', 'cash', 5, '', '2016-04-30 12:49:11', 1),
(6, 'money received', 'pss817325', '3008', 'cash', 6, '', '2016-04-30 12:49:58', 1),
(7, 'money dispatched', 'pss592078', '10000', 'cash', 0, '', '2016-05-04 11:27:23', 1),
(8, 'money dispatched', 'pss499820', '1230', 'cash', 0, '', '2016-05-04 11:29:52', 1),
(9, 'money dispatched', 'pss499820', '1230', 'cash', 0, '', '2016-05-04 11:31:17', 1),
(10, 'money dispatched', 'pss499820', '1230', 'cash', 0, '', '2016-05-04 11:32:02', 1),
(11, 'money dispatched', 'pss667526', '12340', 'cash', 0, 'bonanza', '2016-05-04 11:40:26', 1),
(12, 'money dispatched', 'pss873520', '12345', 'cash', 9, 'coupon', '2016-05-04 11:42:32', 1);

-- --------------------------------------------------------

--
-- Stand-in structure for view `transaction_detail`
--
DROP VIEW IF EXISTS `transaction_detail`;
CREATE TABLE IF NOT EXISTS `transaction_detail` (
`date(transaction_date)` date
,`credit` varchar(50)
,`debit` varchar(50)
);

-- --------------------------------------------------------

--
-- Table structure for table `tree`
--

DROP TABLE IF EXISTS `tree`;
CREATE TABLE IF NOT EXISTS `tree` (
  `id` varchar(20) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `parent_id` varchar(20) NOT NULL,
  `hide` tinyint(1) NOT NULL,
  `position` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tree`
--

INSERT INTO `tree` (`id`, `first_name`, `parent_id`, `hide`, `position`) VALUES
('1', 'pss builders', '0', 0, ''),
('10', 'ppp', '9', 0, 'left'),
('10002', 'blank', '9', 0, 'right'),
('11', 'kk', '1', 0, ''),
('12', 'll', '1', 0, ''),
('13', 'Ambrish Dwivedi', '12', 0, 'left'),
('14', 'Ambrish Dwivedi', '12', 0, 'right'),
('15', 'Rajnish niranjan', '11', 0, 'right'),
('16', 'Rajesh Kr. Shukla', '11', 0, 'left'),
('17', 'uttam', '3', 0, 'left'),
('17002', 'blank', '3', 0, 'right'),
('2', 'Amar Mishra', '1', 0, ''),
('3', 'Diwakar', '2', 0, 'left'),
('4', 'B.D. Chaurasia', '2', 0, 'right'),
('5', 'puneet', '4', 0, 'right'),
('5001', 'blank', '4', 0, 'left'),
('9', 'pp', '1', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `website_gallery`
--

DROP TABLE IF EXISTS `website_gallery`;
CREATE TABLE IF NOT EXISTS `website_gallery` (
  `website_gallery_id` int(11) NOT NULL AUTO_INCREMENT,
  `website_gallery_name` varchar(100) NOT NULL,
  `website_gallery_first_path` varchar(100) NOT NULL,
  `website_gallery_second_path` varchar(100) NOT NULL,
  PRIMARY KEY (`website_gallery_id`)
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `website_gallery`
--

INSERT INTO `website_gallery` (`website_gallery_id`, `website_gallery_name`, `website_gallery_first_path`, `website_gallery_second_path`) VALUES
(25, 'first', 'images/slider-1.png', 'images/slider-1.png'),
(26, 'second', 'images/slider-2.png', 'images/slider-2.png'),
(27, 'third', 'images/slider-3.png', 'images/slider-3.png'),
(28, 'fourth', 'images/slider-4.png', 'images/slider-4.png'),
(30, '123123', 'images/slider-1.png', 'images/slider-1.png'),
(31, 'dsf', 'images/about.png', 'images/about.png'),
(32, 'cxv', 'images/layout3.jpg', 'images/layout3.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `website_menu`
--

DROP TABLE IF EXISTS `website_menu`;
CREATE TABLE IF NOT EXISTS `website_menu` (
  `website_menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `website_menu_name` varchar(50) NOT NULL,
  `website_menu_link` varchar(50) NOT NULL,
  `website_parent_menu_id` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  PRIMARY KEY (`website_menu_id`)
) ENGINE=MyISAM AUTO_INCREMENT=113 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `website_menu`
--

INSERT INTO `website_menu` (`website_menu_id`, `website_menu_name`, `website_menu_link`, `website_parent_menu_id`, `type`) VALUES
(1, 'Home', '#', 0, ''),
(2, 'Projects', '#', 0, ''),
(3, 'Search', '#', 0, ''),
(4, 'Legals', '#', 0, ''),
(5, 'Bankers', '#', 0, ''),
(6, 'Customer Zone', '#', 0, ''),
(7, 'Contact Us', '#', 0, ''),
(8, 'Shagun City', 'shagun-city.php', 2, ''),
(9, 'Defence Inclave', 'defence-inclave.php', 2, ''),
(10, 'About Us', 'about-us.php', 7, ''),
(11, 'Login', 'admin', 7, ''),
(12, 'Jobs', 'jobs.php', 7, ''),
(13, 'Achiever Team', 'achiever-team.php', 4, ''),
(14, 'Picture Gallery', 'picture-gallery.php', 4, ''),
(15, 'Branchs', 'branchs.php', 4, ''),
(16, 'Events', 'events.php', 4, ''),
(17, 'Legals', 'legals.php', 4, ''),
(18, 'Bankers', 'bankers.php', 5, ''),
(19, 'Customer Zone', 'customer-zone.php', 6, ''),
(20, 'Contact Us', 'contact.php', 7, ''),
(21, 'Search', 'search.php', 3, ''),
(26, 'Home', 'index.php', 1, ''),
(112, 'hello Friend', 'hello Friend.php', 2, 'hello Friend'),
(111, 'Diwakar Inclave City', 'Diwakar Inclave City.php', 2, 'Diwakar Inclave City');

-- --------------------------------------------------------

--
-- Structure for view `transaction_detail`
--
DROP TABLE IF EXISTS `transaction_detail`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `transaction_detail`  AS  (select cast(`transaction`.`transaction_date` as date) AS `date(transaction_date)`,(case when (`transaction`.`transaction_type` = 'money received') then ifnull(`transaction`.`transaction_amount`,0) end) AS `credit`,(case when (`transaction`.`transaction_type` = 'money dispatched') then ifnull(`transaction`.`transaction_amount`,0) end) AS `debit` from `transaction`) ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
