<?php
	session_start();
//include_once 'db.php';

if(!isset($_SESSION['user_id']))
{
	header("Location: customer-zone.php");
}
else
{
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>PSS Builder || Home</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php include"script-css.php"; ?>
  <style>
  a:hover
  {
    color: white !important;
  }
  </style>
</head>
<body>
	<?php include"menu.php"; ?>
	<?php
@session_start();
 include_once 'property/pss_db.php';
 $applicant_id=$_SESSION['user_id'];
                    $conn = new DB_con();
                    $con = $conn->connection();
                    $functions = new functions();
					
if(isset($_POST['btn-login']))
{
	$plot_no = $_POST['plot_no'];
	$mobil_no = $_POST['mobil_no'];
	//echo"$plot_no <br> $mobil_no";
	$plot_no = trim($plot_no);
	$mobil_no = trim($mobil_no);
	
	$res=mysqli_query($con,"SELECT plot_price_details.plot_price_details_plot_no, plot_price_details.plot_price_details_plot_book_applicant_id,applicant_detail.applicant_mobile_no,
plot_price_details.plot_price_details_plot_book_applicant_id FROM plot_price_details,applicant_detail  where plot_price_details.plot_price_details_plot_book_applicant_id='$applicant_id' and applicant_detail.applicant_mobile_no='$mobil_no' and plot_price_details.plot_price_details_plot_no='$plot_no'");
	//echo"$res";
	$row=mysqli_fetch_array($res);
	
	$count = mysqli_num_rows($res); // if uname/pass correct it returns must be 1 row
 // echo"$count";
   $plot_no=$row['plot_price_details_plot_no'];
  // echo"$plot_no";
	if($count == 1 && $plot_no==$row['plot_price_details_plot_no'])
	{
		$_SESSION['user_id'] = $row['plot_price_details_plot_book_applicant_id'];
		
		echo"<script>
                         window.location.href='property_summary.php';
                        </script>";
		
		//header("Location: property_value.php");
	}
	else
	{
		?>
        <script>alert('Username / Password Seems Wrong !');</script>
        <?php
	}
	
}
?>
	 <div class="pg-opt"  style="background-color:#3ba0ff;">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h2 style="color:white !important;">Customer Zone</h2>
                </div>
                <div class="col-md-6">
                    <ol class="breadcrumb">
                        <li><a href="index.php">Home</a></li>
                        <li style="color:white !important;" class="active">Customer Zone</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
   
	<section class="slice bg-white">
        <div class="wp-section">
            <div class="container">
                <div class="row">
				
  <div class="col-sm-12 text-right"><a href="logout.php?logout" class="btn btn-danger"><i class="fa fa-share"></i> Logout</a></div>

                    <div class="col-md-4 col-md-offset-4 col-sm-6 col-sm-offset-3">
                        <div class="wp-block default user-form"> 
                            <div class="form-header">
                                <h2>Check Property Summary</h2>
                            </div>
							<?php //echo $_SESSION['user_id']; ?>
                            <div class="form-body">
                                <form action="" ="frmLogin" class="sky-form" method="POST">                                    
                                    <fieldset>                  
                                        <section>
                                            <div class="form-group">
                                                <strong>Plot No.</strong>
                                                <label class="input">
                                                    <i class="icon-append fa fa-edit"></i>
                                                    <input type="text" name="plot_no" placeholder="Enter Plot Number" required>
                                                </label>
                                            </div>     
                                        </section>
                                        <section>
                                            <div class="form-group">
                                                <strong>Mobile No.</strong>
                                                <label class="input">
                                                    <i class="icon-append fa fa-edit"></i>
                                                    <input type="text" name="mobil_no" placeholder="Enter Mobile Number" required>
                                                </label>
                                            </div>     
                                        </section> 
                                        

                                        <section>
                                            <button class="btn btn-base btn-icon btn-icon-right fa fa-search pull-right" type="submit" name="btn-login">
                                                <span>Search</span>
                                            </button>
                                        </section>
                                    </fieldset>  
                                </form>    
                            </div>
                           
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
	
    <?php include"footer.php"; ?>

</body>
</html>
<?php } ?>