<!DOCTYPE html>
<html lang="en">
<head>
  <title>PSS Builder || Home</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php include"script-css.php"; ?>
  <style>
  a:hover
  {
    color: white !important;
  }
  </style>
</head>
<body>
	<?php include"menu.php"; ?>
	
	

	
	
	
	
	
	
	
	 <div class="pg-opt"  style="background-color:#3ba0ff;">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h2 style="color:white !important;">Contact Us</h2>
                </div>
                <div class="col-md-6">
                    <ol class="breadcrumb">
                        <li><a href="index.php">Home</a></li>
                        <li style="color:white !important;" class="active">Contact Us</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

<section class="slice bg-white">
        <div class="wp-section">
            <div class="container">
                <div class="row">
                    <div class="col-md-7">
                        <div class="section-title-wr">
                            <h3 class="section-title left"><span>Send us a message</span></h3>
                        </div>
                        <?php
include 'library.php'; // include the library file
include "classes/class.phpmailer.php"; // include the class name
if(isset($_POST["send"]))
{
	$name = $_POST["name"];
	$email = $_POST["email"];
	$phone = $_POST["phone"];
	$subject = $_POST["subject"];
	$message = $_POST["message"];
	 $email      = mysqli_real_escape_string($_POST['email']);
	 //if (!filter_var($email, FILTER_VALIDATE_EMAIL)) // Validate email address
	 if (!filter_var($email, FILTER_VALIDATE_EMAIL) === false)
        {
		?>
		<div class="alert alert-danger">
        <strong>Faild!<strong>Invalid email address please type a valid email!!
        </div>
			<?php
        }
		else
        {
	?>
	<?php
            
		}
	$email = $_POST["email"];
	$mail	= new PHPMailer; // call the class 
	$mail->IsSMTP(); 
	$mail->Host = SMTP_HOST; //Hostname of the mail server
	$mail->Port = SMTP_PORT; //Port of the SMTP like to be 25, 80, 465 or 587
	$mail->SMTPAuth = true; //Whether to use SMTP authentication
	$mail->Username = SMTP_UNAME; //Username for SMTP authentication any valid email created in your domain
	$mail->Password = SMTP_PWORD; //Password for SMTP authentication
	$mail->AddReplyTo("info@pssbuilders.com", "PSS Builders PVT.Ltd."); //reply-to address
	$mail->SetFrom("info@pssbuilders.com", "PSS Builders PVT.Ltd."); //From address of the mail
	// put your while loop here like below,
	$mail->Subject = "PSS Builders PVT.Ltd."; //Subject od your mail
	$mail->AddAddress("info@pssbuilders.com", "PSS Builders PVT.Ltd."); //To address who will receive this email
	$mail->MsgHTML("$body<b>
	<p>www.pssbuilders.com Contact us Page Details</p>
	<table border='1px' width='500px' height='250px'>
	<tr>
	<td>Contact Name</td>
	<td>$name</td>
	</tr>
	<tr>
	<td>Contact Email</td>
	<td>$email</td>
	</tr>
	<tr>
	<td>Contact Phone</td>
	<td>$phone</td>
	</tr>
	<tr>
	<td>Contact Subject</td>
	<td>$subject</td>
	</tr>
	<tr>
	<td>Contact Message</td>
	<td>$message</td>
	</tr>
	</table></b>"); //Put your body of the message you can place html code here
	//$mail->AddAttachment("images/asif18-logo.jpg"); //Attach a file here if any or comment this line, 
	$send = $mail->Send(); //Send the mails
	if($send){
	?>
	    <div class="alert alert-success">
        <strong>Mail sent successfully<strong>
        </div>
		<?php
	}
	else{
		echo '<center><h3 style="color:#FF3300;">Mail error: </h3></center>'.$mail->ErrorInfo;
	}
}
?>	
                        
                        <form class="form-light mt-20" role="form" method="POST">
                            <div class="form-group">
                                <label>Name</label>
                                <input type="text" class="form-control" placeholder="Your name" name="name" required="required">
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Email</label>
                                        <input type="text" class="form-control" placeholder="Email address" name="email" required="required">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Phone</label>
                                        <input type="text" class="form-control" placeholder="Phone number" name="phone" required="required">
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Subject</label>
                         <input type="text" class="form-control" id="subject" placeholder="Subject" name="subject" required="required">
                            </div>
                            <div class="form-group">
                                <label>Message</label>
  <textarea class="form-control" placeholder="Write you message here..." style="height:100px;" name="message" required="required"></textarea>
                            </div>
                            <button type="submit" class="btn btn-base" name="send">Send message</button>
                        </form>
                    </div>
                    
                    <div class="col-md-5">
                        <div id="mapCanvas" class="map-canvas no-margin"><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3561.2492173009696!2d80.89477221456332!3d26.80019217137786!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x399bfea7c17c0c59%3A0x8c2d3db71232fbaf!2sPSS+Builders+Pvt+Ltd!5e0!3m2!1sen!2sin!4v1459345549553" width="550" height="400" frameborder="0" style="border:0" allowfullscreen></iframe></div>
                        
                       <div class="row">
                            <div class="col-sm-12">
                                <div class="subsection">
                                    <div class="section-title-wr">
                                        <h3 class="section-title left"><span>Contact info</span></h3>
                                    </div>
                                    <div class="contact-info">
                                        <h5><i class="fa fa-map-marker"></i> Address</h5>
                                        <p>Pal Plaza, IInd Floor, KBC-15, Sector B, Barabirwa, LDA Colony, Near Phoenix Mall, Kanpur road, Lucknow.</p>
                                        
                                        <h5><i class="fa fa-envelope"></i> Email</h5>
                                        <p>info@pssbuilders.com</p>
                                        
                                        <h5><i class="fa fa-phone"></i> Phone</h5>
                                        <p> 0522-6888-844</p>
										 <h5><i class="fa fa-globe"></i>Website</h5>
                                        <p><a href="http://www.pssbuilders.com/" title="Website">www.pssbuilders.com</a></p>
                                    </div>
                                </div>
                            </div>
                            
                        </div>

                       
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php include"footer.php"; ?>

</body>
</html>


