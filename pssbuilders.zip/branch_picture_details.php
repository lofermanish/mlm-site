
  <style>
  a:hover
  {
    color: white !important;
  }
  .imgsize
  {
   height:500px;
   width:500px;
  }
  </style>

<?php
if(isset($_REQUEST['picture_date']))
{
$picture_date=$_REQUEST['picture_date'];
//echo"$picture_date";
@include_once 'property/pss_db.php';
@$conn = new DB_con();
@$con = $conn->connection();
									 
				 ?>
			<section class="slice bg-white bb">
        <div class="wp-section">
            <div class="container">
                <div class="row">
				
      <div class="col-md-12 col-md-push-12"><FORM><INPUT Type="button" VALUE="Back" onClick="history.go(0)" class="btn btn-success"></FORM></div>

                    <div class="col-md-6">
                        <div id="workCarousel" class="carousel carousel-4 slide color-two-l" data-ride="carousel">
                            <!-- Indicators -->
                            <ol class="carousel-indicators hide">
                                <li data-target="#homepageCarousel" data-slide-to="0" class="active"></li>
                            </ol>
                            
                            <div class="carousel-inner">
							
                                <div class="item item-dark active">
								<?php
                                    $res = $conn->get_website_gallery_branch_image($con,$picture_date);
									$row = mysqli_fetch_array($res) ?>
                                    <img src="<?php echo $row['image_details_path']; ?>" alt="" class="img-responsive" style="height:400px; width:600px;">
                                </div>
								<?php
								  
				 while ($row = mysqli_fetch_array($res)) {
				 $image_id=$row['image_details_type'];
				 ?>
                                <div class="item item-dark">
                                    <img src="<?php echo $row['image_details_path']; ?>" alt="" class="img-responsive" style="height:400px; width:600px;">
                                </div>
				 <?php } ?>
                            </div>
                            
                            <!-- Controls -->
                            <a class="left carousel-control" href="#workCarousel" data-slide="prev">
                                <i class="fa fa-angle-left"></i>
                            </a>
                            <a class="right carousel-control" href="#workCarousel" data-slide="next">
                                <i class="fa fa-angle-right"></i>
                            </a>     
                            
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="vertical-info">
                            <h4>Title</h4>
                            <p class="delimiter">						
								<?php
									$res = $conn->get_website_gallery_image($con,$picture_date);
									$row = mysqli_fetch_array($res); ?>
                           <?php echo $row['image_details_title']; ?>
                            </p>
                        </div>

                        <div class="section-title-wr mt-40">
                            <h3 class="section-title left">
                                <span>Description</span>
								<hr>
                            </h3>
                        </div> 
                        <p class="">
                        <?php echo $row['image_details_address']; ?>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php
}
?>
