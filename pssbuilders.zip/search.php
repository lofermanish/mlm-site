<!DOCTYPE html>
<html lang="en">
<head>
  <title>PSS Builder || Home</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php include"script-css.php"; ?>
  <style>
  a:hover
  {
    color: white !important;
  }
  </style>
</head>
<body>
	<?php include"menu.php"; ?>
	 <div class="pg-opt"  style="background-color:#3ba0ff;">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h2 style="color:white !important;">Search Property</h2>
                </div>
                <div class="col-md-6">
                    <ol class="breadcrumb">
                        <li><a href="index.php">Home</a></li>
                        <li style="color:white !important;" class="active">Search Property</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
   <section class="slice bg-white">
        <div class="wp-section">
            <div class="container">
                <div class="row">
                    <div class="col-md-8 col-md-offset-2 col-sm-6 col-sm-offset-3">                   
                        <div class="wp-block default user-form no-margin">
                            <div class="form-header">
                                <h2>Search Property..</h2>
                            </div>
                            <div class="form-body">
                                <form action="" id="frmRegister" class="sky-form">                                    
                                    

                                    <fieldset>
                                        <div class="row">
                                            <section class="col-xs-2">
											<strong>I wish to :</strong>
                                               
                                            </section>
                                            
                                            <section class="col-xs-10">
                                                 <label class="select">
                                                    <select name="country">
                                                        <option value="0" selected="" disabled="">Select Type</option>
                                                        <option value="244">Buy</option>
                                                        <option value="1">Rent</option>
                                                        <option value="2">PG</option>
                                                    </select>
                                                    <i></i>
                                                </label>
                                            </section>
                                            
                                            
                                        </div>
                                        
                                        <section>
                                            <div class="row">
                                            <section class="col-xs-2">
											<strong>Bed Rooms :</strong>
                                               
                                            </section>
                                            
                                            <section class="col-xs-10">
                                                 <label class="input">
                                                    <input type="text" name="BedRooms" placeholder="Bed Rooms">
                                                    
                                                </label>
                                            </section>
                                            <section>
                                       
                                            <section class="col-xs-2">
											<strong>Bath Rooms :</strong>
                                               
                                            </section>
                                            
                                            <section class="col-xs-10">
                                                 <label class="input">
                                                    <input type="text" name="BedRooms" placeholder="Bed Rooms">
                                                    
                                                </label>
                                            </section>
                                            
											
                                            <section class="col-xs-3">
											<strong>Show me properties from :</strong>
                                               
                                            </section>
                                            
                                            <section class="col-xs-9">
                                                 <label class="select">
                                                    <select name="country">
                                                        <option value="0" selected="" disabled="">Select Properties</option>
                                                        <option value="244">Builder</option>
                                                        <option value="1">Individual</option>
														<option value="1">Agent</option>
                                                        <option value="2">All</option>
                                                       
                                                    </select>
                                                    <i></i>
                                                </label>
                                            </section>
                                   
                                        </section>
                                            
                                        </div>
                                        </section>
                                       
                                       
                                        <section>
                                            <div class="row">
                                                <div class="col-md-8">
                                                    
                                                </div>
                                               
												 <div class="form-footer">
                                                    <button class="btn btn-base btn-icon btn-icon-right btn-sign-in pull-right" type="submit">
                                                        <span>Search now</span>
                                                    </button>
													

                                                  </div>
                                         </section>
                                    </fieldset>
                                </form>    
                                             </div>
                           
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php include"footer.php"; ?>

</body>
</html>
