<!DOCTYPE html>
<html lang="en">
<head>
  <title>PSS Builder || Home</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php include"script-css.php"; ?>
  <link rel="stylesheet" href="css/bootstrap-override.css">
 <link rel="stylesheet" href="css/blueimp-gallery.min.css">
 <link rel="stylesheet" href="css/bootstrap-image-gallery.min.css">
  <style>
  a:hover
  {
    color: white !important;
  }
  </style>

<script>
   function pic_detail(achiever_date,page_name){
        //alert(img_date);
		//var user = $("#position").val();
        $("#hello").load('show-all_project.php', {"project_type": achiever_date,"page": page_name});
    }

</script>
</head>
<body>
	<?php include"menu.php"; ?>
	 <div class="pg-opt"  style="background-color:#3ba0ff;">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h2 style="color:white !important;">Picture Gallery</h2>
                </div>
                <div class="col-md-6">
                    <ol class="breadcrumb">
                        <li><a href="index.php">Home</a></li>
                        <li style="color:white !important;" class="active">Picture Gallery</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
	<section class="slice bg-white">
        <div class="wp-section">
            <div class="container">
                <div class="row">
                    <div class="col-md-3">
                        <div class="widget">
						    <ul class="categories">
							<?php
							$page_name=basename($_SERVER['PHP_SELF']);
$main_page=basename($page_name,".php");
//echo"<br>$main_page</br>";
				$res = $conn->get_admin_product($con,$main_page);
				 while ($row = mysqli_fetch_array($res)) {
				 $achiever_product_name=$row['achiever_product_name'];
				//echo"$achiever_product_name";
				 ?>
    <li> <a href="#" onclick="pic_detail('<?php echo $achiever_product_name."','".$main_page; ?>')"><?php echo $row['achiever_product_name']; ?></a></li>
	
	            <?php } ?>
                           </ul>
					  </div>                    
					</div>
                    <div class="col-md-9" id="hello">
                    		 
                    </div>
                </div>
            </div>
        </div>
    </section>
<script type="text/javascript" src="js/jquery.blueimp-gallery.min.js"></script>
<script type="text/javascript" src="js/bootstrap-image-gallery.min.js"></script>
<div class="offline-ui offline-ui-up"><div class="offline-ui-content"></div><a href="" class="offline-ui-retry"></a></div>
    <?php include"footer.php"; ?>

</body>
</html>
