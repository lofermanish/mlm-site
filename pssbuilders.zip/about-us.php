<!DOCTYPE html>
<html lang="en">
<head>
  <title>PSS Builder || Home</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php include"script-css.php"; ?>
  <style>
  a:hover
  {
    color: white !important;
  }
  </style>
</head>
<body>
	<?php include"menu.php"; ?>
	 <div class="pg-opt"  style="background-color:#3ba0ff;">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h2 style="color:white !important;">About us</h2>
                </div>
                <div class="col-md-6">
                    <ol class="breadcrumb">
                        <li><a href="index.php">Home</a></li>
                        <li style="color:white !important;" class="active">About us</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <section class="slice white bt bb">
        <div class="wp-section ">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <div class="section-title-wr">
                            <h3 class="section-title left"><span>About us</span></h3>
                        </div>
                        <p align="justify">
                       Gone are the days when people used to deal property matters on the basis of "mouth to mouth publicity" or nearby dealers. Globalization and fast lifestyle has encouraged the real estate industry to step in E-World. Now active partakers of real estate world are eagerly seeking the right options to establish themselves in E-Real Estate World. RealestateIndia.Com is a solution to all what bothers to people who all are dealing in properties or people who all are searching property. As one of the leading property portals, RealestateIndia has tuned itself with pulse of real estate sector. Moving ahead with esteemed registered users and regularly visited by players of real estate industry, RealestateIndia.Com has become the pivot for real-estate sector.
                        </p>
                    </div>
                    <div class="col-md-6">
                       
                        <p>
                        <img src="images/about.png" style="width:400px;">
                        </p>
                    </div>
                </div>
                <div class="row">
                
                    <div class="col-md-12">
                        <div class="subsection">
                            <div class="section-title-wr">
                                <h3 class="section-title left"><span>PSS Builders</span></h3>
                            </div>
                            <div class="widget">
                                <div class="panel-group" id="accordion">
                                    <div class="panel panel-default">
                                      <div class="panel-heading">
                                        <h4 class="panel-title">
                                          <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne" class="collapsed">
                                            Known As
                                          </a>
                                        </h4>
                                      </div>
                                      <div id="collapseOne" class="panel-collapse collapse" style="height: 0px;">
                                        <div class="panel-body">
                                        <p>
                                          Being substantial in the realm of Real estate, we have stridden a long way in a short span of time. With our resolution to raise high, we beat the all hurdles and stood against all odds. This marvelous achievement has been the upshot of the trust, which our clients have shown over the years.
<br>
PSS Builders Pvt. Ltd., is country's leading portal in the online real estate space. Launched in 2014, pssbuilders.com offers one-stop property marketing solutions serving builders, real estate agents and home owners to sell or rent their properties, while offering a feature rich interface for property buyers to search and identify properties that match their requirement.
                                        </p>
                                        </div>
                                      </div>
                                    </div>
                                    <div class="panel panel-default">
                                      <div class="panel-heading">
                                        <h4 class="panel-title">
                                          <a data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" class="collapsed">
                                            Mission & Vission
                                          </a>
                                        </h4>
                                      </div>
                                      <div id="collapseTwo" class="panel-collapse collapse" style="height: 0px;">
                                        <div class="panel-body">
                                          <p>
Our mission is to touch the horizon where our capabilities may successfully meet with the requirements of our clients, that too with ultimate transparency and cost-effectiveness.
<br>
To sow the seeds of par-excellence services with customer centric approach and reap the trust of worldwide clients.
 <br> <br>
We are committed to provide effective advertising solutions in pocket-friendly budgets and grow with the growth of our clients. In fact, zeal to own a home starts right in childhood when we draw the image of home on paper and color it with crayons. However, when we grow we realize it is not a game of paper and crayons rather it needs many efforts, money, adequate guidance, knowledge and much more. Our vision is to be the most trusted platform for property seekers and property dealers that may reduce the hassles usually occurs during searching of properties and property buyers.
                                        </p>
                                        </div>
                                      </div>
                                    </div>
                                   
                                  </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php// include"main-body.php"; ?>
    <?php include"footer.php"; ?>

</body>
</html>
