<!DOCTYPE html>
<html lang="en">
<head>
  <title>PSS Builder || Home</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php include"script-css.php"; ?>
  <style>
  a:hover
  {
    color: white !important;
  }
  </style>
</head>
<body>
	<?php include"menu.php"; ?>
	 <div class="pg-opt"  style="background-color:#3ba0ff;">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h2 style="color:white !important;">Customer Zone</h2>
                </div>
                <div class="col-md-6">
                    <ol class="breadcrumb">
                        <li><a href="index.php">Home</a></li>
                        <li style="color:white !important;" class="active">Customer Zone</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
   
   
   
   <?php
@session_start();
 include_once 'property/pss_db.php';
                    $conn = new DB_con();
                    $con = $conn->connection();
                    $functions = new functions();
if(isset($_POST['btn-login']))
{
	$username = $_POST['username'];
	$password = $_POST['password'];
	
	$username = trim($username);
	$password = trim($password);
	
	$res=mysqli_query($con,"SELECT applicant_id,applicant_detail_username, applicant_detail_password FROM applicant_detail WHERE applicant_detail_username='$username'");
	//echo"$res";
	$row=mysqli_fetch_array($res);
	
	$count = mysqli_num_rows($res); // if uname/pass correct it returns must be 1 row
   //echo"$count";
   $appli_pass=$row['applicant_detail_password'];
   //echo"$appli_pass";
	if($count == 1 && $appli_pass==$password)
	{
		$_SESSION['user_id'] = $row['applicant_id'];
		 //alert('success');
		echo"<script>
                         window.location.href='property_value.php';
                        </script>";
		
		//header("Location: property_value.php");
	}
	else
	{
		?>
        <script>alert('Username / Password Seems Wrong !');</script>
        <?php
	}
	
}
?>
   
   
   
	<section class="slice bg-white">
        <div class="wp-section">
            <div class="container">
                <div class="row">
                    <div class="col-md-4 col-md-offset-4 col-sm-6 col-sm-offset-3">
                        <div class="wp-block default user-form"> 
                            <div class="form-header">
                                <h2>Sign in to check property summary</h2>
                            </div>
                            <div class="form-body ui-content" data-role="main">
                                <form action="" id="frmLogin" class="sky-form" method="POST">                                    
                                    <fieldset>                  
                                        <section>
                                            <div class="form-group">
                                                <label class="label">Username</label>
                                                <label class="input">
                                                    <i class="icon-append fa fa-user"></i>
                                                    <input type="text" name="username">
                                                </label>
                                            </div>     
                                        </section>
                                        <section>
                                            <div class="form-group">
                                                <label class="label">Password</label>
												<strong>Password Example( 0000-00-00 )</strong>
                                                <label class="input">
                                                    <i class="icon-append fa fa-lock"></i>
                                                    <input type="password" name="password" placeholder="Enter Password">
                                                </label>
                                            </div>     
                                        </section> 
                                        

                                        <section>
                                <button class="btn btn-base btn-icon btn-icon-right btn-sign-in pull-right" type="submit" name="btn-login">
                                                <span>Sign in</span>
                                            </button>
                                        </section>
                                    </fieldset>  
                                </form>    
                            </div>
                            <div class="form-footer">
                                <p>Lost your password? <a href="forget_password.php">Click here to recover.</a></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
	
    <?php include"footer.php"; ?>

</body>
</html>
