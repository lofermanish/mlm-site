 <!-- FOOTER -->
    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <div class="col">
                       <h4>Contact us</h4>
					   <hr>
                       <ul>
                            <li><p class="no-margin">Pal Plaza, IInd Floor, KBC-15, Sector B, Barabirwa, LDA Colony,
 	Near Phoenix Mall, Kanpur road, Lucknow.</p></li>
                            <li><p class="no-margin">Phone: 0522-6888-844</p></li>
                            <li>Email: <a href="info@pssbuilders.com" title="Email Us">info@pssbuilders.com</a></li>
                            <li>Website: <a href="http://www.pssbuilders.com/" title="Website">www.pssbuilders.com</a></li>
                        </ul>
                     </div>
                </div>
                
                <div class="col-md-3">
                    <div class="col">
                        <h4>Useful Links</h4>
						<hr>
                       <ul>
							<li><a href="picture-gallery.php">Picture Gallery</a></li>
							<li><a href="defence-inclave.php">Defence Inclave</a></li>
							<li><a href="shagun-city.php">Shagun City</a></li>
							<li><a href="login.php">Login</a></li>
							<li><a href="jobs.php">Jobs</a></li>
							<li><a href="index.php">Home</a></li>
							
                        </ul>
                    </div>
                </div>
                
                <div class="col-md-3">
                    <div class="col col-social-icons">
                        <h4>Follow us</h4>
						<hr>
                        <a href=""><i class="fa fa-facebook"></i></a>
                        <a href=""><i class="fa fa-google-plus"></i></a>
                        <a href=""><i class="fa fa-linkedin"></i></a>
                        <a href=""><i class="fa fa-twitter"></i></a>
                        <a href=""><i class="fa fa-skype"></i></a>
                        <a href=""><i class="fa fa-pinterest"></i></a>
                        <a href=""><i class="fa fa-youtube-play"></i></a>
                        <a href=""><i class="fa fa-flickr"></i></a>
                    </div>
                </div>

                 <div class="col-md-3">
                    <div class="col">
                        <h4>About us</h4>
						<hr>
                        <p class="no-margin">
                       Gone are the days when people used to deal property matters on the basis of "mouth to mouth publicity" or nearby dealers. 
                        <br><br>
                        
                        </p>
                    </div>
                </div>
            </div>
            
            <hr>
            
            <div class="row">
                <div class="col-lg-9 copyright">
                    
                </div>
                <div class="col-lg-3">
                    <a href="http://www.jsminfotech.com/" title="Made with love by Web Pixels" target="_blank" class="">
                         <span class="pull-right" style="float: right; font-family:bauserif; font-size:11px;">Developed and Designed By - Jsm InfoTech Pvt. Ltd.</span>
                    </a>
                </div>
            </div>
        </div>
    </footer>