<html class="js no-touch cssanimations csstransitions" id="ls-global"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="index, follow">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <!-- Essential styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css"> 
      <link rel="stylesheet" href="css/jquery.fancybox.css?v=2.1.5" media="screen"> 
     
    <!-- Boomerang styles -->
        <link id="wpStylesheet" type="text/css" href="css/global-style.css" rel="stylesheet" media="screen">
    <!-- Assets -->
    <link rel="stylesheet" href="css/owl.carousel.css">
    <link rel="stylesheet" href="css/owl.theme.css">
    <link rel="stylesheet" href="css/sky-forms.css">    
    <!--[if lt IE 9]>
        <link rel="stylesheet" href="assets/sky-forms/css/sky-forms-ie8.css">
    <![endif]-->

<script src="js/jquery.js"></script>
    <script src="js/jquery-ui.min.js"></script>

    <!-- Page scripts -->
    <link rel="stylesheet" href="css/layerslider.css" type="text/css">

<link rel="stylesheet" href="css/skin.css" type="text/css">
<style type="text/css">
	.fancybox-margin
	{
	margin-right:17px;
	}
	</style>
<!-- Essentials -->
<script src="js/modernizr.custom.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.mousewheel-3.0.6.pack.js"></script>
<script src="js/jquery.easing.js"></script>
<script src="js/jquery.metadata.js"></script>
<script src="js/jquery.hoverup.js"></script>
<script src="js/jquery.hoverdir.js"></script>
<script src="js/jquery.stellar.js"></script>

<!-- Boomerang mobile nav - Optional  -->
<script src="js/jquery.dlmenu.js"></script>
<script src="js/jquery.dlmenu.autofill.js"></script>

<!-- Forms -->
<script src="js/jquery.powerful-placeholder.min.js"></script> 
<script src="js/cusel.min.js"></script>
<script src="js/jquery.form.min.js"></script>
<script src="js/jquery.validate.min.js"></script>
<script src="js/jquery.maskedinput.min.js"></script>
<script src="js/jquery.modal.js"></script>

<!-- Assets -->
<script src="js/bootstrap-hover-dropdown.min.js"></script>
<script src="js/jquery.ui.totop.min.js"></script>
<script src="js/jquery.mixitup.js"></script>
<script src="js/jquery.mixitup.init.js"></script>
<script src="js/jquery.fancybox.pack.js"></script>
<script src="js/waypoints.min.js"></script>
<script src="js/jquery.countTo.js"></script>
<script src="js/jquery.easypiechart.js"></script>
<script src="js/rrssb.min.js"></script>
<script src="js/jquery.nouislider.min.js"></script>
<script src="js/owl.carousel.js"></script>
<script src="js/tooltip.js"></script>
<script src="js/popover.js"></script>




<script src="js/wp.app.js"></script>

<script src="js/jquery.cookie.js"></script>
<script src="js/wp.switcher.js"></script>
<script type="text/javascript" src="js/wp.ga.js"></script>
