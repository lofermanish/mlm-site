
    <link href="css/site.css" rel="stylesheet" type="text/css" />
	<script src="js/jquery.bootstrap.newsbox.min.js" type="text/javascript"></script>
<!-- MAIN CONTENT -->
     <section class="slice p-15 base">
        <div class="cta-wr">
            <div class="container">
                <div class="row">
                    <div class="col-md-8">
                        
                    </div>
                    <div class="col-md-4">
                      
                    </div>
                </div>
            </div>
        </div>
    </section>


    <section class="slice light-gray bb">
        <div class="wp-section">
            <div class="container">
                <div class="row">
                    <div class="col-md-7">
                        <div class="section-title-wr">
                            <h1 class="left">
                                Welcome to Pss Builder
								<hr>
                            </h1>
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <img src="images/slider-1.png" alt="" class="img-responsive img-thumbnail">
                            </div>
                            <div class="col-md-8">
                                <p>
                                India's upcoimg leading property site with thousands of properties for sale and rent in many cities across India. More than 1,0000 visitors from over all countries search our site every month/year for their residential and commercial real estate needs.  
                                <br>
                               To sow the seeds of par-excellence services with customer centric approach and reap the trust of worldwide clients.
                                </p>
                            </div>
                        </div>
                        <blockquote class="blockquote-1">
                            <p>Properties of more categories like flats and apartments are listed or advertised and allow to search, buy, rent or take on lease. Property owners list their properties for sale or rent; developers and builders list to advertise their projects to a global audience; real estate consultants and brokers list properties to expand their market place.</p>
                            
                        </blockquote>
                    </div>
                    <div class="col-md-5">
                      
<div class="row">
    <div class="left-news">
        <div class="panel panel-default" >
            <div class="panel-heading panel-heading-left"><span>Latest News</apan><i class="fa fa-arrow-circle-right"></i>
			</div>
<marquee behavior="SCROLL" direction="up" onmouseout="this.start();" onmouseover="this.stop();" style="border-width:0px;border-style:solid;max-height:350px;overflow: auto;">
	 <div class="panel-body">
						

								
										<table cellpadding="4">
				<?php
				$res = $conn->get_admin_news($con);
				 while ($row = mysqli_fetch_array($res)) {
				 $news_id=$row['news_id'];
				 //echo"$news_id";
				 ?>
				 			              <tr>
    <td>
	<strong><?php echo $row['news_title']; ?> </strong>
	<hr>
	</td>
												
										  </tr>
											<tr>
    <td>
	<img src="<?php echo $row['news_image']; ?>" width="60" class="img-circle" />   <?php echo $row['news_description']; ?>    <a href="<?php echo $row['news_link']; ?>">Read more..</a>  [<?php echo $row['news_date']; ?>] <br>
	----------------------------------------------------------------------------------------------
	</td>	
											</tr>
				 <?php } ?>
										</table>
									
            </div>
	</marquee>
           
        </div>
    </div>
</div>

                   

<a href="images/pssbuilders.apk" download><img src="images/main.gif" style="width:150px;height:60px;"></a>	<li class="fa fa-hand-o-left"></li> Download Our Mobile App



				   
                        
                    </div>
                </div>
            </div>
        </div>    
    </section>

   
    <section class="slice light-gray">
        <div class="wp-section">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        
                        <div id="carouselTestimonial" class="carousel carousel-testimonials slide" data-ride="carousel">
                            <!-- Indicators -->
                            <ol class="carousel-indicators">
                                <li data-target="#carouselTestimonial" data-slide-to="0" class=""></li>
                                <li data-target="#carouselTestimonial" data-slide-to="1" class="active"></li>
                                <li data-target="#carouselTestimonial" data-slide-to="2" class=""></li>
                            </ol>

                            <!-- Wrapper for slides -->
                            <div class="carousel-inner">
                                <div class="item">
                                    <div class="text-center">
                                        <h4><i class="fa fa-quote-left fa-3x"></i></h4>
                                        <p class="testimonial-text">
                                        Properties of more categories like flats and apartments are listed or advertised and allow to search, buy, rent or take on lease. Property owners list their properties for sale or rent; developers and builders list to advertise their projects to a global audience; real estate consultants and brokers list properties to expand their market place.
                                        </p>
                                        <p>
                                            John Doe – Company Inc
                                        </p>
                                        <span class="clearfix"></span>
                                    </div>
                                </div>
                                <div class="item active">
                                    <div class="text-center">
                                        <h4><i class="fa fa-quote-left fa-3x"></i></h4>
                                        <p class="testimonial-text">
                                        India's upcoimg leading property site with thousands of properties for sale and rent in many cities across India. More than 1,0000 visitors from over all countries search our site every month/year for their residential and commercial real estate needs.
                                        </p>
                                        <p>
                                            John Doe – Company Inc
                                        </p>
                                        <span class="clearfix"></span>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="text-center">
                                        <h4><i class="fa fa-quote-left fa-3x"></i></h4>
                                        <p class="testimonial-text">
                                        Gone are the days when people used to deal property matters on the basis of "mouth to mouth publicity" or nearby dealers. Globalization and fast lifestyle has encouraged the real estate industry to step in E-World. Now active partakers of real estate world are eagerly seeking the right options to establish themselves in E-Real Estate World. 

                                        </p>
                                        <p>
                                            John Doe – Company Inc
                                        </p>
                                        <span class="clearfix"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
	
	<script type="text/javascript">
    $(function () {
        $(".demo1").bootstrapNews({
            newsPerPage: 5,
            autoplay: true,
			pauseOnHover:true,
            direction: 'up',
            newsTickerInterval: 4000,
            onToDo: function () {
                //console.log(this);
            }
        });
		
		$(".demo2").bootstrapNews({
            newsPerPage: 4,
            autoplay: true,
			pauseOnHover: true,
			navigation: false,
            direction: 'down',
            newsTickerInterval: 2500,
            onToDo: function () {
                //console.log(this);
            }
        });

        $("#demo3").bootstrapNews({
            newsPerPage: 3,
            autoplay: false,
            
            onToDo: function () {
                //console.log(this);
            }
        });
    });
</script>