<?php
@$conn=mysql_connect("localhost", "root", "", "pss_builder") or die("Could not connect");
@mysql_select_db("pssbuild_newpss",$conn) or die("could not connect database");
?>

