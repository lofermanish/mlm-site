  <link rel="stylesheet" href="css/bootstrap.min.css">
  <script type="text/javascript" src="js/jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.10.4.custom.min.js"></script>
<script>
   function item_detail(bv_id){
alert('welcome icon');
        $("#pop").load('get_data.php', {"item_id": b_id});
		
    }
	
</script>
  <?php
                    session_start();
                    include_once 'property/pss_db.php';
                    $conn = new DB_con();
                    $con = $conn->connection();
                    $functions = new functions();
                    ?> 
	<?php
				if(isset($_POST['verify']))
				{
					    
                        $code = $_POST['code'];
						//$code1 = $_POST['code1'];
                        
$res = $conn->verify_bv($con,$code);
$count=mysqli_num_rows($res);
//$row =mysqli_fetch_assoc($res);

				if($count>0)
				{
				$row =mysqli_fetch_assoc($res);
			if(($row['bv_code_use']==0)&&($_SESSION['code']=$row['bv_code_number'])&& ($_SESSION['code1']=$row['bv_code_value']))
	{		

?>
<script type="text/javascript">
       alert("Verified");
          window.location.href = "distributor_reg_form.php?v=<?php echo base64_encode($row['bv_code_value']);?>&c=<?php echo $code;?>";
         </script><?php

				
			}
			else
{?>
	<script>
	alert("Already Used!!");
	</script>
<?php

}
				

		




				}


else{
	?><script>
	
	alert("Please Enter the Correct BV Code");</script><?php
}				}?>
	 
 
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body style="background-color:#2980B9;">
 
<div class="container"  style="padding-top:100px;">
  <div class="col-sm-3"></div><div class="col-sm-6">
  <div class="panel panel-info">
    <div class="panel-heading"><strong><center>Verify Your BV Code</center></strong></div>
    <div class="panel-body">
     


        
      <form method="POST">
	  
  <form method="POST" action="distributor_reg_form.php">
				
                <div class="col-md-12" align="center"><input type="text" class="form-control" placeholder="Enter Your Secret BV Code" name="code"  required="required"><br></div>
<a href="distributor_pre_reg_form.php">Dont have a BV Code Register Here</a>
	
	                   <p align="center"> <input type="submit" class="btn btn-info" name="verify" value="verify"></P> 

      </form>

</div</div>
  </div>
</div>
</div>
</body>
 
 



