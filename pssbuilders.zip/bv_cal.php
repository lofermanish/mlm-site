







<?php
				 
         $reward_type=$_REQUEST['reward_type'];
		 
		  if($reward_type=="reward" || $reward_type=="pair income" || $reward_type=="bonanza"){
            $payment_type=$reward_type;
            
        ?>
				 
        <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/r/bs-3.3.5/jq-2.1.4,dt-1.10.8/datatables.min.css"/>
 
		<!--<script type="text/javascript" src="https://cdn.datatables.net/r/bs-3.3.5/jqc-1.11.3,dt-1.10.8/datatables.min.js"></script>-->
		<script type="text/javascript" charset="utf-8">
			$(document).ready(function() {
				$('.example').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print','pageLength'
        ]
    },
           {
        dom: 'Bfrtip',
        lengthMenu: [
            [ 10, 25, 50, -1 ],
            [ '10 rows', '25 rows', '50 rows', 'Show all' ]
        ]
    } 
                );
			} );
		</script>
                <script type="text/javascript">
	// For demo to fit into DataTables site builder...
	$('.example')
		.removeClass( 'display' )
		.addClass('table table-striped table-bordered');
</script>

<br><br><br><br>
        
                
<div class="col-sm-12">     <table class="table table-bordered display example" id="example"><thead>  <tr>
                                       <th>S.No.</th>
                                                  <th>Name</th>
                                                  <th>Company Id</th>
                                                  <th>Total Left B V</th>
                                                  <th>Total Right B V</th>
												<?php if($payment_type=="pair income" ){ ?> <th>Remaining Reward Amount</th><th>10%</th><th>5%</th><th>Payable Amount</th> <?php } ?>
                                              <?php if($payment_type=="reward" || $payment_type=="bonanza" ){ ?>    
   											     <th>Reward Commodity</th> 
                                                  <th>Reward Amount</th> <?php } ?>
												  <th>Position</th>
												  <th>Pay</th> 
                                      </tr></thead>
									  
       
                               <tr>
                                          <td>
                                              <?php echo ++$jj; ?>
                                          </td>
                                          <td>
                                              <?php echo $row['distributor_name']; ?>
                                          </td>
                                          <td>
                                              <?php echo $row['distributor_company_id']; ?>
                                          </td>
                                          <td>
                                              <?php echo $count_left_bv; ?>
                                          </td>
                                          <td>
                                              <?php echo $count_right_bv; ?>
                                          </td>
										 <?php if($count_left_bv<$count_right_bv){
											  
											  ?>
                                              <?php  $bv=$count_left_bv; ?>
                                          <?php
										  }
										  else{
											   ?>
                                              <?php $bv=$count_right_bv; ?>
                                          <?php
		}
										  ?>
                                       										  <?php 
										  
									$paid_res=$conn->get_admin_paid_reward12($con,$payment_type,$bv);
        
									$paid_row=mysqli_fetch_array($paid_res);
		?>
		
	 
										  
                                         
										  
                                       <?php if($payment_type=="reward" || $payment_type=="bonanza"){ ?>   <td>
                                              <?php echo $commodity=$paid_row['payment_type_commodity']; ?>
                                       <?php }?></td> 
                                          <td>
                                              <?php if($payment_type=="reward" || $payment_type=="bonanza"){echo $paid_row['payment_type_price'];} else { echo $small*$row_reward['payment_type_price']; } ?>
                                          </td>
										  
										 <td>
										 <?php echo $paid_row['payment_type_position']; ?>
										 
										 </td>
										  <td>
										   <?php if($commodity==""){
											   echo "";
										   }else{?>
										  <a href="money_dispatched.php" class="btn btn-success">Pay</a><?php } ?>
										  </td>
                                      </tr>
                     
                              
                              
                           
	  </table>
    
    
    </body>
</html>




<?php

}?>