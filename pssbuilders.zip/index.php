<!DOCTYPE html>
<html lang="en">
<head>
  <title>PSS Builder || Home</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php include"script-css.php"; ?>
<script type="text/javascript">
	$(document).ready(function(){
		$("#myModal").modal('show');
	});
</script>
</head>
<body>

	<?php include"menu.php"; ?>
    <?php include"slider.php"; ?>
    <?php include"main-body.php"; ?>
    <?php include"footer.php"; ?>
	
	
	

<div id="myModal" class="modal fade">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h4 class="modal-title">Register for exclusive pre-launch offers</h4>
            </div>
			<?php
				if(isset($_POST['upload_details']))
				{
					    
                        $property_enquiry_name = $_POST['name'];
                        $property_enquiry_phone = $_POST['phone'];
						$property_enquiry_email = $_POST['email'];
                        $property_enquiry_city = $_POST['city'];
                        $property_enquiry_min_price = $_POST['max_rang'];
					    $property_enquiry_max_price = $_POST['min_rang'];
	$res = $conn->insert_website_loading_page_enquiry($con, $property_enquiry_name, $property_enquiry_phone, $property_enquiry_email, $property_enquiry_city, $property_enquiry_min_price, $property_enquiry_max_price, $date_time);
	
	if($res)
	    {
		?>
		
		<div class="alert alert-success">
			<strong>Your Details Send Successfully</strong>
        </div>
		
		<?php
		}
		else
		{
	   ?>
	   <div class="alert alert-danger">
            <strong>Your Details Not Send</strong>
       </div>
		<?php	
		}
				}
				?>
            <div class="modal-body">
                <form method="POST">
				<div class="col-md-4"><strong>Name</strong></div>
                <div class="col-md-8"><input type="text" class="form-control" placeholder="Enter Your Name" name="name" required="required"><br></div>
				<div class="col-md-4"><strong>Phone</strong></div>
                <div class="col-md-8"><input type="text" class="form-control" placeholder="Enter Your Phone" name="phone" required="required"><br></div>
				<div class="col-md-4"><strong>Email</strong></div>
                <div class="col-md-8"><input type="email" class="form-control" placeholder="Enter Your Email" name="email" required="required"><br></div>
				<div class="col-md-4"><strong>City</strong></div>
                <div class="col-md-8"><input type="text" class="form-control" placeholder="Enter Your City" name="city" required="required"><br></div>
				<div class="col-md-4"><strong>Price Rang</strong></div>
                <div class="col-md-8">
				
		<div class="col-md-5"><select name="max_rang" required class="form-control">
          <option value="0">Min</option>
         <option value="499999">Below 5 Lacs</option>
		 <option value="500000">5 Lacs</option>
           <option value="1000000">10 Lacs</option>
            <option value="1500000">15 Lacs</option>
             <option value="2000000">20 Lacs</option>
              <option value="2500000">25 Lacs</option>
               <option value="3000000">30 Lacs</option>
               <option value="3000001">Above 30Lacs</option>

        </select></div>
		<div class="col-md-2">To</div>
		<div class="col-md-5"><select name="min_rang" required class="form-control">
         <option value="0">Max</option>
          <option value="499999">Below 5 Lacs</option>
          <option value="500000">5 Lacs</option>
           <option value="1000000">10 Lacs</option>
            <option value="1500000">15 Lacs</option>
             <option value="2000000">20 Lacs</option>
              <option value="2500000">25 Lacs</option>
               <option value="3000000">30 Lacs</option>
               <option value="3000001">Above 30Lacs</option>
        </select></div>
		<br><br>
		</div>
				<br>
                   <p align="center"> <button type="submit" class="btn btn-danger" name="upload_details"><span>I am Interested</span></button></P> 
                </form>
            </div>
        </div>
    </div>
</div>

	
			
</div>

</body>
</html>
