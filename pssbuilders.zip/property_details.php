<!DOCTYPE html>
<html lang="en">
<head>
  <title>PSS Builder || Home</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php include"script-css.php"; ?>
  <style>
  a:hover
  {
    color: white !important;
  }
  </style>
</head>
<body>
	<?php include"menu.php"; ?>
	 <div class="pg-opt"  style="background-color:#3ba0ff;">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h2 style="color:white !important;">Customer Zone</h2>
                </div>
                <div class="col-md-6">
                    <ol class="breadcrumb">
                        <li><a href="index.php">Home</a></li>
                        <li style="color:white !important;" class="active">Customer Zone</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
   
	<section class="slice bg-white">
        <div class="wp-section">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-sm-12">
                        <div class="wp-block default user-form"> 
                            <table class="table table-bordered">
    <thead>
      <tr>
        <th>S.No.</th>
        <th>Id</th>
        <th>Name</th>
		<th>Paid Amount</th>
		<th>Current Amount</th>
		<th>Date</th>
        <th>Received/No Received</th>
        <th>Print Recipt</th>
		</tr>
		
    </thead>
    <tbody>
      <tr>
        <td><strong>1</strong></td>
        <td>Ps111</td>
		<td>Raju Kumar</td>
		<td>1222</td>
        <td>34534</td>
		<td>2016-02-04 18:05:04</td>
        <td>Received</td>
        <td><button class="btn btn-danger fa-lg fa fa-print">  Print</button></td>
      </tr>
    </tbody>
  </table>
 
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
	
    <?php include"footer.php"; ?>

</body>
</html>
