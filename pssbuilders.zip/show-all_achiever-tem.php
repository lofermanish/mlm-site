
  <style>
  a:hover
  {
    color: white !important;
  }
  .imgsize
  {
   height:500px;
   width:500px;
  }
  </style>

<?php
if(isset($_REQUEST['achiever_type']))
{
$achiever_type=$_REQUEST['achiever_type'];
//echo"$achiever_type";
@include_once 'property/pss_db.php';
@$conn = new DB_con();
@$con = $conn->connection();
									 
				 ?>
     	<!-- Code -->
                    	<div class="wp-example">
                            <div class="row mt-20">
							
						<?php
				$res = $conn->get_website_achiever_team_details($con,$achiever_type);
				while ($row = mysqli_fetch_array($res)) {
				$achiever_team_name=$row['achiever_team_id'];
				//echo"$achiever_team_name";
				 ?>
                            <div class="col-md-6">
								<div class="widget">
						    <ul class="categories">
							    <li>
                                    <div class="section-title-wr">
<h3 class="section-title" style="margin-top:10px;text-align:center;"><span><?php echo $row['achiever_team_name']; ?></span><hr></h3>
<div class="section-title-wr" style="text-align:center;"><img src="<?php echo $row['achiever_team_image']; ?>"></div>
<hr>
                                    </div>
                                    <p>
    <?php echo $row['achiever_team_description']; ?>
                                    </p>
								</li>
                            </ul>
					            </div>
                            </div>
				 <?php } ?>
				 
                       
				
   
	
	           
                                               
				

                            </div>
                            

                        </div>  

<?php
}
?>
