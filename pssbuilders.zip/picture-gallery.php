<!DOCTYPE html>
<html lang="en">
<head>
  <title>PSS Builder || Home</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php include"script-css.php"; ?>
  <link rel="stylesheet" href="css/bootstrap-override.css">
 <link rel="stylesheet" href="css/blueimp-gallery.min.css">
 <link rel="stylesheet" href="css/bootstrap-image-gallery.min.css">
  <style>
  a:hover
  {
    color: white !important;
  }
  .imgsize
  {
   height:180px;
   width:220px;
  }
  </style>
<script>

   function pic_detail(img_date){
        //alert(img_date);
		//var user = $("#position").val();
        $("#hello").load('picture_gallery_details.php', {"picture_date": img_date});
    }

</script>
</head>
<body>
	<?php include"menu.php"; ?>
	 <div class="pg-opt"  style="background-color:#3ba0ff;">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h2 style="color:white !important;">Picture Gallery</h2>
                </div>
                <div class="col-md-6">
                    <ol class="breadcrumb">
                        <li><a href="index.php">Home</a></li>
                        <li style="color:white !important;" class="active">Picture Gallery</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
	

<section class="slice light-gray bb">
        <div class="wp-section">
            <div class="container">
                <div class="row" id="hello">
				<?php
				 $res = $conn->get_website_gallery($con);
				 while ($row = mysqli_fetch_array($res)) {
				 $picture_date= $row['image_details_date'];
				 ?>
				         <div class="col-lg-3 col-md-3">
                         <div class="wp-block hero">
						 <section class="panel panel-default">
                         <div class="thmb-img" >
                         <a href="#" onclick="pic_detail('<?php echo $picture_date; ?>')">
						 <div style="color:#3ba0ff; font-size:18px;"><?php echo $row['image_details_title']; ?></div>
						 <hr>
						 <img src="<?php echo $row['image_details_path']; ?>" class="imgsize"></a>
						 <hr>
						 <div style="color:black; font-size:12px;"><?php echo $row['image_details_address'];?> </div>						 
                </div> 
				
</section>

                             </div>
							
                             </div>
				 <?php }?>
				 </div>
				  
			</div>
		</div>
</div>
			
</section>
<script type="text/javascript" src="js/jquery.blueimp-gallery.min.js"></script>
<script type="text/javascript" src="js/bootstrap-image-gallery.min.js"></script>
<div class="offline-ui offline-ui-up"><div class="offline-ui-content"></div><a href="" class="offline-ui-retry"></a></div>

    <?php include"footer.php"; ?>

</body>
</html>
<div style="border: thin double #C0C0C0; float: right; height: 161px; width: 211px;" class="w_divborder" align="left">
<div class="block width2" align="left">
News					
<marquee id="m1" behavior="SCROLL" direction="up" onmouseout="this.start();" 
onmouseover="this.stop();" scrollamount="1" scrolldelay="80" scrollspeed="5" >

</div></marquee>
					</div>
