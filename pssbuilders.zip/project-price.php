<header class="navbar main-header" style="background-color:#3ba0ff;">
     <script src="js/jquery.blockUI.min.js" ></script>  
     <link rel="stylesheet" href="css/spinner.css">
    <a class="navbar-brand" href="">
        <span style="font-size:17px;">Pss Builders&nbsp;</span></div>
    </a>
    <ul class="nav navbar-nav navbar-left sidebar-toggle-ul">
        <li class="navbar-main hidden-lg hidden-md">
            <a href="javascript:void(0);" id="sidebar-toggle">
                <span class="meta">
                    <span class="arrow"><i class="arrow fa fa-angle-right pull-right"></i></span>
                </span>
            </a>
        </li>

        <li class="navbar-main hidden-sm hidden-xs">
            <a href="javascript:void(0);" id="sidebar-collapse">
                <span class="meta">
                    <span class="icon"><i class="fa fa-outdent" style="color:blue;"></i></span>
                </span>
            </a>
        </li>
    </ul>
<?php
	        $id=$_SESSION['user'];
            $name=$conn->get_admin_login_name($con,$id);
            $res=$conn->get_admin_distributor_detail_by_cmpny_id($con,$name);
            $row=  mysqli_fetch_array($res);
            $dis_name=$row['distributor_name'];
            $image_path=$row['distributor_image_path'];
            if($image_path=="../image_uploads/" || $image_path==""){
                $image_path="images/avatar.png";
            }
            ?>
    <ul class="nav navbar-nav navbar-right">
        <li class="dropdown icons-dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><span style="color:blue;">Company Id : <?php echo $name ?></span></a>
<!--            <ul class="dropdown-menu list-group">
                <li class="list-group-item heading"><p>Notification</p></li>
                <a href="http://flatter.cloudtub.com/index.html#" class="list-group-item"><i class="fa fa-user"></i> <p>John sent you friend request</p></a>
                <a href="http://flatter.cloudtub.com/index.html#" class="list-group-item"><i class="fa fa-envelope-o"></i> <p>Sam sent important mail</p></a>
                <a href="http://flatter.cloudtub.com/index.html#" class="list-group-item"><i class="fa fa-calendar"></i> <p>You have pending job</p></a>
                <a href="http://flatter.cloudtub.com/index.html#" class="list-group-item"><i class="fa fa-money"></i> <p>Received $1826 from client</p></a>

            </ul>-->
        </li>
            

        <li class="dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><span  style="color:blue;"><?php echo "$dis_name" ?></span> <img class="img-circle" src="<?php echo $image_path; ?>" alt="avatar"> <b class="caret"></b></a>
            <ul class="dropdown-menu">
<!--                <li><a href="http://flatter.cloudtub.com/index.html#"><i class="fa fa-globe" ></i> Notification <span class="label label-danger"> 5</span></a></li>
                <li><a href="http://flatter.cloudtub.com/index.html#"><i class="fa fa-user"></i> Profile</a></li>
                <li><a href="http://flatter.cloudtub.com/index.html#"><i class="fa fa-gear"></i> Settings</a></li>-->
                <li><a href="logout.php?logout"><i class="fa fa-share"></i> Logout</a></li>
            </ul>
        </li>
    </ul>
</header>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>PSS Builder || Home</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php include"script-css.php"; ?>
  <style>
  a:hover
  {
    color: white !important;
  }
  </style>
</head>
<body>
	<?php include"menu.php"; ?>
	 <div class="pg-opt"  style="background-color:#3ba0ff;">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h2 style="color:white !important;">Customer Zone</h2>
                </div>
                <div class="col-md-6">
                    <ol class="breadcrumb">
                        <li><a href="index.php">Home</a></li>
                        <li style="color:white !important;" class="active">Customer Zone</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
   
	<section class="slice bg-white">
        <div class="wp-section">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-sm-12">
                        <div class="wp-block default user-form">
					
                            <table class="table table-bordered">
    <thead>
      <tr>                              <th>S.No.</th>
                                        <th>Plot No.</th>
										<th>Plot Name</th>
										<th>Plot Length</th>
										<th>Plot Breadth</th>
										<th>Area</th>
										<th>Corner</th>
					
										<th>Plot Availability</th>
		</tr>
		
    </thead>
    <tbody>
      				<?php
				 
                    include_once 'property/pss_db.php';
                    $conn = new DB_con();
                    $con = $conn->connection();
                    $functions = new functions();
                    
				 $count=0;
				 $res = $conn->get_admin_get_admin_plot_details($con);
				 while ($row = mysqli_fetch_array($res)) {
				 $plot_price_details_id=$row['plot_price_details_id'];
				 $count=$count+1;
				 ?>
	<tr class="1">
	<td><?php echo $count; ?></td>
	<td><?php echo $row['plot_price_details_plot_no']; ?></td>
	<td><?php echo $row['plot_price_details_name']; ?></td>
	<td><?php echo $row['plot_price_details_height']; ?></td>
	<td><?php echo $row['plot_price_details_width']; ?></td>
	<?php $area=$row['plot_price_details_height']*$row['plot_price_details_width']; ?>
	<td><?php echo $area; //echo $row['plot_price_details_amount']; ?></td>
	<td></td>
	<td><?php echo $row['plot_price_details_plot_availability']; ?></td>
	
	</tr>
				<?php }?>
    </tbody>
  </table>
 
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
	
    <?php include"footer.php"; ?>

</body>
</html>
