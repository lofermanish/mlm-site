<?php
error_reporting(0);
define("SMTP_HOST", "mail.pssbuilders.com"); //Hostname of the mail server
define("SMTP_PORT", "25"); //Port of the SMTP like to be 25, 80, 465 or 587
define("SMTP_UNAME", "pssbuild"); //Username for SMTP authentication any valid email created in your domain
define("SMTP_PWORD", "381MIjpjr3"); //Password for SMTP authentication
?>