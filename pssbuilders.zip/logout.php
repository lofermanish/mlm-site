<?php
session_start();

if(!isset($_SESSION['user_id']))
{
	header("Location: customer-zone.php");
}
else if(isset($_SESSION['user_id'])!="")
{
	header("Location: dashboard.php");
}

if(isset($_GET['logout']))
{
	session_destroy();
	unset($_SESSION['user_id']);
	header("Location: customer-zone.php");
}
?>