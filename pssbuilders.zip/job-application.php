<?php
if(isset($_REQUEST['id']))
{
	?>
<fieldset class="no-padding">           
<section class="no-margin">
                                            <div class="row">
                                                <div class="col-xs-6">
                                                    <div class="form-group">
                                                        <label class="label">Name</label>
                                                        <label class="input">
                                                            <i class="icon-append fa fa-user"></i>
                                                            <input type="text" name="name" placeholder="">
                                                            <b class="tooltip tooltip-bottom-right">Needed to enter the Name</b>
                                                        </label>
                                                    </div>               
                                                </div>
                                                <div class="col-xs-6">
                                                    <div class="form-group">
                                                        <div class="form-group">
                                                            <label class="label">E-mail</label>
                                                            <label class="input">
                                                                <i class="icon-append fa fa-envelope-o"></i>
                                                                <input type="email" name="email" placeholder="">
                                                                <b class="tooltip tooltip-bottom-right">Needed to enter the E-mail</b>
                                                            </label>
                                                        </div>  
                                                    </div>               
                                                </div>
                                            </div> 
											 <div class="row">
                                                <div class="col-xs-6">
                                                    <div class="form-group">
                                                        <label class="label">Phone</label>
                                                        <label class="input">
                                                            <i class="icon-append fa fa-phone"></i>
                                                            <input type="text" name="phone" placeholder="">
                                                            <b class="tooltip tooltip-bottom-right">Needed to enter the Phone</b>
                                                        </label>
                                                    </div>               
                                                </div>
                                                <div class="col-xs-6">
                                                    <div class="form-group">
                                                        <div class="form-group">
                                                            <label class="label">Qualification</label>
                                                            <label class="input">
                                                                <i class="icon-append fa fa-comment-o"></i>
                                                                <input type="text" name="Qualification" placeholder="">
                                                                <b class="tooltip tooltip-bottom-right">Needed to enter the Qualification</b>
                                                            </label>
                                                        </div>  
                                                    </div>               
                                                </div>
                                            </div> 
                                           <div class="row">
                                                <div class="col-xs-6">
                                                    <div class="form-group">
                                                        <label class="label">Address</label>
                                                        <label class="input">
                         <textarea class="form-control" placeholder="Write your address here" rows="5" name="Address"></textarea>
                                                            <b class="tooltip tooltip-bottom-right">Needed to enter the Address</b>
                                                        </label>
                                                    </div>               
                                                </div>
                                                <div class="col-xs-6">
                                                    <div class="form-group">
                                                        <div class="form-group">
                                                            <label class="label">Upload Resume</label>
                                                            <label class="input">
                                                                <input type="file" placeholder="" name="Resume">
                                                            </label>
                                                        </div>  
                                                    </div>               
                                                </div>
                                            </div> 
											 <div class="modal-footer">
											
	            	<button class="btn btn-base pull-right" type="submit" name="btn-upload">
					 <span class="fa fa-upload"></span>
	            		<span>Submit</span>
	            	</button>   
	            </div>
                                            
                                        </section>
                                    </fieldset>
<?php
}
?>

