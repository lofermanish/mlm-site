
<?php
include_once '../../common_Resources/establishment/dbMySql.php';
$con = new DB_con();
if(isset($_REQUEST['icon_id']))
{
$icon_id=$_REQUEST['icon_id'];
//echo"$icon_id";
$sql="SELECT * FROM fa_fa_icon WHERE fa_fa_icon_id =$icon_id'";
//echo"$sql";
$result = mysql_query($sql);
$row = mysqli_fetch_array($result)
$fa_fa_icon_name=$row['fa_fa_icon_name'];
$fa_fa_icon_class=$row['fa_fa_icon_class'];
$icon_id
echo"$fa_fa_icon_name<br>$fa_fa_icon_class<br>$fa_fa_icon_class<br>";
}
?>
