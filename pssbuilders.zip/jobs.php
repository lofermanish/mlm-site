<!DOCTYPE html>
<html lang="en">
    <head>
        <title>PSS Builder || Home</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <?php include"script-css.php"; ?>
        <style>
            a:hover
            {
                color: white !important;
            }
        </style>
        <script>

            $(document).ready(function() {
                $("#position").change(function() {
                    var user = $("#position").val();
					if(user=="")
					 {
				  $("#hello").load('job-application.php');
				    }
					else
					{
                    $("#hello").load('job-application.php', {"id": user});
					}
                });
            });
        </script>

        <style>
            .btn-file {
                position: relative;
                overflow: hidden;
            }
            .btn-file input[type=file] {
                position: absolute;
                top: 0;
                right: 0;
                min-width: 100%;
                min-height: 100%;
                font-size: 100px;
                text-align: right;
                filter: alpha(opacity=0);
                opacity: 0;
                outline: none;
                background: white;
                cursor: inherit;
                display: block;
            }	
        </style>
    </head>
    <body>
        <?php include"menu.php"; ?>
        <div class="pg-opt"  style="background-color:#3ba0ff;">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <h2 style="color:white !important;">Jobs</h2>
                    </div>
                    <div class="col-md-6">
                        <ol class="breadcrumb">
                            <li><a href="index.php">Home</a></li>
                            <li style="color:white !important;" class="active">Jobs</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>




        <section class="slice bg-white">
            <div class="wp-section">
                <div class="container">
                    <div class="row mb-40">
                        <div class="col-md-12 col-sm-12">                   
                            <div class="wp-block default user-form">

                                <div class="form-body">
                                    <form action=""class="sky-form" enctype="multipart/form-data" name="image_upload" method="POST">
                                        <?php
//                                        if($conn){
//                                            echo "hello";
//                                        }
                                        ?>			

                                        <fieldset class="no-padding">           
                                            <section class="no-margin">
                                                <div class="row">
                                                    <div class="col-xs-6">
                                                        <div class="form-group">
                                                            <label class="label">HR Number </label>
                                                            <label class="input">
                                                                <i class="icon-append fa fa-phone"></i>
                                                                <input type="text" name="hr_number" placeholder="" readonly value="0522-6888-844">

                                                            </label>
                                                        </div>               
                                                    </div>
                                                    <div class="col-xs-6">
                                                        <div class="form-group">
                                                            <label class="label">Jobs Position </label>
                                                            <label class="select">
                                                                <select name="jobs_postion" id="position">
                                                                    <option value="">Select Job Position</option>
                                                                    <?php $functions->listitem("$job_postion"); ?>

                                                                </select>

                                                                <i></i>
                                                            </label>
                                                        </div>               
                                                    </div>
                                                </div>   

                                            </section>
                                        </fieldset>

                                        <span id="hello"> </span>


                                    </form>   
                                </div>

                            </div>
                        </div>
                    </div>
                    </section>    
                    <?php include"footer.php"; ?>

                    </body>
                    </html>


                    <?php
//include_once 'db.php';

                    if (isset($_POST['btn-upload'])) {
//	echo "hello";
                        $jobs_postion = $_POST['jobs_postion'];
                        $name = $_POST['name'];
                        $email = $_POST['email'];
                        $phone = $_POST['phone'];
                        $Qualification = $_POST['Qualification'];
                        $Address = $_POST['Address'];
                        move_uploaded_file($_FILES['Resume']['tmp_name'], "Resume/" . $_FILES['Resume']['name']);
                        $file = "Resume/" . $_FILES['Resume']['name'];
//	 echo"$file";
//	echo "hello";

                        $res = $conn->insert_website_career($con, $jobs_postion, $Qualification, $file, $email, $phone, $Address, $date_time);
//	echo"$file";

                        echo $res;
                        if ($res) {
                            ?>
                            <script>
                                alert('Record inserted...');
                                window.location = 'jobs.php'
                            </script>
        <?php
    } else {
        ?>
                            <script>
                                alert('error inserting record...');
                                window.location = 'jobs.php'
                            </script>
                            <?php
                        }
                    }
                    ?>
















