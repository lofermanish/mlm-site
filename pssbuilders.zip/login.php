<!DOCTYPE html>
<html lang="en">
<head>
  <title>PSS Builder || Home</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php include"script-css.php"; ?>
  <style>
  a:hover
  {
    color: white !important;
  }
  </style>
</head>
<body>
	<?php include"menu.php"; ?>
	 <div class="pg-opt"  style="background-color:#3ba0ff;">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h2 style="color:white !important;">Sign In</h2>
                </div>
                <div class="col-md-6">
                    <ol class="breadcrumb">
                        <li><a href="index.php">Home</a></li>
                        <li style="color:white !important;" class="active">Sign In</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

 <section class="slice bg-white bb">
        <div class="wp-section">
            <div class="container">
                <div class="row">
                    <div class="col-md-4 col-sm-6">
                        
                    </div>

                    <div class="col-md-4 col-sm-6">
                        <div class="wp-block default user-form"> 
                            <div class="form-header base">
                                <h2>Sign in to your account</h2>
                            </div>
                            <div class="form-body">
                                <form action="" id="frmLogin" class="sky-form">                                    
                                    <fieldset>                  
                                        <section>
                                            <div class="form-group">
                                                <label class="label">Email</label>
                                                <label class="input">
                                                    <i class="icon-append fa fa-user"></i>
                                                    <input type="email" name="username">
                                                </label>
                                            </div>     
                                        </section>
                                        <section>
                                            <div class="form-group">
                                                <label class="label">Pass</label>
                                                <label class="input">
                                                    <i class="icon-append fa fa-lock"></i>
                                                    <input type="password" name="pass">
                                                </label>
                                            </div>     
                                        </section> 
                                        <section>
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <label class="checkbox"><input type="checkbox" name="remember"><i></i>Keep me logged in</label>
                                                </div>
                                            </div>
                                        </section>

                                        <section>
                                            <button class="btn btn-base btn-icon btn-icon-right btn-sign-in pull-right" type="submit">
                                                <span>Login</span>
                                            </button>
                                        </section>
                                    </fieldset>  
                                </form>    
                            </div>
                            <div class="form-footer base">
                                <p>Lost your password? <a href="#">Click here to recover.</a></p>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4 col-sm-6">
                       
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php include"footer.php"; ?>

</body>
</html>
